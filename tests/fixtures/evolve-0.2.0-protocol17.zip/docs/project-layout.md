# 实际工程目录

版本 0.2.0，protocol 17／schema 4。本页由当前源码和运行包清单生成。



## 独立运行包

完整运行包含 99 份运行资源及 evolve-package.json 自身。实际资源摘要以[包清单](../evolve-package.json)为准；目录可整体安装、移动并离线定位资源。以下各路径在工程中有真实文件，构建时只复制这些资源。

```text
evolve/
├── .agents/
│   └── plugins/
│       └── marketplace.json
├── .claude-plugin/
│   ├── marketplace.json
│   └── plugin.json
├── .codex-plugin/
│   └── plugin.json
├── assets/
│   └── templates/
│       ├── config.toml
│       ├── knowledge-architecture.md
│       ├── knowledge-codemap.md
│       ├── knowledge-data.md
│       ├── knowledge-decision.md
│       ├── knowledge-development.md
│       ├── knowledge-domain.md
│       ├── knowledge-project.md
│       ├── knowledge-rule.md
│       └── knowledge-spec.md
├── docs/
│   ├── architecture.md
│   ├── compatibility.md
│   ├── development.md
│   ├── installation.md
│   ├── project-layout.md
│   ├── troubleshooting.md
│   ├── usage.md
│   └── workflows.md
├── runtime/
│   ├── evolve_core/
│   │   ├── __init__.py
│   │   ├── analysis.py
│   │   ├── apply.py
│   │   ├── archive.py
│   │   ├── archive_sets.py
│   │   ├── backup.py
│   │   ├── cancellation.py
│   │   ├── checks.py
│   │   ├── cli.py
│   │   ├── config_edit.py
│   │   ├── configure.py
│   │   ├── connect.py
│   │   ├── continuation.py
│   │   ├── cross_dependencies.py
│   │   ├── data_material.py
│   │   ├── errors.py
│   │   ├── exporting.py
│   │   ├── external.py
│   │   ├── external_actions.py
│   │   ├── external_material.py
│   │   ├── external_process.py
│   │   ├── external_recovery.py
│   │   ├── external_registry.py
│   │   ├── external_work.py
│   │   ├── formal.py
│   │   ├── knowledge.py
│   │   ├── knowledge_facts.py
│   │   ├── knowledge_impact.py
│   │   ├── knowledge_proposals.py
│   │   ├── learning.py
│   │   ├── maintenance.py
│   │   ├── package.py
│   │   ├── patches.py
│   │   ├── plans.py
│   │   ├── preservation.py
│   │   ├── privacy.py
│   │   ├── project_knowledge.py
│   │   ├── protection.py
│   │   ├── reading.py
│   │   ├── recover.py
│   │   ├── requests.py
│   │   ├── resume.py
│   │   ├── revisions.py
│   │   ├── rules.py
│   │   ├── store.py
│   │   ├── structured.py
│   │   ├── verify.py
│   │   ├── work.py
│   │   └── workspace.py
│   └── evolve.py
├── shared/
│   ├── context.md
│   ├── contract.md
│   ├── data-work.md
│   ├── external-work.md
│   ├── knowledge-adoption.md
│   ├── knowledge-candidates.md
│   ├── knowledge-documents.md
│   ├── knowledge-patches.md
│   ├── knowledge-rules.md
│   ├── learning-cycle.md
│   ├── multiple-work.md
│   ├── project-knowledge.md
│   ├── protocol.md
│   ├── recovery.md
│   └── structured-plans.md
├── skills/
│   ├── evolve-apply/
│   │   └── SKILL.md
│   ├── evolve-archive/
│   │   └── SKILL.md
│   ├── evolve-init/
│   │   └── SKILL.md
│   ├── evolve-learn/
│   │   └── SKILL.md
│   ├── evolve-maintain/
│   │   └── SKILL.md
│   ├── evolve-propose/
│   │   └── SKILL.md
│   ├── evolve-verify/
│   │   └── SKILL.md
│   └── evolve-workflow/
│       └── SKILL.md
├── CHANGELOG.md
├── LICENSE
├── NOTICE.md
├── README.md
└── evolve-package.json
```

运行包保留八 Skill、单份 shared／runtime、模板、宿主与市场清单、许可／来源说明及本版本离线指南。源码 tests、开发控制器、用户数据不进入运行包。目标项目的 evolve/／.evolve-local/ 是工作资料，不放进插件目录。
