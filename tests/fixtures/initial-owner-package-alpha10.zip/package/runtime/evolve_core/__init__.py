"""Shared, host-independent Evolve runtime."""
VERSION = "0.1.0-alpha.10"
PROTOCOL_VERSION = 8
SCHEMA_VERSION = 3
DESIGN_BASELINE = "0.6.2"
