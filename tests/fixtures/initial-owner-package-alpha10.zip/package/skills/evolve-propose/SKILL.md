---
name: evolve-propose
description: 为 Evolve 工作形成短方案或复杂 spec、修订方案，或开展不修改业务的独立调查。
---

归属 propose、update、analyze。复用当前资料，区分事实、假设和未知。复杂方案给目标、边界、行为、验收和真实任务依赖；调查保存可重复症状判据、来源与限制，不凭分析请求开始修复。

保存复杂 spec／任务清单或修订既有方案时，先读[复杂规格与任务](../../shared/structured-plans.md)，整体呈现后保存完整文档；必要预重构保留前后判据及只读输入。修订先读该文档的[REV 分支](../../shared/structured-plans.md#revision)，呈现具体变化，再按实际确认登记接受。

正式文档是必需成果时，读取[正式知识交付](../../shared/knowledge-candidates.md)，在方案／Task 声明负责的 init（初次）／sync（修订）动作及实际文档 AC；正式文件经具体批准后由 owner 应用，不安排普通 apply 抢写。

即时解释：读取现场及必要的原检查，用对话说明实际事实、假设、建议和限制即完成此分支，无需构造请求材料。用户明确需要结构化校验结果时，才读取[调查请求](../../shared/protocol.md#analysis-request)的 answer_only 分支，通过标准输入提交；宿主拒绝该输入形式时，以已取得的只读观察直接答复结束。

明确留档调查时，读取[调查请求](../../shared/protocol.md#analysis-request)的 record 字段与证据要求；未接入则先最小 init，仅建立记录设施，调查不创建 Change。工作内排查仅沿仍有效的 parent 执行，已结束后另建独立调查。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-propose`，动作必须属于本 Skill。用户不需要填写内部编号。
