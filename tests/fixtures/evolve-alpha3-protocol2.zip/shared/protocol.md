# 确定性工具请求协议

本协议供宿主中的 AI 适配请求，不要求用户填写内部 ID 或 JSON。先读取实际 Skill 文件定位完整安装根，再运行 status；完整请求可按原授权连续切换 owner，显式阶段请求保持边界。

## 调用

```text
python3 <实际插件根>/runtime/evolve.py --project <目标项目根> <动作> [目标标题或ID] --owner evolve-<负责者> --method <方法> --request <JSON文件或->
```

路径含空格时按 argv 参数传递或正确引用。`--request -` 从标准输入读取 JSON，适合宿主准备请求；纯查询不接受写请求。十四动作的 owner 由运行时固定校验，实际可用方法见 status，未开放方法返回 UNAVAILABLE。

输入暂存及宿主拒绝标准输入时的回退按[共享运行约定](contract.md)执行；纯查询直接调用，不生成请求文件。

## 请求与授权

每个写请求包含 `authorization` 和 `input` 两个对象。authorization 保存实际用户来源 `source`、原话 `text`、本次允许的 `effect_kinds`；业务或知识文件修改另有具体 `paths` 数组。effect_kinds 使用 project_records（工作事实）、business_files（业务文件）、checks（已约定检查）、knowledge（具体正式内容应用）；不留档调查使用 read_only。授权来源由宿主忠实提供，字段不是身份认证；历史经验或配置不能充当用户授权。

新请求可不填内部编号，工具在只读准备时生成 request_id，定位 project_id／workspace_epoch，并为实施、验收及封存冻结当前 Change／REV／Task 版本。目标标题唯一时可解析，多个候选须明确。先用 status 指定目标读取 plan 原文及 Task definition；未指定目标时只列导航，不一次展开全部任务正文。knowledge_refs 的批准版本与实际字节分开，pending_knowledge 不是正式规则；latest_verification.recorded_status 不等于当前通过，applicability 未核实时为 unconfirmed。返回的 request_context 和 input_bindings 保存这些绑定；重试必须将它们合并回原请求及 input，并保留原输入，不能重新读当前版本替代旧绑定。已提供 request_id 的请求缺少原身份或 epoch 会拒绝，避免旧请求越过恢复截点。

`ok` 只表示接口操作；业务结论看 data.outcome、status、task_checks 和真实证据。checks_not_passed、blocked、needs_recovery 不能报告完成。副作用状态不明时先核对 pending_runs（包括 operations 与 pending_checks）和 maintain recover；不要生成新 ID 重试猜结果。检查主进程退出不等于子进程组已经停止；launch_unknown、foreign_host 或 process_group_present 均保留占用，不补记通过。

## 已实现的请求内容

| 动作／方法 | input 内容及边界 |
|---|---|
| init／connect | 可选 name、checks。checks 是 id、argv 数组、项目相对 cwd、timeout；只配置不执行。初次接入只建记录设施；重复接入沿用身份。已有配置变化先返回 config_candidate；实际呈现 candidate 后，新请求保存相同 name／checks、expected_config_digest 及 presentation（原文 text 与 source）应用；检查按 ID 合并，不运行命令，不模板覆盖未知内容 |
| propose／create | title、plan、completion、scope 文件数组、acceptance 条件数组、required_checks ID 数组、presentation（实际呈现的 text 与 source）。只存短方案，不默认接受或修改业务 |
| analyze／investigate | question、scope 项目内文件或目录范围、sources、business_effect=read_only、record_intent=answer_only／record、analysis。独立留档不创建 Change／Task，具体格式见下文 |
| apply／implement | 绑定 change_id、revision_id、definition_digest、accepted_plan_digest；files 数组逐项给 path、expected_digest（原文件不存在为 null）、content。expected_versions 冻结 change／task 行版本。新请求的版本与方案绑定可由准备步骤补齐；文件字节前置仍显式保存 |
| verify／run | 当前绑定及 reviews，分别提供 spec／standards 的实际 observer、summary、fingerprint_digest 和 findings。spec 逐个 AC 给 acceptance_results（ac_id、status、basis）；只验收不修复或写测试；仅当必需命令非空时需要 checks 效果授权。已 archived 的工作项可追加当前现场复验，保留 Change／Task 和原封存截点；cancelled 仍受阻 |
| archive／close | 当前绑定与最新 verification_id。任务、最新必需检查、审查及完成截点现场全部成立后封存；不隐式批准或同步知识 |
| init／baseline.propose | path（Markdown）、expected_digest、content、presentation。只存具体初次基线候选，目标仍不改 |
| init／baseline.apply | proposal_id 与 approval（proposal_version、candidate_digest、expected_digest、source、text），另需 knowledge 效果和具体 paths。批准与实际文件版本分别留档 |
| maintain／recover | 明确 operation_id 或 run_id；唯一可判定中断可自动定位。保留现场和候选，只按原有效授权核实本地步骤，不运行旧业务命令或补造通过 |

已有源文件发生外部变化时，apply 需用 observations 明确登记路径与当前摘要；工具不猜修改者或意图。同 REV 的 done 任务再次实施还要引用实际失败的 reopen_verification_id。更改需求／验收含义需要 update，当前复杂修订未开放时如实说明，不能伪装实现修正。

## 验收和审查

review 的 fingerprint_digest 必须对应实际检查过的当前 workspace。规格和规范分别说明依据；每个必需 AC 有实际结果及来源。findings 必须给局部 id、path、basis、impact 和 blocking；不能只用“已读”清除必需发现。复查时 resolutions 引用原 verification_id、finding_id 并给本次实际依据，旧发现与失败保持不变。实际自审填写真实观察者，不称独立审查。

配置的 argv 检查在数据库事务和短锁之外运行；每次派发及文件写入前重新核对身份、epoch、包和资源归属。检查退出零不替代 AC 或审查。源码、未跟踪输入、必要检查变化会重核证据；保留业务文件，不能删断言换通过。任务级检查与整体验收分别记录，apply 返回 implemented 也不等于 archive 条件已成立。

<a id="analysis-request"></a>

## 调查请求

即时问答直接只读回答；需要结构化校验时用 record_intent=answer_only 与 read_only 效果，通过标准输入传请求，不先 init，不创建库、run、备份或暂存目录。宿主拒绝这种输入形式时仍可给出实际只读观察的对话回答，并说明未生成结构化结果。明确留档用 record 与 project_records 效果；未接入时先最小 init，仅建记录设施。两者均声明 business_effect=read_only。运行时保存或返回宿主实际调查的材料，不替宿主执行命令，不把提供者的陈述认证为机器自测。

sources 是有唯一 id 的数组。每个来源给 kind、observer、observed_at、limitations。时间为带时区的实际观察时间；不知日期用 null，并在限制中说明。file 来源另给 path 与 expected_digest，运行时核对并保存实际原字节。observation 来源给 object、version（不知用 null 并说明限制）、method、content 原始观察输出；不能只填“通过”。reference 来源给同样的 object／version／method，以及 location 和未取得原文的限制，不放 content，也不承诺外部内容可恢复。源文件必须在声明 scope 内。

analysis 包含 observations、hypotheses 两个数组，以及 answer_status=answered／partial／inconclusive、conclusion、coverage、limitations、remaining_questions、next_steps。后四项为字符串数组。观察逐条给 local_key=F1、statement、sources 来源 ID 数组；假设给 local_key=H1、statement、status=unconfirmed／supported／refuted、observations 观察局部键数组、basis。supported 也不等于证明所有环境的根因；completed 只表示这一轮结束。partial／inconclusive 保留限制与待答问题。

排错调查另存 analysis.symptom：criterion 绑定 method、environment、input、expected、expected_source（独立预期的来源 ID）、side_effects；原方法是已登记检查时另存完整 check 定义（id／argv／cwd／timeout），不要换成宽松命令。symptom 保存 status=reproduced／not_reproduced／blocked／historical、attempts、failures、sources 和 limitations。当前复现与未复现须有带日期、留存输出的 observation 和实际次数；历史／受阻可将未知次数写 null，不猜次数。偶发问题另给 intermittent=true、trigger、window 及采样限制，一次未复现不代表消除。缺权限只记限制，不加生产探针或持久化测试；隔离复现实验先核对实际副作用。

独立留档结果返回 run_id；用 status 指定该 RUN 可读原分析、result_digest、criterion_digest、当前头和后续纠正。续查的 previous 为所见头的 run_id／result_digest；旧头不再派生第二个后继，幂等重试仍返回原结果。纠正在新 F／H 的 corrects 数组中引用原 run_id、result_digest、local_key，旧结论不改写。未知结果先核对 pending_runs；maintain 仅封存实际中断，不补造分析成功。

工作内排查可给 parent（run_id、input_digest、execution_instance），从实际 pending_runs 读取，保持父阶段范围。父阶段须仍是同一实际活动执行且未撤销授权；已结束时另开独立调查。parent 不代表修改授权，analyze 仍不写业务。未留档的 answer_only 不派生 previous／parent 或持久纠正。

转修复时另外呈现短方案并使用当前修改授权；propose.input.analysis_basis 引用调查 run_id、result_digest、adoption_basis，说明当前适用依据。有症状判据时同时给原 criterion_digest，方案冻结原 symptom 与 check 定义。调查许可不能充当 business_files 权限。

这类修复的 verify.input 另给 symptom_result：原 criterion_digest、当前 fingerprint_digest、status=passed／failed／blocked、observer、observed_at、basis、evidence 原始复验输出、attempts、failures、limitations。观察发生于当前任务结果之后，原检查仍由 verify 真实执行；原判据不可通过改摘要或换检查静默降低。缺 red 或偶发样本不足时保留限制，记录只是该观察范围的结果，不自动推断因果问题消除。双维审查、逐 AC、失败后同 REV 修正与封存门禁继续适用；只有命令绿灯没有原判据复验不能完成。

## 恢复限制

当前 recover 覆盖已有本地实施／初次知识／增量配置文件 journal、初始化截点、未派发文件操作的中断登记，以及 verify／archive 的记录收尾；完整档案 restore 和正式数据操作尚未开放。记录收尾保留已提交的验收／封存事实，原 run 仍为 interrupted，由 finalized_by 关联维护结果；未提交的验收保持 blocked，不重跑检查。检查执行仍在运行或启动结果尚无确证时拒绝回收占用。启动身份未知时，可在同一 recover 请求中提供 check_observations：逐个绑定 status 中的 execution_id、command_digest、host，给出 outcome=not_started／stopped、带时区的 observed_at、实际 source 和 basis。必须对应派发之后的确证，不能是猜测或仅凭主进程退出；运行时仍能观察到进程组时拒绝接管。确证由维护 run 单独留档，不推断检查通过。第三种文件内容保留冲突，已提交后的外部回退不会按旧候选覆盖。恢复不新增测试通过记录；原来确已保存的任务完成及证据也不会被抹去。原生 Windows 运行仍待实际验收，不能用路径单元测试冒充。
