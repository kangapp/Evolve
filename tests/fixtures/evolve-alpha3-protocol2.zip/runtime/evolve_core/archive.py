"""Seal completion at a verified workspace cutoff; never approves knowledge."""
import json
from pathlib import Path

from .errors import EvolveError
from .package import canonical
from .requests import normalize, require_effect
from .store import Store, identifier
from .work import change_context, claim_resources, fingerprint, gate, versions
from .workspace import writer_lock


def archive(root, payload):
    root = Path(root).resolve()
    request = normalize(payload)
    require_effect(request, 'project_records')
    store, run_id, operation_id = None, None, identifier()
    try:
        with writer_lock(root) as generation:
            store = Store(root)
            run_id, previous = store.start(request, action='archive', method='close', owner='evolve-archive')
            if previous is not None:
                return previous
            change, revision, task, definition = change_context(store, request)
            if task['state'] != 'done' or task['result_json'] is None:
                raise EvolveError('INCOMPLETE_TASK', 'Required implementation is not complete', exit_code=3)
            latest = store.one('SELECT * FROM verifications WHERE change_id=? AND revision_id=? '
                               'ORDER BY observed_at DESC,id DESC LIMIT 1', (change['id'], revision['id']))
            if not latest or latest['status'] != 'passed' or request['input'].get('verification_id') != latest['id']:
                raise EvolveError('VERIFICATION', 'Only the latest required passing verification can authorize closure', exit_code=3)
            source = store.one('SELECT status,result_digest,result_json FROM phase_runs WHERE id=?', (latest['source_run_id'],))
            reconciled = False
            if source and source['status'] == 'interrupted':
                facts = json.loads(source['result_json'])
                recovery = store.one("SELECT result_json FROM phase_runs WHERE id=? AND action='maintain' AND method='recover' AND status='completed'",
                                     (facts.get('finalized_by'),))
                result = json.loads(recovery['result_json']) if recovery else {}
                reconciled = (facts.get('outcome') == 'reconciled_committed_metadata'
                              and facts.get('saved_operation_result') == {'verification_id': latest['id'], 'status': 'passed'}
                              and result.get('original_run_id') == latest['source_run_id'] and result.get('original_facts_committed') is True)
            if not source or (source['status'] != 'completed' and not reconciled):
                raise EvolveError('VERIFICATION', 'Verification run has not been safely finalized', exit_code=4)
            snapshot = fingerprint(root, definition)
            if snapshot['digest'] != json.loads(latest['fingerprint_json'])['digest']:
                raise EvolveError('STALE_VERIFICATION', 'Workspace or check configuration changed after verification', exit_code=3)
            if json.loads(latest['items_json']).get('unresolved_prior_findings'):
                raise EvolveError('REVIEW_FINDINGS', 'Required review findings remain unresolved', exit_code=3)
            pending = [dict(row) for row in store.connection.execute(
                "SELECT id,target_path,state,version FROM knowledge_proposals WHERE state IN ('proposed','approved','deferred') "
                "AND applied_operation_id IS NULL ORDER BY id")]
            claim_resources(store, run_id, operation_id, generation, change, definition['scope'], 'project_records')
            expected = versions(store, change['id'], task['id'])
            gate(store, request, run_id, operation_id, expected)
            if fingerprint(root, definition)['digest'] != snapshot['digest']:
                raise EvolveError('WORKSPACE_CHANGED', 'Workspace changed at completion cutoff', exit_code=3)
            with store.transaction() as connection:
                connection.execute("UPDATE changes SET state='archived',row_version=row_version+1 WHERE id=?", (change['id'],))
                connection.execute('INSERT INTO source_runs VALUES (?,?,?,?)',
                                   (run_id, latest['source_run_id'], source['result_digest'], 'completion_basis'))
                connection.execute("UPDATE operations SET state='committed',result_json=? WHERE id=?",
                                   (canonical({'verification_id': latest['id'], 'fingerprint': snapshot['digest']}).decode(), operation_id))
                connection.execute('DELETE FROM resource_claims WHERE operation_id=?', (operation_id,))
                store.event(run_id, 'change_archived', {'change_id': change['id'], 'verification_id': latest['id'],
                                                      'fingerprint_digest': snapshot['digest'], 'knowledge_approval': 'not_implied'})
            return store.finish(run_id, {'committed': True, 'outcome': 'archived', 'change_id': change['id'],
                                'verification_id': latest['id'], 'completion_fingerprint': snapshot['digest'],
                                'knowledge': 'pending_project_proposals' if pending else 'not_proposed',
                                'knowledge_scope': 'project', 'pending_knowledge': pending,
                                'versions': versions(store, change['id'], task['id'])})
    except EvolveError as error:
        if store is not None and run_id is not None:
            if not store.run_started(run_id):
                error.committed = True
                raise
            with writer_lock(root):
                with store.transaction() as connection:
                    connection.execute("UPDATE operations SET state='failed' WHERE id=?", (operation_id,))
                    connection.execute('DELETE FROM resource_claims WHERE operation_id=?', (operation_id,))
                store.finish(run_id, {'committed': True, 'outcome': 'blocked', 'message': str(error)}, status='blocked')
                error.committed = True
        raise
    finally:
        if store is not None:
            store.close()
