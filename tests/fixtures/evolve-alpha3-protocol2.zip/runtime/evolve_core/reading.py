"""Read a consistent temporary history snapshot without touching live SQLite sidecars."""
from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3
import tempfile
import tomllib

from . import PROTOCOL_VERSION, SCHEMA_VERSION
from .errors import EvolveError
from .checks import pending_checks
from .workspace import current_digest, inside, request_staging_only
from .store import schema_compatible, validate_lineage
from .analysis import analysis_views


@contextmanager
def history_snapshot(root):
    root = Path(root).resolve()
    database = inside(root, 'evolve/history.db')
    if not database.is_file():
        raise EvolveError('NOT_CONNECTED', 'Explicit project connection is required')
    paths = [database, database.with_name(database.name + '-wal')]
    before = {p: p.read_bytes() for p in paths if p.exists()}
    with tempfile.TemporaryDirectory(prefix='evolve-read-') as directory:
        for path, content in before.items():
            (Path(directory) / path.name).write_bytes(content)
        connection = sqlite3.connect(str(Path(directory) / database.name))
        connection.row_factory = sqlite3.Row
        try:
            meta = dict(connection.execute('SELECT key,value FROM project_meta'))
            if int(meta['schema_version']) != SCHEMA_VERSION or int(meta.get('protocol_version', PROTOCOL_VERSION)) != PROTOCOL_VERSION:
                raise EvolveError('SCHEMA_VERSION', 'History schema or protocol is unsupported; no migration attempted')
            config = tomllib.loads(inside(root, 'evolve/config.toml').read_text())
            if config.get('config_version') != 1:
                raise EvolveError('CONFIG_VERSION', 'Configuration version is unsupported')
            if config.get('history') != {'backend': 'sqlite', 'database': 'evolve/history.db'}:
                raise EvolveError('CONFIG_PATH', 'History path/backend changed')
            if config.get('project', {}).get('id') != meta['project_id']:
                raise EvolveError('PROJECT_IDENTITY', 'Project configuration and history identities differ')
            guard = inside(root, '.evolve-local/control/guard.json')
            if guard.exists():
                value = json.loads(guard.read_text())
                validate_lineage(connection, meta, value)
            if before != {p: p.read_bytes() for p in paths if p.exists()}:
                raise EvolveError('PROJECT_CHANGED', 'History changed while preparing the observation', exit_code=3)
            yield connection, meta
            if before != {p: p.read_bytes() for p in paths if p.exists()}:
                raise EvolveError('PROJECT_CHANGED', 'History changed while reading; prepare a fresh observation', exit_code=3)
        except EvolveError:
            raise
        except (OSError, ValueError, TypeError, KeyError, sqlite3.Error) as error:
            raise EvolveError('PROJECT_INVALID', 'Cannot inspect current project history: ' + str(error))
        finally:
            connection.close()


def current_state(root, target=None):
    root = Path(root).resolve()
    for name in ('evolve/config.toml', 'evolve/history.db', '.evolve-local'):
        inside(root, name)
    if not root.is_dir():
        raise EvolveError('PROJECT_ROOT', 'Project root must be an existing directory')
    config, database = root / 'evolve/config.toml', root / 'evolve/history.db'
    if not config.exists() and not database.exists():
        if (root / 'evolve').exists() or ((root / '.evolve-local').exists() and not request_staging_only(root)):
            raise EvolveError('PROJECT_COLLISION', 'Evolve-named files require inspection; no changes made')
        return {'state': 'not_connected', 'root': str(root), 'project_id': None, 'changes': []}
    if not config.is_file() or not database.is_file():
        raise EvolveError('PROJECT_INCOMPLETE', 'Configuration and history must both exist; no recreation attempted')
    with history_snapshot(root) as (connection, meta):
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        changes = []
        if 'changes' in tables:
            for row in connection.execute('SELECT * FROM changes ORDER BY code'):
                if target and target not in (row['id'], row['code'], row['title']):
                    continue
                tasks = [dict(t) for t in connection.execute('SELECT id,state,row_version,definition_digest,definition_json FROM tasks '
                                                            'WHERE change_id=? AND revision_id=?',
                                                            (row['id'], row['current_revision']))]
                for task in tasks:
                    definition = task.pop('definition_json')
                    if target:
                        task['definition'] = json.loads(definition)
                revision = connection.execute('SELECT * FROM plan_revisions WHERE id=?', (row['current_revision'],)).fetchone()
                details = {}
                if target and revision:
                    text = connection.execute('SELECT content FROM blobs WHERE digest=?', (revision['plan_digest'],)).fetchone()
                    details['plan'] = {'revision_id': revision['id'], 'digest': revision['plan_digest'],
                                       'text': text['content'].decode('utf-8') if text else None,
                                       'presented_at': revision['presented_at'], 'accepted': revision['accepted_event_id'] is not None}
                    latest = connection.execute('SELECT id,status,observed_at,source_run_id FROM verifications WHERE change_id=? AND revision_id=? '
                                                'ORDER BY observed_at DESC,id DESC LIMIT 1', (row['id'], revision['id'])).fetchone()
                    details['latest_verification'] = ({'id': latest['id'], 'recorded_status': latest['status'],
                                                       'observed_at': latest['observed_at'], 'source_run_id': latest['source_run_id'],
                                                       'applicability': 'unconfirmed'} if latest else None)
                changes.append({**dict(row), 'tasks': tasks, 'plan_digest': revision['plan_digest'] if revision else None,
                                'details_loaded': bool(target), **details})
        analyses = analysis_views(connection, target) if 'phase_runs' in tables else []
        if target and len(changes) + len(analyses) != 1:
            raise EvolveError('TARGET', 'Target is missing or ambiguous; choose a stable change or analysis identity')
        pending_runs = [dict(r) for r in connection.execute("SELECT id,action,method,started_at,input_digest,execution_instance FROM phase_runs WHERE status='started'")] if 'phase_runs' in tables else []
        for run in pending_runs:
            run['execution_instance'] = json.loads(run['execution_instance'])
            run['operations'] = [dict(r) for r in connection.execute(
                'SELECT id,state,effect_kind FROM operations WHERE run_id=?', (run['id'],))] if 'operations' in tables else []
            run['pending_checks'] = pending_checks(connection, run['id']) if 'events' in tables else []
        knowledge_refs = []
        if {'artifacts', 'artifact_versions'}.issubset(tables):
            for item in connection.execute("SELECT a.path,v.id,v.blob_digest,v.source_run_id,v.observed_at FROM artifacts a "
                                            "JOIN artifact_versions v ON v.id=a.current_version WHERE a.kind='knowledge' AND a.path IS NOT NULL ORDER BY a.path"):
                observed = current_digest(inside(root, item['path']))
                knowledge_refs.append({'path': item['path'], 'artifact_version_id': item['id'],
                                       'registered_digest': item['blob_digest'], 'source_run_id': item['source_run_id'],
                                       'registered_at': item['observed_at'], 'observed_digest': observed,
                                       'confirmation': 'approved_version' if observed == item['blob_digest'] else 'unconfirmed'})
        pending_knowledge = [dict(r) for r in connection.execute("SELECT id,target_path,state,version,candidate_digest FROM knowledge_proposals "
                                                               "WHERE state IN ('proposed','approved','deferred') AND applied_operation_id IS NULL ORDER BY id")] if 'knowledge_proposals' in tables else []
        init_journal = inside(root, '.evolve-local/control/init.json')
        initialization = json.loads(init_journal.read_text()).get('state') if init_journal.is_file() else 'unregistered'
        return {'state': 'connected', 'root': str(root), 'project_id': meta['project_id'],
                'workspace_epoch': meta.get('workspace_epoch'), 'schema_version': int(meta['schema_version']),
                'checkpoint': meta.get('checkpoint'), 'changes': changes, 'analyses': analyses, 'pending_runs': pending_runs,
                'knowledge_refs': knowledge_refs, 'pending_knowledge': pending_knowledge,
                'write_compatible': schema_compatible(connection), 'initialization': initialization}
