---
name: evolve-verify
description: 验收 Evolve 工作成果，执行相关检查、回归和规格／规范两方面审查时使用。
---

归属 verify。核对实际成果、检查配置和证据时效。规格符合性和规范／维护性分别给结论，必需问题阻碍完成；修复交 apply，只 verify 不改业务或测试源码。缺环境如实 blocked，不凭退出码宣布所有验收通过。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-verify`，动作必须属于本 Skill。用户不需要填写内部编号。
