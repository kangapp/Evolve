---
name: evolve-propose
description: 为 Evolve 工作形成短方案或复杂 spec、修订方案，或开展不修改业务的独立调查。
---

归属 propose、update、analyze。复用当前资料，区分事实、假设和未知。复杂方案给目标、边界、行为、验收和真实任务依赖；调查保存可重复症状判据、来源与限制，不凭分析请求开始修复。

即时解释直接只读查看并回答，不先 init；需要结构化校验时可通过标准输入调用 analyze 的 answer_only，宿主拒绝该输入形式则保留对话回答，不为问答创建暂存目录。明确需要留档时用 record，未接入则先做最小记录接入，不为调查创建 Change。工作内排查仅沿仍有效的 parent 执行，已结束后另建独立调查。具体字段与证据要求读取[调查请求](../../shared/protocol.md#analysis-request)。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-propose`，动作必须属于本 Skill。用户不需要填写内部编号。
