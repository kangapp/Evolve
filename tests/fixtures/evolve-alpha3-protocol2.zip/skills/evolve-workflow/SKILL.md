---
name: evolve-workflow
description: 定位 Evolve 项目工作项、只读状态、下一步与跨会话续接；或分派明确的 Evolve 动作。
---

归属 status、next、resume。先解释用户意图和唯一目标，再调用实际负责的 Skill；router 不代写业务。无动作使用 status。next／resume 未开放时准确报告不可用，不用旧聊天猜进度。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-workflow`，动作必须属于本 Skill。用户不需要填写内部编号。
