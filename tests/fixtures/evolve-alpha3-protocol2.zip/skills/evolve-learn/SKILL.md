---
name: evolve-learn
description: 检索、记录和反馈当前项目的 Evolve 经验，处理反例或提议规则／检查改进时使用。
---

归属 learn。未指定子方法只说明用法。带来源和适用条件检索经验，空结果与来源故障分开；记录实际采用效果和反例。晋升规则需具体批准，自动化改进由原 owner 按授权实施。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-learn`，动作必须属于本 Skill。用户不需要填写内部编号。
