# 诊断与排错

先执行 usage 中的只读 doctor，保留返回的 error.code、包版本和内容摘要。不要把诊断失败后重装当作项目接入或数据恢复。

| 错误 | 含义与下一步 |
|---|---|
| PYTHON_VERSION | 使用 Python 3.11+；插件不会自动安装系统依赖 |
| PACKAGE_INCOMPLETE | 资源缺失／被改或摘要不一致；重新构建／安装完整同版本包 |
| PACKAGE_VERSION | 内核、清单或能力表混用；停止写入，使用完整一致版本 |
| PROJECT_COLLISION | 存在同名 evolve 或 .evolve-local 资料；先核对身份，不覆盖 |
| PROJECT_INCOMPLETE | 配置／库仅有其一；保留现场，不能按新项目重建 |
| PROJECT_CHANGED | 观察期间历史变化；重做只读核查，不使用混合截点 |
| PROJECT_INVALID／PROJECT_IDENTITY | 配置、库或身份异常；只读诊断不修复 |
| SCHEMA_VERSION／CONFIG_VERSION | 当前包不支持该版本；保留数据，不自动迁移或降级 |
| UNKNOWN_ACTION／UNKNOWN_METHOD／OWNER | 动作、方法或负责 Skill 不匹配；按真实能力重试 |
| DUPLICATE_INSTALLATION | 发现同名散装 Skill；核对来源并选择单一渠道，工具不删除已有文件 |
| UNAVAILABLE | 当前版本尚未提供该方法；不是业务通过或资料已保存 |
| ANALYSIS_SOURCE_CHANGED／ANALYSIS_SCOPE | 调查实际来源已变或不在声明范围；重新读取并核对实际范围，保留原观察，不将新字节冒充旧来源 |
| ANALYSIS_HEAD／ANALYSIS_RUNNING | 旧调查头已有后继，或前一轮尚未安全结束；读取当前头及实际执行，不按日期猜新主题或覆盖进度 |
| ANALYSIS_INCOMPLETE | 观察已提供但分析没有完整保存；先看 pending_runs、原输入和已存证据，不能补记成功；实际中断由 maintain 收尾 |
| ANALYSIS_PARENT | 原父阶段不再是所见的活动执行、范围不同或授权失效；核实现场后独立调查，不沿过期阶段越界 |
| SYMPTOM_CHANGED／SYMPTOM_REVERIFY_REQUIRED | 修复或验收缺少原症状判据，或替换了原预期／检查；恢复原判据复验，改变验收含义需重新确认 |
| SYMPTOM_LIMITATIONS | 缺 red 或偶发样本不足；记录观察局限，不补造根因、失败次数或问题已消除的结论 |
| REQUEST_REQUIRED／AUTHORIZATION | 写方法需要实际授权来源及输入；用户由 AI 准备请求，不从历史经验推断授权 |
| VERSION／WORKSPACE_EPOCH／DEFINITION | 请求依据已变化；重新核对现场和原请求，不用当前版本替换旧请求绑定 |
| FILE_CONFLICT／WORKSPACE_CHANGED | 原字节或受检现场已变化；保留外部内容，明确登记观察并重新判断证据 |
| FILE_TARGET_CHANGED | 目录别名指向的实际文件与原操作绑定不同；保留 journal 和两处文件，核实原目标。恢复前须恢复可核对的原指向，不能将相同字节视为同一文件 |
| CHECK_CONFIG | 必需检查命令与已批准依据不同；核实配置与方案，不沿用旧通过记录 |
| STALE_REVIEW／STALE_VERIFICATION | 审查或验收对应旧现场；按当前内容复验，不能只改摘要使旧结果适用 |
| CONFIG_PRESENTATION／KNOWLEDGE_APPROVAL | 缺具体候选或批准绑定；展示实际内容并按有效授权应用 |
| CONFIG_UNSUPPORTED | 当前配置表达式不能无损编辑；保留原文件，不能用模板覆盖未知段落 |
| CREDENTIAL_CONTENT | 输入包含当前环境中已知凭证；使用环境引用，凭证不进入记录或文件候选 |
| NEEDS_RECOVERY／JOURNAL_INVALID | 本地文件与记录需要核实，或 journal 与原授权不符；先只读诊断再选择原操作恢复 |
| WRITER_ACTIVE／CLAIM | 原执行仍可能运行或相关资源已被占用；核对原执行，不凭时间或新请求编号接管 |
| CHECK_OBSERVATION | 核实信息缺失、过时或与原执行／命令不符；按实际观察补齐，不修改执行身份换成别的命令 |
| CHECK_RUNNING／CHECK_EXECUTION_UNKNOWN | 检查进程组仍存在或启动身份未知；查看 pending_runs 中的 pending_checks，保留占用与现场，不重跑猜结果 |

status 返回的 pending_runs 包含运行、操作及待核实检查身份。maintain recover 需要明确的原 operation_id 或 run_id；唯一可判定的中断可自动定位。该操作收尾已授权的本地文件或记录事实，不执行原检查命令、不补造测试通过。已保存的任务完成、验收及封存事实保持，第三种文件内容保留为冲突。

缺少进程身份的检查不会自动解除。取得具体执行、命令、主机、时间及范围的确证后，由 AI 按[请求协议](../shared/protocol.md)将 check_observations 随原操作的 recover 请求登记；仅凭“主进程退出”不足以证明停止，也不能推断测试通过。系统仍观察到进程组时保持受阻，不通过手改数据库、删除占用或清库重建跳过。原生 Windows 的进程与恢复行为仍待真实验收。


