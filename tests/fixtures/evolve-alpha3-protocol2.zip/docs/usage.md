# 使用说明

当前为 0.1.0-alpha.3 开发包，M1 整阶段尚未通过。小修改已通过本机双宿主验收；独立调查与原判据复验正在当前切片验收。学习、复杂 spec、知识批量同步和完整档案恢复尚未开放，返回 UNAVAILABLE。

## 第一个任务：已有项目的小修复

起点：已有源码和检查入口，完整 Evolve 包安装并在当前项目启用，Python 3.11+。从实际宿主发现的 evolve-workflow 入口表达请求，例如：

```text
接入这个项目，梳理总计错误的相关代码，保存短方案，按我确认的范围修复并测试通过。
```

AI 先核对资料和授权；明确修改的简单任务先展示短方案即可在原范围推进。包安装、项目接入、正式知识批准分别处理：init 只建立配置和记录设施，沿用原有代码与资料，不自动写 project.md。

方案包含目标、具体文件范围、完成条件、相关检查和限制。propose 保存原文与任务定义，尚不代表已批准或实施。apply 按实际呈现的当前方案及修改授权写入，每次核对原字节与版本；相关检查失败保留源码和失败证据，修正复测。

任务检查通过后，verify 另行检查规格符合性和项目规范／维护性，并记录逐项 AC、实际观察者和真实检查结果。只请求 verify 时不会修改业务或测试源码；缺测试给出补充方案。已封存工作项允许追加当前现场的验收记录，保留原 Change／Task、历史 VER 和封存截点；当前字节与原实施范围不符时如实受阻，不强行重开实施。审查发现必需问题后，已有完整修改授权可继续修复复查；主观建议与必需问题区分。

最后 archive 重新核对当前现场、最新必需验证、任务及未决审查问题，保存具体完成截点。任务检查通过不会自动封存，附带知识也不会自动批准。源码或检查配置变化后，旧通过不能冒充当前通过。

结果分别查看 implemented、verify 的 status 与 archived。checks_not_passed、blocked、needs_recovery 都需要继续处理。配置与历史保存在目标项目 evolve/config.toml、evolve/history.db；本地 journal、保护备份和协调信息在 .evolve-local/。插件缓存不存目标项目历史。

## 调查而不实施

只需要即时解释时，可以说“解释一下总计为什么不对，暂不留档也不修改”。AI 使用不留档调查，不先 init，不创建历史库或业务工作项。返回的事实与假设来自实际读取和观察，未完成检查会保留限制。

需要以后接续时，可以说“只调查总计错误并保存独立记录，暂不修复”。未接入时先最小接入，再保存独立 analysis run；不会为了调查建立 Change／Task，也不需要 archive。来源、观察时点、原文／输出、事实 F1、假设 H1、未答问题与下一步分开保存。completed 表示本轮结束，partial／inconclusive 仍表示答案有限。外部历史材料注明实际观察者，未知日期不补成今天；只引用未取得的外部原文时不承诺恢复其内容。实际留存的文件与输出当前在历史库的 evidence／blobs 中。

排错先保留能捕捉真实症状的方法、输入、独立预期、环境、原始观察及副作用。运行一次没有失败不等于消除偶发问题；没有权限、无法复现、缺 red 时如实记录。调查可以在已允许的隔离环境复现，新增持久化测试、业务配置或真实环境探针仍须修改授权。

用 status 指定调查 RUN ID 可读原始结论、来源、result_digest、criterion_digest、当前头与后续纠正。明确“沿这次调查继续”才派生 previous；新问题新主题，同标题的多个主题不自动合并。旧头不会分叉，旧结论不覆盖，后继反驳仍关联原 F／H。任务内排查沿仍有效的父执行绑定，阶段已结束则另起独立调查，不继承过期修改权限。

决定修复后，再明确授权和实际文件范围。AI 呈现短方案，引用原调查及症状判据，走 apply、verify 与 archive。verify 除真实检查和双维审查外还保存原判据的当前复验；不能换宽松条件、删断言或只凭退出 0 声称完成。只请求调查或只验收都不会自动开始修复。

## 查看状态与只读诊断

```bash
python3 /absolute/path/evolve-package/runtime/evolve.py --project /path/to/project status
python3 /absolute/path/evolve-package/runtime/evolve.py --project /path/to/project status "总计错误"
python3 /absolute/path/evolve-package/runtime/evolve.py --project /path/to/project maintain --method doctor
```

替换上述路径为实际安装根及目标项目根。未接入时 data.project.state=not_connected，不创建记录。已接入时可查看工作项、任务版本与 pending_runs。状态中的 analyses 按调查主题列当前头；指定 RUN ID 可看历史原快照和当前纠正。指定唯一工作项标题或 ID 后，status 另外返回原来实际呈现的短方案、当前 Task 定义及最新历史验收引用，无需回旧聊天找正文。最新验收的 recorded_status 是当时记录，applicability=unconfirmed 表示本次查询没有重新验收，不能直接汇报“当前通过”。knowledge_refs 导航到已批准正式文档；目标字节与批准版本不同时标 unconfirmed，pending_knowledge 中的候选也不自动成为正式约定。标题不唯一时明确选择，不按最近会话猜目标。host_enablement=not_observed 表示运行时未检查宿主启用配置，不能据此宣称已启用插件。

## 正式知识与本地恢复

初次基线先呈现具体候选，再按候选版本、内容摘要和目标基线批准，由 init 应用并核对实际文件。通用“实现并完成”不会隐含批准正式知识。知识的后续批量修订和规则晋升仍在后续切片。

中断后先核对现场。maintain recover 只处理已登记的本地步骤：原字节可继续、已为候选仅补事实、第三种内容保留冲突；不会重跑旧检查或业务命令，不把恢复当测试通过。运行进程尚未确认停止时不会接管。备份／恢复整套档案的 restore 尚未开放，当前保护备份不能冒充完整恢复产品。

## AI 使用的工具接口

用户无需填写内部编号。宿主 AI 使用[请求协议](../shared/protocol.md)准备 JSON，调用 `--request <文件>` 或 `--request -`。工具返回系统生成的 request_context 和 input_bindings；重试合并原绑定与原输入，避免重新猜版本。纯查询不接受写请求。


