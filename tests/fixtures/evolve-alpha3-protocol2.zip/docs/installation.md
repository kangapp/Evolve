# 安装与项目启用

0.1.0-alpha.3 为 IMP-003 开发包；当前方法以 status 为准，M1 整阶段仍未通过。



## 获取完整包

从源码根运行 `python3 scripts/build_package.py --out /absolute/path/evolve-package`。输出是包含两个宿主清单、八个 Skill、shared、runtime、模板和用户说明的完整目录。安装时指向这个目录，禁止仅复制 Skill。宿主缓存与目标项目中的 evolve/ 工作资料分开。

本地市场使用稳定的完整安装目录，例如 `/absolute/path/evolve-installed`。源码构建可以直接输出到该目录；拿到下载包时，先将整个目录复制到这个新位置，再用它注册市场。目标目录需不存在：

```bash
python3 -c 'import shutil,sys; shutil.copytree(sys.argv[1],sys.argv[2])' /path/to/download/evolve-package /absolute/path/evolve-installed
```

下文的 `/absolute/path/evolve-installed` 是该稳定安装根。原始下载副本可移走；稳定安装根属于本地安装的一部分，需保留。本机 Claude Code 2.1.117 对本地目录市场中的相对路径插件会原位加载：`plugin list` 列出的独立缓存副本不代表 Skill 实际从该缓存运行。用宿主显示的 Skill `Base directory` 和 doctor 的 package_root 核对实际来源。该区别已通过真实模型调用及移走原目录后的发现失败复现；不能只见到缓存文件就宣称安装独立。

## Codex CLI

```bash
codex plugin marketplace add /absolute/path/evolve-installed
codex plugin add evolve@evolve-local
codex plugin list
```

本机 Codex CLI 0.154.0 的 `plugin add` 会把用户配置中的插件设为 enabled=true。为落实项目范围，安装后先将用户配置（默认 `~/.codex/config.toml`）中该插件的 enabled 改为 false，再在目标项目的 `.codex/config.toml` 中维护 `[plugins."evolve@evolve-local"]` 的 `enabled = true`；项目配置需被宿主信任。宿主若仅支持用户范围启用，应先说明限制并停在未满足的验收项。本机实测 app-server 发现的名称为 `evolve:evolve-workflow`（八个 Skill 均有 evolve 命名空间）；使用宿主按该名称展示的入口，逻辑动作 status 不依赖全局 `/evolve` 命令。

## Claude Code

```bash
claude plugin marketplace add /absolute/path/evolve-installed --scope project
claude plugin install evolve@evolve-local --scope project
claude plugin list --json
```

从目标项目运行上述命令，使启用配置限定在该项目。Skill 入口按插件命名空间组织为 `/evolve:evolve-workflow`；实际交互发现结果以验收记录为准。需要临时调试时可使用 `claude --plugin-dir /absolute/path/evolve-package`，临时加载不代替市场安装验收。

## 更新、禁用和卸载

当前尚未验收更新、卸载重装和项目迁移（IMP-005）。保持完整版本一起切换，不手工替换单文件。配置中关闭启用与卸载包分别处理；项目 evolve/ 和 .evolve-local/ 的资料保留。正式可操作步骤在对应切片验收后补充。不提供自动下载器或项目数据清理。

alpha.3 的协议为 v2（表结构仍为 schema v1），因为调查所绑定的症状复验已是新增写入门禁。旧 alpha.2 不支持这些门禁，会拒绝新协议档案；alpha.3 同样不自动接纳旧协议写入。当前阶段使用新的受控验收项目；发现旧档案时保留资料并报告不兼容，不清库、重建或手改协议号来跳过检查。即时只读问答可直接调查业务文件，无需为此升级档案。
