---
name: evolve-archive
description: 封存已完成的 Evolve 工作，或应用已批准且仍适用的项目知识差异时使用。
---

归属 archive、sync。先核对必需成果和验收，封存完成事实与正式知识应用分别表达。archive 不隐式 sync，sync 不自动批准；必需文档尚未应用不能完成，附带知识可延期。

复杂工作封存前按[复杂规格与任务](../../shared/structured-plans.md)核对全部任务及整项 VER，任务验收引用不能替代它。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-archive`，动作必须属于本 Skill。用户不需要填写内部编号。
