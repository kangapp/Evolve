---
name: evolve-maintain
description: 查询 Evolve 历史、诊断档案，或按请求导出、取消、备份及恢复时使用。
---

归属 history、maintain。默认 doctor 只读。恢复先保护现存内容并核对包／身份／版本，补确定性事实；保留包外用户文件和未知外部保护，不重放业务命令或自动合并分叉库。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-maintain`，动作必须属于本 Skill。用户不需要填写内部编号。
