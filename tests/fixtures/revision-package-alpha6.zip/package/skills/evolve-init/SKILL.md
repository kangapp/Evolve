---
name: evolve-init
description: 用户请求将已有或新项目接入 Evolve，或调整 Evolve 工具配置时使用。
---

归属 init。增量发现资料并保留既有内容；接入记录设施与业务骨架分开。先给基线候选与缺口，具体正式内容获批后应用。包安装由宿主管理，不在 init 自我升级。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-init`，动作必须属于本 Skill。用户不需要填写内部编号。
