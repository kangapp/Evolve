# 安装与项目启用

当前源码为 0.1.0-alpha.6（IMP-006 开发中）；M1 受检基线为 alpha.4，已通过当前环境验收。安装开发包前核对实际方法和协议兼容性。



## 获取完整包

从源码根运行 `python3 scripts/build_package.py --out /absolute/path/evolve-package`。输出是包含两个宿主清单、八个 Skill、shared、runtime、模板和用户说明的完整目录。安装时指向这个目录，禁止仅复制 Skill。宿主缓存与目标项目中的 evolve/ 工作资料分开。

本地市场使用稳定的完整安装目录，例如 `/absolute/path/evolve-installed`。源码构建可以直接输出到该目录；拿到下载包时，先将整个目录复制到这个新位置，再用它注册市场。目标目录需不存在：

```bash
python3 -c 'import shutil,sys; shutil.copytree(sys.argv[1],sys.argv[2])' /path/to/download/evolve-package /absolute/path/evolve-installed
```

下文的 `/absolute/path/evolve-installed` 是该稳定安装根。原始下载副本可移走；稳定安装根属于本地安装的一部分，需保留。本机 Claude Code 2.1.117 对本地目录市场中的相对路径插件会原位加载：`plugin list` 列出的独立缓存副本不代表 Skill 实际从该缓存运行。用宿主显示的 Skill `Base directory` 和 doctor 的 package_root 核对实际来源。该区别已通过真实模型调用及移走原目录后的发现失败复现；不能只见到缓存文件就宣称安装独立。

## Codex CLI

```bash
codex plugin marketplace add /absolute/path/evolve-installed
codex plugin add evolve@evolve-local
codex plugin list
```

本机 Codex CLI 0.154.0 的 `plugin add` 会把用户配置中的插件设为 enabled=true。为落实项目范围，安装后先将用户配置（默认 `~/.codex/config.toml`）中该插件的 enabled 改为 false，再在目标项目的 `.codex/config.toml` 中维护 `[plugins."evolve@evolve-local"]` 的 `enabled = true`；项目配置需被宿主信任。宿主若仅支持用户范围启用，应先说明限制并停在未满足的验收项。本机实测 app-server 发现的名称为 `evolve:evolve-workflow`（八个 Skill 均有 evolve 命名空间）；使用宿主按该名称展示的入口，逻辑动作 status 不依赖全局 `/evolve` 命令。

## Claude Code

```bash
claude plugin marketplace add /absolute/path/evolve-installed --scope project
claude plugin install evolve@evolve-local --scope project
claude plugin list --json
```

从目标项目运行上述命令，使启用配置限定在该项目。Skill 入口按插件命名空间组织为 `/evolve:evolve-workflow`；实际交互发现结果以验收记录为准。需要临时调试时可使用 `claude --plugin-dir /absolute/path/evolve-package`，临时加载不代替市场安装验收。

## 更新、禁用和卸载

更新前先让相关执行安全结束；有 pending_runs 或未结束文件日志时，先按[恢复说明](troubleshooting.md)核对，不在运行中替换安装目录。保留旧完整版本，将完整新版放到原稳定安装路径，再执行对应宿主步骤。不要逐个替换 Skill 或 runtime 文件。稳定安装根属于安装内容，Claude 本地目录市场仍会从那里加载。新会话核对 doctor 返回的 package_root、版本、摘要以及项目身份；只有 schema／protocol 兼容才继续写入。包更新不重放旧请求、不迁移项目库或扩大授权。

Codex CLI 0.154.0 没有 plugin update 子命令。安全结束后，在目标项目使用它实际支持的重新安装路径：

```bash
codex plugin remove evolve@evolve-local
codex plugin add evolve@evolve-local
codex plugin list
```

重新 add 后按上文再次关闭用户级 enabled，只在目标项目启用并保持宿主信任。临时禁用时，将目标项目 `.codex/config.toml` 中该插件的 enabled 设为 false，用户级也维持 false；重新启用改回项目级 true。卸载使用 remove；这些操作不替代项目接入或清理项目资料。

Claude Code 2.1.117 从目标项目执行：

```bash
claude plugin marketplace update evolve-local
claude plugin update evolve@evolve-local --scope project
```

按宿主提示重启后使用新版本。禁用、重新启用和卸载分别为：

```bash
claude plugin disable evolve@evolve-local --scope project
claude plugin enable evolve@evolve-local --scope project
claude plugin uninstall evolve@evolve-local --scope project
```

卸载后按首次安装中的 install 命令重装；保留项目 `evolve/`、`.evolve-local/`、映射文档和业务文件。重装后 status 应显示原 project_id／workspace_epoch 和历史，不能当新项目建库；显式 init 可以追加一次已接入回执，不重置历史或正式知识。禁用／卸载不证明旧进程或外部操作已停止，项目数据清理是另一个明确请求。



alpha.3 的协议为 v2（表结构仍为 schema v1），因为调查所绑定的症状复验已是新增写入门禁。旧 alpha.2 不支持这些门禁，会拒绝新协议档案；alpha.3 同样不自动接纳旧协议写入。当前阶段使用新的受控验收项目；发现旧档案时保留资料并报告不兼容，不清库、重建或手改协议号来跳过检查。即时只读问答可直接调查业务文件，无需为此升级档案。

alpha.4 的协议升为 v3（schema 仍 v1），隔离旧写入器忽略暂停指令的语义问题。暂停／续接及项目学习已通过当前环境验收；旧 alpha.3 档案保留并使用完整旧兼容包，不自动迁移、重建或手改协议号。前述生命周期验收仅证明同 schema／protocol 的兼容包切换，不证明跨该协议边界升级。

alpha.6 使用 protocol v5（schema 仍 v1），隔离旧写入器忽略修订接受与继承条件的可能。当前已接通复杂任务提案、依赖实施、预重构前后证明和任务／整体验收，REV 已接通，IMP-006 尚待复杂场景原生宿主验收；旧 alpha.4／alpha.5 档案继续使用保留的完整兼容包，不自动迁移、重建或手改协议号。
