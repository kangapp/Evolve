# 多 Skill 插件架构与范围

状态：0.5.2 双路径设计审查修订，尚未实现；本轮仅设计文档、实施计划和 SVG，不开始插件编码。

阅读顺序：[使用指南](user-guide.md) → [领域模型与权威](domain-model.md) → 本文及按需加载的运行时协议。

## 1. 架构决定

首版形态为一个 SDD 插件，包含九个功能 Skill、一个共享 Python 工具内核、一套公共协议和模板。Skill 是完整职责的工作流单元；插件是整体分发单元；共享内核是状态与执行一致性的基础。

旧的“一个业务 Skill + 多个命令薄包装”已由本方案替代。宿主适配仍可有薄包装，但它只解析入口、定位资源和传参，不承载阶段业务逻辑。

![多 Skill 插件整体架构](diagrams/01-system-architecture.svg)

## 2. 层次和职责

- **用户与宿主**：用户决定目标、阶段与必要确认；宿主提供 Skill 发现、交互、文件、终端及实际执行权限。
- **路由 Skill：sdd-workflow**：定位项目和阶段、status／next／resume、说明合法下一步。可将明确请求交给负责的 Skill，不包办规划、开发或发布。
- **六个阶段 Skill**：sdd-init、sdd-propose（含 analyze 子动作）、sdd-apply、sdd-verify、sdd-release、sdd-archive 分别持有本阶段完整方法、输入输出及完成条件。
- **支持 Skill**：sdd-learn 负责经验维护与晋升方法；sdd-maintain 负责历史、导出、取消、备份和恢复。
- **共享内核**：配置、状态转换、持久化、指纹、幂等、版本、证据、执行结果、生成视图、命令执行及恢复。它不凭语义推断业务已经满足。

独立分析由 sdd-propose 的 analyze 方法负责，业务只读但可留档；纯查询、即时不留档解释、变更内排查与独立分析的边界见 [analysis-workflow.md](analysis-workflow.md)。不增加第十个 Skill 或独立分析实体。

每个 Skill 可直接进入，也可被路由推荐。用户跳过路由不等于跳过状态核查。Skill 并非独立常驻进程，多 Skill 不默认产生多 Agent、独立模型 API 或后台自动调度。

## 3. 单一事实来源

具体字段权威以 [domain-model.md](domain-model.md) 为准；任务概要与完整任务、AC 含义与检查结果、发布材料与实际观察分开维护。

- Markdown 管当前项目目标、规格、提议、方案、决策、代码地图和正式规则。
- SQLite 管结构化任务定义和进度、关键修订、事件、验证、发布、经验、phase_runs（含输入核查和封存结果）。
- SQLite 保存 Markdown 历史快照与索引，当前正文仍通过 Markdown 编辑；过去快照不会被新内容覆盖。
- tasks.md、状态汇总、验证报告和执行摘要为带来源版本的生成视图，不能直接编辑视图就假定数据库状态已改变。
- 大附件保存文件，数据库记录来源、摘要、范围及引用。恢复包必须包含必要附件。

所有 Skill 共用一份项目配置、一份 history.db 和同一套编号、证据与状态语义；禁止每个 Skill 维护自己的数据库或自由拼接 SQL 更新状态。

## 4. 入口与轮转

命令和逻辑动作的唯一归属见 [命令映射](contracts.md)。入口 → 功能 Skill → 共享内核 → 封存执行结果 → 从当前事实推荐下一步，是统一路径。

开发六入口之外，明确分析留档走项目级 run 的短路径，不强制 CHG、验收或业务归档。恢复既有分析只读；明确续查时新建 run，转修复由普通 propose／update 定位已有或新建 CHG，分析结果不能代替方案接受。

默认阶段转换由用户触发。router 与来源 Skill 只推荐合法后续动作；用户明确要求多阶段连续执行时才在该范围内组合，遇关键未决问题、冲突或未知外部结果暂停相关动作。

每个写阶段以稳定 request_id 执行 prepare → start → execute → finish → present：先核查上下文，建立 phase_run；结束时事务封存 run.result、事件和必要知识结论。接收 run 核查 source_runs、targets 与结果的 basis_refs，相关业务有效性和当前提交行版本分别判断；多变更发布不能用一个 REV 代表全部输入。

![执行结果复用与输入核查](diagrams/15-skill-handoff-and-rotation.svg)

执行结果不是权限凭证；owner_skill 和已接受范围的说明也不创造宿主权限。多个 Skill 的职责约束由公共工具核查，并不能阻止其他编辑器直接改文件。

## 5. 运行时与资源定位

运行时设计为 Python 3.11+ 标准库，采用 sqlite3、argparse、json、hashlib、pathlib、tomllib、subprocess 等，不要求数据库服务或模型 API。

配置采用 TOML，初始模板生成后由用户或 Agent 编辑并校验；标准库提供解析而不提供写入能力。[Python TOML 文档](https://docs.python.org/3.11/library/tomllib.html)

SQLite 使用显式事务及一致性备份；实际探测模块是否可用，不只看 Python 版本。[Python sqlite3 文档](https://docs.python.org/3.11/library/sqlite3.html)

插件安装清单定位 plugin root、runtime/sdd.py、shared/、模板与九个 Skill。持久化项目资料不保存开发机绝对路径。首版整包校验插件版本和数据库 schema；内部运行接口与结果格式随整包版本检查，不建立独立对外交接协议；缺少公共资源时报具体依赖错误，不退化为无留档执行。

## 6. 预期插件源结构

```text
spec-driven/
├── AGENT.md
├── docs/                         # 设计文档及已有绘图工具
└── sdd-plugin/                   # 后续编码阶段才创建
    ├── <宿主插件清单与适配资源>
    ├── skills/
    │   ├── sdd-workflow/SKILL.md
    │   ├── sdd-init/SKILL.md
    │   ├── sdd-propose/SKILL.md
    │   ├── sdd-apply/SKILL.md
    │   ├── sdd-verify/SKILL.md
    │   ├── sdd-release/SKILL.md
    │   ├── sdd-archive/SKILL.md
    │   ├── sdd-learn/SKILL.md
    │   └── sdd-maintain/SKILL.md
    ├── shared/                   # 执行协议、动作归属、公共参考与资源定位
    ├── runtime/
    │   ├── sdd.py                # 唯一工具入口
    │   └── sdd_core/             # 状态、存储、执行及恢复
    └── assets/templates/
```

各 Skill 按需包含自己的 references 和必要元数据，公共协议只保存一处。禁止九份实现拷贝或把整个开发 docs 目录装入每个 Skill。

## 7. 宿主适配和分发

优先验证 Codex 和 Claude Code。一个插件可打包多个 Skill，具体清单与入口按宿主支持的格式实现并验收。[官方插件架构](https://developers.openai.com/plugins/concepts/plugins)

- Codex 使用实际可用的 Skill 选择／显式引用方式；项目级发现目录参考 .agents/skills，但完整插件共享资源不能只复制一个裸 Skill 就宣称安装完成。[官方 Skills 文档](https://learn.chatgpt.com/docs/build-skills)
- Claude Code 使用其 Skill／插件命令机制；插件命名空间可能影响命令显示，安装验收记录最终可用拼写，不覆写宿主命令。[Claude Code Skills](https://code.claude.com/docs/en/skills)
- 支持原生 Skill 调用时按宿主机制使用；没有统一调用 API 时由当前 Agent 显式加载目标 Skill 的方法和公共工具。不得用发一段斜杠文本冒充可靠内部调用。
- 先整包本地验证，不自动全局安装、发布到市场或改用户权限配置；云端兼容和自动更新不列入首版承诺。

init 对已有 AGENTS.md／CLAUDE.md 只做最小导航接入，保留有效规则；安装插件和初始化目标项目是不同动作。

## 8. 目标项目布局

```text
target-project/
├── <既有源码、测试与宿主规则>
├── sdd/
│   ├── config.toml
│   ├── history.db               # 所有 Skill 共用；结果与输入核查合一
│   ├── project.md
│   ├── codemap.md
│   ├── specs/<capability>/spec.md
│   ├── decisions/DEC-*.md
│   ├── changes/<change-id>/
│   ├── changes/archive/<change-id>/
│   ├── evidence/<verification-id>/
│   ├── releases/<release-id>/
│   └── exports/<export-id>/
└── .sdd-local/                   # 短锁、暂存、备份及 init/restore 控制清单
```

项目 ID 与执行引用不依赖宿主会话 ID。Markdown、history.db 和必要附件随项目保存；临时目录不是普通执行结果的唯一来源；建库前与换库中，独立控制清单是恢复例外，完成后将结果写入库。支持个人跨会话先后接续，不默认支持并行修改同一变更或数据库跨分支自动合并。

## 9. 当前交付边界

多 Skill 架构已采用；0.5.2 对开发／独立分析两条路径完成职责、留档和恢复一致性修订，见 [双路径审查](design-review-0.5.1.md)；0.4.1 审查作为历史依据保留，见 [design-review.md](design-review.md)。尚无可运行插件、SKILL.md、runtime、历史数据库或宿主实测结果。用户明确要求暂不编码，即使设计整理完成也不自动进入 M1。
