# 0.5.2 完整案例：独立排查、换会话续查、修复、验证、归档与发布

本文是设计模拟，不是已执行记录。下述应用、日志、编号、指纹、检查结果和发布结果均为假设；本轮只创建案例文档，不创建 history.db、不修改业务、不执行检查或部署。`/sdd-*` 是逻辑入口，实际宿主注册和参数形式仍待实现验证。

依据：[独立分析契约](../analysis-workflow.md)、[命令与模板](../contracts.md)、[执行承接](../skill-handoff.md)、[存储](../storage.md)及[发布恢复](../release-and-recovery.md)。分析异常分支另见[聚焦排查案例](analysis-investigation-walkthrough.md)。

## 1. 场景、身份及产物约定

假设有一个已有源码的 reader-app，收藏接口在同一用户并发收藏同一文章时偶发 500。数据库已有“用户 + 文章”唯一约束，现有接口约定首次收藏返回 201，重复收藏返回 200；真实数据库不可用应保留现有 503 错误语义。起初项目尚未接入 SDD，用户只想查原因。

主线依次经过：

```text
会话 A：明确独立排查 → init records_only → analyze A（partial）
会话 B：resume（只读） → analyze B（有范围的 answered）
       → init development（补目标基线） → propose（呈现 REV）
       → apply（候选 C1） → verify（失败）
       → apply（修正为 C2） → verify（通过）
       → archive（未发布） → release prepare → release execute（test 成功）
会话 C：status / history（只读回看）
```

RUN-A／RUN-B 等只是文中的执行别名，实际 run／request／operation 使用系统生成的稳定 ID，用户无需填写。业务变更使用虚构友好编号 `CHG-20261027-c5d6e7f8`，以下简称本次修复；REV-001、TASK-001 等编号均为示例，实际须使用系统展示值。C1／C2 为实际源码、配置、依赖及测试范围的指纹简称。

所有路径均为**目标项目内的预期产物**，不是当前 spec-driven 仓库里实际创建的业务文件。本例选择将可读报告统一放入 sdd/exports，便于与可编辑资料分开；这是案例路径选择，不增加新的固定目录契约。

每个写阶段共有的 SQLite 留档是 phase_runs 的当前输入、targets、来源与 input_checks，及时提交的 events／operations，以及结束时一次封存的 result／result_digest。以下逐步只补充本阶段具体内容。跨阶段来源用 source_runs，直接 REV／VER／REL／artifact 用带类型的资料引用；不用一条 previous 链混装所有阶段。

## 2. 会话 A：只排查并留档，自动最小接入

**你发：**

```text
/sdd-propose --analyze
排查收藏接口偶发 500，标题“收藏 500 排查”。
只读取现有源码和我提供的脱敏日志，不修改业务，不重放真实请求。
结果留档；缺少 SDD 时只接必要记录设施，先不要修复或提出修复方案。
```

**由谁执行：** sdd-propose 负责 analyze；发现无记录底座时先加载 sdd-init，使用 records_only 接入，再开始分析。用户不必额外发 init，不会被要求先完成整套产品访谈。

**产生的文档与文件：**

- `sdd/config.toml`、`sdd/history.db`、`sdd/project.md` 最小范围导航；必要的 `.sdd-local/control/` 初始化清单。导航只说明本次观察范围及未知项。
- `sdd/evidence/<RUN-A>/`：必要源码片段／版本摘要、脱敏日志及来源说明。不会复制全部日志或保存凭证。
- 本次未要求独立报告，因此不生成 analysis.md，也不创建业务骨架、proposal、TASK、未来规格或 VER。

**SQLite 预期记录：**

- RUN-I-R：owner=sdd-init，input.profile=records_only，保存实际覆盖、配置／导航引用及记录设施完成结果。没有业务 CHG／TASK。
- RUN-A：owner=sdd-propose，action=analyze，target 为项目，input 中记录问题、范围、完成条件、business_effect=read_only、record=true。
- evidence 的 source_run_id 为 RUN-A、verification_id 为空；事件及时保存已查入口、观察和待查问题。
- 封存 result.analysis：F1“先查询后插入”；F2“已有日志定位到插入路径，但缺错误码”；H1“并发插入触发唯一冲突，未按重复收藏处理”；Q1“缺少同请求错误码及关联日志”。
- RUN-A 状态 completed，answer_status=partial。F1／H1 是 RUN-A 内的局部标记，H1 不是已确认根因。

**你看到的结果及推荐：**

> 已保存本轮排查及必要证据；目前存在并发唯一冲突假设，尚不能确认本次 500 的根因。业务未修改。下一步补充失败请求错误码和关联日志后继续排查，也可以到此结束。

这里“留档完成”只指记录已实际保存，不代表故障已修复；不要求业务归档或验收。

## 3. 会话 B：先只读恢复

你结束会话 A，在同一项目工作区打开新会话，发：

```text
/sdd-resume 收藏 500 排查
```

**由谁执行：** sdd-workflow。

**文档与 SQLite：** 不产生文件、不写 run／事件、不更新索引或 guard。读取 project/config、分析链、RUN-A 结果、证据和当前相关文件，显示目标、F1／F2、H1、Q1、当时资料版本、当前差异及后续限制／纠正。

**你看到的恢复摘要：**

> 找到“收藏 500 排查”，当前分析头为 RUN-A。本轮结论 partial，待补错误码与请求关联。当前相关源码未变；本次仅恢复上下文，尚未继续取证或修改业务。

标题相同的多轮先按链折叠；同名不同主题才澄清。若显式恢复历史 RUN-A，而后来已有 RUN-B，会保留 A 的快照并提示 B，不静默替换。换会话不靠旧聊天恢复，也不自动创建新的修复变更。

## 4. 会话 B：补充证据，明确续查

**你发：**

```text
/sdd-propose --analyze
继续“收藏 500 排查”，结合我补充的脱敏错误码和关联日志核查 H1。
仍只分析，不修改业务。结束后保存一份可读报告。
```

**由谁执行：** sdd-propose 的 analyze 方法。

**模拟新证据：** 两个请求的用户与文章相同、时间重叠；对应插入报唯一约束冲突；现有异常路径将该冲突返回为 500。假定这些记录的对应关系足以支持本例的因果判断，但不能推出所有 500 都来自同一个原因。

**产生的文档与文件：**

- `sdd/evidence/<RUN-B>/` 保存新增必要日志、来源及摘要。
- `sdd/exports/<RUN-B>/analysis.md`：封存结果的生成视图，列事实、假设及其支持范围、结论、限制；头部标来源 RUN-B、result_digest、资料版本和生成时间。
- 不编辑当前规格／项目知识，不创建业务 CHG／REV／TASK／VER。

**SQLite 预期记录：**

- 新 RUN-B：previous_run_id=RUN-A，source_runs 引用 A 的封存结果。start 短事务核对 A 仍为链头、没有其他进行中或已创建后继；相同请求重试返回原 B。
- A／H1 作为 historical_context 重检；本次判断必需的日志和源码作为当前依据分别核查。input_checks 标明用途、必需性、适用性和来源限制。
- result.analysis.answer_status=answered，结论限定为“本组关联请求及对应源码版本的失败由未处理唯一冲突造成”；新增证据与局部条目可追溯。
- A 当时的 partial／H1 文本不改写。B 支持的是 `(A, A.result_digest, H1)` 的限定范围，没有把 A 伪装成第一次就已确认。

**推荐：** 本轮分析可直接结束；若要处理缺陷，再明确提出修复方案。此时不能直接将 RUN-B 当 CHG 去 apply／archive。

## 5. 从记录接入转到开发起点：按范围补基线

为把接入范围展示清楚，本例显式发一次 init；实际也可将“缺基线时先补齐收藏模块基线”写在下一步 propose 请求中，由两个负责 Skill 分别留 run，不必固定多发一道命令。

**你发：**

```text
/sdd-init
基于现有 reader-app 补齐收藏模块开发基线，复用已有 SDD 配置和历史库。
恢复现有行为、代码位置和测试方法，登记已有 test 环境发布适配配置。
只补必要文档和配置，不修改业务、不新增应用骨架、不执行部署。
```

**由谁执行：** sdd-init，input.profile=development。

**产生／更新的文档与文件：**

- 补齐 `sdd/project.md`，按需创建 `sdd/codemap.md`、`sdd/legacy-baseline.md`、`sdd/specs/favorites/spec.md`。
- 记录已经证实的唯一约束、身份边界、首次／重复响应及真实服务错误约定；偶发 500 标为实现缺陷／risk，不包装成希望保留的行为。
- `sdd/config.toml` 仅登记已识别、适用的检查与 test 发布／观察／回滚适配及指纹范围；不能照抄示例命令。这里假设原项目已具备可用适配，不在案例中实现它们。
- 新的未来修复行为仍留给下一步 proposal，不能在 init 提前声称已经实现。

**SQLite 预期记录：**

- RUN-I-D 保存 development profile、实际扫描覆盖、unknown／risk、初始化检查和产物快照；复用原 project_id／history.db。
- 本次明确范围的 initialization 系统记录及必要基线任务，完成范围为文档／导航／配置检查；它独立于后续业务修复 CHG，不要求先 propose。
- artifact_versions／blobs 保存资料快照，spec_items 定位当前基线。RUN-B 的根因结论不因补齐文档就变成业务已实现。

**推荐：** 必要基线可用时进入 propose；存在影响本次修复的关键未知则先澄清。records_only 完成并不自动满足这一条件。

## 6. 明确转修复：创建并呈现方案

**你发：**

```text
/sdd-propose
根据“收藏 500 排查”的最新有效结论提出轻量修复方案，引用证据，先不实施。
同用户同文章重复或并发收藏沿用现有成功语义，不生成重复记录；
保留身份校验以及真实数据库不可用时的 503，不扩大到其他接口。
若已有匹配的活动修复，请继续该变更，不要重复建单。
```

**由谁执行：** sdd-propose 的普通 create／update。本例假设没有匹配活动变更，因此新建 `CHG-20261027-c5d6e7f8`；有明确既有目标则 update。

**产生的文档：**

- `sdd/changes/CHG-20261027-c5d6e7f8/proposal.md` 一份短提议，内嵌必要增量、AC、范围／非目标、风险、开放问题和任务概要。
- 本例不额外创建空 design.md、delta-spec.md、tasks.md；当前规格不被未来方案覆盖。

**方案示例：** 精确识别对应唯一冲突、按现有重复收藏语义返回；其他数据库异常维持原错误路径；加入并发、隔离及失败回归。

- AC-001：同一用户同一文章并发收藏，一次首次成功、另一次按已有重复成功响应，最终仅一条记录，不出现本缺陷导致的 500。
- AC-002：顺序重复保持成功语义，不同用户收藏相互隔离。
- AC-003：未登录／无权限行为保持现有约定。
- AC-004：真实数据库不可用仍为原 503，不能被当成重复收藏成功。

**SQLite 预期记录：**

- RUN-P 引用 RUN-B 及初始化资料，核对当前相关源码、后续纠正与实际基线；分析来源是判断依据，不是执行授权。
- changes 创建本次 bugfix，plan_revisions 绑定 REV-001、proposal 快照、增量／验收引用和任务定义摘要，并记录已向用户呈现的版本。
- tasks 保存完整定义／依赖：TASK-001 异常分流与响应处理；TASK-002 回归检查；proposal 只写概要，状态由 DB 管。
- 无关键未决则生命周期 ready；尚未接受实施。RUN-P 通过 source_runs 引用分析，不能用 previous_run_id=RUN-B 混入分析链。

**你看到：** 修复方案已呈现，下一步可以 apply；尚未修改业务。发现关键行为选择不明时先澄清，不自动替用户决定。

## 7. 实施：apply 接受有效修订

**你发：**

```text
/sdd-apply CHG-20261027-c5d6e7f8
```

**由谁执行：** sdd-apply。这个指令接受已呈现且仍有效的 REV-001，不要求额外 approve。默认执行全部就绪任务。

**预期文件变化：** 业务异常处理源码和必要回归测试发生实际修改；`sdd/evidence/<RUN-AP1>/` 保存任务检查依据。本例假定任务级的正常／重复收藏检查通过，得到候选 C1；当时未覆盖稍后验收中的特定连接故障注入，检查范围及限制如实记录，不将 AC-004 写成已通过。无需另写手工进度表或复制 proposal。

**SQLite 预期记录：**

- RUN-AP1 核对有效 REV、材料摘要、依赖、当前意图及来源。
- 保存 REV-001 的 plan.accepted 事件与接受来源；changes 进入 active，任务逐项 start／finish，保存实际变更、检查方法、证据及限制。
- 保存 C1 实现指纹及结果引用，封存 RUN-AP1。任务 done 是实际实施／检查记录，不能代替变更级验收。

**推荐：** `/sdd-verify CHG-20261027-c5d6e7f8`；只请求 apply，因此不自动替用户发布。

## 8. 独立验收：发现失败，保留证据

**你发：**

```text
/sdd-verify CHG-20261027-c5d6e7f8
按全部有效 AC 验收，包含隔离环境的并发、权限和数据库失败场景，保存验收报告。
```

**由谁执行：** sdd-verify。在当前请求允许的受控测试环境运行，不对真实用户数据重放故障。

**模拟结果：** AC-001／002／003 通过；AC-004 失败——某类连接故障被过宽异常处理误判为重复成功。这是 C1 的实现不符合已约定方案，不是新需求，不因修正它自动创建新 REV。

**产生的文档与文件：**

- `sdd/evidence/<RUN-V1>/`：本次实际检查、环境、输入和输出摘要／必要附件。
- `sdd/exports/VER-001/verification.md`：数据库生成的本次失败报告，标候选 C1、REV-001、AC 映射及限制。

**SQLite 预期记录：**

- RUN-V1、verifications 中的 VER-001、verification_items 的逐项结果，关联证据及检查前后 C1 指纹。
- VER-001 总结 failed；失败不被此前任务 done 或其他三项通过遮盖。归档／发布条件不满足。
- 保存失败范围和回到实施的建议；verify 不静默修业务代码，不删除失败记录，也不伪造修复完成。

**推荐：** 对原修复变更 apply，修正异常分类并补覆盖该场景。若发现需要改变原行为／范围／AC，才先 update、呈现新修订。

## 9. 回到实施并复验：同一修复，形成新候选

**你依次发：**

```text
/sdd-apply CHG-20261027-c5d6e7f8
修正 VER-001 指出的异常误判，补充相应回归，保持 REV-001 范围。
```

本次 RUN-AP2 核对失败证据，按实际原因重开相关任务，保留旧完成事件；精确分流异常，得到候选 C2。旧 C1 的验证不再作为 C2 的有效通过依据。必要任务检查和新证据进入 `sdd/evidence/<RUN-AP2>/`。

```text
/sdd-verify CHG-20261027-c5d6e7f8
针对当前候选重新核对全部有效 AC 和相关回归，保存报告。
```

**SQLite 预期记录：** RUN-V2、VER-002，固定 REV-001、C2 和当前检查配置；逐项 AC-001 至 AC-004 适用且均通过，前后候选未漂移，必需回归完整。RUN-AP2 与 RUN-AP1 属于同类续作，可关联 previous；两个 verify 的新旧关系也不抹去 VER-001。

**产生的文档与文件：** `sdd/evidence/<RUN-V2>/` 和 `sdd/exports/VER-002/verification.md`。旧 VER-001 报告及正式失败证据保留。

**推荐：** 现在“可归档”由任务闭合、当前有效验收通过、无关键问题及引用完整派生，不新增一个手工 done 状态，也不表示已经上线。

## 10. 归档：同步规格，保留未发布事实

**你发：**

```text
/sdd-archive CHG-20261027-c5d6e7f8
保存归档摘要，本次先不发布。
```

**由谁执行：** sdd-archive，内部包含必要 sync。用户无需另发 sync。

**产生／更新的文档：**

- 基于已验证实现更新 `sdd/specs/favorites/spec.md` 的对应条目；本例将并发重复仍成功、真实服务错误仍保留原语义的验收约束作为经验证增量补齐；异常分类的具体实现留在代码／方案中，已存在的行为条目引用原编号而不重复新增。
- proposal 等本次有效材料移入 `sdd/changes/archive/CHG-20261027-c5d6e7f8/`。
- 按本次要求生成其中的 `archive-summary.md`，记录冻结修订、实现 C2、有效 VER-002、失败修正过程及归档时未发布事实。它是生成视图，不手写状态替代 DB。
- 正式分析／任务／验收证据保持稳定 artifact 身份，不因归档复制多份。

**SQLite 预期记录：**

- RUN-ARCH 逐项核查 REV-001、C2、VER-002、任务范围和当前基线；执行可恢复文件／DB 操作。
- spec_applications 保存稳定增量、基线及结果摘要、验收与操作引用，重复请求不重复应用。
- artifacts 更新当前路径，历史快照引用不改写；changes 生命周期 archived，保留归档时间与冻结范围。
- 归档结束时尚无实际发布记录，展示 unreleased；这与 archived 是两项独立事实。

归档移动和有证明的规格同步不改变验收含义，不因 CHG 行版本增加一律废弃 VER-002。出现冲突／中断时保留现场并恢复，不能宣称全部成功。

## 11. 发布准备：固定版本、环境和候选

**你发：**

```text
/sdd-release prepare
将 CHG-20261027-c5d6e7f8 纳入 v1.4.3，目标 test，使用已验收候选 C2。
生成发布说明、检查清单和回滚方案，先不部署。
```

**由谁执行：** sdd-release。C2 是系统展示的当前候选简称，不要求用户自己计算摘要。

**产生的文档：**

- `sdd/releases/REL-001/release-notes.md`：修复的问题、纳入变更及范围。
- `sdd/releases/REL-001/checklist.md`：候选一致性、test 环境部署及上线后检查。
- `sdd/releases/REL-001/rollback.md`：触发条件、原项目已知的恢复目标／配置、步骤及恢复检查。假设本例恢复目标为 test 的 v1.4.2；准备不代表执行回滚。

**SQLite 预期记录：**

- RUN-RP、REL-001（prepared）、release_changes 关联本次已归档修复、REV-001、C2、有效验收和准备材料摘要。
- 核对必要证据适用于同一最终候选，配置／材料有效，没有本地待恢复事项或环境未决占用。
- 若材料／执行配置变化，需要更新准备并重核依据；候选或目标环境变化按发布契约处理，不能沿用旧成功。

**推荐：** 明确执行 test 发布，或停留在准备完成。prepare 不调用部署命令，不改写归档时的 unreleased 快照。

## 12. 实际发布并记录结果

**你发：**

```text
/sdd-release execute REL-001
将已准备的 v1.4.3 / C2 发布到 test，使用项目现有适配并核实结果。
```

**由谁执行：** sdd-release。这个请求才覆盖实际 test 部署；本例假设所需适配可用、检查与准备仍有效。

**模拟成功依据：** 适配返回与请求匹配的操作、候选、test 环境及实际外部部署引用；对应部署已结束，配置要求的部署后检查通过。不能仅凭进程退出 0 写成功。

**产生的文件：** `sdd/evidence/<RUN-RE>/` 保存必要部署／健康检查依据；准备材料仍为原三份，不额外手写一份“已成功”正文充当事实。

**SQLite 预期记录：**

- RUN-RE 在执行前登记 release_attempt、稳定外部幂等键、候选、环境及请求摘要，并建立环境未决占用，再调用外部程序。
- 记录执行结果、external_id、实际环境观察、observed_at、检查证据及来源；核实成功后 REL-001 汇总 succeeded，解除对应占用。
- changes 仍 archived；追加发布关联。归档摘要保留当时 unreleased，当前查询显示本次修复已随 REL-001 在 test 发布成功。
- RUN-RE 结束结果封存；策略备份／知识检查属于支持步骤，不要求用户再发命令，后置备份失败如实提示但不抹去已确认部署事实。

成功限定为 **C2 在 test 环境的本次发布及观察**。production 尚未发布；后续交付 production 必须有该环境的独立发布准备／执行依据，不能沿用 test 的成功状态。

## 13. 会话 C：回看完整历史与经验

在后续新会话，你可以发：

```text
/sdd-status CHG-20261027-c5d6e7f8
/sdd-history 查询“收藏 500 排查”以及关联修复的分析、验收、归档和发布历史
/sdd-release status REL-001
```

这是三项只读查询，不产生 run／报告／业务修改。status 显示当前修复范围已归档、test 的最近确认发布及观察时间；history 展示 A 的 partial、B 的有限根因结论、REV 接受、C1 失败、C2 通过、归档、REL 的准备和实际尝试。标题不是长期身份，查询通过关联定位实际 run／CHG／VER／REL。

**经验如何留下：** 阶段结束可由 learn 支持方法将本次证据足够的项目经验记录为有条件建议：“有唯一约束的先查后插场景，应以精确唯一冲突处理并发重复，并保留其他数据库故障语义。”SQLite 记录适用范围、支持证据、C1 反例和 C2 验收结果；不足以泛化时维持 candidate。

后续类似提议按需检索经验，记录是否采用及实际效果；active 仍只是建议，不是自动生效的正式规则。正式规则／个人库晋升需要具体确认和负责的 learn run，不作为发布后必经步骤。本案例无需再手动 retro；用户要求集中复盘时才另发对应命令。

## 14. 最终文件和 SQLite 关系

以下仅为本例预期结构：

```text
reader-app/
├── 既有业务源码与回归测试                 # 修复阶段才修改
├── sdd/
│   ├── config.toml
│   ├── history.db
│   ├── project.md
│   ├── codemap.md
│   ├── legacy-baseline.md                 # 本例需要而创建
│   ├── specs/favorites/spec.md
│   ├── changes/archive/CHG-20261027-c5d6e7f8/
│   │   ├── proposal.md                    # 可编辑语义材料的冻结版本
│   │   └── archive-summary.md             # 归档时的生成视图
│   ├── evidence/
│   │   ├── <RUN-A>/                       # 首轮观察与假设依据
│   │   ├── <RUN-B>/                       # 续查新证据
│   │   ├── <RUN-AP1>/                     # C1 任务检查
│   │   ├── <RUN-V1>/                      # C1 失败证据
│   │   ├── <RUN-AP2>/                     # C2 修正与检查
│   │   ├── <RUN-V2>/                      # C2 通过证据
│   │   └── <RUN-RE>/                      # test 部署及观察
│   ├── exports/                           # 可再生成，不是唯一证据
│   │   ├── <RUN-B>/analysis.md
│   │   ├── VER-001/verification.md
│   │   └── VER-002/verification.md
│   └── releases/REL-001/
│       ├── release-notes.md
│       ├── checklist.md
│       └── rollback.md
└── .sdd-local/                            # 必要控制清单／暂存／保护备份
```

正式恢复包包含数据库、配置、权威 Markdown 及所有必要证据，不依赖 exports；history.db 随 Git 保存，但 Skill 不自动提交／推送，也不把 Git 回退当作线上回滚。

**关键关系：**

```text
分析链 previous：RUN-A → RUN-B
                       │ source_runs（经重核）
                       ▼
RUN-I-D 的基线 ─────→ RUN-P：CHG / REV-001
                       │
                       ▼
RUN-AP1：C1 → RUN-V1：VER-001 failed
                 │             │
                 └────→ RUN-AP2：C2 → RUN-V2：VER-002 passed
                                          ├──→ RUN-ARCH
                                          └──→ RUN-RP → RUN-RE
                                                 ▲       ▲
                        归档材料及当前领域依据 ────┴───────┘
```

除首行分析链外，其余箭头表示来源／领域依据关系，不代表统一 previous 链。archive 与 release 均核对适用 VER，不能只相信最近一个 run。resume／status／history 没有写入，因此不是执行链节点。普通阶段支持备份／经验也不额外制造独立业务阶段。

## 15. 换会话遇到异常时，指令怎样变化

这些是按需分支，不是主线额外必走步骤。

**分析中断：** 如果 A 仍 started 且拥有者已确认异常退出，系统推荐实际目标：

```text
/sdd-recover --run <系统展示的分析 RUN>
```

maintain 创建 RUN-M，核对已提交进度、证据，给原 A 封存 interrupted，不补造根因。下一次明确 analyze 续查，previous 仍指 A，source 可引 A 的恢复摘要及 M；不能 previous=M。若 A 已正常 completed + partial，直接续查，无需 recover。

**报告失败：** B 已封存但 analysis.md 生成失败，显示 VIEW_STALE；发 `/sdd-export <系统展示的 RUN-B> 的分析报告`，maintain 只重导原结果，不新建 analyze 后继或重查业务。报告不能覆盖来源／规格／proposal。

**部署超时／回执丢失：** REL-001 为 unknown，保留未决占用，不重发 execute。你发：

```text
/sdd-release status REL-001 --refresh
```

release 创建观察 run／attempt，按外部操作引用核实实际状态和原尝试是否结束，保存证据后更新观察。仅“当前版本看起来正确”不足以证明所有未知操作已结束；无法核实继续 unknown。没有 --refresh 的 status 只读本地，不查询外部。

**已存在修复：** 新会话再次要求处理相同问题时，定位已有活动 CHG 并按意图 update／apply；需要重大行为修改先呈现新 REV，不能把 RUN-B 结论当成新方案接受。已经归档后再改业务，创建后继 CHG，不重开旧档案。

## 16. 实际使用可以更短

本例把每项动作拆开用于理解职责；日常只需表达明确目标，不必管理 RUN、摘要或 SQL：

- 首轮：“只查原因，留档，不修复。”
- 换会话：“恢复这项排查”；补资料后“继续查”。
- 决定修复：“补齐必要基线，提出修复方案，先不实施。”
- 看过有效方案后：“apply；完成后验证，通过再归档。”这已覆盖连续范围，各阶段仍独立留 run；关键新选择先澄清。
- 需要交付：“准备 v1.4.3 的 test 发布”；看过材料后“执行 REL-001”。

分析完成、修复实施、验收通过、归档、环境发布各有可追溯依据。读业务不等于不留档，分析 answered 不等于已修复；文件可读不代表它是可独立编辑的事实来源。

本文仅用于检查 0.5.2 使用路径及记录契约，没有执行上述业务命令；不能作为 V 系列功能验收通过证据。
