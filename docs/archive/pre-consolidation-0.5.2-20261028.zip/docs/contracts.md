# 配置、工具接口与文档契约

状态：0.5.2 双路径设计审查修订，尚未实现；本轮仅设计文档、实施计划和 SVG，不开始插件编码。

## 0. 常用入口与完整归属

开发入门只展示 init、propose、apply、verify、archive、release 六项；独立分析使用 propose 的 --analyze 子动作，完整场景见 [user-guide.md](user-guide.md)。目标参数可在唯一明确时省略，工具负责定位并在输出中说明；用户不填写 request／run／operation ID、摘要或 SQL。下面的完整注册清单供高级使用和宿主适配，动作归属只有这一份。


以下 `/sdd-*` 是建议的逻辑别名；宿主可能使用 `$sdd-*`、Skill 选择器或带插件命名空间的入口。安装时验证实际注册及参数，不占用宿主 `/init`、`/archive`。不支持短别名时保留所属 Skill 加动作的调用形式。

- `sdd-workflow`：`/sdd-workflow <意图>`、`/sdd-status [目标]`、`/sdd-next [目标]`、`/sdd-resume [目标]`。只读路由、状态与续接。
- `sdd-init`：`/sdd-init [项目]`。开发接入；明确独立分析留档且无底座时内部选择 records_only，见下述初始化契约。
- `sdd-propose`：`/sdd-propose <需求>`、`/sdd-update <CHG> <修订>`。创建和修订变更规划（转修复先定位已有 CHG，避免重复建单）；`/sdd-propose --analyze <问题及范围>` 负责独立留档分析，不创建 CHG。均属同一 Skill。
- `sdd-apply`：`/sdd-apply [CHG] [任务]`。接受已呈现有效方案并实施。
- `sdd-verify`：`/sdd-verify [CHG] [范围]`。独立验收与真实证据。
- `sdd-release`：`/sdd-release [prepare|execute|record|status|rollback] <目标及参数>`。发布准备、实际执行／登记、外部状态核实与回滚。
- `sdd-archive`：`/sdd-sync <CHG>`、`/sdd-archive [CHG]`。规格同步及封存，archive 包含必要同步。
- `sdd-learn`：`/sdd-learn <动作及参数>`、`/sdd-retro <CHG或阶段>`、`/sdd-experience search|review|promote|disable <参数>`。经验检索、复盘、审阅与确认晋升。
- `sdd-maintain`：`/sdd-maintain doctor|history|export|cancel|backup|restore|recover <参数>`；别名 `/sdd-history <条件>`、`/sdd-export <范围与格式>`、`/sdd-cancel <CHG> <原因>`、`/sdd-recover <OP>` 或 `--run <RUN>`／`--journal <路径>`／`--history`。维护档案和一致性。

backup／restore 通过 `/sdd-maintain backup|restore` 触发。目标、环境或候选不明确时先澄清，不按最近聊天猜测。明确 analyze 或分析留档请求时，router 交 sdd-propose 执行；普通解释默认不留档。业务只读不等于 SDD 不写：analyze 可写 run／证据／按需报告；status／resume 等纯查询仍无副作用。详细边界见 [analysis-workflow.md](analysis-workflow.md)。

省略子动作时，release 默认 prepare，workflow 默认 status，maintain 默认 doctor，learn 默认说明可用动作；后三者均只读。

- `/sdd-status`、`/sdd-next`、`/sdd-resume`、`/sdd-history`、maintain doctor、experience search／review 默认只读。review 变更经验状态或提案决定时须携带明确决定与目标版本，是写动作。
- `/sdd-release status <REL>` 只读本地；加 `--refresh` 才查询外部并登记观察。该读写边界适用于全部宿主和底层接口。
- `/sdd-experience promote <EXP> --target project-rule|checklist|personal` 默认准备并呈现提案，不写正式规则或个人库；`promote --apply --proposal <ID> --revision <版本>` 在已取得该具体候选确认后生效。已有明确确认可直接完成，不再次索要同一确认。
- export 会写派生报告，backup／restore／recover 为写阶段；cancel 不回退源码。阶段方法均遵守当前意图，直接入口和路由入口核查相同。

本映射是未来宿主入口清单的来源；Skill 职责见 [multi-skill-plugin.md](multi-skill-plugin.md)，执行结果和输入核查字段见 [skill-handoff.md](skill-handoff.md)。实际打包时需自动校验一条别名恰有一个 owner，不能让入口包装复制阶段业务规则。

## 1. 配置

初版采用 `sdd/config.toml`；固定 `history.backend="sqlite"` 是格式声明，不是供用户切换后端的菜单。

```toml
config_version = 1

[project]
id = "00000000-0000-0000-0000-000000000001"
name = "sample-project"
language = "zh-CN"

[history]
backend = "sqlite"
database = "sdd/history.db"

[paths]
specs = "sdd/specs"
changes = "sdd/changes"
decisions = "sdd/decisions"
evidence = "sdd/evidence"
releases = "sdd/releases"
local = ".sdd-local"

[workflow]
archive_requires_release = false
# 若改为 true，必须另设 archive_release_environment = "test"
apply_default = "all_ready"
manual_verification_allowed = true

[fingerprint]
include = ["src", "tests", "scripts", "package.json", "package-lock.json"]
exclude = ["node_modules", "dist"]

[checks.unit]
argv = ["npm", "test", "--", "--runInBand"]
cwd = "."
timeout_seconds = 300

[release.environments.test]
deploy_argv = ["python", "scripts/deploy.py", "--target", "test"]
status_argv = ["python", "scripts/deploy_status.py", "--target", "test"]
rollback_argv = ["python", "scripts/rollback.py", "--target", "test"]
cwd = "."
timeout_seconds = 600
```

以上只是说明格式的虚构项目配置；init 必须识别真实项目后生成适用项。records_only 只生成必要配置和范围导航，不填入检查／发布示例，不声称开发基线完成；development 才按实际目标补齐开发起点。profile 是 init 输入／结果中的范围，不是另一个历史后端或配置状态机。不能把示例检查和发布命令原样写入所有项目。项目 UUID 由工具生成，配置中的示例值不得照抄。

- 用户无需懂 TOML 或 SQL；可以用自然语言要求 Agent 配置和更新，再经工具校验。
- archive_requires_release 默认为 false；若显式启用，必须配置 archive_release_environment，门禁核对该环境、当前候选及当前可确认成功，不以任意历史成功代替。
- 配置版本、路径、枚举、超时、可执行命令参数均有类型检查。未知关键字段提示错误，不静默忽略拼写。
- `fingerprint.include` 缺省时采用自动发现；显式指定后报告范围，并提示目录外新业务文件需要纳入。配置本身与依赖锁文件始终纳入校验依据。
- 项目资料、执行 cwd、导出及恢复路径相对项目根并防止越界／链接逃逸。插件资源从只读安装根定位；唯一受控的项目外写入是用户已确认的 personal 晋升目标，按个人库协议定位，不能用普通 artifact 路径越过项目边界。
- 运行时凭证由现有环境或项目既有机制提供，不把值写入配置、数据库或报告。
- 配置变更产生事件和摘要；对验证或发布有影响时旧准备状态失效。
- 首版不提供任意插件加载代码或 shell 模板解释器。需要 shell 时在参数数组中显式指定解释器和脚本，由项目定义。

## 2. 工具入口

Agent 从插件资源清单定位共享内核，按负责 Skill 的方法解析入口，调用形式：

```text
python <plugin-root>/runtime/sdd.py --project <project-root> <action> --json
python <plugin-root>/runtime/sdd.py --project <project-root> <action> --input - --json
```

`--input -` 从标准输入读取 UTF-8 JSON，避免把多行文档、引号或敏感参数拼进 shell 命令。`python` 是描述性的解释器名；宿主先探测实际可用命令，不硬编码开发机路径。

工具动作职责：

- `phase prepare | start | finish | inspect`：调用 Skill 持有阶段，内核按 request_id、输入、版本及 epoch 幂等登记，不能借通用接口绕过归属。
- `evidence record`：写入来源 run 和证据引用，verification_id 可空；不能因独立分析伪造验收记录。
- `doctor`：运行时、配置、数据库、未完成操作与引用完整性检查。
- `init`：input.profile=records_only|development；记录接入与开发起点分别核对完成条件，复用已有设施，不自行决定业务技术栈。
- `change create | revise | accept | cancel`：维护规划、接受记录与生命周期。
- `task start | finish | block | reopen`：检查依赖和版本，事务记录结果。
- `verify run | record`：运行已配置检查或登记真实观察证据。
- `release prepare | execute | record | status | rollback`：发布记录及执行尝试。
- `spec sync`、`archive`：采用操作日志安全同步／移动材料。
- `status`、`next`、`resume`、`history`：只读查询，按需分页；支持项目分析标题／RUN 与 action=analyze；标题按链折叠，显式 RUN 展示该快照和当前链头，目标不唯一则澄清。
- `knowledge record`、`experience search | review | record | disable`、`promotion prepare | apply`：支持知识检查、经验版本、应用反馈、提案及确认晋升；search／review 默认只读，其余按负责者和支持步骤规则写入。
- `export readable | recovery`、`backup`、`restore`、`recover`：报告、可恢复包和中断恢复。

analyze 由 Agent 使用共享 phase／evidence／artifact 工具完成，不由新增 Python analyze 子命令假装自动推理。phase 输入允许 action=analyze、项目级 targets 和业务只读／留档策略；续查带 previous_run_id 和准备时链头前置条件，start 核对唯一顺序后继。source_runs 仅为执行引用；其他领域／资料引用进入 input.references。字段与用途核查以 [run 协议](skill-handoff.md) 为准。

这些是底层确定性接口；不是让用户学习更多命令。Agent 层的 propose/apply 由多次读写与实现动作组成，不由单一 Python 子命令假装完成所有业务判断。

## 3. 请求与响应

典型写入请求：

```json
{
  "operation_id": "7afdf7e0-42cf-4d51-8e79-130ef3b0c650",
  "request_id": "52ea9433-e3b8-4545-a928-e1096083f640",
  "owner_skill": "sdd-propose",
  "run_id": "fe69ee7e-640e-44ef-b84f-6b390635a763",
  "expected_workspace_epoch": "9b6cfec4-f0ac-4923-9395-e3666c50e553",
  "source_runs": [],
  "targets": [{"entity_type": "change", "entity_id": "CHG-20261026-8f3a91c2"}],
  "expected_versions": [{"entity_id": "CHG-20261026-8f3a91c2", "row_version": 4}],
  "reason": "用户要求增加失败回滚场景",
  "payload": {
    "artifact_paths": ["sdd/changes/CHG-20261026-8f3a91c2/proposal.md"]
  }
}
```

示例为已 start 的一次规划写入；实体键可由工具解析友好编号，run／request／epoch 使用 UUID。start 请求尚无 run_id，已有 guard 时携 expected_workspace_epoch；首次明确写请求可用“guard 不存在”的前置条件，在短锁和控制清单下建立 epoch，若别的写入已建 guard 则拒绝旧前置。init／restore journal 的身份例外按恢复协议处理。每次子动作沿用 request_id，使用自己的 operation_id。

响应固定信封：`ok`、`action`、`operation_id`、`data`、`warnings`；失败增加 `error.code`、`error.message`、`error.next_steps`。文本模式复用同一结果，不由两套业务逻辑生成不同事实。

- 成功退出 0；输入／前置条件错误退出 2；版本／占用冲突退出 3；需恢复退出 4；外部执行失败或结果未知退出 5；非预期内部错误退出 1。
- 返回结构包含 committed、run_id、提交后的实体版本和摘要、业务 outcome、知识检查及 view／backup 状态。ok 只表示接口动作成功，不表示业务验证通过；发布未知／执行失败返回明确错误与已提交事实。派生报告或后置备份失败不否认 committed。
- 当前 epoch 下先查幂等记录：同一操作 ID 且输入一致返回原提交结果及其历史时效，不再次要求旧 expected_versions 等于现值；同 ID 不同输入拒绝。仅首次写入核对当前版本；操作未完成返回恢复状态。epoch 已切换则旧执行请求拒绝，不能绕过恢复边界。
- 未知操作结果不会用成功信封掩盖。原始异常可写本地诊断，用户摘要不输出环境凭证。
- 读命令没有副作用，不因 `resume` 自动迁移、修复或执行发布。

## 4. Markdown 识别规则

不实现通用 Markdown 或 YAML 解释器。模板提供少量确定的标题约定，工具用稳定标识和摘要检查，业务语义由 Agent 负责。

当前规格最小结构：

```markdown
# Capability: 收藏

## Purpose
用户可以保存稍后阅读的文章。

## FR-001: 收藏文章
确认依据：用户确认与当前实现的对应证据。
行为：登录用户可以收藏一篇文章。

## AC-001: 重复收藏
关联：FR-001
Given 已收藏的文章，When 再次收藏，Then 不生成重复记录。

## Open questions
没有未决关键问题；普通未决项按 OQ 编号记录。
```

- 需求与验收使用明确标题和稳定编号，避免依赖段落顺序定位。
- 历史项目的每项行为另外注明确定性和代码／测试／文档依据。
- 文档可增加合理章节，不要求每个模板都填满；空问题不必生成虚构条目。
- 工具只能检查结构和引用存在，不能仅凭 Given/When/Then 字样判定验收有效。
- 增量规格明确 `ADD`、`MODIFY`、`REMOVE`，引用原编号及基线；工具接收已确定的新正文和预期原文摘要，冲突时拒绝全文覆盖。
- 外部文档若不能无损纳入固定标题格式，保留原文并通过 artifact 映射和显式条目索引接入，不自动重写整个文档库。

## 5. 按需模板与编辑权限

字段权威以 [domain-model.md](domain-model.md) 为准。可编辑资料包含 project、规格、proposal、必要设计／决策、正式规则和发布准备材料；tasks、verification、archive-summary、execution-summary、resume 和经验摘要是只读生成视图。SQLite 的文档快照只保存过去版本，不另建同权当前正文。

轻量或普通小变更默认一份 proposal：原因、范围与非目标、必要增量和 AC、风险／问题、任务概要及结果引用。完整任务定义和依赖由数据库维护，提议不复制可独立修改的任务清单。行为变更需要的增量可以内嵌于 proposal，有实际复杂度时才拆 delta-spec／design。


首版按需提供以下模板，不在 init 时一次性创建所有空文件：

- `project.md`：用户、问题、目标、非目标、约束、业务背景、成功标准、资料导航和开放问题。
- `codemap.md`：实际入口、主要模块、数据与权限边界、测试位置、常见改动位置和未知范围。
- `legacy-baseline.md`：扫描范围、确认行为、推断、缺陷／风险和未知项的证据清单。
- `proposal.md`：原因、范围、非目标、必要行为增量及验收、任务概要、风险和待决问题。TASK 仅引用，不在此手工维护进度。
- `delta-spec.md`（需要分文件时）：操作、目标条目、基线与新行为、验收及兼容影响。
- `design.md`：候选方案、选择理由、影响面、接口／数据、验证与回滚考虑；标准变更按需创建。
- `decision.md`：上下文、选择、依据、后果、来源变更和被替代关系。
- `verification.md`：逐项验收、实际方法、结果、版本／范围、证据与限制，数据库生成。
- `release-notes.md`、`checklist.md`、`rollback.md`：版本与环境、变更集合、部署前后检查、触发条件、恢复步骤与验证。
- `archive-summary.md`：从冻结修订、领域结果与应用记录生成实际交付和遗留问题；动态发布状态按查询时事实展示，不回写冻结档案。
- `analysis.md`：按需由分析 run.result 生成，区分事实、假设、结论与限制；默认位于 sdd/exports/<run-id>/，不是可独立编辑的分析正文。
- `execution-summary.md`：从 run 的 result 和 input_checks 生成，展示来源、实际范围、阻碍与证据；不单独生成交接档案或回执。
- `tasks.md`、`resume.md`：生成视图；resume 默认直接返回，需要保存时才生成文件。

生成视图头部包含 `generated_from`、`entity_id`、`record_version`、`generated_at` 和相关 digest。直接修改视图会被识别，工具不会反向猜测它代表了何种业务状态变更。

视图按需生成或刷新，时效由记录版本判断。权威数据库已经提交而报告生成失败时，返回已提交的事实和 `VIEW_STALE` 提示，后续重新生成；不能将任务状态回退或重复执行真实操作来修复显示问题。单独导出旧 analysis.md 使用 maintain export，并绑定原 run／result_digest，不新建 analyze 后继。目标路径禁止覆盖权威材料、业务文件或来源证据。

## 6. 默认输出粒度

常规查询默认不落盘报告；显式保存／导出才生成文件。必要快照、引用、证据仍留档，追溯不依赖是否生成可读报告。

每个动作结束给用户简洁说明：做了什么、实际结果、未完成／受阻部分、需要阅读的材料及下一步。完整事件、原始命令输出和数据库字段不默认展示。

恢复包与摘要报告明确区分；只读查询默认展示最近摘要，用户追问时再展开修订、任务或证据。这样既保留过程，也不要求用户关注每个执行细节。
