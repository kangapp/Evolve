# 执行记录、结果复用与轮转协议

状态：0.5.2 双路径设计审查修订，尚未实现；本轮仅设计文档、实施计划和 SVG，不开始插件编码。

## 1. 单一承接机制

```text
来源 run：输入依据 → 实际执行 → 封存 result
                                  ↓ 引用
下一 run：核查 source_runs / 领域记录 → 记录 input_checks → 执行
```

phase_runs 一条执行记录保存本次输入、核查和实际结束结果。result 内保存摘要、领域记录和证据的稳定引用，不复制 VER、REL、任务等全部正文。跨阶段承接直接引用 run_id + result_digest；多输入、多目标仍可表达。

独立 handoffs、handoff_receipts 和 source_handoff_ids 属于已被替代的 0.4.1 方案，首版不创建对应表、接口、协议版本或迁移。当前尚无实现库，因此不存在删改用户历史的问题。必要关系可由无独立生命周期的 run 关联行索引，不恢复一套交接状态机。

## 2. 用户与阶段边界

先区分业务副作用与是否留档：纯查询／即时不留档解释直接返回；独立 analyze 虽不修改业务，仍是 SDD 写阶段，完整建立 run 并封存结果，见 [分析路径](analysis-workflow.md)。

用户明确动作 → 负责 Skill 核查 → 建立 run → 执行 → 封存实际结果 → 显示下一步。宿主能原生加载 Skill 时使用其机制，否则当前 Agent 显式加载负责者方法。直接入口不跳过核查。

六个常用命令、自然语言请求和高级入口使用同一规则。只有一个明确目标时自动定位并说明；多目标含糊才澄清。用户明确多个阶段时可在范围内继续，各自留 run；只请求单阶段时不自动扩大。推荐、历史接受和来源结果均不创造新执行授权。

![执行记录与跨阶段复用](diagrams/15-skill-handoff-and-rotation.svg)

## 3. 写阶段内部生命周期

这些步骤由共享内核支撑，用户无需逐项触发，Skill 不各自实现一套：

1. **prepare**：解析目标、当前意图、资料、来源结果、关键问题和恢复阻碍。纯查询或即时不留档解释在此返回，不建 run、不分配编号、不标 stale、不改 guard／索引、不备份或迁移。
2. **start**：按稳定 request_id 幂等建立 run，事务内复核当前版本、workspace_epoch 和前置条件，将 source_runs、targets 及 input_checks 写入该 run。init 建库前先保存同一身份的控制清单。
3. **execute**：子动作按 operation_id 及时保存任务、验证、发布尝试或操作进度；每次写入再核对当前条件。不能跨对话或长命令持有事务，也不能把数据库锁当作源码锁。
4. **finish**：按稳定 operation_id 事务提交 run 终态、result、result_digest 和事件。一个 run 只有一个结束结果，响应丢失返回既有结果；报告或完成点备份失败不重跑业务。
5. **present**：展示实际结果、主要限制、相关材料及建议。下一步从当前事实计算，不单独持久化 next_candidates 状态；结果中的历史摘要不充当当前推荐清单。

阶段唯一请求键为 project_id + workspace_epoch + request_id；相同输入重试返回既有 run，不同输入拒绝。子动作 operation_id 在执行前固定，不以换 ID 绕过未知结果。当前 epoch 下已提交重试先核对幂等记录再返回历史事实；首次写入才核对新提交的 expected_versions。

run 从 started 结束为 completed／blocked／failed／interrupted，终态不重开。新工作创建新 run；previous_run_id 只表达同类执行的续接，跨阶段来源放 source_runs。分析链要求同项目 action=analyze，单链按顺序续接，见第 6 节；completed 表示本次动作结束，不能替代领域对象的验收或发布结果。

## 4. result 的最小字段

- 所属 run 已保存 owner_skill、action、项目、targets 和开始／结束时间，不在 result 重复建立来源身份。
- result 保存实际完成摘要、未完成和阻碍、限制、产物／领域记录／证据引用及对应不可变版本。
- `basis_refs[]` 引用有效规划修订、任务定义摘要、VER／候选、配置摘要、规格应用证明等必要依据；已有权威记录的值通过引用读取。
- 独立分析可包含 result.analysis：已确认观察、明确标注的假设、有范围的结论、answer_status（answered／partial／inconclusive）及剩余问题；不把 completed 等同问题已经解决。
- 知识处理状态和相关经验版本／应用记录。无新经验、pending 和 unavailable 分别记录，不要求每阶段写复盘文档。
- 封存 result 使用规范化字节摘要 result_digest；结果不整段复制聊天或原始输出。

分析 action=analyze 的 input 保存标题、analysis_kind、目标／问题、范围、完成条件、business_effect=read_only、record=true。标题用于检索，不成为新实体；来源与核查仍用相同 run 字段。

普通结束结果不可覆盖。源码已改但检查未记录时明确未知；恢复可给未结束 run 封存 interrupted 及确认过的部分事实，标明 finalized_by 和恢复 run，不能伪造原 Skill 已完整 finish。已封存结果发现错误，通过纠正事件或后继 run 补充。

## 5. input_checks 与多输入核查

`source_runs[]` 只装来源执行引用，每项包含 run_id、result_digest、对应 target、purpose 和 required；purpose 至少区分 historical_context（历史上下文）与 decision_basis（本次判断依据）。直接 REV、VER、REL、artifact 等采用带类型的 input.references／basis_refs，不把非 run ID 塞入 source_runs。首次／直接进入阶段根据当前权威记录建输入快照，不伪造来源执行。所有引用核对同项目、实际归属和摘要；可选引用的缺失须明确记录。

`input_checks[]` 是接收 run 的输入字段，记录引用目标、核查的业务依据、当前版本／摘要、accepted／stale／rejected、原因与时间；没有独立 ID 或可消费状态。多输入必须逐项核查，不能仅使用最近一个 run。accepted 只表示适合声明的用途，不认可来源的每一句话为真；读取还须核对已关联的纠正／取代记录，result_digest 相同不代表结论仍适用。必需的当前决策依据 stale／rejected 时阻止依赖它的动作；缺失可选上下文可缩小范围并保留限制，不把全部来源都当作强制完成门禁。输入通过只对本 run 有效，实际子操作仍再次检查。

historical_context 核对身份、完整性和历史用途；旧结论已过时或被反驳仍可作为重检对象，accepted 时必须说明适用性变化。decision_basis 另核对当前有效范围，不能以“历史参考”绕过修复、验收或发布必需条件。摘要不匹配／来源不可确认不能伪称有效历史结果。

同一来源 result 可同时被 archive 和 release 的不同 run 引用；不设置已消费标志。prepare 已发现不合法时可只读返回；需持久化失败核查时建 action=preflight 的 blocked run，将原因放在该 run 的 input_checks 与 result，不另发回执。

来源快照版本用于审计，业务 basis 用于有效性，接收方 expected_versions 用于本次提交，三者分开。路径移动、发布关联、无关经验追加可能增加 row_version，但有 artifact 身份或 spec_application 证明时仍可采用原证据；验收含义、候选或无法证明的基线改变则不能放行。首版保守核对配置摘要，避免假装具备精细影响推理。

## 6. 追溯、恢复和内部支持

run 关联 operation／event／领域记录；result 引用来源事实，input_checks 说明为何采用或拒绝。这样保留完整追溯，而不是把领域结果再复制成几类交接记录。查询对旧证据不匹配可显示派生 stale，持久化纠正由负责写动作处理。

sdd-workflow 只读重建变更或分析的目标、进度、问题、结果和现场。分析显式 RUN 恢复该快照并显示链头；标题按链折叠后定位。续查新建 run，start 事务核对最新分析链头及唯一后继，previous_run_id 指向同项目上一 analyze；旧结果不重开。维护封存 interrupted 后，续查仍接原分析，维护 run 仅作为额外来源。修复提议通过 source_runs 引用分析，不混入 analyze 链；转修复先定位已有活动 CHG，再决定 create／update。无 OP 的中断 apply 可由 maintain recover --run 核对；本地 OP／init 或 restore journal 仍走 [恢复协议](release-and-recovery.md)。维护只补确定性登记，不凭文件存在将任务判 done，也不补造分析结论，不重放未知部署。

必要排查只可支持仍 started 且范围获准的父阶段；已结束父 run 后的新“只查”请求另建分析。后续限制追加事实，不重写原 input。完整规则见 [分析路径](analysis-workflow.md)。

知识结束检查、策略备份等支持步骤沿用父 run，记录 component_skill 和 operation_id；独立 learn／backup／recover 请求才另建 run。pending 知识处理通过后继 learn 结果关联，保留原 run 当时事实。正式规则／个人库晋升需对具体候选确认。

插件整包版本与数据库 schema 必须兼容；内部结果格式随整包校验，不单独建立对外交接协议。workspace_epoch、检查点、短锁、独立换库日志及外部未决占用继续由内核维护，用户无需管理这些字段。

## 7. 一条可核查路径

propose 的 run P 产生 CHG-A／REV-2 并呈现；apply 的 run A 核查该修订及 P.result 后实施。verify 的 run V 产生 VER-A，结果引用最终候选与证据；archive 和 release 各自 run 的 input_checks 可采用 V.result，同时重新核对当前事实。

归档移动材料和同步规格不改 V.result；应用证明有效时后续发布仍可采用证据。另含 CHG-B 时必须追加 B 的适用验证输入。新会话只需目标和当前请求，系统恢复这些引用；用户不填写 run 或结果摘要。
