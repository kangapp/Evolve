# 存储、修订与追溯设计

状态：0.5.2 双路径设计审查修订，尚未实现；本轮仅设计文档、实施计划和 SVG，不开始插件编码。

字段权威唯一清单见 [领域对象与数据边界](domain-model.md)。本文只展开结构化记录；本文的数据库索引与历史快照不改变 Markdown 正文的编辑权威。

## 1. 存储原则

- 一个项目根内一份 `sdd/history.db`，随项目 Git 保存，不使用用户目录中的共享数据库。
- 采用普通 SQLite 数据表与追加事件，当前状态和对应事件在同一事务提交。首版不是完整事件溯源系统，不承诺仅靠叙述事件重建全部数据。
- Markdown 当前材料由 Agent 编辑，工具捕获有效修订的内容与摘要；数据库的过去快照不会随文件覆盖而改变。
- 文本快照去重保存，测试输出等大附件保存文件。备份和可恢复导出必须包含所引用附件。
- 模型不记录全量聊天或每次工具调用，记录能解释变更和恢复工作的关键事实。
- 0.2 补充新增经验、支持／反例证据、复用结果和审阅记录实体，来源仍指向本库历史。个人库仅在确认晋升后写入，详见[经验记录契约](commands-and-learning.md)。

## 2. 标识与公共字段

所有核心实体有 UUID 主键。用户可见变更号形如 `CHG-20261026-8f3a91c2`，可选标题 slug 不属于身份。工具通过唯一约束检查碰撞，不能仅依赖时间戳生成唯一键。

- 项目级语义编号：`G-001`、`NG-001`、`FR-001`、`BR-001`、`AC-001`、`BUG-001`、`DEC-001`、`OQ-001`，由项目内计数器分配，不复用已废弃编号。
- 任务编号在变更内为 `TASK-001`，完整引用必须带 `change_id`。
- 规划修订在变更内为 `REV-001`，其他记录展示 `VER-…`、`REL-…` 等友好编号。
- 编号预留后没有产物也不回收，允许跳号；不能为追求连续性重排历史。
- 时间保存 UTC ISO 8601，显示时用用户指定时区；没有可用时区转换数据时明确显示 UTC，不改变历史时间。
- 可变实体保存 `row_version` 整数，请求在 expected_versions[] 中提供该实体的预期版本。
- 引用采用实体 ID、artifact ID 及项目相对路径，不把安装 Skill 的机器路径写入持久化记录。

## 3. 逻辑实体与最小字段

下面确定 v1 数据契约；具体 SQL DDL 在实现阶段生成并迁移。通用字段包括 `id`、`project_id`、创建时间及适用的更新版本。

### 3.1 project_meta 与 counters

`project_meta` 保存项目 UUID、schema 版本、创建工具版本、初始化状态及不可变数据库检查点谱系。每次成功写事务生成 checkpoint ID 和前驱引用；事件序号不单独作为谱系身份。项目 UUID 与配置一致，不随目录改名变化。

`counters` 保存各语义编号已分配值，分配在写事务内进行。外部已有编号接入时先校验、登记，不重新编号用户资料。

### 3.2 changes

字段：`change_key`、标题、类型、轻量级别、生命周期、受阻前阶段、当前有效规划修订、接受的修订、基线引用、创建与归档时间、摘要、`row_version`。

development 初始化系统记录使用保留类型 `initialization`；records_only 只留 init run 和记录底座，不为了留档虚构 CHG／TASK。init 的 profile、覆盖和产物引用由 input／result 保存，project_meta 的初始化状态不能代替开发就绪性判断。普通变更类型与状态取值见[工作流](workflow.md)。

### 3.3 plan_revisions、blobs 与 artifact_versions

- `plan_revisions`：变更、修订序号、前修订、原因、来源、用户可见摘要、任务定义摘要、验收引用摘要、规划 digest；呈现记录另保存修订、材料摘要、呈现方式／来源与时间。未呈现修订不可沿用旧接受。
- `blobs`：SHA-256、字节内容、编码、长度。文本快照保留实际 UTF-8 字节；不依赖路径保存旧内容。
- `artifacts`：逻辑身份、所属变更或项目、种类、当前相对路径、是否生成视图。
- `artifact_versions`：artifact、修订或操作、blob 引用、内容摘要、时间及来源。

同内容 blob 共享，但相同文件在不同修订的关系分别保留。文件移动仅更新当前路径映射，不修改过去版本引用。

### 3.4 spec_items 与 delta_items

- `spec_items`：语义编号、类型、能力归属、当前 artifact、当前版本摘要、确定性标签、状态及来源依据。它是 Markdown 的索引，正文仍以文档为权威。
- `delta_items`：稳定 delta_id、变更修订、前版本／已应用来源、操作 `add | modify | remove`、目标规格编号、预期基线摘要、目标内容快照、关联验收和依赖。

删除保留 tombstone 与原因，不复用旧编号。纯维护变更可以没有增量项，但需记录 `spec_delta=none` 原因。

### 3.5 tasks 与 task_dependencies

`tasks` 是完整任务定义与执行状态的权威，proposal 只保留概要、tasks.md 为按需生成视图。字段：变更、局部编号、所属规划修订、目标、范围、关联规格／验收、完成条件、状态、结果摘要及版本。

任务定义修订保留在规划修订快照中，旧执行事件仍引用当时定义。`task_dependencies` 为同变更任务的有向关系，工具校验无环；跨变更依赖通过变更关联表达。

更改任务定义不能抹去旧完成事实；受影响任务重新打开或标记待评估并记录原因。任务完成要求结果摘要及适用证据，不能只写一个布尔值。

### 3.6 events 与 relations

`events` 字段：事件 UUID、项目内单调序号、事件类型、关联变更／任务／发布、run／操作 ID、时间、来源、结构化 payload、简洁摘要。

事件类型最少覆盖：初始化、规划创建／修订／接受、任务开始／完成／受阻／重开、验证登记／过期、规格同步、归档、取消、发布尝试／结果、恢复与注记。

`relations` 保存变更、需求、缺陷、决策、后继变更之间的显式关系。对 polymorphic 引用由工具验证目标存在；可以拆成具体外键表，不能因为使用通用关联就跳过完整性校验。

事件是追加历史。误记通过纠正事件和当前投影更新处理，不直接改掉过去发生的事实。

### 3.7 verifications 与 evidence

- `verifications`：变更、任务范围、规划修订、代码指纹、配置摘要、执行方式、evidence_level、开始／结束时间、结果、时效、环境摘要及限制。
- `verification_items`：验收编号／内容摘要、required／not_applicable 及原因、逐项结果和实际方法；一个命令通过不自动证明全部验收。
- `evidence`：source_run_id、可空 verification_id、artifact 或附件路径、字节摘要、长度、观察时间、来源及简述。

独立分析直接关联来源 run，不伪造 VER／AC。source_run_id 必填且同项目；verification_id 非空时须核对 VER 的实际归属。复用旧证据保留原观察者、来源 run、时间和摘要，经显式关联采用，不改写为新 run 亲自观察；分析证据本身不等于新候选验收通过。必要附件登记前核对持久化及摘要，外部引用注明可获取性与恢复限制。

人工检查的观察者来源可以是用户说明或 Agent 的实际观察，不伪造人员身份。未执行、失败、受阻都可留档，只有适用且有效的通过证据参与完成判断。

### 3.8 releases、release_changes 与 release_attempts

- `releases`：友好编号、版本、环境、候选代码指纹、准备材料摘要、当前汇总状态、最近观察时间及版本。
- `release_changes`：发布与变更的多对多关系，固定当时的规划／实现／验收依据。
- `release_attempts`：执行、状态检查或回滚类型，外部幂等键、请求目标／恢复目标、执行器摘要、开始／结束、执行结果、环境观察及观察时间、进程或外部操作引用、证据与错误摘要。状态查询失败不能覆盖最近确认的部署事实。

`environment_claims` 按 project_id + environment 唯一关联未决 deploy／rollback attempt；running／unknown 保留占用，核实后释放。它是持久化业务约束，不是长数据库事务。

一个发布多次尝试不覆盖旧尝试。回滚关联原发布和实际恢复版本；不能把“配置了回滚命令”写成已回滚。

### 3.9 spec_applications 与 operations

- `spec_applications`：增量项及修订、目标基线与结果摘要、应用时间、关联验收及操作 ID。唯一键基于稳定 delta_id + 目标内容摘要，保留应用时修订；不能单凭新 REV 重新应用旧 ADD。
- `operations`：操作 ID、动作、目标、输入摘要、期望版本、状态 `prepared | applying | committed | needs_recovery | aborted`、暂存清单摘要、已完成步骤与错误信息。

与变更 lifecycle 分离：某变更可以 active，而一次归档操作处于 needs_recovery。不能用改变变更状态掩盖中断。

### 3.10 phase_runs：输入核查与封存结果

`phase_runs` 保存项目、request_id、workspace_epoch、previous_run_id、owner_skill、action、目标集合、规范化 input 及其摘要、source_runs、input_checks、开始／结束、状态、result 和 result_digest。

- action=analyze 可只关联项目，没有 CHG／REV／TASK。input 保存分析类型、标题、问题、范围、完成条件和业务只读／留档策略；过程事件及时记录观察、证据、假设和未决问题。result.analysis 的完整契约见 [分析路径](analysis-workflow.md)，不新增独立分析表。
- targets 定位本次领域对象；source_runs 引用来源 run 及结果摘要，可有多个。直接领域资料／REV／VER／REL 放带类型的 input.references／basis_refs；source_runs 只含真实 run_id／result_digest／target／purpose／required，来源为空不伪造执行。
- input_checks 保存每项输入的用途、相关业务依据、接收时版本／摘要、核查结论与原因。它是本 run 的输入记录，没有独立回执编号或状态机。
- result 在终态封存，保存完成范围、限制、未完成／阻碍及领域记录／产物／证据引用；引用已有 VER 等记录而不复制全部业务字段。result_digest 随规范化结果一次提交，不另建结果身份。
- 请求唯一键为项目 + epoch + request_id。finish 按稳定 operation_id 幂等提交一个结果；相同输入重试只返回原结果。run 及领域对象用稳定 ID 校验同项目关联。
- targets／来源引用可通过无独立生命周期的关联行建立索引和外键；input_checks／result 可用版本化结构字段保存。需要的索引不形成新的领域对象，JSON 字段不要求额外数据库扩展。

首版不创建独立 handoffs、handoff_receipts 或 H 编号，原三类记录收敛到一类 run。事件记录关键事实，operation 记录幂等及恢复步骤；它们不重复保存全部 result。查询与恢复从这些关联重建上下文。

状态、字段及结果复用的唯一协议见 [skill-handoff.md](skill-handoff.md)。同一来源 result 可被多个后续 run 核查；业务 basis 与本次提交版本分开。归档路径移动和无关事件不凭空使证据失效。

查询可按项目、action、input 标题、run 及时间定位分析；必要索引是执行字段索引，不是新增分析实体。

分析续查使用 previous_run_id 关联同项目、action=analyze 的最新已结束分析；修复和维护结果只走 source_runs，不进入分析链。起始请求携带准备时所见链头，start 短事务核对链头、无进行中后继及唯一分析后继；索引／约束校验同项目、同动作及无环。幂等重试先查原 run，不因自身已成后继再次创建。首版顺序续查，不隐式分叉／合并。查询按链折叠标题；显式 RUN 保留历史快照并提示当前头，不新增分析实体或可手工维护的 head 状态。

source_runs 的 historical_context 与 decision_basis、required 和逐项 input_checks 遵循 [统一协议](skill-handoff.md)。过时结论可用于重检，不能冒充当前决策依据。观察／假设的局部键只在 run.result 内有效，引用需带 run_id + result_digest + local_key；反驳与纠正追加新事实并关联原 run／局部条目，不覆盖旧结果；查询及当前依据核查须同时读取后续纠正／取代提示，历史导出明确截止点。

### 3.11 支持记录和外部控制

普通阶段无新发现时仅在 run 结果保留简短知识检查结论，不强制新增完整复盘或 knowledge_reviews 行；有需要跟进的处理时才另建支持记录。

经验、经验版本、支持／反例、应用效果的字段见 [commands-and-learning.md](commands-and-learning.md)；knowledge_reviews、promotion_proposals、rule_bindings、check_applications 见 [experience-governance.md](experience-governance.md)。它们通过 run／operation 关联本阶段事实，计划问题使用带稳定 OQ ID、blocking 和状态的修订条目，不能只存于聊天。

策略备份和知识结束检查可关联父 run，保存 component_skill 及 operation_id；独立支持请求另建 run。个人库晋升有稳定 promotion_id 与候选摘要，项目和个人库分别提交，恢复协议不将它们伪装为同一事务。

非 Git 的 workspace guard、init／restore journal 位于 .sdd-local/control，保存实际 epoch、清单及恢复进展。它们不是第二份业务历史；只服务启动、换库和防旧请求重放，完成后将结果导入权威库。restore 不能仅依赖将被替换的 operations 表恢复自身。

## 4. 规划修订的边界

以下变化创建新规划修订：范围、增量规格、验收、主要方案、任务定义或依赖。普通任务进展、命令输出、补充执行摘要只追加事件。

修订捕获一个逻辑整体：有效 Markdown 快照、结构化任务定义、规格与验收关系及其摘要。`apply` 接受的是这个整体，不是某个随时会变的目录。

直接编辑 Markdown 后，`status`／`resume` 显示 `unregistered_changes`。`update` 从旧快照及候选暂存捕获差异，解释并呈现后再通过可恢复协议将候选设为有效。数据库中的旧快照不得被编辑器新内容覆盖。

## 5. 实现指纹与证据时效

实现指纹包含实际源码、配置、依赖锁文件及测试文件的路径和内容摘要；Git HEAD 仅作辅助元数据，不能代表脏工作区的实际代码。

- 默认保守扫描 Git 已跟踪文件及未忽略的新业务文件，排除 SDD 历史库、生成视图、备份、运行输出及已配置构建产物；无 Git 时采用配置化目录扫描。
- 项目内映射的规格文档单独计算规划摘要。若工具验证代码本身位于 SDD 默认排除目录，则必须显式纳入代码范围。
- 不读取凭证文件正文进入快照，不把依赖目录打包进历史。排除规则和检测范围写入证据，不能暗示未扫描范围也受验证。
- 文件摘要按实际字节计算；换行、依赖或配置改变可保守地使证据过期，不以修改时间替代内容校验。
- 首版默认受实现指纹或验收修订影响时将相关变更验证标为 stale，不实现复杂的代码影响分析。可以重跑以建立新的有效证据。
- 外部环境变化不一定能由源码摘要检测；证据必须保留环境与观察时间，发布前检查策略可以要求重新验证。

## 6. 数据库连接与写入规则

- 每个连接显式设置并确认 `foreign_keys=ON`；启用明确事务控制，避免依赖不同 Python 版本的默认提交行为。
- 初版使用 `journal_mode=DELETE`，简化数据库作为单个 Git 文件的保存；不依赖 WAL sidecar 作为权威历史。
- 写入使用短事务、必要的 `BEGIN IMMEDIATE` 和有限的 busy 等待；不把模型思考或发布子进程放在数据库事务中。
- 首次执行写操作检查 `expected_versions` 与 `expected_workspace_epoch`；已提交幂等重试先校验当前 epoch 和输入再返回原事实，详见 contracts.md。首次写入在同一事务内更新实体、添加事件及操作状态。过期写入报 `VERSION_CONFLICT`，不做最后写入覆盖。
- 绑定参数执行 SQL，状态转换和引用存在性由工具检查；只读查询不能修改库、workspace guard、编号或索引；发现不匹配只返回诊断。
- 未知更高 schema 版本拒绝写入；升级前备份，迁移逐版执行并记录工具版本。首版只承诺创建 v1，未来变更必须新增迁移，不重建丢历史。

多文件原子性、写锁和中断恢复见[发布与恢复](release-and-recovery.md)。不支持多个 Agent 同时编辑同一变更；短期工具写锁和摘要检查只能检测部分冲突，不能宣称替代所有编辑器的锁。

## 7. Git 与保留策略

已确认：数据库随 Git 保存。默认纳入当前知识、变更材料、必要证据、发布材料及 `history.db`；临时输出、锁和本地备份排除。

- init 仅提出／增量写入数据库的二进制属性与 `.sdd-local/` 忽略规则，保留用户既有配置。
- 操作完成后关闭连接；不在有进行中写操作时建议用户切分支或提交。
- 不自动提交数据库和源码。操作结果提示应一起审阅和提交的文件集合。
- 数据库发生 Git 冲突时暂停工具写入，不自动选 ours/theirs、不按文本合并；保留两份后依据实际分支选择或后续专门修复。
- Git checkout 使本地档案回到该版本，不证明外部发布环境也回退；记录中的 succeeded 带观察时间，不能替代实时环境核实。
- 首版不提供跨分支数据库自动合并或历史后端迁移。恢复包服务同项目的备份恢复，不充当多人数据库合并协议。

归档不清理历史快照或证据。大附件保留可按项目配置限制未来采集，但不能静默删掉已有唯一证据；本地备份首版不自动清理。
