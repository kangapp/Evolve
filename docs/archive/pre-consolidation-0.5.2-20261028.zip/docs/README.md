# SDD 多 Skill 插件设计

版本：0.5.2 双路径设计审查修订。更新：2026-10-27。需求基线：[AGENT.md](../AGENT.md)。本轮仅设计、计划和 SVG，尚无插件代码、数据库或宿主实测结果。

## 先从使用路径阅读

1. [六个入口使用指南](user-guide.md)：普通功能、小改动、明确多阶段请求、续接和异常。
2. [领域对象与权威边界](domain-model.md)：对象含义、Markdown／SQLite／证据／视图各自负责哪些字段。
3. [插件架构](architecture.md)：九个 Skill 的分工、公共内核和资源布局。

独立认知工作另看 [分析、排查与解释路径](analysis-workflow.md)：不改业务也能留档、换会话续查及明确转修复。

完整模拟案例：[文章收藏从 init、换会话、验证修复到归档发布](examples/article-favorites-walkthrough.md)，逐步列出用户指令、文档及 SQLite 记录；不代表实现或测试已执行。

0.5.2 完整模拟案例：[收藏 500 从独立排查、换会话续查到修复、失败复验、归档和 test 发布](examples/analysis-to-release-walkthrough.md)，逐步列出指令、文档产物、SQLite 记录和后续路径。

分析边界及异常分支聚焦案例：[收藏 500 独立排查、跨会话续接与转修复](examples/analysis-investigation-walkthrough.md)。

常用路径：初始化一次 → 提议 → 实施 → 验证 → 归档；发布按需。已有明确选择复用，唯一目标自动定位，复杂度不足时不拆设计文档。入门只需六个阶段入口，高级命令在需要时推荐。

独立路径：明确分析问题 → 取证／解释 → 封存本轮结果；没有 CHG 也可留档。即时问答不强制记录，只有明确修复才进入普通变更流程，九个 Skill 数量不变。

本轮完成[0.5.1 完整设计审查及修订](design-review-0.5.1.md)：统一记录接入与开发起点、父阶段边界、分析链续接、来源用途、修复归属和失败留档。以下正文与图册为修订后的 0.5.2；历史审查保留原版本语境。

## 精简后的统一约定

- **九个 Skill 保留**：路由、六个阶段、经验和维护，共用一个内核；Skill 数量不等于用户必经步骤数。
- **权威按字段划分**：Markdown 编辑业务含义与决定；SQLite 维护结构化任务、执行事实和关联；生成 Markdown 不独立编辑；证据文件保留实际观察。
- **一类执行记录承接工作**：run.result 保存结束结果及引用，下一 run.input_checks 记录采用／拒绝理由。原独立交接和回执并入 run，不增加 H 编号或对外交接协议。
- **必要保障保留**：稳定请求与操作 ID、当前版本／证据核查、关键事件、控制 journal、保护备份及外部未知核实均由内核处理。
- **副作用按两个维度判断**：纯查询／即时不留档解释不写 SDD；analyze 不修改业务，但保存项目级 run、证据与按需报告。分析执行结束不代表结论已确认。
- **状态和报告按需派生**：可归档、同步程度和下一步由事实计算；报告无需每步落盘。经验不要求每次单独复盘，正式规则及个人库晋升仍需具体确认。

原有用户决定继续有效：Markdown + SQLite 固定组合，history.db 随 Git 保存，apply 接受已呈现的有效方案，默认全部就绪任务，验证后允许先归档再发布。SQLite 不做文本合并，Skill 不自动 Git 提交或扩大执行范围。

## 按需查阅运行时与实现设计

- [九个 Skill 输入输出](multi-skill-plugin.md)、[工作流与状态](workflow.md)、[唯一命令映射和模板](contracts.md)。
- [执行结果与轮转协议](skill-handoff.md)、[存储细节](storage.md)、[发布与恢复](release-and-recovery.md)。
- [经验复用](commands-and-learning.md)、[知识晋升及参考依据](experience-governance.md)。
- [实施与验收计划](validation.md)、[决策记录](decisions.md)、[0.4.1 历史审查](design-review.md)。

使用者不用先读运行时字段或 SQL；维护者按改动范围加载相关契约，避免把全部文档放进每次 Skill 上下文。

## SVG 图册

全部 16 张图表达 0.5.2 设计，通过本地 SVG 引用展示；点击图片可查看原图。建议先看 02、13，再按需看阶段和恢复细节。时序图分支不表示每次都需要执行；蓝色为请求，绿色为写入，虚线为返回或条件路径。

### 01 整体架构与职责边界

九个 Skill 保留，常用六入口通过宿主或路由进入；共享内核统一记录、版本核查和恢复，文档与 DB 各有权威。

[![整体架构与职责边界](diagrams/01-system-architecture.svg)](diagrams/01-system-architecture.svg)

详细契约：[architecture.md](architecture.md)。

### 02 六个常用入口与正常路径

初始化一次；每项变更 propose → apply → verify → archive，发布按需。sync、知识检查和必要备份属于内部步骤，不是额外必经命令。

[![六个常用入口与正常路径](diagrams/02-end-to-end-workflow.svg)](diagrams/02-end-to-end-workflow.svg)

详细契约：[user-guide.md](user-guide.md)。

### 03 命令解析与下一步推荐

单一明确目标自动定位并说明；只有含糊目标或关键未决才询问。下一步从当前事实计算，用户不管理内部执行参数。

[![命令解析与下一步推荐](diagrams/03-command-and-next-step.svg)](diagrams/03-command-and-next-step.svg)

详细契约：[contracts.md](contracts.md)。

### 04 初始化与已有项目基线

按目的选择接入范围：独立分析仅接记录底座；开发时新项目建最小骨架，旧项目区分已证实、推断、风险和未知。必要业务词汇进入项目说明，不机械创建全部模板。

[![初始化与已有项目基线](diagrams/04-init-new-and-existing.svg)](diagrams/04-init-new-and-existing.svg)

详细契约：[workflow.md](workflow.md)。

### 05 提议、修订与资料承接

短 proposal 是默认讨论入口，必要增量可内嵌；数据库任务与 Markdown 快照共同绑定修订，呈现并接受后实施。

[![提议、修订与资料承接](diagrams/05-propose-and-update.svg)](diagrams/05-propose-and-update.svg)

详细契约：[domain-model.md](domain-model.md)。

### 06 实施与逐项结果

按依赖推进就绪任务，源码与证据及时留档。任务完成与变更验收分开，无 OP 的中断也有恢复入口。

[![实施与逐项结果](diagrams/06-apply-task-execution.svg)](diagrams/06-apply-task-execution.svg)

详细契约：[workflow.md](workflow.md)。

### 07 验收、证据和完成门禁

AC 含义来自对应 Markdown 修订，实际结果由 SQLite 和证据维护；局部通过不能代替完整验收。

[![验收、证据和完成门禁](diagrams/07-verify-and-evidence.svg)](diagrams/07-verify-and-evidence.svg)

详细契约：[storage.md](storage.md)。

### 08 同步与归档

archive 包含必要同步；稳定增量防重、基线冲突保留，移动路径和合法应用证明不自动废弃旧验收。

[![同步与归档](diagrams/08-sync-and-archive.svg)](diagrams/08-sync-and-archive.svg)

详细契约：[release-and-recovery.md](release-and-recovery.md)。

### 09 发布、观察和回滚

prepare 不部署；status 只读，--refresh 才核实并登记。未知尝试先核实，回滚核对恢复目标，环境占用不靠短锁代替。

[![发布、观察和回滚](diagrams/09-release-status-and-rollback.svg)](diagrams/09-release-status-and-rollback.svg)

详细契约：[release-and-recovery.md](release-and-recovery.md)。

### 10 跨会话续接与中断恢复

路由只读恢复领域对象和 run；维护按 OP／RUN／journal／history 定位，仅补确定性步骤，不重复业务或未知部署。

[![跨会话续接与中断恢复](diagrams/10-resume-and-recover.svg)](diagrams/10-resume-and-recover.svg)

详细契约：[release-and-recovery.md](release-and-recovery.md)。

### 11 查询、导出、备份及换库

报告按需生成；恢复包排除自身和派生物。库外 journal 保护换库步骤，恢复不自动回退源码、个人库和外部环境。

[![查询、导出、备份及换库](diagrams/11-history-export-and-restore.svg)](diagrams/11-history-export-and-restore.svg)

详细契约：[release-and-recovery.md](release-and-recovery.md)。

### 12 事实、经验与复用

普通阶段只留必要事实和简短结论，重要发现再提炼经验；支持和反例共同反馈。正式规则与个人库晋升具体确认。

[![事实、经验与复用](diagrams/12-learning-and-promotion.svg)](diagrams/12-learning-and-promotion.svg)

详细契约：[experience-governance.md](experience-governance.md)。

### 13 领域对象与数据权威

区分领域、执行和表示层：Markdown 定义业务含义，SQLite 管任务和执行事实；报告是只读视图，历史快照不成为当前正文。

[![领域对象与数据权威](diagrams/13-object-and-trace-model.svg)](diagrams/13-object-and-trace-model.svg)

详细契约：[domain-model.md](domain-model.md)。

### 14 轻量、取消与辅助路径

小改动减少材料；明确多阶段请求可连续执行。取消保留已发生事实，查询不虚构写阶段。

[![轻量、取消与辅助路径](diagrams/14-lightweight-and-cancel.svg)](diagrams/14-lightweight-and-cancel.svg)

详细契约：[workflow.md](workflow.md)。

### 15 run 结果复用与输入核查

来源 run 封存 result，接收 run 保存 input_checks；一个结果可供多方引用。保留多目标、摘要、当前版本与失败依据，不建独立交接和回执。

[![run 结果复用与输入核查](diagrams/15-skill-handoff-and-rotation.svg)](diagrams/15-skill-handoff-and-rotation.svg)

详细契约：[skill-handoff.md](skill-handoff.md)。

### 16 独立分析、续查与转修复

由 sdd-propose analyze 执行项目级分析：记录事实、假设、未知和有范围的结论；resume 只读恢复，明确续查新建 run。只有用户明确提出修复，才新建或修订匹配 CHG，不伪造验收或复用分析授权实施。

[![独立分析：业务只读但留档、跨会话续查、明确转修复](diagrams/16-analysis-and-explanation.svg)](diagrams/16-analysis-and-explanation.svg)

详细契约：[analysis-workflow.md](analysis-workflow.md)；完整案例：[analysis-investigation-walkthrough.md](examples/analysis-investigation-walkthrough.md)。

## 图册维护与实施边界

[diagram_sources.py](diagrams/diagram_sources.py) 保存交互源，[render_diagrams.py](diagrams/render_diagrams.py) 保存布局，[manifest.json](diagrams/manifest.json) 保存输出清单。修改正文时同步源和 SVG；在项目根执行 `python docs/diagrams/render_diagrams.py` 可用标准库再生成，仅操作图册。

当前止于 M0。后续收到实现指令后按 M1—M4 推进；V-001—V-061 是未来验收要求，不因文档或 SVG 检查就标为功能已通过。0.4.1 的审查发现及检查快照保留作历史，不再作为独立交接数据表的建设要求。
