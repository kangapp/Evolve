"""Render documentation-only SVG diagrams using the Python standard library.

Run from any directory: python docs/diagrams/render_diagrams.py
These figures describe a proposed system; this is not the Evolve implementation.
"""

from __future__ import annotations

import html
import json
import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
COLORS = {
    "ink": "#172b46", "muted": "#52647b", "line": "#bac8d8",
    "blue": "#235da8", "blue_bg": "#eef4fc", "green": "#176c61",
    "green_bg": "#edf8f4", "amber": "#94520b", "amber_bg": "#fff6e8",
    "red": "#a33342", "red_bg": "#fff1f2", "white": "#ffffff",
    "gray_bg": "#f5f7fa",
}


def esc(value: str) -> str:
    return html.escape(str(value), quote=True)


def wrap(text: str, max_width: float, size: float) -> list[str]:
    lines: list[str] = []
    for paragraph in text.split("\n"):
        line, width = "", 0.0
        tokens = re.findall(r"[A-Za-z0-9_./<>-]+|\s+|[^A-Za-z0-9_./<>\s-]", paragraph)
        for token in tokens:
            advance = sum(size * (1.0 if unicodedata.east_asian_width(c) in "WF" else 0.59) for c in token)
            if line and width + advance > max_width:
                carried = ""
                if token in "，。、；：？！)]}）】":
                    tail = re.search(r"[A-Za-z0-9_./<>-]+$", line)
                    carried = tail.group() if tail else line[-1:]
                    line = line[:-len(carried)]
                elif line[-1:] in "（【([":
                    carried, line = line[-1:], line[:-1]
                lines.append(line.rstrip())
                line = carried
                width = sum(size * (1.0 if unicodedata.east_asian_width(c) in "WF" else 0.59) for c in carried)
            if not line and token.isspace():
                continue
            line += token
            width += advance
        lines.append(line.rstrip())
    return lines


class SVG:
    def __init__(self, title: str, subtitle: str, width: int, height: int, number: int):
        self.width, self.height = width, height
        self.parts = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
            f'viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc">',
            f'<title id="title">{esc(title)}</title><desc id="desc">{esc(subtitle)}</desc>',
            '<defs>',
        ]
        for key in ("blue", "green", "amber", "red", "muted"):
            self.parts.append(
                f'<marker id="arrow-{key}" viewBox="0 0 10 10" refX="9" refY="5" '
                f'markerWidth="8" markerHeight="8" orient="auto-start-reverse">'
                f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{COLORS[key]}"/></marker>'
            )
        self.parts.extend([
            '</defs>',
            '<style>text{font-family:"Microsoft YaHei","PingFang SC","Noto Sans CJK SC",sans-serif}'
            'path,line,rect{vector-effect:non-scaling-stroke}</style>',
            f'<rect width="{width}" height="{height}" fill="{COLORS["white"]}"/>',
        ])
        self.text(44, 45, f"EVOLVE / {number:02d}", size=15, color="blue", weight=600)
        self.text(44, 90, title, size=32, weight=600)
        self.text(44, 124, subtitle, size=18, color="muted")
        self.line(44, 146, width - 44, 146, "line", arrow=False)

    def text(self, x, y, value, size=21, color="ink", anchor="start", weight=400):
        self.parts.append(
            f'<text x="{x}" y="{y}" fill="{COLORS[color]}" font-size="{size}" '
            f'font-weight="{weight}" text-anchor="{anchor}">{esc(value)}</text>'
        )

    def multiline(self, x, y, lines, size=21, anchor="start", color="ink", weight=400):
        for index, value in enumerate(lines):
            self.text(x, y + index * (size + 7), value, size, color, anchor, weight)

    def rect(self, x, y, width, height, fill="gray_bg", stroke="line", radius=8):
        self.parts.append(
            f'<rect x="{x}" y="{y}" width="{width}" height="{height}" rx="{radius}" '
            f'fill="{COLORS[fill]}" stroke="{COLORS[stroke]}" stroke-width="1.2"/>'
        )

    def line(self, x1, y1, x2, y2, color="blue", dashed=False, arrow=True):
        dash = ' stroke-dasharray="7 6"' if dashed else ''
        marker = f' marker-end="url(#arrow-{color})"' if arrow else ''
        self.parts.append(
            f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{COLORS[color]}" '
            f'stroke-width="1.7"{dash}{marker}/>'
        )

    def path(self, points, color="blue", dashed=False):
        path = "M " + " L ".join(f"{x} {y}" for x, y in points)
        dash = ' stroke-dasharray="7 6"' if dashed else ''
        self.parts.append(
            f'<path d="{path}" fill="none" stroke="{COLORS[color]}" stroke-width="1.7" '
            f'marker-end="url(#arrow-{color})"{dash}/>'
        )

    def node(self, x, y, width, height, title, body, kind="blue"):
        self.parts.append(f'<g data-box="{x},{y},{width},{height}">')
        self.rect(x, y, width, height, f"{kind}_bg", "line")
        self.text(x + 18, y + 35, title, size=23, weight=600, color=kind)
        self.multiline(x + 18, y + 69, wrap(body, width - 36, 20), size=20)
        self.parts.append('</g>')

    def finish(self, name: str):
        y = self.height - 48
        self.line(44, y - 23, self.width - 44, y - 23, "line", arrow=False)
        self.text(44, y + 4, "设计 0.5.6 · Evolve / 九个 Skill / 尚未实现 · 2026-10-29", size=15, color="muted")
        self.text(self.width - 44, y + 4, "实线：请求/操作   虚线：返回/条件路径   编号：图内顺序", size=15, color="muted", anchor="end")
        self.parts.append('</svg>')
        (ROOT / name).write_text("\n".join(self.parts) + "\n", encoding="utf-8")
        return {"file": name, "width": self.width, "height": self.height}


def sequence(number, name, title, subtitle, lanes, events):
    width = 1440
    xs = [112 + index * (width - 224) / (len(lanes) - 1) for index in range(len(lanes))]
    y = 265
    placements = []
    count = 0
    for event in events:
        if "section" in event:
            lines = wrap(event["section"], width - 140, 21)
            height = 32 + len(lines) * 28
            placements.append(("section", y, height, lines, event))
            y += height + 20
        else:
            count += 1
            label = f'{count:02d}  {event[2]}'
            a, b = xs[event[0]], xs[event[1]]
            available = min(abs(b - a) - 28, 720)
            lines = wrap(label, available, 21)
            height = len(lines) * 28 + 39
            placements.append(("message", y, height, lines, event))
            y += height
    height = int(y + 108)
    svg = SVG(title, subtitle, width, height, number)
    for x, label in zip(xs, lanes):
        lines = wrap(label, 174, 21)
        svg.rect(x - 100, 169, 200, 77, "blue_bg")
        svg.multiline(x, 199, lines, size=21, anchor="middle", weight=600)
        svg.line(x, 247, x, height - 91, "line", dashed=True, arrow=False)
    for kind, y, row_height, lines, event in placements:
        if kind == "section":
            svg.parts.append(f'<g data-box="48,{y},{width - 96},{row_height}">')
            svg.rect(48, y, width - 96, row_height, "amber_bg" if event.get("warn") else "gray_bg")
            svg.multiline(68, y + 32, lines, size=21, color="amber" if event.get("warn") else "muted", weight=500)
            svg.parts.append('</g>')
            continue
        a, b = xs[event[0]], xs[event[1]]
        style = event[3] if len(event) > 3 else "blue"
        color = "muted" if style == "return" else style
        center = (a + b) / 2
        label_width = min(abs(b - a) - 28, 720)
        label_height = len(lines) * 28
        svg.parts.append(f'<g data-box="{center-label_width/2},{y},{label_width},{label_height + 9}">')
        svg.rect(center - label_width / 2, y, label_width, label_height + 9, "white", "white", radius=3)
        svg.multiline(center, y + 22, lines, size=21, anchor="middle", color=color)
        svg.parts.append('</g>')
        arrow_y = y + label_height + 16
        svg.line(a, arrow_y, b, arrow_y, color, dashed=style in ("return", "red", "amber"))
    return svg.finish(name)


def architecture():
    svg = SVG("Evolve：整体架构与职责边界", "统一入口；常规 / 数据开发及独立分析共用九个 Skill；工作范围由 spec 决定", 1440, 1900, 1)
    for y1, y2 in [(284, 330), (440, 490), (616, 670), (1240, 1300)]:
        svg.line(720, y1, 720, y2)
    svg.node(460, 180, 520, 104, "用户", "决定目标、阶段与范围；确认具体知识晋升")
    svg.node(460, 330, 520, 110, "宿主入口 / 插件适配", "/evolve <动作>；宿主形式待实测\n解析参数，定位 Skill 与公共资源")
    svg.node(460, 490, 520, 126, "evolve-workflow / 路由", "规范动作 / 子方法 / 范围；只读路由\nresume 核对项目级配置与领域目标")
    svg.rect(24, 670, 1392, 570, "gray_bg")
    svg.text(48, 706, "功能 Skill：独立方法、输入输出与完成条件；下列位置不表示自动执行顺序", size=21, color="muted")
    modules = [
        ("evolve-init", "接入 / 开发起点；维护 Evolve 配置\n身份固定；业务配置走变更流程"),
        ("evolve-propose", "create / update 规划业务变更\nanalyze 只分析并留档，不修复"),
        ("evolve-apply", "按有效spec形成约定成果\n代码 / SQL / 模型等，保留实际依据"),
        ("evolve-verify", "按spec测试 / 对账 / 口径核对\n成果范围、实际证据与限制"),
        ("evolve-release", "按spec准备 / 执行或登记交付\n成果目标、实际观察和恢复安排"),
        ("evolve-archive", "规格同步与变更封存\n允许验证后先归档、保留未发布"),
        ("evolve-learn", "经验检索、复盘、审阅与晋升\n正式规则 / 个人库具体确认"),
        ("evolve-maintain", "封存后图文导出；档案维护与恢复\n只引用源事实，不重查或改旧结论"),
        ("共享执行记录", "run.result → 下一 run.input_checks\n多目标引用；不另建交接和回执"),
    ]
    for i, (title, body) in enumerate(modules):
        svg.node(44 + (i % 3) * 466, 738 + (i // 3) * 166, 420, 140, title, body, "green" if i >= 6 else "blue")
    svg.node(300, 1300, 840, 142, "共享 Python 内核 / runtime/evolve.py", "唯一状态、存储与执行协议；配置、版本、指纹、幂等、结果及恢复\n公共模板按需读取；业务意义由阶段 Skill 判断，不靠工具退出码猜测")
    for x in [206, 548, 890, 1232]:
        svg.path([(720, 1442), (720, 1475), (x, 1475), (x, 1520)], "green")
    svg.node(44, 1520, 324, 160, "evolve/ 项目资料", "Markdown 业务含义与决定\nconfig.toml 由 init 自动维护", "green")
    svg.node(386, 1520, 324, 160, "evolve/history.db", "任务、修订、验证与发布\nrun 输入核查 / 结果及经验", "green")
    svg.node(728, 1520, 324, 160, "证据 / 生成视图", "实际附件保存来源\n只读报告按需生成", "green")
    svg.node(1070, 1520, 324, 160, "项目成果 / 外部目标", "实施、验收与约定交付\n具体方法看项目spec", "amber")
    svg.text(44, 1743, "结束：封存真实结果与必要引用；下一步从当前事实计算；推荐本身不启动下一业务阶段。", size=21, color="muted")
    svg.text(44, 1783, "设计边界：Skill 不是常驻 Agent；不默认并行、后台调度、自动提交或自动改写全局规则。", size=21, color="muted")
    return svg.finish("01-system-architecture.svg")


def lifecycle():
    svg = SVG("统一入口：六个开发动作与按需发布", "使用 /evolve <动作>；初始化自动配置，跨会话复用；内部记录由九个 Skill 维护", 1440, 1540, 2)
    rows = [
        ("01  /evolve init", "evolve-init：新骨架 / 已有项目基线", "项目起点，仅首次或明确补齐", "复用已有选择；关键未知先澄清"),
        ("02  /evolve propose", "evolve-propose：短提议、验收、数据库任务", "呈现有效修订；任务视图按需", "必要时才拆设计 / 增量文档；不自动实施"),
        ("03  /evolve apply", "evolve-apply：接受方案；按依赖实施", "实际改动、任务结果和依据", "指定范围；关键阻碍暂停相关任务"),
        ("04  /evolve verify", "evolve-verify：逐项验收、证据与时效", "通过 / 失败 / 受阻及覆盖", "失败回修复；局部 passed 不等于完整完成"),
        ("05  /evolve archive", "evolve-archive：包含必要同步，封存结果", "当前规格与档案；可未发布", "可归档由事实计算，不重复手工维护状态"),
        ("06  /evolve release", "evolve-release：按需准备、执行或登记", "环境、候选及实际发布观察", "可先发布再归档；unknown 先核实"),
    ]
    y = 204
    for i,(command,action,output,branch) in enumerate(rows):
        if i:
            svg.line(210,y-31,210,y-5,dashed=i==5)
        svg.node(44,y,332,128,command,output,"green" if i>=4 else "blue")
        svg.node(416,y,526,128,"本次负责者",action)
        svg.node(982,y,414,128,"条件 / 回访",branch,"amber")
        svg.line(376,y+64,409,y+64)
        svg.line(942,y+64,975,y+64,"amber",dashed=True)
        y += 163
    svg.node(44,1220,1352,170,"按需支持，不增加必经命令", "evolve-workflow 定位和续接；evolve-learn 简短知识检查与重要经验；evolve-maintain 策略备份和异常恢复。\n数据排查 / 血缘用 /evolve analyze，只读业务并留档；纯查询不写；具体工作看 spec。", "green")
    return svg.finish("02-end-to-end-workflow.svg")


def object_model():
    svg = SVG("领域对象与数据权威边界", "先理解对象及关系，再选择表示方式；任务完成、验收通过、归档和环境发布保留独立含义", 1440, 1510, 13)
    # Project ownership and direct domain references. Runtime is described below.
    svg.path([(720,310),(720,350),(254,350),(254,400)],"green")
    svg.line(720,310,720,400,"green")
    svg.path([(720,310),(720,350),(1186,350),(1186,400)],"green")
    svg.line(510,480,464,480,"green")
    svg.line(976,480,930,480,"green")
    svg.line(720,560,720,650,"green")
    svg.line(1186,560,1186,650,"green")
    svg.line(976,730,930,730,"green")
    svg.node(510,190,420,120,"项目 Project","目标、边界、业务词汇与历史\n拥有规格、变更及发布关联")
    svg.node(44,400,420,160,"能力 / 规格 Spec","当前行为 / 口径、约束和AC\n变更引用基线并提出增量","green")
    svg.node(510,400,420,160,"变更 Change","动机、范围、修订及接受\n定义任务，关联受影响规格")
    svg.node(976,400,420,160,"发布 Release","候选成果 + 目标 + 变更集合\n交付方式由spec确定","amber")
    svg.text(487,455,"引用",size=15,anchor="middle",color="green")
    svg.text(953,455,"M:N",size=15,anchor="middle",color="green")
    svg.text(736,612,"任务",size=18,color="green")
    svg.text(1202,612,"依据",size=18,color="green")
    svg.node(44,650,420,160,"经验 / 正式规则","经验引用实际任务、验证与发布\n规则经确认，保留来源与适用条件","green")
    svg.node(510,650,420,160,"任务 Task","按spec形成约定工作成果\n任务完成仍需对应验收")
    svg.node(976,650,420,160,"验证与证据","变更：候选 / AC 的实际验收\n分析：来源明确、有范围的证据","green")
    svg.text(953,705,"核验",size=15,anchor="middle",color="green")
    svg.node(44,865,1352,130,"执行层：一条 run 承接结果","run 保存输入核查和封存结果，operation 管幂等恢复，event 留关键事实；下一 run 重核来源。\n独立分析可只关联项目：记录事实、假设和结论状态，不伪造 CHG / VER；明确修复再提出新变更。")
    svg.text(44,1052,"表示层：每个字段只有一个编辑权威，历史快照和只读报告不成为第二套当前状态",size=21,color="muted")
    svg.node(44,1090,420,210,"可编辑 Markdown","目标、规格 / AC 含义、提议\n设计理由、决定及正式规则\n任务只保留概要；发布材料可审阅","green")
    svg.node(510,1090,420,210,"SQLite 结构化事实","任务定义 / 状态、有效修订与接受\n验证、发布、经验、分析及执行关联\n历史快照不是当前正文，报告可再生成","blue")
    svg.node(976,1090,420,210,"证据文件 / 生成视图","附件保存真实来源，DB 维护引用\ntasks / analysis 等按需生成\n直接改报告不会反向更改事实","green")
    svg.text(44,1370,"资料承接：候选编辑 → 修订绑定文档与任务 → 接受并实施 → 验证 → 同步当前规格与归档。",size=20,color="muted")
    return svg.finish("13-object-and-trace-model.svg")


def main():
    from diagram_sources import SEQUENCES

    manifest = [architecture(), lifecycle()]
    for spec in SEQUENCES:
        manifest.append(sequence(**spec))
    manifest.append(object_model())
    manifest.sort(key=lambda item: item["file"])
    (ROOT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Generated {len(manifest)} SVG diagrams in {ROOT}")


if __name__ == "__main__":
    main()
