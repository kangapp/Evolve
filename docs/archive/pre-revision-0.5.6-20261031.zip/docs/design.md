# 总体设计与领域模型

设计基线：0.5.6；更新：2026-10-29（Asia/Shanghai）。本轮审查四类场景在职责、模板、留档与续接／转修复上的一致性，修订为 0.5.6，不开始插件编码。

本文定义目标、对象、职责和数据权威。[工作流](workflows.md)定义操作行为，[运行契约](runtime.md)定义技术字段和恢复，[交付计划](delivery.md)保存决策与验收，[案例](scenarios.md)仅演示。一个规则在负责文档中维护，其他文档通过章节链接引用。

导航：[范围](#scope) · [工作范围](#work-scope) · [对象](#domain) · [权威](#authority) · [架构](#architecture) · [布局](#layout) · [参考](#references)


<a id="scope"></a>

## 目标、范围与非目标

为个人开发者与 AI 构建 Evolve（项目演进）多 Skill 插件，以 SDD 为开发方法，支持多个会话先后接续；优先验证 Codex 与 Claude Code。从需求起点覆盖规划、实施、验收、交付与留档，兼顾常规开发、数据开发、不修改业务的数据排查及血缘梳理。

当前没有安装生效的 Skill、插件 runtime、history.db 或宿主实测结果。已确认决定见[决策基线](delivery.md#decisions)；工程方案不表述为用户逐项指定。

产品名、入口和资料根统一为 Evolve、`/evolve <动作>`、`evolve/`；九个执行 Skill 使用 `evolve-*`。当前开发仓库 spec-driven 保持原名。名称表达持续理解与演进项目；SDD 仍用于说明规格驱动方法及参考来源。

### 目标

- G-001：把模糊想法收敛为目标、非目标、可验证行为和明确的开放问题。
- G-002：同时支持空项目初始化和已有项目接入，保留已有技术栈、目录与有效规范。
- G-003：以规格驱动实施，建立需求、任务、工作成果、验证、交付之间的追溯关系，代码是成果的一种形式。
- G-004：每次变更保留动机、边界、方案、修订原因、执行摘要、验证和最终结果。
- G-005：让新会话仅凭项目内文件及历史库恢复上下文，不依赖原聊天仍然可见。
- G-006：按变更风险调整材料和验证深度，避免小改动承担完整大功能流程。
- G-007：通过统一写入和校验机制减少状态遗漏、编号冲突及失真的完成记录。
- G-008：让使用者主要阅读规划与结果，详细执行记录由 Skill 维护并按需查询。
- G-009：相同核心流程可在 Codex 和 Claude Code 上执行，宿主差异集中在适配层。
- G-010：独立认知工作可保存事实、假设和限制并跨会话续查；不以留档为由修改业务或虚构变更验收。

### 非目标

- NG-001：首版不构建 Web 管理后台、独立 SaaS 或多人实时协作平台。
- NG-002：不把所有文档、源码、测试输出和完整聊天无差别写入 SQLite。
- NG-003：不固定应用或数据技术栈，不替用户预选框架、数据平台或交付工具。
- NG-004：不复刻 OpenSpec 全部能力，不将其 CLI 设为必要依赖。
- NG-005：不以文档替代真实测试，不将计划、推断或未执行的发布写成完成事实。
- NG-006：不默认录制每个工具调用、每次编辑或操作系统活动。
- NG-007：不因启用 Evolve 自动推送、合并、部署或执行数据库迁移；实际动作遵循当前用户授权和项目配置。

<a id="work-scope"></a>

## 通用工作范围与成果

Evolve 负责组织工作、记录迭代、验证结果和沉淀经验；项目 spec 决定具体做什么、范围、方法与完成标准。实现或正式约定发生改变时，不论代码、数据还是文档，均走变更路径；仅解释／调查／关系观察走独立 analyze。工作目的决定路径，数据排查和血缘梳理中的正式知识修订也遵循相同边界。九个 Skill、十五个顶层动作、现有领域对象和状态取值保持不变。

工作成果可以是代码、SQL、脚本、模型定义、项目配置、正式文档或按 spec 确认的其他结果。成果不是新实体或新状态机，以现有 artifact／引用、任务结果、验证和证据表达。仅导出独立分析报告无需创建 CHG 或 REL；明确要改变业务、正式知识或交付范围时再提出变更。

数据对象、业务日期、输入输出、计算口径和血缘覆盖按需要作为项目上下文记录；不为数据工作新增 profile、强制平台配置、资产目录、作业运行表、血缘图数据库或独立平台适配。项目既有工具／资料及实际结果可以作为依据，工具不可用时报告限制，不宣称插件具备未实现的平台能力。

首次／缺失事实基线由 init 在明确范围补齐；已有有效业务口径、规格或正式依赖的改变归 propose／update，经验及确认后的规则晋升归 learn。分析结果、正式业务知识和经验规则分别承接，不因对象叫“血缘图”就跳过对应负责动作。

补数、修数及其他实际操作由有效 spec 与当前请求确定，复用既有执行、验证及未知结果处理；不新增一套数据操作流程。纯记录导出、SQL 提交或作业成功只说明相应事实，不能自动证明 spec 中更大范围的目标已完成。

<a id="domain"></a>

## 领域对象及关系

- **领域层**：项目、能力／规格条目、变更、任务、验证与证据、发布、经验及正式规则；回答要做什么、发生了什么、凭什么确认。
- **执行层**：Skill 执行方法；run 记录一次执行及其结果，operation 实现幂等和中断恢复，event 留下关键事实。它们不等同于业务完成。
- **表示层**：可编辑 Markdown、SQLite 记录、证据文件和生成视图。文件或表不是新的业务对象，同一对象有多种展示形式仍只维护一套权威字段。

独立分析／排查／解释是工作目的，可由项目级 run 表达；不因为它尚未改变业务就伪造变更对象，也不为每个工作目的新增一套数据表。

分析主题由同项目 analyze run 的顺序链派生，不新增分析实体。初始化 records_only 是记录底座覆盖，development 是开发起点范围；两者由 init run 留事实，不成为两套业务状态机。

例如“验证”是对象，“通过”是结果，“验证报告”是展示。业务事实优先，存储方式和 Skill 数量不能改变其含义。

- **项目 Project**：拥有目标、边界、业务词汇、规格及迭代历史，project_id 不随目录或宿主变化。
- **能力与规格条目 Spec**：描述当前已确认且与实现相符的行为、约束和 AC。变更中的未来行为是增量提议，不能提前冒充当前基线。
- **变更 Change**：一次有范围、动机、验收和结果的工作，可关联多个规格；修订保留范围、材料、任务定义和接受依据的历史整体。
- **任务 Task**：变更内的实施单元，形成 spec 约定的工作成果，有依赖、完成条件和实际结果；任务完成不等于验收通过。
- **验证 Verification**：对明确候选成果、实际范围和验收集合的检查，方法可以是测试、对账、口径核对、结果检查或人工观察；结果、覆盖、时效与证据共同决定能否采用。**证据 Evidence** 保存来源和范围，也可直接来自独立分析 run，不一定有 VER。
- **发布 Release**：将 spec 确定的候选成果在明确目标／环境准备、交付和观察，可纳入多个变更；不限定为应用代码部署，与归档独立。
- **经验 Experience**：由可追溯事实提炼、有适用条件的建议，保留支持和反例。正式规则 Rule 是经确认的约束，不是经验状态自动升级出来的强制命令。

主关系：项目拥有规格和变更；变更经修订定义任务与规格增量；任务实施后由验证和证据证明结果；发布关联适用变更；经验引用这些实际事实，并在下一次使用时记录效果。

业务词汇属于目标项目，例如“用户—文章—收藏”的身份和唯一性约束。init 在 project.md 或现有领域文档中梳理必要定义；业务复杂时才分出领域说明，代码地图不替代业务概念。

增量规格描述相对基线新增／修改／删除的行为；规划修订绑定材料、任务定义和验收引用的历史整体。归档封存本次实际完成范围，与发布观察独立；已归档／取消对象的后继业务修改通过新变更关联。

事实确定性使用 confirmed／inferred／risk／unknown，附代码、测试、文档或用户确认依据。现有测试证明的行为不自动等于用户期望保留的行为，已知缺陷必须标识。

<a id="authority"></a>

## Markdown、SQLite、证据和视图的权威

由 Agent 或用户编辑，通过候选修订和接受流程生效：

- project.md：目标、非目标、范围、业务词汇、约束和项目级开放问题。
- specs：当前行为、规则和验收含义；未实现提议不得直接覆盖。
- proposal：本次动机、范围、未来增量、验收、风险、问题和任务概要。简单变更将必要内容写在一份文件中。
- design／decision：有真实技术取舍或长期决定时创建，避免机械拆文档。
- 正式规则：经确认的当前约束与适用范围。
- release-notes／checklist／rollback：可审阅的交付内容、检查安排和恢复步骤，修改后相关准备摘要重新校验。

这些文档里的 TASK 引用和进展摘要不形成可独立编辑的完整任务表；动态状态不由手写状态标题决定。proposal 中“已验收”的文字也不能替代数据库验证记录。

### SQLite：结构化工作与事实

由共享工具规范化写入，用户通过命令或自然语言要求变更：

- Change 身份、有效修订／接受记录、生命周期及关联；Markdown 决定语义，数据库标明哪些材料版本当前有效。
- Task 的完整定义、依赖、完成条件、状态和结果；proposal 只保留概要，tasks.md 从数据库生成。
- Verification 的逐项结果、证据引用、候选摘要、实际方法、时效与环境；AC 含义由对应 Markdown 修订确定，数据库不另造同权 AC 正文。
- Release 的候选／环境关联、尝试、实际观察和未决占用；可编辑发布材料不直接更改部署状态。
- Experience 的条件、状态、版本、来源及复用效果；经验摘要是生成视图，正式规则正文仍归 Markdown。
- 独立分析的目标／问题／范围、观察、假设、结论状态与剩余问题由 run 保存，CHG 可空；分析报告是其生成视图，不另建可自由编辑的同权结论。
- 修订快照、索引、run 输入核查／结束结果、event 和 operation；保存可解释和可恢复的历史。

文档历史快照是过去字节及摘要，不是另一份当前可编辑正文。规格索引只定位编号与版本，失配要报告或重建，不能反向改写文档语义。过去事实通过纠正事件及新记录补充，不覆盖原结果。

归档／交付只声明已接受 spec 的实际完成范围。被交付成果与验收依据分别引用，有限观察不推导未检查范围；由外部系统或用户提供的结果核对适用性后可作为证据，不能冒充 Agent 自己执行。

### 证据文件与生成视图

实际命令输出、附件、截图等保存为证据文件，SQLite 保存稳定引用、摘要、范围和来源；可恢复包包含必要附件，不能只打包数据库。

tasks.md、verification.md、archive-summary.md、execution-summary.md、resume.md、analysis.md 和经验导出均为**按需生成视图**。头部标来源、版本与时间；不要求每次都落盘。直接修改这些文件不会更新数据库，工具识别后解释正确修订入口，不猜测复选框代表的动作。

TOML 配置由 evolve-init 根据初始化确认、真实项目事实及后续明确调整生成维护，规定 Evolve 的执行约定；项目原有代码、SQL、模型及配置代表相应实现。实际表结构、外部数据或关系观察保留来源和时点，数据库里的快照不能独立修改源事实。Markdown 维护业务含义与决定，避免为同一字段定义制造第二份手改权威。

可归档、同步程度和下一步由事实派生，不新增手工 done、archive_ready 或推荐状态表。未知、未运行、失败和通过分别保留；经验引用次数不等于成功次数。

具体模板和字段见[文档契约](runtime.md#documents)及[数据模型](runtime.md#data)。

<a id="architecture"></a>

## 插件层次与九个 Skill

一个插件分发九个 Skill、一个共享确定性内核和公共模板；公共资源只维护一份。宿主包装只负责发现、资源定位和传参，不复制阶段业务实现。

![整体架构](diagrams/01-system-architecture.svg)

- **用户／宿主**：决定目标、范围与必要确认，提供交互和实际工具权限。
- **evolve-workflow**：承接统一入口，只读解析、路由、状态、推荐和上下文恢复；写动作交对应 owner 执行。
- **evolve-init**：记录接入或开发起点，自动维护 Evolve 执行约定；普通业务配置变更仍由 propose／apply 承接。
- **evolve-propose**：变更 create／update，以及独立 analyze 方法。
- **evolve-apply**：按已呈现的有效修订形成约定成果，不限定为修改应用代码。
- **evolve-verify**：按 spec 验收成果、口径和实际结果，记录方法与证据。
- **evolve-archive**：规格同步与变更封存。
- **evolve-release**：按 spec 准备、执行或登记实际交付，保留核实与回滚事实。
- **evolve-learn**：经验、复盘及确认后的知识晋升。
- **evolve-maintain**：档案查询、导出、取消、备份与恢复。

各动作的完整输入、前置、输出及下一步仅在[工作流](workflows.md)定义。Skill 的数量不等于用户必经步骤数；常用开发六入口之外，分析可短路径结束。Skill 不是常驻进程，不默认派生多 Agent、后台调度或模型 API 调用。

入口动作、子方法及当前范围先规范化，再按唯一 owner 执行；配置支持方法归 init，原父 run 的执行归属保持不变。跨会话只读恢复同时查看项目级配置操作及领域目标，不能因无 CHG 而遗漏中断。具体门禁与恢复按 workflows／runtime 维护。

内核负责配置、规范化写入、状态校验、幂等、指纹、证据、结果和恢复，不凭语义推断业务已满足。owner_skill 是追溯及动作归属字段，不是身份认证；公共协议不能阻止所有外部编辑器直接改文件。

![领域、执行和表示层](diagrams/13-object-and-trace-model.svg)

<a id="layout"></a>

## 预期插件与目标项目布局

```text
spec-driven/
├── AGENT.md
├── docs/                         # 设计文档及已有绘图工具
└── evolve-plugin/                # 后续编码阶段才创建
    ├── <宿主插件清单与适配资源>
    ├── skills/
    │   ├── evolve-workflow/SKILL.md
    │   ├── evolve-init/SKILL.md
    │   ├── evolve-propose/SKILL.md
    │   ├── evolve-apply/SKILL.md
    │   ├── evolve-verify/SKILL.md
    │   ├── evolve-release/SKILL.md
    │   ├── evolve-archive/SKILL.md
    │   ├── evolve-learn/SKILL.md
    │   └── evolve-maintain/SKILL.md
    ├── shared/                   # 执行协议、动作归属、公共参考与资源定位
    ├── runtime/
    │   ├── evolve.py             # 唯一工具入口
    │   └── evolve_core/          # 状态、存储、执行及恢复
    └── assets/templates/
```

各 Skill 按需包含自己的 references 和必要元数据，公共协议只保存一处。禁止九份实现拷贝或把整个开发 docs 目录装入每个 Skill。

### 使用插件后的目标项目

```text
target-project/
├── <既有源码、测试与宿主规则>
├── evolve/
│   ├── config.toml              # init 自动生成维护，用户无需手填
│   ├── history.db               # 所有 Skill 共用；结果与输入核查合一
│   ├── project.md
│   ├── codemap.md
│   ├── specs/<capability>/spec.md
│   ├── decisions/DEC-*.md
│   ├── changes/<change-id>/
│   ├── changes/archive/<change-id>/
│   ├── evidence/<run-or-verification-id>/
│   ├── releases/<release-id>/
│   └── exports/<export-id>/
└── .evolve-local/                # 短锁、暂存、备份及 init/restore 控制清单
```

项目 ID 与执行引用不依赖宿主会话 ID。Markdown、history.db 和必要附件随项目保存；临时目录不是普通执行结果的唯一来源；建库前与换库中，独立控制清单是恢复例外，完成后将结果写入库。支持个人跨会话先后接续，不默认支持并行修改同一变更或数据库跨分支自动合并。

已有文档目录由 init 自动识别并通过配置映射，不强制迁移。当前尚无旧版插件或真实历史库，本轮不执行 sdd 目录迁移、不重命名当前仓库，也不为旧命令承诺兼容包装。若未来接入项目已有同名 evolve/ 或多套候选资料，先核对身份与内容并澄清冲突，不能覆盖或创建第二份权威库。evidence 可以直接归属于分析 run，也可对应验收；目录定位来源，CHG／VER／REL 的关联以数据库为准。模板按需生成，目标布局不等于 init 要创建全部空目录／文件。

运行时资源定位、宿主发现和整包版本核对见[运行环境](runtime.md#environment)。本项目自己的设计文档结构见[总入口](README.md)。

<a id="references"></a>

## 参考依据与采用边界

- 用户提供的[《SDD开发工作流》](https://nor7qsazs0.feishu.cn/docx/JGVLdGyxmoIfpTxeibicfp6Znhg)。飞书 CLI 因当前授权身份权限不足未能读取，通过浏览器已有登录会话阅读了相关章节。部分代码块显示未加载，不能将其未显示的内容当作已获取依据。
- [OpenSpec Concepts](https://github.com/Fission-AI/OpenSpec/blob/main/docs/concepts.md) 与 [How Commands Work](https://github.com/Fission-AI/OpenSpec/blob/main/docs/how-commands-work.md)：参考当前规格、独立变更、增量规格、可回访修订、同步和归档的思想。
- [SQLite 使用场景](https://www.sqlite.org/whentouse.html)与[外键约束](https://www.sqlite.org/foreignkeys.html)：作为本地结构化历史的技术依据。

借鉴 OpenSpec 的思想，不默认要求安装 OpenSpec，不宣称与其命令、目录或内部格式完全兼容。



参考 Matt Pocock 的 [ask-matt](https://github.com/mattpocock/skills/blob/main/skills/engineering/ask-matt/SKILL.md)、[to-spec](https://github.com/mattpocock/skills/blob/main/skills/engineering/to-spec/SKILL.md) 和 [retro](https://github.com/mattpocock/skills/blob/main/skills/engineering/retro/SKILL.md)，采用职责、路由和组合思想；不直接移植自动提交、外部跟踪器、临时交接目录、强制清上下文或并行代理策略。

只读核对本机 `D:/workplace/automated-deployment` 当前工作区的协作规范、任务与发现记录，以及一个对应代码和测试案例。该项目存在原有未提交改动，本次没有修改该项目、运行产品流程或重新执行其测试。

已核对的来源：

- [AGENTS.md §0](../../automated-deployment/AGENTS.md#L9)：按触发场景读取规则的唯一路由。
- [AGENTS.md §5](../../automated-deployment/AGENTS.md#L194)：写入触发、先索引后正文、失效标识与编号关联。
- [AGENTS.md §6](../../automated-deployment/AGENTS.md#L228)：任务结束记录与知识晋升；同主题至少三条触发提案，核心规则修改需确认。
- [任务完成规范](../../automated-deployment/docs/rules/task-completion.md#L31)：知识晋升检查是每次任务总结的一部分。
- [缺陷守则与索引](../../automated-deployment/docs/rules/bug-prevention.md)：短核心守则、主题索引与按需展开的详细案例分层。
- [FIND-028](../../automated-deployment/docs/rules/decision-log.md#L3880)、[TC-226/227](../../automated-deployment/docs/rules/task-completion-history.md#L237)：问题、修复与确认晋升的实际记录。
- [补丁写入实现](../../automated-deployment/lib/api/services/data_service_sync.py#L507)、[回归用例](../../automated-deployment/tests/test_data_service_sync.py#L411)：用切片替换避免转义内容被替换字符串再次解释。
- [BUG-035](../../automated-deployment/docs/rules/bug-prevention-archive.md#L373)：发布包状态成功但内容为空的反例及前后检查设计。

这些证据表明存在规范驱动的记录、引用、晋升和部分实现落地，不能据此声称项目已经具备全自动学习引擎，也不能证明所有任务都完整遵守规范。

上述相对链接只便于当前相邻工作区阅读，引用行号用于本轮核对；未来交付 Skill 不依赖此项目或其机器路径，不能把链接复制为目标项目的必读规则。

该参考中的按场景读取、结束知识检查、主题聚合、确认晋升和证据关联用于当前[经验流程](workflows.md#learning)。固定三条阈值、平台字段和技术规则不自动成为本插件规范：含转义的补丁需要真实往返校验，但不能泛化为禁止所有正则替换；包状态成功须核对实际交付，但不硬编码原平台字段；静态／夹具／模拟／真实环境证据层次不得互相冒充。
