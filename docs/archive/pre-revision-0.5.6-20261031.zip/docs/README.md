# Evolve 多 Skill 插件设计入口

设计基线 **0.5.6**；更新：2026-10-29。当前只有设计与模拟案例，未开始插件编码、建库、安装或真实发布。工作约束先读 [AGENT.md](../AGENT.md)。

Evolve（项目演进）以 SDD 为开发方法，覆盖分析、规划、实施、验收、归档、交付和经验复用；常规开发、数据开发共用变更路径，数据排查与血缘梳理共用独立分析。具体平台、操作方式和完成标准由项目 spec 确定，不建设平台适配或新状态机。统一逻辑入口为 `/evolve <动作>`；九个 Skill 共用 `evolve/` 内的项目资料与历史。初始化自动识别并生成配置，只确认必要选择；后续无需手填配置。

```text
/evolve init
/evolve propose 增加收藏功能
/evolve apply
/evolve verify
/evolve archive
/evolve release

/evolve analyze 排查收藏接口偶发500，只分析并留档
/evolve resume
```

以上为设计中的逻辑入口，实际宿主调用形式待适配实测。resume 只读恢复，同时核对配置中断；仅调整 Evolve 配置继续使用 init，业务配置修改走变更流程。具体演练见[配置调整中断与续接](scenarios.md#configuration-recovery)。

## 五份主文档

1. [总体设计与领域模型](design.md)：目标、非目标、对象关系、九个 Skill 职责、数据权威和插件布局。
2. [命令与工作流程](workflows.md)：唯一命令映射，开发／分析路径、阶段契约、续接、转修复和知识晋升。
3. [运行契约、存储与恢复](runtime.md)：SQLite、配置、模板、工具、run／来源、证据、幂等和恢复机制。
4. [实施、验收与决策](delivery.md)：M0—M4、V-001—V-084、有效决定、工程方案及开放问题。
5. [场景演练](scenarios.md)：常规开发、独立排查与配置恢复，并补充[数据开发](scenarios.md#data-development)、[数据排查](scenarios.md#data-investigation)和[血缘梳理](scenarios.md#data-lineage)三个案例。

第一次了解：design → workflows → scenarios。后续实现按动作加载 runtime 对应章节和 delivery 的阶段要求，不必一次读完所有正文。

## 路径与总览

开发：init → propose → apply → verify → archive；release 按需。独立分析：明确问题 → 取证／解释 → 留档结束；明确续查或修复后再进入相应动作。单阶段请求不自动扩大，明确多阶段请求可在范围内继续。

![整体架构](diagrams/01-system-architecture.svg)

常规流程详见[开发图](workflows.md#common)，分析及转修复详见[分析图](workflows.md#analysis)。17 张 SVG 已分别放入负责的正文附近；[图册清单](diagrams/manifest.json)保留完整文件索引。

## 维护和历史

定义／权威仅在 design 维护，动作／门禁仅在 workflows 维护，技术字段／恢复仅在 runtime 维护，计划／验收／决定仅在 delivery 维护；案例引用规则。锚点保持稳定，先修正文，再同步受影响的图、案例和链接。

图册源为 [diagram_sources.py](diagrams/diagram_sources.py) 与 [render_diagrams.py](diagrams/render_diagrams.py)。在项目根运行 `python docs/diagrams/render_diagrams.py` 仅重新生成文档 SVG，不执行插件或案例操作。

[历史审查、原文快照及迁移清单](archive/consolidation-record.md)集中在 archive，默认不作为当前规范加载。重组记录保存 0.5.2 当时的检查结果；0.5.3 按 [D-015](delivery.md#decisions) 统一命名、入口和配置。0.5.4 已完成[专项完整审查](delivery.md#review-053)，收紧入口、配置及恢复边界；[0.5.5 泛化修订](delivery.md#generalization-055)按 D-016 兼顾数据场景；当前 [0.5.6 四场景审查](delivery.md#review-055)收紧职责、最小上下文、封存导出及续接／修复边界，九个 Skill／十五个动作不变，V 增至 84 项未来要求。
