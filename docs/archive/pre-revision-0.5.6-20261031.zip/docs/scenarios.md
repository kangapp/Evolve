# 场景演练：常规开发与数据工作

设计基线：0.5.6；更新：2026-10-29。本文仅演示使用，所有业务答复、编号、源码、日志、候选、验收和发布结果均为假设；没有执行业务操作或创建 history.db。入口是待宿主适配的逻辑命令。

规则以[工作流](workflows.md)及[运行契约](runtime.md)为准，案例不定义第二套契约。所有“保存报告／图”的请求都在源结果封存后自动调用已有 maintain export，以独立导出 run 留来源／输出摘要；用户无需多发命令，导出不进入分析续查链或改写源结果。阅读导航：[新项目](#new-project) · [独立排查到发布](#investigation) · [配置续接](#configuration-recovery) · [数据开发](#data-development) · [数据排查](#data-investigation) · [血缘梳理](#data-lineage) · [异常及边界](#edges)。


<a id="new-project"></a>

## 案例 A：新项目初始化到功能迭代和交付

假设从空目录开始构建单用户本地待办 CLI。模拟中用户已经选择 Python 3.11+ 和本地 JSON 业务文件；Evolve 历史仍固定 SQLite，两者是不同数据。暂不做登录、多设备同步、多人协作和云部署。此案例补足新项目起点，后续阶段的详细失败／恢复记录由第二案例展开。

### A1. init：建立最小起点

```text
/evolve init 从空目录建立本地待办CLI，沿用已讨论的Python标准库方案。
先澄清必要范围，再建最小可运行骨架和文档；不提前实现待办功能。
```

输入已明确则不重复访谈；这里只生成最小命令帮助／工程结构及适用检查方法，不将未来功能写成已实现规格。development 初始化创建 evolve/project.md、evolve/codemap.md、自动维护的 evolve/config.toml、evolve/history.db 和必要导航；用户无需填写 TOML。模拟摘要为“采用已确定的 Python 标准库、本地 JSON 业务文件和 SQLite 历史，检查方式按实际工程生成，发布方式暂缺”。固定规则不逐项询问。

SQLite 预期记录：项目身份、init run、initialization 系统记录及本次骨架／导航检查、覆盖和未知项、材料快照。没有发布执行器时如实记录，不抄入虚构部署命令。

### A1a. 以后调整配置：仍通过自然语言

假设后续明确要调整检查方式，可以发：

```text
/evolve init 将项目检查改为 python -m unittest discover -s tests，其他约定沿用。
```

evolve-init 读取已有配置和工程事实，校验适用性后只更新该检查项，保留文档映射、其他约定与说明，不重建业务骨架或历史库，也不立刻运行检查。SQLite 保存 init run、配置变更来源／前后摘要和影响，不建新的 CHG／TASK；旧验证及发布准备按摘要重新核查。用户不需要知道 TOML 字段；若未作此调整，直接继续 A2。

### A2. propose：首个功能迭代

```text
/evolve propose 添加待办、列出未完成待办、标记完成；重启后仍可读取。
本次只支持单用户本地文件；请提出方案，先不实施。
```

模拟澄清：空标题报错；待办有稳定 ID；默认列表只展示未完成；重复完成已有任务按幂等结果处理；文件损坏须明确报错，不能覆盖成空列表。

文档：一份短 proposal.md 内嵌必要增量与验收；无需空 design／delta 文件。SQLite：一个示例 CHG-CLI、REV-001、完整任务／依赖及规划快照，呈现后 ready，但未接受。TASK-001 为数据持久化，TASK-002 为命令入口与错误响应，TASK-003 为相应回归；依赖逐项记录。

### A3. 部分 apply 后正常换会话

```text
/evolve apply CHG-CLI 只做 TASK-001
```

CHG-CLI 是本文友好占位，实际使用系统展示的变更号。指令接受已呈现 REV-001，本次仅实施持久化任务及适当检查。SQLite 保存接受来源、任务实际结果、指纹和证据；CLI 任务仍待做，不因依赖等待假记故障 blocked。通常不新增报告，证据保存正式附件。

正常结束后在同一工作区换会话：

```text
/evolve resume CHG-CLI
/evolve apply CHG-CLI
```

resume 只读恢复，显示 TASK-001 已完成、TASK-002 就绪及后续任务，不建 run 或文件。明确 apply 才新建实施 run，完成其余就绪任务；不重复做仍有效的 TASK-001。工作区源码、文档、数据库和必要证据必须保留，不靠复制聊天恢复。配置直接读取 evolve/config.toml，用户无需再次确认初始选择；resume 发现项目检查方式变化时只提示差异，不重写配置。

### A4. verify：用实际结果验收

```text
/evolve verify CHG-CLI 核对新增、列表过滤、完成幂等、重启持久化及文件损坏处理，保存报告。
```

假定受控检查全部通过，候选 C-CLI 前后未变。SQLite 记录 VER-CLI、逐项结果、REV、实际候选、环境／范围与证据；按要求生成 verification.md。检查损坏文件不会覆盖用户真实业务数据。任务 done 不代替这次验收；检查未运行时不能采用假设通过。

### A5. archive：形成已实现规格

```text
/evolve archive CHG-CLI 保存归档摘要，先不发布。
```

同步已实现并验收的待办行为，保存增量应用证明；材料移入归档目录，生成摘要。SQLite 保留 archived 与尚无实际发布的 unreleased，继续保存旧规划和证据。

### A6. 发布准备及人工结果登记

```text
/evolve release prepare 本次待办CLI的0.1.0版本，目标本地分发，生成说明、检查清单和回滚方案，先不执行。
```

发布材料为 release-notes／checklist／rollback 三份可审阅文档。仅准备材料不要求先接入真实部署；本例保留配置不变，REL-CLI 固定候选、范围、环境、验收与准备摘要。若此时首次需要接入执行器，先由 init 支持方法在明确范围内补配置并记录 component_skill=evolve-init／operation；配置改变导致原验收依据过期时，推荐 `/evolve verify CHG-CLI`，取得适用结果后再 prepare，不能沿用旧通过记录。没有执行适配就停在准备，不能伪称自动分发成功。

若用户后来已经人工交付，并提供可核查的包摘要、交付记录和实际结果，可明确登记：

```text
/evolve release record REL-CLI 根据我提供的交付记录和包摘要登记实际结果，注明人工分发来源。
```

SQLite 保存真实来源、时间、候选对应关系和观察，必要附件入 evidence；满足本例假设的成功依据才汇总 succeeded。record 不伪装成插件执行过分发。自动执行、失败复验和发布未知处理见第二案例。

<a id="investigation"></a>

## 案例 B：独立排查、换会话续查、修复及发布

### B1. 场景、身份及产物约定

假设有一个已有源码的 reader-app，收藏接口在同一用户并发收藏同一文章时偶发 500。数据库已有“用户 + 文章”唯一约束，现有接口约定首次收藏返回 201，重复收藏返回 200；真实数据库不可用应保留现有 503 错误语义。起初项目尚未接入 Evolve，用户只想查原因。

主线依次经过：

```text
会话 A：明确独立排查 → init records_only → analyze A（partial）
会话 B：resume（只读） → analyze B（有范围的 answered）
       → init development（补目标基线） → propose（呈现 REV）
       → apply（候选 C1） → verify（失败）
       → apply（修正为 C2） → verify（通过）
       → archive（未发布） → release prepare → release execute（test 成功）
会话 C：status / history（只读回看）
```

RUN-A／RUN-B 等只是文中的执行别名，实际 run／request／operation 使用系统生成的稳定 ID，用户无需填写。业务变更使用虚构友好编号 `CHG-20261027-c5d6e7f8`，以下简称本次修复；REV-001、TASK-001 等编号均为示例，实际须使用系统展示值。C1／C2 为实际源码、配置、依赖及测试范围的指纹简称。

所有路径均为**目标项目内的预期产物**，不是当前 spec-driven 仓库里实际创建的业务文件。本例选择将可读报告统一放入 evolve/exports，便于与可编辑资料分开；这是案例路径选择，不增加新的固定目录契约。

每个写阶段共有的 SQLite 留档是 phase_runs 的当前输入、targets、来源与 input_checks，及时提交的 events／operations，以及结束时一次封存的 result／result_digest。以下逐步只补充本阶段具体内容。跨阶段来源用 source_runs，直接 REV／VER／REL／artifact 用带类型的资料引用；不用一条 previous 链混装所有阶段。

### B2. 会话 A：只排查并留档，自动最小接入

**你发：**

```text
/evolve analyze
排查收藏接口偶发 500，标题“收藏 500 排查”。
只读取现有源码和我提供的脱敏日志，不修改业务，不重放真实请求。
结果留档；缺少 Evolve 时只接必要记录设施，先不要修复或提出修复方案。
```

**由谁执行：** evolve-propose 负责 analyze；发现无记录底座时先加载 evolve-init，使用 records_only 接入，再开始分析。用户不必额外发 init，不会被要求先完成整套产品访谈。

**产生的文档与文件：**

- `evolve/config.toml`、`evolve/history.db`、`evolve/project.md` 最小范围导航；必要的 `.evolve-local/control/` 初始化清单。导航只说明本次观察范围及未知项。
- `evolve/evidence/<RUN-A>/`：必要源码片段／版本摘要、脱敏日志及来源说明。不会复制全部日志或保存凭证。
- 本次未要求独立报告，因此不生成 analysis.md，也不创建业务骨架、proposal、TASK、未来规格或 VER。

**SQLite 预期记录：**

- RUN-I-R：owner=evolve-init，input.profile=records_only，保存实际覆盖、配置／导航引用及记录设施完成结果。没有业务 CHG／TASK。
- RUN-A：owner=evolve-propose，action=analyze，target 为项目，input 中记录问题、范围、完成条件、business_effect=read_only、record=true。
- evidence 的 source_run_id 为 RUN-A、verification_id 为空；事件及时保存已查入口、观察和待查问题。
- 封存 result.analysis：F1“先查询后插入”；F2“已有日志定位到插入路径，但缺错误码”；H1“并发插入触发唯一冲突，未按重复收藏处理”；Q1“缺少同请求错误码及关联日志”。
- RUN-A 状态 completed，answer_status=partial。F1／H1 是 RUN-A 内的局部标记，H1 不是已确认根因。

**你看到的结果及推荐：**

> 已保存本轮排查及必要证据；目前存在并发唯一冲突假设，尚不能确认本次 500 的根因。业务未修改。下一步补充失败请求错误码和关联日志后继续排查，也可以到此结束。

这里“留档完成”只指记录已实际保存，不代表故障已修复；不要求业务归档或验收。

### B3. 会话 B：先只读恢复

你结束会话 A，在同一项目工作区打开新会话，发：

```text
/evolve resume 收藏 500 排查
```

**由谁执行：** evolve-workflow。

**文档与 SQLite：** 不产生文件、不写 run／事件、不更新索引或 guard。读取 project/config、分析链、RUN-A 结果、证据和当前相关文件，显示目标、F1／F2、H1、Q1、当时资料版本、当前差异及后续限制／纠正。

**你看到的恢复摘要：**

> 找到“收藏 500 排查”，当前分析头为 RUN-A。本轮结论 partial，待补错误码与请求关联。当前相关源码未变；本次仅恢复上下文，尚未继续取证或修改业务。

标题相同的多轮先按链折叠；同名不同主题才澄清。若显式恢复历史 RUN-A，而后来已有 RUN-B，会保留 A 的快照并提示 B，不静默替换。换会话不靠旧聊天恢复，也不自动创建新的修复变更。

### B4. 会话 B：补充证据，明确续查

**你发：**

```text
/evolve analyze
继续“收藏 500 排查”，结合我补充的脱敏错误码和关联日志核查 H1。
仍只分析，不修改业务。结束后保存一份可读报告。
```

**由谁执行：** evolve-propose 的 analyze 方法。

**模拟新证据：** 两个请求的用户与文章相同、时间重叠；对应插入报唯一约束冲突；现有异常路径将该冲突返回为 500。假定这些记录的对应关系足以支持本例的因果判断，但不能推出所有 500 都来自同一个原因。

**产生的文档与文件：**

- `evolve/evidence/<RUN-B>/` 保存新增必要日志、来源及摘要。
- `evolve/exports/<RUN-B>/analysis.md`：封存结果的生成视图，列事实、假设及其支持范围、结论、限制；头部标来源 RUN-B、result_digest、资料版本和生成时间。
- 不编辑当前规格／项目知识，不创建业务 CHG／REV／TASK／VER。

**SQLite 预期记录：**

- 新 RUN-B：previous_run_id=RUN-A，source_runs 引用 A 的封存结果。start 短事务核对 A 仍为链头、没有其他进行中或已创建后继；相同请求重试返回原 B。
- A／H1 作为 historical_context 重检；本次判断必需的日志和源码作为当前依据分别核查。input_checks 标明用途、必需性、适用性和来源限制。
- result.analysis.answer_status=answered，结论限定为“本组关联请求及对应源码版本的失败由未处理唯一冲突造成”；新增证据与局部条目可追溯。
- A 当时的 partial／H1 文本不改写。B 支持的是 `(A, A.result_digest, H1)` 的限定范围，没有把 A 伪装成第一次就已确认。

**推荐：** 本轮分析可直接结束；若要处理缺陷，再明确提出修复方案。此时不能直接将 RUN-B 当 CHG 去 apply／archive。

### B5. 从记录接入转到开发起点：按范围补基线

为把接入范围展示清楚，本例显式发一次 init；实际也可将“缺基线时先补齐收藏模块基线”写在下一步 propose 请求中，由两个负责 Skill 分别留 run，不必固定多发一道命令。

**你发：**

```text
/evolve init
基于现有 reader-app 补齐收藏模块开发基线，复用已有 Evolve 配置和历史库。
恢复现有行为、代码位置和测试方法，登记已有 test 环境发布适配配置。
只补必要文档和配置，不修改业务、不新增应用骨架、不执行部署。
```

**由谁执行：** evolve-init，input.profile=development。

**产生／更新的文档与文件：**

- 补齐 `evolve/project.md`，按需创建 `evolve/codemap.md`、`evolve/legacy-baseline.md`、`evolve/specs/favorites/spec.md`。
- 记录已经证实的唯一约束、身份边界、首次／重复响应及真实服务错误约定；偶发 500 标为实现缺陷／risk，不包装成希望保留的行为。
- `evolve/config.toml` 仅登记已识别、适用的检查与 test 发布／观察／回滚适配及指纹范围；不能照抄示例命令。这里假设原项目已具备可用适配，不在案例中实现它们。
- 新的未来修复行为仍留给下一步 proposal，不能在 init 提前声称已经实现。

**SQLite 预期记录：**

- RUN-I-D 保存 development profile、实际扫描覆盖、unknown／risk、初始化检查和产物快照；复用原 project_id／history.db。
- 本次明确范围的 initialization 系统记录及必要基线任务，完成范围为文档／导航／配置检查；它独立于后续业务修复 CHG，不要求先 propose。
- artifact_versions／blobs 保存资料快照，spec_items 定位当前基线。RUN-B 的根因结论不因补齐文档就变成业务已实现。

**推荐：** 必要基线可用时进入 propose；存在影响本次修复的关键未知则先澄清。records_only 完成并不自动满足这一条件。

### B6. 明确转修复：创建并呈现方案

**你发：**

```text
/evolve propose
根据“收藏 500 排查”的最新有效结论提出轻量修复方案，引用证据，先不实施。
同用户同文章重复或并发收藏沿用现有成功语义，不生成重复记录；
保留身份校验以及真实数据库不可用时的 503，不扩大到其他接口。
若已有匹配的活动修复，请继续该变更，不要重复建单。
```

**由谁执行：** evolve-propose 的普通 create／update。本例假设没有匹配活动变更，因此新建 `CHG-20261027-c5d6e7f8`；有明确既有目标则 update。

**产生的文档：**

- `evolve/changes/CHG-20261027-c5d6e7f8/proposal.md` 一份短提议，内嵌必要增量、AC、范围／非目标、风险、开放问题和任务概要。
- 本例不额外创建空 design.md、delta-spec.md、tasks.md；当前规格不被未来方案覆盖。

**方案示例：** 精确识别对应唯一冲突、按现有重复收藏语义返回；其他数据库异常维持原错误路径；加入并发、隔离及失败回归。

- AC-001：同一用户同一文章并发收藏，一次首次成功、另一次按已有重复成功响应，最终仅一条记录，不出现本缺陷导致的 500。
- AC-002：顺序重复保持成功语义，不同用户收藏相互隔离。
- AC-003：未登录／无权限行为保持现有约定。
- AC-004：真实数据库不可用仍为原 503，不能被当成重复收藏成功。

**SQLite 预期记录：**

- RUN-P 引用 RUN-B 及初始化资料，核对当前相关源码、后续纠正与实际基线；分析来源是判断依据，不是执行授权。
- changes 创建本次 bugfix，plan_revisions 绑定 REV-001、proposal 快照、增量／验收引用和任务定义摘要，并记录已向用户呈现的版本。
- tasks 保存完整定义／依赖：TASK-001 异常分流与响应处理；TASK-002 回归检查；proposal 只写概要，状态由 DB 管。
- 无关键未决则生命周期 ready；尚未接受实施。RUN-P 通过 source_runs 引用分析，不能用 previous_run_id=RUN-B 混入分析链。

**你看到：** 修复方案已呈现，下一步可以 apply；尚未修改业务。发现关键行为选择不明时先澄清，不自动替用户决定。

### B7. 实施：apply 接受有效修订

**你发：**

```text
/evolve apply CHG-20261027-c5d6e7f8
```

**由谁执行：** evolve-apply。这个指令接受已呈现且仍有效的 REV-001，不要求额外 approve。默认执行全部就绪任务。

**预期文件变化：** 业务异常处理源码和必要回归测试发生实际修改；`evolve/evidence/<RUN-AP1>/` 保存任务检查依据。本例假定任务级的正常／重复收藏检查通过，得到候选 C1；当时未覆盖稍后验收中的特定连接故障注入，检查范围及限制如实记录，不将 AC-004 写成已通过。无需另写手工进度表或复制 proposal。

**SQLite 预期记录：**

- RUN-AP1 核对有效 REV、材料摘要、依赖、当前意图及来源。
- 保存 REV-001 的 plan.accepted 事件与接受来源；changes 进入 active，任务逐项 start／finish，保存实际变更、检查方法、证据及限制。
- 保存 C1 实现指纹及结果引用，封存 RUN-AP1。任务 done 是实际实施／检查记录，不能代替变更级验收。

**推荐：** `/evolve verify CHG-20261027-c5d6e7f8`；只请求 apply，因此不自动替用户发布。

### B8. 独立验收：发现失败，保留证据

**你发：**

```text
/evolve verify CHG-20261027-c5d6e7f8
按全部有效 AC 验收，包含隔离环境的并发、权限和数据库失败场景，保存验收报告。
```

**由谁执行：** evolve-verify。在当前请求允许的受控测试环境运行，不对真实用户数据重放故障。

**模拟结果：** AC-001／002／003 通过；AC-004 失败——某类连接故障被过宽异常处理误判为重复成功。这是 C1 的实现不符合已约定方案，不是新需求，不因修正它自动创建新 REV。

**产生的文档与文件：**

- `evolve/evidence/<RUN-V1>/`：本次实际检查、环境、输入和输出摘要／必要附件。
- `evolve/exports/VER-001/verification.md`：数据库生成的本次失败报告，标候选 C1、REV-001、AC 映射及限制。

**SQLite 预期记录：**

- RUN-V1、verifications 中的 VER-001、verification_items 的逐项结果，关联证据及检查前后 C1 指纹。
- VER-001 总结 failed；失败不被此前任务 done 或其他三项通过遮盖。归档／发布条件不满足。
- 保存失败范围和回到实施的建议；verify 不静默修业务代码，不删除失败记录，也不伪造修复完成。

**推荐：** 对原修复变更 apply，修正异常分类并补覆盖该场景。若发现需要改变原行为／范围／AC，才先 update、呈现新修订。

### B9. 回到实施并复验：同一修复，形成新候选

**你依次发：**

```text
/evolve apply CHG-20261027-c5d6e7f8
修正 VER-001 指出的异常误判，补充相应回归，保持 REV-001 范围。
```

本次 RUN-AP2 核对失败证据，按实际原因重开相关任务，保留旧完成事件；精确分流异常，得到候选 C2。旧 C1 的验证不再作为 C2 的有效通过依据。必要任务检查和新证据进入 `evolve/evidence/<RUN-AP2>/`。

```text
/evolve verify CHG-20261027-c5d6e7f8
针对当前候选重新核对全部有效 AC 和相关回归，保存报告。
```

**SQLite 预期记录：** RUN-V2、VER-002，固定 REV-001、C2 和当前检查配置；逐项 AC-001 至 AC-004 适用且均通过，前后候选未漂移，必需回归完整。RUN-AP2 与 RUN-AP1 属于同类续作，可关联 previous；两个 verify 的新旧关系也不抹去 VER-001。

**产生的文档与文件：** `evolve/evidence/<RUN-V2>/` 和 `evolve/exports/VER-002/verification.md`。旧 VER-001 报告及正式失败证据保留。

**推荐：** 现在“可归档”由任务闭合、当前有效验收通过、无关键问题及引用完整派生，不新增一个手工 done 状态，也不表示已经上线。

### B10. 归档：同步规格，保留未发布事实

**你发：**

```text
/evolve archive CHG-20261027-c5d6e7f8
保存归档摘要，本次先不发布。
```

**由谁执行：** evolve-archive，内部包含必要 sync。用户无需另发 sync。

**产生／更新的文档：**

- 基于已验证实现更新 `evolve/specs/favorites/spec.md` 的对应条目；本例将并发重复仍成功、真实服务错误仍保留原语义的验收约束作为经验证增量补齐；异常分类的具体实现留在代码／方案中，已存在的行为条目引用原编号而不重复新增。
- proposal 等本次有效材料移入 `evolve/changes/archive/CHG-20261027-c5d6e7f8/`。
- 按本次要求生成其中的 `archive-summary.md`，记录冻结修订、实现 C2、有效 VER-002、失败修正过程及归档时未发布事实。它是生成视图，不手写状态替代 DB。
- 正式分析／任务／验收证据保持稳定 artifact 身份，不因归档复制多份。

**SQLite 预期记录：**

- RUN-ARCH 逐项核查 REV-001、C2、VER-002、任务范围和当前基线；执行可恢复文件／DB 操作。
- spec_applications 保存稳定增量、基线及结果摘要、验收与操作引用，重复请求不重复应用。
- artifacts 更新当前路径，历史快照引用不改写；changes 生命周期 archived，保留归档时间与冻结范围。
- 归档结束时尚无实际发布记录，展示 unreleased；这与 archived 是两项独立事实。

归档移动和有证明的规格同步不改变验收含义，不因 CHG 行版本增加一律废弃 VER-002。出现冲突／中断时保留现场并恢复，不能宣称全部成功。

### B11. 发布准备：固定版本、环境和候选

**你发：**

```text
/evolve release prepare
将 CHG-20261027-c5d6e7f8 纳入 v1.4.3，目标 test，使用已验收候选 C2。
生成发布说明、检查清单和回滚方案，先不部署。
```

**由谁执行：** evolve-release。C2 是系统展示的当前候选简称，不要求用户自己计算摘要。

**产生的文档：**

- `evolve/releases/REL-001/release-notes.md`：修复的问题、纳入变更及范围。
- `evolve/releases/REL-001/checklist.md`：候选一致性、test 环境部署及上线后检查。
- `evolve/releases/REL-001/rollback.md`：触发条件、原项目已知的恢复目标／配置、步骤及恢复检查。假设本例恢复目标为 test 的 v1.4.2；准备不代表执行回滚。

**SQLite 预期记录：**

- RUN-RP、REL-001（prepared）、release_changes 关联本次已归档修复、REV-001、C2、有效验收和准备材料摘要。
- 核对必要证据适用于同一最终候选，配置／材料有效，没有本地待恢复事项或环境未决占用。
- 若材料／执行配置变化，需要更新准备并重核依据；候选或目标环境变化按发布契约处理，不能沿用旧成功。

**推荐：** 明确执行 test 发布，或停留在准备完成。prepare 不调用部署命令，不改写归档时的 unreleased 快照。

### B12. 实际发布并记录结果

**你发：**

```text
/evolve release execute REL-001
将已准备的 v1.4.3 / C2 发布到 test，使用项目现有适配并核实结果。
```

**由谁执行：** evolve-release。这个请求才覆盖实际 test 部署；本例假设所需适配可用、检查与准备仍有效。

**模拟成功依据：** 适配返回与请求匹配的操作、候选、test 环境及实际外部部署引用；对应部署已结束，配置要求的部署后检查通过。不能仅凭进程退出 0 写成功。

**产生的文件：** `evolve/evidence/<RUN-RE>/` 保存必要部署／健康检查依据；准备材料仍为原三份，不额外手写一份“已成功”正文充当事实。

**SQLite 预期记录：**

- RUN-RE 在执行前登记 release_attempt、稳定外部幂等键、候选、环境及请求摘要，并建立环境未决占用，再调用外部程序。
- 记录执行结果、external_id、实际环境观察、observed_at、检查证据及来源；核实成功后 REL-001 汇总 succeeded，解除对应占用。
- changes 仍 archived；追加发布关联。归档摘要保留当时 unreleased，当前查询显示本次修复已随 REL-001 在 test 发布成功。
- RUN-RE 结束结果封存；策略备份／知识检查属于支持步骤，不要求用户再发命令，后置备份失败如实提示但不抹去已确认部署事实。

成功限定为 **C2 在 test 环境的本次发布及观察**。production 尚未发布；后续交付 production 必须有该环境的独立发布准备／执行依据，不能沿用 test 的成功状态。

### B13. 会话 C：回看完整历史与经验

在后续新会话，你可以发：

```text
/evolve status CHG-20261027-c5d6e7f8
/evolve history 查询“收藏 500 排查”以及关联修复的分析、验收、归档和发布历史
/evolve release status REL-001
```

这是三项只读查询，不产生 run／报告／业务修改。status 显示当前修复范围已归档、test 的最近确认发布及观察时间；history 展示 A 的 partial、B 的有限根因结论、REV 接受、C1 失败、C2 通过、归档、REL 的准备和实际尝试。标题不是长期身份，查询通过关联定位实际 run／CHG／VER／REL。

**经验如何留下：** 阶段结束可由 learn 支持方法将本次证据足够的项目经验记录为有条件建议：“有唯一约束的先查后插场景，应以精确唯一冲突处理并发重复，并保留其他数据库故障语义。”SQLite 记录适用范围、支持证据、C1 反例和 C2 验收结果；不足以泛化时维持 candidate。

后续类似提议按需检索经验，记录是否采用及实际效果；active 仍只是建议，不是自动生效的正式规则。正式规则／个人库晋升需要具体确认和负责的 learn run，不作为发布后必经步骤。本案例无需再手动 retro；用户要求集中复盘时才另发对应命令。

### B14. 最终文件和 SQLite 关系

以下仅为本例预期结构：

```text
reader-app/
├── 既有业务源码与回归测试                 # 修复阶段才修改
├── evolve/
│   ├── config.toml
│   ├── history.db
│   ├── project.md
│   ├── codemap.md
│   ├── legacy-baseline.md                 # 本例需要而创建
│   ├── specs/favorites/spec.md
│   ├── changes/archive/CHG-20261027-c5d6e7f8/
│   │   ├── proposal.md                    # 可编辑语义材料的冻结版本
│   │   └── archive-summary.md             # 归档时的生成视图
│   ├── evidence/
│   │   ├── <RUN-A>/                       # 首轮观察与假设依据
│   │   ├── <RUN-B>/                       # 续查新证据
│   │   ├── <RUN-AP1>/                     # C1 任务检查
│   │   ├── <RUN-V1>/                      # C1 失败证据
│   │   ├── <RUN-AP2>/                     # C2 修正与检查
│   │   ├── <RUN-V2>/                      # C2 通过证据
│   │   └── <RUN-RE>/                      # test 部署及观察
│   ├── exports/                           # 可再生成，不是唯一证据
│   │   ├── <RUN-B>/analysis.md
│   │   ├── VER-001/verification.md
│   │   └── VER-002/verification.md
│   └── releases/REL-001/
│       ├── release-notes.md
│       ├── checklist.md
│       └── rollback.md
└── .evolve-local/                            # 必要控制清单／暂存／保护备份
```

正式恢复包包含数据库、配置、权威 Markdown 及所有必要证据，不依赖 exports；history.db 随 Git 保存，但 Skill 不自动提交／推送，也不把 Git 回退当作线上回滚。

**关键关系：**

```text
分析链 previous：RUN-A → RUN-B
                       │ source_runs（经重核）
                       ▼
RUN-I-D 的基线 ─────→ RUN-P：CHG / REV-001
                       │
                       ▼
RUN-AP1：C1 → RUN-V1：VER-001 failed
                 │             │
                 └────→ RUN-AP2：C2 → RUN-V2：VER-002 passed
                                          ├──→ RUN-ARCH
                                          └──→ RUN-RP → RUN-RE
                                                 ▲       ▲
                        归档材料及当前领域依据 ────┴───────┘
```

除首行分析链外，其余箭头表示来源／领域依据关系，不代表统一 previous 链。archive 与 release 均核对适用 VER，不能只相信最近一个 run。resume／status／history 没有写入，因此不是执行链节点。普通阶段支持备份／经验也不额外制造独立业务阶段。

### B15. 换会话遇到异常时，指令怎样变化

这些是按需分支，不是主线额外必走步骤。

**分析中断：** 如果 A 仍 started 且拥有者已确认异常退出，系统推荐实际目标：

```text
/evolve maintain recover --run <系统展示的分析 RUN>
```

maintain 创建 RUN-M，核对已提交进度、证据，给原 A 封存 interrupted，不补造根因。下一次明确 analyze 续查，previous 仍指 A，source 可引 A 的恢复摘要及 M；不能 previous=M。若 A 已正常 completed + partial，直接续查，无需 recover。

**报告失败：** B 已封存但 analysis.md 生成失败，显示 VIEW_STALE；发 `/evolve maintain export <系统展示的 RUN-B> 的分析报告`，maintain 只重导原结果，不新建 analyze 后继或重查业务。报告不能覆盖来源／规格／proposal。

**部署超时／回执丢失：** REL-001 为 unknown，保留未决占用，不重发 execute。你发：

```text
/evolve release status REL-001 --refresh
```

release 创建观察 run／attempt，按外部操作引用核实实际状态和原尝试是否结束，保存证据后更新观察。仅“当前版本看起来正确”不足以证明所有未知操作已结束；无法核实继续 unknown。没有 --refresh 的 status 只读本地，不查询外部。

**已存在修复：** 新会话再次要求处理相同问题时，定位已有活动 CHG 并按意图 update／apply；需要重大行为修改先呈现新 REV，不能把 RUN-B 结论当成新方案接受。已经归档后再改业务，创建后继 CHG，不重开旧档案。

### B16. 实际使用可以更短

本例把每项动作拆开用于理解职责；日常只需表达明确目标，不必管理 RUN、摘要或 SQL：

- 首轮：“只查原因，留档，不修复。”
- 换会话：“恢复这项排查”；补资料后“继续查”。
- 决定修复：“补齐必要基线，提出修复方案，先不实施。”
- 看过有效方案后：“apply；完成后验证，通过再归档。”这已覆盖连续范围，各阶段仍独立留 run；关键新选择先澄清。
- 需要交付：“准备 v1.4.3 的 test 发布”；看过材料后“执行 REL-001”。

分析完成、修复实施、验收通过、归档、环境发布各有可追溯依据。读业务不等于不留档，分析 answered 不等于已修复；文件可读不代表它是可独立编辑的事实来源。

以上案例仅用于检查使用路径及记录契约，没有执行上述业务命令；不能作为 V 系列功能验收通过证据。

<a id="configuration-recovery"></a>

## 案例 C：配置调整中断后，换会话继续原变更

此例沿用案例 A 的已接入项目，CHG-CLI 的 REV-001 已呈现并接受，TASK-001 完成，其余任务待做。K1／K2／K3 只是配置摘要简称；所有故障与结果仍为模拟，没有实际操作目标项目。

### C1. 调整 Evolve 检查约定

```text
/evolve init 将检查命令改为 python -m unittest discover -s tests，其他约定沿用。
```

evolve-init 只维护 evolve/config.toml，已有测试入口须适用；不替用户新增测试代码或改业务配置。建立 RUN-I 与 OP-C，准备 journal，保存 K1 旧字节／K2 候选及摘要；没有新 CHG／TASK／REV。假设文件替换为 K2 后、数据库最终登记前进程中断，RUN-I 尚未结束。

### C2. 新会话恢复原功能

```text
/evolve resume CHG-CLI
```

evolve-workflow 只读展示原任务与已接受 REV，同时报告项目级 RUN-I／OP-C。即使 OP-C 没有 CHG，也不能漏掉：配置文件是 K2，最后已登记依据为 K1，当前存在待恢复操作。旧任务完成事实保留，当前验证可能过期；不补配置、不自动 apply、不沿用旧部署请求。推荐系统已定位的 `/evolve maintain recover OP-C`。

不生成报告或 run。若配置无法解析，仍在固定位置诊断已有库／清单并注明当前配置未确认；不能把它当空项目建第二份库。

### C3. 明确恢复确定性登记

```text
/evolve maintain recover OP-C
```

evolve-maintain 先核对项目身份、原意图、journal、实际文件及 K2 摘要。文件已是候选值时，只补配置快照、操作及事件，不再改文件，不运行新测试命令。维护 run 记录恢复结果，原未结束 RUN-I 按实际范围封存 interrupted／finalized_by，OP-C 记录已确认提交；不能声称原会话完整成功或验证已通过。

如果文件此时变成第三方修改的 K3，则保留现状并报告冲突，不覆盖 K3、不拿新 request 绕过待恢复操作。若原 OP 已提交且同 epoch 重试，返回原提交结果；不会因配置已从 K1 变成 K2 再执行一次。切换 epoch 的旧请求拒绝，重新核对当前档案。

### C4. 原有效方案继续执行

```text
/evolve apply CHG-CLI
/evolve verify CHG-CLI
```

恢复完成后，新的 apply run 引用有效 REV、配置 K2 及必要恢复结果，再检查当前任务依据。仅调整检查约定不改变原接受的 REV，不重复初始化或抹去 TASK-001 的实际完成；任务定义／实现确有变化才按相应契约处理。新的 verify 以 K2 和实际候选运行，形成新 VER；旧验证结果保留，不能改成新配置下已通过。archive／release 沿用前述正常门禁。

### C5. 首次发布补配置

`/evolve release prepare` 若当前范围明确包含接入真实发布约定，可由 init 支持方法在 release 父 run 内补齐配置，记录 component_skill=evolve-init、OP 与 K2→K4；父输入保持不变，结果引用新配置版本。原验证过期时，本轮保存带阻碍的材料并结束，推荐 verify，再用新 run 重新 prepare；不自动越阶段。已有 REL 的候选变化按发布契约新建 REL。execute／status --refresh／rollback 缺配置时直接报告，不偷偷重配。

### C6. 指令与配置边界

- `/evolve relase execute REL-CLI` 或 `/evolve release excute REL-CLI`：提示未知动作／子动作，无 run、无默认 prepare，也不推测为部署授权。
- `/evolve 请提出收藏功能方案，先不实施`：按明确自然语言路由 propose；不因前次调用过 apply 而实施。
- 要修改 package.json、产品环境变量或应用行为：提出变更；`init` 只调整 Evolve 配置，不能成为绕过方案的修复入口。
- 要把 project.id 或 history.database 改成另一项目／新库：拒绝普通配置重写，说明身份／定位限制；需要恢复时使用经过核对的原档案，不创建替代空库。

<a id="data-scenarios"></a>

## 数据场景：共用既有流程

以下 D／E／F 为三个独立模拟，可以单独阅读；编号均为占位。具体平台、SQL 方言、连接、执行和补数／修数安排由目标项目的 spec 与既有能力决定，本例不实现或调用平台。所有文档／数据库记录均为预期产物，没有实际创建。

![三类数据场景与通用工作流](diagrams/17-data-scenarios.svg)

<a id="data-development"></a>

## 案例 D：新增店铺日支付订单汇总

**场景与 spec 范围。** 已有 SQL 项目，新增按“业务日期＋店铺”汇总的支付订单数。本例假设已确认按支付日计入、同订单去重、列出固定输入／输出和样例结果；当前变更只交付 SQL、检查和口径说明，指定日期／样例对账是约定验收依据，不包含历史补数。若实际项目需要其他范围，应在有效 spec 中明确，不由工作流猜测。

### D1. init：按范围接入

```text
/evolve init 接入当前SQL项目，沿用已有目录、工具和文档。
整理现有输入资料与口径，建立迭代记录；不执行数据变更。
```

evolve-init 按 development 接入，自动维护 evolve/config.toml／history.db，生成最小 project.md 与 codemap.md，导航到原 sql/、checks/ 和业务资料；已有正式规格按原位置映射。只确认必要未知，不配置特定平台或新 data profile。SQLite 留项目、init run、实际初始化范围、资料／配置快照和必要初始化系统记录；未来汇总行为不提前写成已实现。

### D2. propose：口径和成果形成有效修订

```text
/evolve propose 新增店铺日支付订单汇总SQL。
按已确认的支付日和去重口径，列明输入输出、边界与对账标准；先不实施。
```

evolve-propose 形成 evolve/changes/CHG-DATA/proposal.md，内嵌增量与 AC：业务日期／店铺键唯一、订单去重符合约定、指定样例与独立对账结果相符。本例列 TASK-001 SQL、TASK-002 检查及对账、TASK-003 口径说明；SQLite 保存完整定义／依赖、REV-001、来源和呈现记录。无需另建资产表、平台状态或空 design.md。

### D3. apply：形成约定成果

```text
/evolve apply CHG-DATA 只做 TASK-001
```

本次接受已呈现 REV-001，形成 sql/ads_shop_order_di.sql 及相称检查，必要证据位于 evolve/evidence/<实施RUN>/。SQLite 留任务结果、实际材料摘要和限制；SQL 文件完成不代表已产出所有目标数据，也不自动执行历史补数。

### D4. 换会话继续

```text
/evolve resume CHG-DATA
/evolve apply CHG-DATA
```

resume 只读显示已接受修订、TASK-001 及未完成任务，并检查项目级配置／操作阻碍；不重新执行 SQL。明确 apply 才创建新实施 run，完成 checks/order_count.sql、约定样例及方案内说明；若执行需项目外部能力，按实际可用工具或用户提供的可核查结果记录，缺能力则如实受阻，不伪造插件执行过。

### D5. verify：按 spec 核对实际结果

```text
/evolve verify CHG-DATA 按约定样例、粒度唯一性和指定日期对账验收，保存报告。
```

evolve-verify 建 VER-DATA，记录 SQL／检查材料摘要、业务日期、实际输入与覆盖、对账方法、逐项预期／实际、来源和限制。假设本例真实依据充足且适用项通过；必要附件入 evolve/evidence/<验证RUN>/，按请求生成 evolve/exports/VER-DATA/verification.md。SQLite 沿用 verifications／verification_items／evidence，报告另留引用 VER-DATA 及源 run 的 export 记录，不建数据专属验收状态。Agent 没有亲自执行时，用户／项目工具提供的实际结果可在核对对象、日期、方法和来源后采纳，并保留原观察者及时间；所需检查没有发生或无可采纳依据才记 not_run／blocked。样例通过仅满足本例已明确的检查标准，不能声称所有日期均核查；若真实 AC 要求更大范围，先补齐或按 update 修订，不直接归档。

### D6. archive：封存范围内成果

```text
/evolve archive CHG-DATA 保存摘要，暂不交付。
```

evolve-archive 同步已实施并验证的口径到 evolve/specs/shop-orders/spec.md（若映射既有正式文档则沿原位置），将 proposal 等移入 changes/archive/CHG-DATA/，按请求生成 archive-summary.md。SQLite 保存规格应用、归档与 VER 关联；完成事实仅覆盖本次 SQL／检查／说明，没有“历史分区已补齐”的结果。

### D7. 按需交付

```text
/evolve release prepare 将本次已验证SQL版本交付给项目约定的任务目录，先准备材料。
```

evolve-release 固定 REL-DATA 的成果材料摘要、范围和目标，生成 releases/REL-DATA/ 的说明／检查清单／恢复安排。若项目没有可用执行方式，就停在准备；本例不为交付安装平台适配或改配置。用户随后已按原项目方式完成交付并提供材料和依据时，可发：

```text
/evolve release record REL-DATA 根据我提供的SQL版本、交付记录和检查结果登记实际交付。
```

SQLite 保存实际来源、观察、release_changes 与证据；record 不伪装成插件执行。后续复盘可把本次对账发现及适用范围记为项目经验，没有新经验也可如实记录，不额外要求 learn 命令。常规开发仍沿用同一条路径。

<a id="data-investigation"></a>

## 案例 E：数据下降排查、换会话续查与转修复

**场景。** 某店铺汇总在指定日期比对照范围下降；这只是待解释现象，不预先认定缺陷。本例复用已有项目记录；若无底座，先按 records_only 最小接入，不要求完整数据项目初始化。

### E1. 明确只排查并留档

```text
/evolve analyze 排查店铺日汇总2026-10-28的数据下降，标题“店铺日汇总数据下降排查”。
先核对日期、口径、资料完整性及相关SQL；只分析，结果留档，不修改数据或正式规格。
```

evolve-propose 使用 action=analyze、kind=investigate。input 保存问题、可区分的对象／日期、对照基准及限制，已有资料能补齐的不重复问，关键比较范围未知则先澄清或明确受限结论；result.analysis 保存 F1“当前结果差异”、F2“现有材料显示部分来源尚待核实”、H1“可能因输入未完整而下降”及待查项。关键 SQL／结果摘要／来源时点入 evidence，必要附件位于 evolve/evidence/<RUN-E1>/。无 CHG／TASK／VER，没有自动修复或业务 archive；未定位原因可 completed + partial。

### E2. 新会话恢复并续查

```text
/evolve resume 店铺日汇总数据下降排查
/evolve analyze 继续这项排查，结合新提供的来源记录核查H1，保存报告，仍不修改。
```

resume 只读显示已查／未查、日期与资料时点、事实／假设和限制。明确续查才创建 RUN-E2，previous 指 E1，source 引 E1 的封存结果；新资料按当前范围重新判断。假设本例材料支持“本次汇总缺少约定的一部分输入”，结论说明因果依据及适用日期，不能推到所有下降；旧观察只对原日期／范围成立，后续改查其他日期时写入新 run 并重核，不更新 E1 的范围。SQLite 保留两轮结果，报告由 E2 生成 evolve/exports/<RUN-E2>/analysis.md；旧假设不改写成当时已确认事实。

### E3. 可结束，也可明确转修复

本轮分析可以直接留档结束。若用户决定改变依赖／逻辑，发：

```text
/evolve propose 根据这项排查提出修复方案，保持已确认口径，先不实施。
本次是否包含补数及具体完成标准，在方案中明确。
```

先定位已有匹配 CHG，明确修订时 update；无匹配且明确新建才创建变更。方案引用已封存 E2／局部发现及所需纠正来源，匹配已有 CHG 时核对问题、对象和范围，不能只看标题；E2 若只是旧范围参考按 historical_context 采用，当前修复所需依据另核对。明确修复目标和验收后再呈现有效 REV，不从“输入不全”的观察直接改变既有口径，也不自动接受或执行。后续 apply／verify／archive 仍走常规路径；没有平台专属操作状态或修复引擎。经验记录保留来源时点和适用条件，不把一次现象泛化为通用根因。

<a id="data-lineage"></a>

## 案例 F：字段来源与下游引用梳理

**场景。** 需要说明 ads_shop_order_di.paid_order_count 从哪里来，以及哪些现有材料引用它。目标是记录并解释当前可见关系，本例不建设血缘平台。

### F1. 设定范围与预期成果

```text
/evolve analyze 梳理paid_order_count的来源、计算过程和下游引用，标题“paid_order_count血缘梳理”。
以当前项目SQL及提供的说明为范围，标明依据、推断与未覆盖部分；生成报告和关系图，留档。
```

evolve-propose 使用现有 research／investigate kind，input 保存对象、来源范围、资料版本和完成条件，不新增 lineage kind／Skill。假定读取到的 SQL 显示由订单标识去重聚合：结果分别记录可直接定位的字段引用与表达式、材料中发现的下游引用，以及动态引用等未能确认的部分。没有读取／观察到的依赖不能标为不存在，也不能把源码中的关系冒充实际运行已覆盖。

### F2. 留档与图文输出

SQLite 的 result.analysis 在封存前保存关系事实底稿：局部标记、可识别端点、转换／关系说明、确定性、适用范围与逐项来源；例如“当前SQL显示该表达式”只对这份材料成立，不证明实际运行关系。关键 SQL 片段及必要关系资料作为 evidence／artifact 引用，不创建血缘边表或全量元数据镜像。按请求生成：

```text
evolve/exports/<RUN-F1>/analysis.md
evolve/exports/<RUN-F1>/lineage.svg
```

两者由已有 maintain export 在源 F1 封存后以独立 export run 生成，带同一来源 run／result_digest；导出不写 F1 输入／结论或分析链。仅使用封存底稿中的关系，不为补图重新读取 SQL 或添加新推断；底稿不足时报告缺口。图不另作可编辑的关系权威。图失败只重导视图，部分图文失败不否认已封存分析；必要依据仍在 evidence，不把 exports 当唯一来源。

### F3. 换会话及正式知识承接

```text
/evolve resume paid_order_count血缘梳理
/evolve analyze 继续这项梳理，补充核对我新提供的下游资料，更新本轮报告和关系图。
```

resume 不写记录或自动刷新；续查创建 F2，指向同链头，保留 F1 的旧范围与结论；新图由新封存结果生成，不覆盖旧事实。若只要重导旧图，走 maintain export，不移动链头。

如果只补齐缺失且有直接依据的基线／导航，可以明确 init 并保留来源和未知；已有口径／正式依赖的新增改变或纠正走 propose／update，经修订、实施／验证及同步生效。不能借 init 覆盖已有正式含义，也不能借 learn 代改业务规格。单纯梳理可直接结束，无需 CHG、VER、archive 或 release；关系图导出不被当作发布完成。已有正式知识发生改变后，后续方案检索其范围、依据与经验，不因图被多次查看就自动晋升为规则。

### F4. 从梳理结果转入不同后续目的

只要改变图的排版／格式，使用 maintain export，不改关系底稿；发现原 F1 的来源或结论错误，发 analyze 更正并引用 `(run, digest, local_key)`，新结果保留纠正链；需要修正 SQL、项目定义或现行依赖约定，发 propose／update 并引用当前适用分析。三者不能只靠“修一下血缘图”这个表述混用，意图含糊时先澄清。

例如“根据这项梳理修复既有依赖定义，先提出方案”进入变更路径；已有匹配 CHG 则按明确修订意图复用，已归档／取消对象需新建后继。不把观察本身作为新口径或验收通过，实施后仍按新的有效 spec 验证。

<a id="edges"></a>

## 补充边界：已有案例之外的选择

- **即时解释后再要求保存**：新建当前留档 run，原说明为导入上下文，重核或注明依据限制，不倒填旧执行。
- **留档意图收窄**：后续不记录不删除已有历史；正在执行且明确禁止继续写入时停止写入、说明未封存，不能偷偷 finish。
- **主动结束但允许留档**：负责者封存已发生范围与 user_stopped，结果可 partial；不造 CHG cancel，已结束不再建空 run。
- **后来反驳旧结论**：新分析／纠正事件关联原 run 和局部条目，当前恢复及依据核查显示取代提示，保留原封存结果。
- **回看旧 A 而已有 B**：显式 RUN 保留 A 快照并显示头；继续通常从 B 接，A 作历史来源，不无声遗漏 B 或分叉。
- **变更内排查**：仅仍 started 且获准的父 run 内沿用；已结束 apply 后只查原因，另建 analyze 并关联 CHG。
- **已有修复或后继变化**：活动 CHG 按明确意图 update／apply；归档后修改业务新建后继 CHG，分析来源不能代替新 REV 的呈现和接受。
- **知识反馈**：来源、假设强度和反例可随阶段进入项目经验；正式规则／个人库晋升由具体确认的 learn 动作处理，不自动改正式知识。

原先三份案例的逐字版本见[重组前快照及迁移说明](archive/consolidation-record.md)。案例对应现有 V 系列，不是已完成的功能测试。
