# 运行契约、存储与恢复

设计基线：0.5.6；更新：2026-10-29。本文维护技术字段与持久化契约；业务含义归[总体设计](design.md#authority)，动作 owner、用户授权及阶段完成门禁归[工作流](workflows.md)。接口、schema 和故障注入仍待实现，不把文档示例当作可用工具。

导航：[环境](#environment) · [配置](#configuration) · [文档模板](#documents) · [工具接口](#tools) · [执行协议](#execution) · [来源核查](#inputs) · [数据模型](#data) · [分析记录](#analysis-records) · [分析链](#analysis-chain) · [指纹](#fingerprints) · [发布执行](#release-executor) · [知识持久化](#knowledge) · [恢复](#recovery) · [连接与Git](#database)


<a id="environment"></a>

## 运行环境、资源定位与宿主适配

运行时设计为 Python 3.11+ 标准库，采用 sqlite3、argparse、json、hashlib、pathlib、tomllib、subprocess 等，不要求数据库服务或模型 API。

配置采用 TOML，由 evolve-init 自动生成维护；用户通过初始化答复或自然语言调整项目约定，无需手填文件。标准库提供解析而不提供写入能力，后续实现须提供受控写入与往返校验。[Python TOML 文档](https://docs.python.org/3.11/library/tomllib.html)

SQLite 使用显式事务及一致性备份；实际探测模块是否可用，不只看 Python 版本。[Python sqlite3 文档](https://docs.python.org/3.11/library/sqlite3.html)

插件安装清单定位 plugin root、runtime/evolve.py、shared/、模板与九个 Skill。持久化项目资料不保存开发机绝对路径。首版整包校验插件版本和数据库 schema；内部运行接口与结果格式随整包版本检查，不建立独立对外交接协议；缺少公共资源时报具体依赖错误，不退化为无留档执行。

优先验证 Codex 和 Claude Code。一个插件可打包多个 Skill，具体清单与入口按宿主支持的格式实现并验收。[官方插件架构](https://developers.openai.com/plugins/concepts/plugins)

- Codex 使用实际可用的 Skill 选择／显式引用方式；项目级发现目录参考 .agents/skills，但完整插件共享资源不能只复制一个裸 Skill 就宣称安装完成。[官方 Skills 文档](https://learn.chatgpt.com/docs/build-skills)
- Claude Code 使用其 Skill／插件命令机制；插件命名空间可能影响命令显示，安装验收记录最终可用拼写，不覆写宿主命令。[Claude Code Skills](https://code.claude.com/docs/en/skills)
- 支持原生 Skill 调用时按宿主机制使用；没有统一调用 API 时由当前 Agent 显式加载目标 Skill 的方法和公共工具。不得用发一段斜杠文本冒充可靠内部调用。
- 先整包本地验证，不自动全局安装、发布到市场或改用户权限配置；云端兼容和自动更新不列入首版承诺。

init 对已有 AGENTS.md／CLAUDE.md 只做最小导航接入，保留有效规则；安装插件和初始化目标项目是不同动作。

<a id="configuration"></a>

## 配置与路径契约

初版默认采用 `evolve/config.toml`，随项目保存；配置不是必读产品文档。读取已有配置与资料，自动发现事实，采用既定默认值，仅确认影响范围、验收或执行目标的未决项。换会话直接复用，重复 init 增量补齐；发布执行器按首次实际需要延后接入。用户交互规则见 [init](workflows.md#init)。固定 `history.backend="sqlite"` 是格式声明，不是供用户切换后端的菜单。

```toml
config_version = 1

[project]
id = "00000000-0000-0000-0000-000000000001"
name = "sample-project"
language = "zh-CN"

[history]
backend = "sqlite"
database = "evolve/history.db"

[paths]
specs = "evolve/specs"
changes = "evolve/changes"
decisions = "evolve/decisions"
evidence = "evolve/evidence"
releases = "evolve/releases"
local = ".evolve-local"

[workflow]
archive_requires_release = false
# 若改为 true，必须另设 archive_release_environment = "test"
apply_default = "all_ready"
manual_verification_allowed = true

[fingerprint]
include = ["src", "tests", "scripts", "package.json", "package-lock.json"]
exclude = ["node_modules", "dist"]

[checks.unit]
argv = ["npm", "test", "--", "--runInBand"]
cwd = "."
timeout_seconds = 300

[release.environments.test]
deploy_argv = ["python", "scripts/deploy.py", "--target", "test"]
status_argv = ["python", "scripts/deploy_status.py", "--target", "test"]
rollback_argv = ["python", "scripts/rollback.py", "--target", "test"]
cwd = "."
timeout_seconds = 600
```

以上只是说明格式的虚构项目配置；init 必须识别真实项目后生成适用项。records_only 只生成必要配置和范围导航，不填入检查／发布示例，不声称开发基线完成；development 才按实际目标补齐开发起点。profile 是 init 输入／结果中的范围，不是另一个历史后端或配置状态机。不能把示例检查和发布命令原样写入所有项目。项目 UUID 由工具生成，配置中的示例值不得照抄。

### 定位、身份与可维护范围

先定位明确项目根，再只读检查固定 `evolve/config.toml`、`evolve/history.db` 和 `.evolve-local/control/`；从子目录发现祖先项目时，遇嵌套／多候选根不能越过用户明确范围自动选择。不扫描相邻项目或用户目录拼接一份新档案，不因配置缺失而新建库。只有明确新接入且固定位置不存在既有库／控制清单／冲突材料时，init 才建立新 project_id。

- project.id 创建后不可通过普通配置调整改变；history.backend 固定 SQLite，history.database 固定 evolve/history.db，paths.local 固定 .evolve-local，config_version 是格式声明。它们不是自由重配字段；身份／定位不符时拒绝普通写入，查明档案或走已有恢复协议。首版不提供通过改路径迁移历史库或控制区的功能。
- 可维护的是项目展示与语言、已支持的流程策略、文档映射、检查／指纹及发布执行约定。配置仅改变 Evolve 如何定位和执行，不改业务源码／package.json／应用配置／正式规格。文档映射调整要核对同一 artifact 身份和已存在资料，不隐含搬文件、建立新基线或丢弃旧引用。
- 已有配置无法解析、与库身份不符、存在未完成／未核清的控制 journal 或库缺失／损坏时，status／resume／doctor 返回具体诊断和可信读取范围。诊断可在固定位置以只读且禁止创建模式检查已存在库及控制清单；配置不可用时展示历史事实须注明当前配置未确认，不能提供可写就绪结论。不能把恢复库的一部分拼成新的默认配置。
- 恢复使用既有 OP journal／可校验快照或同项目恢复包；缺少足够依据则报告缺失项。明确 init 不构成覆盖损坏档案的许可。控制清单仍只是恢复材料，不成为第二份业务历史；更换机器缺少本地 guard 按[恢复协议](#recovery)核对，不重新问已确定的项目选择。

### 自动维护及阶段影响

- 配置唯一维护方法归 evolve-init；独立明确调整使用 init run；只在 release prepare 当前明确范围内允许父 run + component_skill=evolve-init／operation 的发布配置支持。其他阶段若需明确配置调整，先单独 init，原负责者再重新 prepare。所有只读入口、analyze 及 release status／refresh／record／execute／rollback 不隐含重配；首次分析缺底座的 records_only 是单独的初始化 run。
- 自动维护只更新明确目标字段，保留已有支持字段中的自定义值、注释及文档映射；未知关键字段／格式不支持时明确受阻，不通过整文件模板重写丢失用户内容。类型／结构无法保持时保留原文件，不能以“自动维护”为由丢掉不理解的内容。写前核对摘要和版本，校验候选；多文件协议在替换前保存实际旧字节、候选字节及摘要，记录目标与旧／新版本，并通过既有 artifact_versions／blobs 和事件留档，不新增配置历史库。
- 项目配置使用稳定的 project 级 artifact，kind=config；最后已登记摘要取其已提交 artifact_versions，不把磁盘现值自动认作登记版本。没有登记的手改只报告差异；核对接受后由 init 登记，不能让查询偷偷推进版本。
- 写配置和登记数据库分两步时使用既有 prepared journal：文件仍为旧值可按前置继续；已为候选值只补登记；第三种值保留冲突并阻止普通写入。恢复不能运行新检查／部署命令；原 init 或父 run 只能按确认过的实际范围结束，不能补造未执行验证。恢复及 init 成功不删除过去失败、重做初始化任务或重开终态 run。
- 固定 SQLite 与默认策略不是初始化问卷。部署 argv、目标环境和权限不能仅凭自动发现推定已获执行授权；未配置项明确标缺失，不填样例。配置本身不保存动态任务／验收／发布状态，不代替 SQLite。
- 人工编辑仍可识别：只读动作报告未登记差异，下一次明确 init 调整后校验登记；不静默覆盖。配置变化按既定保守摘要规则重核验证／发布准备，历史事实继续保留。
- archive_requires_release 默认为 false；若显式启用，必须配置 archive_release_environment，门禁核对该环境、当前候选及当前可确认成功，不以任意历史成功代替。
- 配置版本、路径、枚举、超时、可执行命令参数均有类型检查。未知关键字段提示错误，不静默忽略拼写。
- `fingerprint.include` 缺省时采用自动发现；显式指定后报告范围，并提示目录外新业务文件需要纳入。配置本身与依赖锁文件始终纳入校验依据。
- 项目资料、执行 cwd、导出及恢复路径相对项目根并防止越界／链接逃逸。插件资源从只读安装根定位；唯一受控的项目外写入是用户已确认的 personal 晋升目标，按个人库协议定位，不能用普通 artifact 路径越过项目边界。
- 运行时凭证由现有环境或项目既有机制提供，不把值写入配置、数据库或报告。
- 配置变更产生事件和摘要；按现有保守配置摘要核对验证及发布准备，旧结果保留但失效时必须重新验证。仅调配置不创建 CHG／TASK／REV，不抹去原任务结果或方案接受；业务配置／行为／验收变化仍走 propose／update。配置有效性、规划接受和历史执行事实分别核对。
- release prepare 中的合法配置支持保留父 run 不可变输入；子操作记录旧／新配置摘要、当前请求依据和确定性结果，result.basis_refs 引用已提交配置版本及 OP。后续依赖操作重新读取当前配置和候选，核对与该 OP 一致；保留 start 时 input_checks，将后续核查与阻碍记入子操作／事件及实际结果，不原地改 input.digest、旧 VER 或原 REL。原验收过期时 prepare 可保存带阻碍的材料并结束，verify 与后续 prepare 使用新 run；候选变化按发布契约新建 REL，不在 execute 内偷偷重配。
- 配置重试沿用原稳定 request／operation 及候选输入；同 epoch 已提交重试先返回原结果，不能因配置已被自己更新而再次要求旧摘要等于现值，也不能重新扫描出另一份候选后假称同请求。操作未完成交 recover，epoch 变化拒绝旧写请求。这个顺序与其他写操作一致。
- 首版不提供任意插件加载代码或 shell 模板解释器。需要 shell 时在参数数组中显式指定解释器和脚本，由项目定义。

<a id="documents"></a>

## Markdown 识别、模板与生成视图

不实现通用 Markdown 或 YAML 解释器。模板提供少量确定的标题约定，工具用稳定标识和摘要检查，业务语义由 Agent 负责。

当前规格最小结构：

```markdown
# Capability: 收藏

## Purpose
用户可以保存稍后阅读的文章。

## FR-001: 收藏文章
确认依据：用户确认与当前实现的对应证据。
行为：登录用户可以收藏一篇文章。

## AC-001: 重复收藏
关联：FR-001
Given 已收藏的文章，When 再次收藏，Then 不生成重复记录。

## Open questions
没有未决关键问题；普通未决项按 OQ 编号记录。
```

- 需求与验收使用明确标题和稳定编号，避免依赖段落顺序定位。
- 历史项目的每项行为另外注明确定性和代码／测试／文档依据。
- 文档可增加合理章节，不要求每个模板都填满；空问题不必生成虚构条目。
- 工具只能检查结构和引用存在，不能仅凭 Given/When/Then 字样判定验收有效。
- 增量规格明确 `ADD`、`MODIFY`、`REMOVE`，引用原编号及基线；工具接收已确定的新正文和预期原文摘要，冲突时拒绝全文覆盖。
- 外部文档若不能无损纳入固定标题格式，保留原文并通过 artifact 映射和显式条目索引接入，不自动重写整个文档库。

### 公共骨架与按需上下文

常规开发、数据开发、数据排查与血缘梳理复用同一模板骨架，按任务相关性补内容，不新增 data profile、平台字段或专属状态机。共同问题是：目标是什么、对象与范围是什么、依据来自哪里、预期成果是什么、如何判断完成、实际结果和限制是什么。

- spec／proposal：明确成果、输入输出、规则与验收；数据工作按需注明对象定位、粒度／口径、业务日期或范围、边界样例。未涉及的项省略，不强制空章节。
- verification：从对应 spec 读取标准；实际方法可为测试、对账、口径核对、结果检查或人工观察，记对象版本／日期／覆盖、预期与实际、证据及限制。检查部分资料不推导全量成立。
- analysis：在既有 input 与 result.analysis 保存问题／范围、关键资料或 SQL 引用、观察时间、事实／假设／结论、未查与限制。血缘观察记录起点／终点或字段、关系说明、来源及确定性；不为每种工作目的创建表或状态。
- 关键 SQL、结果摘要、关系来源等通过 artifacts／evidence 保存；不要求完整查询日志或所有数据行入库。报告／血缘图按需从已封存结果生成，正式业务口径或依赖约定仍归已映射 Markdown，不由生成图反向更新。

### 最小上下文与可省略项

“按需”由结论／验收用途决定，不能省略区分对象和适用范围的依据。各场景都需可识别目标、实际范围、来源、预期／完成标准和结果限制；资料时点、业务日期、版本或比较基准影响判断时必须记录，无法取得则标未知和影响，不猜默认值。与问题无关的日期／粒度等可省略，普通应用任务不填数据问卷。

这些信息复用现有 input／result、artifact／版本、verification 范围和 evidence 引用；不是额外上下文表。Agent 从当前请求和已有资料补齐已知值，只澄清影响目标或结论的关键缺口。来源观察时间、执行时间和本次记录时间各自保真，用户提供的旧结果不倒填成当前观察。

### 按需模板

编辑权限遵循[字段权威](design.md#authority)。以下定义生成格式与模板内容，不另建当前正文的第二份编辑权威。

轻量或普通小变更默认一份 proposal：原因、范围与非目标、必要增量和 AC、风险／问题、任务概要及结果引用。完整任务定义和依赖由数据库维护，提议不复制可独立修改的任务清单。行为变更需要的增量可以内嵌于 proposal，有实际复杂度时才拆 delta-spec／design。


首版按需提供以下模板，不在 init 时一次性创建所有空文件：

- `project.md`：用户、问题、目标、非目标、约束、业务背景、成功标准、资料导航和开放问题。
- `codemap.md`：项目导航，可覆盖代码入口、SQL／模型、口径资料、检查与成果位置，保留实际边界和未知范围；沿用文件名，不要求为数据项目再建资产目录。
- `legacy-baseline.md`：扫描范围、确认行为、推断、缺陷／风险和未知项的证据清单。
- `proposal.md`：原因、对象／范围、非目标、约定成果、必要行为／口径增量及验收、任务概要、风险和待决问题；按需补数据上下文。TASK 仅引用，不在此手工维护进度。
- `delta-spec.md`（需要分文件时）：操作、目标条目、基线与新行为、验收及兼容影响。
- `design.md`：候选方案、选择理由、影响面、接口／数据、验证与回滚考虑；标准变更按需创建。
- `decision.md`：上下文、选择、依据、后果、来源变更和被替代关系。
- `verification.md`：逐项验收、标准、实际方法与结果、成果／依据、业务日期或版本／覆盖、证据与限制，数据库生成。
- `release-notes.md`、`checklist.md`、`rollback.md`：spec 约定的交付对象、版本／范围与目标、变更集合、交付前后检查、恢复条件／安排及验证；按项目需要填写，不假定只能部署应用。
- `archive-summary.md`：从冻结修订、领域结果与应用记录生成实际交付和遗留问题；动态发布状态按查询时事实展示，不回写冻结档案。
- `analysis.md`：按需由分析 run.result 生成，区分事实、假设、结论、资料时点／覆盖与限制；数据排查和血缘图说明沿用同一报告；默认位于 evolve/exports/<run-id>/，不是可独立编辑的分析正文。
- `execution-summary.md`：从 run 的 result 和 input_checks 生成，展示来源、实际范围、阻碍与证据；不单独生成交接档案或回执。
- `tasks.md`、`resume.md`：生成视图；resume 默认直接返回，需要保存时才生成文件。

生成视图包含 `generated_from`、`entity_id`、`record_version`、`generated_at` 和相关 digest；文本放在头部，按需 SVG 放在内嵌 metadata，均引用同一封存结果。直接修改视图会被识别，工具不会反向猜测它代表了何种业务状态变更。

视图按需生成或刷新，时效由来源版本和声明截止点判断。阶段结果报告先封存业务结果，随后由既有 maintain export 方法以独立 export run／operation 生成视图；当前请求已明确要报告／图时自动完成该已授权动作，不额外要求用户再发指令。export 的 source_runs 引用封存结果，既有目标引用放 input.references，不进入分析 previous 链，也不改来源 input／result。没有请求视图就不增加导出 run。

tasks／resume 等领域视图可以直接引用已存在的领域版本和必要封存结果；若用户要求保存只读查询，原查询仍不建 run，独立 export run 保存查询范围、捕获的来源版本和输出，不虚构查询来源 run。export 自身只返回其产物，不再为自身触发报告／导出或重新取证，避免递归。源 result 不预写“报告已生成”；实际派生状态在 export run 留档，当前返回汇总业务事实与派生状态。history／resume 按领域目标或分析链定位主进度，导出只作为相关产物，不因最近多了 export run 而改变业务阶段或分析链头。

权威事实已提交而派生导出失败时返回事实和 VIEW_STALE；重试原导出或新建明确重导，仅处理派生文件，不重跑任务／查询或追加 analyze。导出 run 保存实际视图来源、输出摘要和失败／限制；图文可部分成功，缺失图不否认分析已经封存，也不把导出失败记成业务失败。目标路径禁止覆盖权威材料、业务文件或来源证据。

分析／关系图只展示封存 observations 中已经表达的内容及其引用；必要的局部标记、对象端点、关系说明、确定性、适用范围与逐项依据应在封存前保存于 observations／可选 details 和既有证据中，不新增关系表。仅有 SQL 链接而缺少已封存关系时，导出只能生成已有说明或报告缺口，不重新解析／补查并冒充原结论。排版／格式可重导；新增／改正关系事实走新的 analyze 或关联纠正。

默认报告如展示后续纠正，正文和 metadata 同时标注纠正来源及截止时点，保留原结论为历史；精确历史导出注明当时快照。缺资料影响可读性或依据可核查性时如实标限，不从当前文件补造过去事实。

### 输出粒度

常规查询默认不落盘报告；显式保存／导出才生成文件。必要快照、引用、证据仍留档，追溯不依赖是否生成可读报告。

每个动作结束给用户简洁说明：做了什么、实际结果、未完成／受阻部分、需要阅读的材料及下一步。完整事件、原始命令输出和数据库字段不默认展示。

恢复包与摘要报告明确区分；只读查询默认展示最近摘要，用户追问时再展开修订、任务或证据。这样既保留过程，也不要求用户关注每个执行细节。

<a id="tools"></a>

## 确定性工具入口与请求响应

Agent 从插件资源清单定位共享内核，按负责 Skill 的方法解析入口，调用形式：

```text
python <plugin-root>/runtime/evolve.py --project <project-root> <action> --json
python <plugin-root>/runtime/evolve.py --project <project-root> <action> --input - --json
```

`--input -` 从标准输入读取 UTF-8 JSON，避免把多行文档、引号或敏感参数拼进 shell 命令。`python` 是描述性的解释器名；宿主先探测实际可用命令，不硬编码开发机路径。

工具动作职责：

- `phase prepare | start | finish | inspect`：调用 Skill 持有阶段，内核按 request_id、输入、版本及 epoch 幂等登记，不能借通用接口绕过归属。
- `evidence record`：写入来源 run 和证据引用，verification_id 可空；不能因独立分析伪造验收记录。
- `doctor`：运行时、配置、数据库、未完成操作与引用完整性检查。
- `init`：input.profile=records_only|development；记录接入与开发起点分别核对完成条件，复用已有设施，不自行决定业务技术栈。已接入项目的明确配置调整沿用实际覆盖，仅在本次输入范围内更新并记录，不重建初始化任务；发布中按需支持仍走同一 init 方法。
- `change create | revise | accept | cancel`：维护规划、接受记录与生命周期。
- `task start | finish | block | reopen`：检查依赖和版本，事务记录结果。
- `verify run | record`：运行已配置检查或登记真实观察证据。
- `release prepare | execute | record | status | rollback`：发布记录及执行尝试。
- `spec sync`、`archive`：采用操作日志安全同步／移动材料。
- `status`、`next`、`resume`、`history`：只读查询，按需分页；支持项目分析标题／RUN 与 action=analyze；标题按链折叠，显式 RUN 展示该快照和当前链头，目标不唯一则澄清。
- `knowledge record`、`experience search | review | record | disable`、`promotion prepare | apply`：支持知识检查、经验版本、应用反馈、提案及确认晋升；search／review 默认只读，其余按负责者和支持步骤规则写入。
- `export readable | recovery`、`backup`、`restore`、`recover`：报告、可恢复包和中断恢复。

analyze 由 Agent 使用共享 phase／evidence／artifact 工具完成，不由新增 Python analyze 子命令假装自动推理。phase 输入允许 action=analyze、项目级 targets 和业务只读／留档策略；续查带 previous_run_id 和准备时链头前置条件，start 核对唯一顺序后继。source_runs 仅为执行引用；其他领域／资料引用进入 input.references。字段与用途核查以 [run 协议](#execution) 为准。

这些是底层确定性接口；不是让用户学习更多命令。Agent 层的 propose/apply 由多次读写与实现动作组成，不由单一 Python 子命令假装完成所有业务判断。

### 请求、响应和重试

典型写入请求：

```json
{
  "operation_id": "7afdf7e0-42cf-4d51-8e79-130ef3b0c650",
  "request_id": "52ea9433-e3b8-4545-a928-e1096083f640",
  "owner_skill": "evolve-propose",
  "run_id": "fe69ee7e-640e-44ef-b84f-6b390635a763",
  "expected_workspace_epoch": "9b6cfec4-f0ac-4923-9395-e3666c50e553",
  "source_runs": [],
  "targets": [{"entity_type": "change", "entity_id": "CHG-20261026-8f3a91c2"}],
  "expected_versions": [{"entity_id": "CHG-20261026-8f3a91c2", "row_version": 4}],
  "reason": "用户要求增加失败回滚场景",
  "payload": {
    "artifact_paths": ["evolve/changes/CHG-20261026-8f3a91c2/proposal.md"]
  }
}
```

示例为已 start 的一次规划写入；实体键可由工具解析友好编号，run／request／epoch 使用 UUID。start 请求尚无 run_id，已有 guard 时携 expected_workspace_epoch；首次明确写请求可用“guard 不存在”的前置条件，在短锁和控制清单下建立 epoch，若别的写入已建 guard 则拒绝旧前置。init／restore journal 的身份例外按恢复协议处理。每次子动作沿用 request_id，使用自己的 operation_id。

响应固定信封：`ok`、`action`、`operation_id`、`data`、`warnings`；失败增加 `error.code`、`error.message`、`error.next_steps`。文本模式复用同一结果，不由两套业务逻辑生成不同事实。

- 成功退出 0；输入／前置条件错误退出 2；版本／占用冲突退出 3；需恢复退出 4；外部执行失败或结果未知退出 5；非预期内部错误退出 1。
- 返回结构包含 committed、run_id、提交后的实体版本和摘要、业务 outcome、知识检查及 view／backup 状态。ok 只表示接口动作成功，不表示业务验证通过；发布未知／执行失败返回明确错误与已提交事实。派生报告或后置备份失败不否认 committed。
- 当前 epoch 下先查幂等记录：同一操作 ID 且输入一致返回原提交结果及其历史时效，不再次要求旧 expected_versions 等于现值；同 ID 不同输入拒绝。仅首次写入核对当前版本；操作未完成返回恢复状态。epoch 已切换则旧执行请求拒绝，不能绕过恢复边界。
- 未知操作结果不会用成功信封掩盖。原始异常可写本地诊断，用户摘要不输出环境凭证。
- 读命令没有副作用，不因 `resume` 自动迁移、修复或执行发布。

<a id="execution"></a>

## 统一执行生命周期、结果与支持归属

```text
来源 run：输入依据 → 实际执行 → 封存 result
                                  ↓ 引用
下一 run：核查 source_runs / 领域记录 → 记录 input_checks → 执行
```

phase_runs 一条执行记录保存本次输入、核查和实际结束结果。result 内保存摘要、领域记录和证据的稳定引用，不复制 VER、REL、任务等全部正文。跨阶段承接直接引用 run_id + result_digest；多输入、多目标仍可表达。

独立 handoffs、handoff_receipts 和 source_handoff_ids 属于已被替代的 0.4.1 方案，首版不创建对应表、接口、协议版本或迁移。当前尚无实现库，因此不存在删改用户历史的问题。必要关系可由无独立生命周期的 run 关联行索引，不恢复一套交接状态机。

### prepare → start → execute → finish → present

这些步骤由共享内核支撑，用户无需逐项触发，Skill 不各自实现一套：

1. **prepare**：按[唯一入口契约](workflows.md#commands)规范化 owner／动作／子方法、带类型目标及当前明确范围；宿主或自然语言形式不改变规范动作，同请求重试不重新推断目的。解析目标、资料、来源结果、关键问题和恢复阻碍。纯查询或即时不留档解释在此返回，不建 run、不分配编号、不标 stale、不改 guard／索引、不备份或迁移。
2. **start**：按稳定 request_id 幂等建立 run，事务内复核当前版本、workspace_epoch 和前置条件，将 source_runs、targets 及 input_checks 写入该 run。init 建库前先保存同一身份的控制清单。
3. **execute**：子动作按 operation_id 及时保存任务、验证、发布尝试或操作进度；每次写入再核对当前条件。不能跨对话或长命令持有事务，也不能把数据库锁当作源码锁。
4. **finish**：按稳定 operation_id 事务提交 run 终态、result、result_digest 和事件。一个 run 只有一个结束结果，响应丢失返回既有结果；报告或完成点备份失败不重跑业务。
5. **present**：按当前请求在源结果封存后调用已有 maintain export 处理按需报告／图；它有自己的 run，不重开源阶段或改其结果。export 阶段仅返回自身产物、不递归触发本步骤的导出；纯查询保存视图按[视图约定](#documents)处理。随后展示实际结果、主要限制、相关材料及建议。下一步从当前事实计算，不单独持久化 next_candidates 状态；结果中的历史摘要不充当当前推荐清单。

阶段唯一请求键为 project_id + workspace_epoch + request_id；相同规范输入重试返回既有 run，不同输入拒绝。规范输入保存请求的动作／子方法、目标、当前范围与来源说明，路由不能在同一 request 下把 analyze 改成 propose 或把 release prepare 改成 execute。恢复摘要及历史 run 只提供依据，不能独立授权新副作用；用户当前明确指令与既有授权范围一致时无需重复确认。子动作 operation_id 在执行前固定，不以换 ID 绕过未知结果。当前 epoch 下已提交重试先核对幂等记录再返回历史事实；首次写入才核对新提交的 expected_versions。

run 从 started 结束为 completed／blocked／failed／interrupted，终态不重开。新工作创建新 run；previous_run_id 只表达同类执行的续接，跨阶段来源放 source_runs。分析链要求同项目 action=analyze，单链按顺序续接，见[分析链](#analysis-chain)；completed 表示本次动作结束，不能替代领域对象的验收或发布结果。

### result 最小契约

- 所属 run 已保存 owner_skill、action、项目、targets 和开始／结束时间，不在 result 重复建立来源身份。
- result 保存实际完成摘要、未完成和阻碍、限制、产物／领域记录／证据引用及对应不可变版本。
- `basis_refs[]` 引用有效规划修订、任务定义摘要、VER／候选、配置摘要、规格应用证明等必要依据；已有权威记录的值通过引用读取。
- 独立分析的 result.analysis 字段见[分析记录](#analysis-records)，业务完成含义见工作流。
- 知识处理状态和相关经验版本／应用记录。无新经验、pending 和 unavailable 分别记录，不要求每阶段写复盘文档。
- 封存 result 使用规范化字节摘要 result_digest；结果不整段复制聊天或原始输出。

普通结束结果不可覆盖。源码已改但检查未记录时明确未知；恢复可给未结束 run 封存 interrupted 及确认过的部分事实，标明 finalized_by 和恢复 run，不能伪造原 Skill 已完整 finish。已封存结果发现错误，通过纠正事件或后继 run 补充。

### 内部支持与有限归属例外

run 关联 operation／event／领域记录；result 引用实际事实，input_checks 说明采用／拒绝理由，不再复制成独立交接／回执。查询只显示派生 stale，不写纠正状态。

知识结束检查、策略备份及仅在 release prepare 明确范围内的 init 配置支持沿用父 run，记录 component_skill 和 operation_id；输入不可变和配置依据切换统一见[配置契约](#configuration)。独立配置调整／learn／backup／recover 或正式规则／个人库晋升由负责 Skill 另建 run。pending 后续处理追加来源关联，不重写原 run 当时事实。

首次或明确补开发底座的 development init 可在本次范围完成并封存 initialization 系统记录，records_only 和已有项目仅调整插件配置时只有 init run；此例外不能用于普通业务 CHG。maintain 只可恢复未结束 run 为 interrupted、登记已确认部分事实和 finalized_by，不把它写成原阶段完整成功。

内部结果格式随插件整包及 schema 校验，不新增单独对外交接协议。用户不管理 request／run／operation 或摘要字段。

![结果复用与输入核查](diagrams/15-skill-handoff-and-rotation.svg)

<a id="inputs"></a>

## 多来源核查与语义有效性

`source_runs[]` 只装来源执行引用，每项包含 run_id、result_digest、对应 target、purpose 和 required；purpose 至少区分 historical_context（历史上下文）与 decision_basis（本次判断依据）。直接 REV、VER、REL、artifact 等采用带类型的 input.references／basis_refs，不把非 run ID 塞入 source_runs。首次／直接进入阶段根据当前权威记录建输入快照，不伪造来源执行。所有引用核对同项目、实际归属和摘要；可选引用的缺失须明确记录。

`input_checks[]` 是接收 run 的输入字段，记录引用目标、核查的业务依据、当前版本／摘要、accepted／stale／rejected、原因与时间；没有独立 ID 或可消费状态。多输入必须逐项核查，不能仅使用最近一个 run。accepted 只表示适合声明的用途，不认可来源的每一句话为真；读取还须核对已关联的纠正／取代记录，result_digest 相同不代表结论仍适用。必需的当前决策依据 stale／rejected 时阻止依赖它的动作；缺失可选上下文可缩小范围并保留限制，不把全部来源都当作强制完成门禁。输入通过只对本 run 有效，实际子操作仍再次检查。

historical_context 核对身份、完整性和历史用途；旧结论已过时或被反驳仍可作为重检对象，accepted 时必须说明适用性变化。decision_basis 另核对当前有效范围，不能以“历史参考”绕过修复、验收或发布必需条件。摘要不匹配／来源不可确认不能伪称有效历史结果。

同一来源 result 可同时被 archive 和 release 的不同 run 引用；不设置已消费标志。prepare 已发现不合法时可只读返回；需持久化失败核查时建 action=preflight 的 blocked run，将原因放在该 run 的 input_checks 与 result，不另发回执。

来源快照版本用于审计，业务 basis 用于有效性，接收方 expected_versions 用于本次提交，三者分开。路径移动、发布关联、无关经验追加可能增加 row_version，但有 artifact 身份或 spec_application 证明时仍可采用原证据；验收含义、候选或无法证明的基线改变则不能放行。首版保守核对配置摘要，避免假装具备精细影响推理。

### 可核查路径

propose 的 run P 产生 CHG-A／REV-2 并呈现；apply 的 run A 核查该修订及 P.result 后实施。verify 的 run V 产生 VER-A，结果引用最终候选与证据；archive 和 release 各自 run 的 input_checks 可采用 V.result，同时重新核对当前事实。

归档移动材料和同步规格不改 V.result；应用证明有效时后续发布仍可采用证据。另含 CHG-B 时必须追加 B 的适用验证输入。新会话只需目标和当前请求，系统恢复这些引用；用户不填写 run 或结果摘要。

<a id="data"></a>

## SQLite 逻辑模型与标识

- 一个项目根内一份 `evolve/history.db`，随项目 Git 保存，不使用用户目录中的共享数据库。
- 采用普通 SQLite 数据表与追加事件，当前状态和对应事件在同一事务提交。首版不是完整事件溯源系统，不承诺仅靠叙述事件重建全部数据。
- Markdown 当前材料由 Agent 编辑，工具捕获有效修订的内容与摘要；数据库的过去快照不会随文件覆盖而改变。
- 文本快照去重保存，测试输出等大附件保存文件。备份和可恢复导出必须包含所引用附件。
- 模型不记录全量聊天或每次工具调用，记录能解释变更和恢复工作的关键事实。

### 标识与公共字段

所有核心实体有 UUID 主键。用户可见变更号形如 `CHG-20261026-8f3a91c2`，可选标题 slug 不属于身份。工具通过唯一约束检查碰撞，不能仅依赖时间戳生成唯一键。

- 项目级语义编号：`G-001`、`NG-001`、`FR-001`、`BR-001`、`AC-001`、`BUG-001`、`DEC-001`、`OQ-001`，由项目内计数器分配，不复用已废弃编号。
- 任务编号在变更内为 `TASK-001`，完整引用必须带 `change_id`。
- 规划修订在变更内为 `REV-001`，其他记录展示 `VER-…`、`REL-…` 等友好编号。
- 编号预留后没有产物也不回收，允许跳号；不能为追求连续性重排历史。
- 时间保存 UTC ISO 8601，显示时用用户指定时区；没有可用时区转换数据时明确显示 UTC，不改变历史时间。
- 可变实体保存 `row_version` 整数，请求在 expected_versions[] 中提供该实体的预期版本。
- 引用采用实体 ID、artifact ID 及项目相对路径，不把安装 Skill 的机器路径写入持久化记录。

下面确定 v1 数据契约；具体 SQL DDL 在实现阶段生成并迁移。通用字段包括 `id`、`project_id`、创建时间及适用的更新版本。

### project_meta 与 counters

`project_meta` 保存项目 UUID、schema 版本、创建工具版本、初始化状态及不可变数据库检查点谱系。每次成功写事务生成 checkpoint ID 和前驱引用；事件序号不单独作为谱系身份。项目 UUID 与配置一致，不随目录改名变化。

`counters` 保存各语义编号已分配值，分配在写事务内进行。外部已有编号接入时先校验、登记，不重新编号用户资料。

### changes

字段：`change_key`、标题、类型、轻量级别、生命周期、受阻前阶段、当前有效规划修订、接受的修订、基线引用、创建与归档时间、摘要、`row_version`。

development 初始化系统记录使用保留类型 `initialization`；records_only 只留 init run 和记录底座，不为了留档虚构 CHG／TASK。init 的 profile、覆盖和产物引用由 input／result 保存，project_meta 的初始化状态不能代替开发就绪性判断。普通变更类型与状态取值见[工作流](workflows.md#common)。

### plan_revisions、blobs 与 artifact_versions

- `plan_revisions`：变更、修订序号、前修订、原因、来源、用户可见摘要、任务定义摘要、验收引用摘要、规划 digest；呈现记录另保存修订、材料摘要、呈现方式／来源与时间。未呈现修订不可沿用旧接受。
- `blobs`：SHA-256、字节内容、编码、长度。文本快照保留实际 UTF-8 字节；不依赖路径保存旧内容。
- `artifacts`：逻辑身份、所属变更或项目、种类、当前相对路径、是否生成视图。
- `artifact_versions`：artifact、修订或操作、blob 引用、内容摘要、时间及来源。

同内容 blob 共享，但相同文件在不同修订的关系分别保留。文件移动仅更新当前路径映射，不修改过去版本引用。

### spec_items 与 delta_items

- `spec_items`：语义编号、类型、能力归属、当前 artifact、当前版本摘要、确定性标签、状态及来源依据。它是 Markdown 的索引，正文仍以文档为权威。
- `delta_items`：稳定 delta_id、变更修订、前版本／已应用来源、操作 `add | modify | remove`、目标规格编号、预期基线摘要、目标内容快照、关联验收和依赖。

删除保留 tombstone 与原因，不复用旧编号。纯维护变更可以没有增量项，但需记录 `spec_delta=none` 原因。

### tasks 与 task_dependencies

`tasks` 是完整任务定义与执行状态的权威，proposal 只保留概要、tasks.md 为按需生成视图。字段：变更、局部编号、所属规划修订、目标、范围、关联规格／验收、完成条件、状态、结果摘要及版本。

任务定义修订保留在规划修订快照中，旧执行事件仍引用当时定义。`task_dependencies` 为同变更任务的有向关系，工具校验无环；跨变更依赖通过变更关联表达。

更改任务定义不能抹去旧完成事实；受影响任务重新打开或标记待评估并记录原因。任务完成要求结果摘要及适用证据，不能只写一个布尔值。

### events 与 relations

`events` 字段：事件 UUID、项目内单调序号、事件类型、关联变更／任务／发布、run／操作 ID、时间、来源、结构化 payload、简洁摘要。

事件类型最少覆盖：初始化、规划创建／修订／接受、任务开始／完成／受阻／重开、验证登记／过期、规格同步、归档、取消、发布尝试／结果、恢复与注记。

`relations` 保存变更、需求、缺陷、决策、后继变更之间的显式关系。对 polymorphic 引用由工具验证目标存在；可以拆成具体外键表，不能因为使用通用关联就跳过完整性校验。

事件是追加历史。误记通过纠正事件和当前投影更新处理，不直接改掉过去发生的事实。

### verifications 与 evidence

- `verifications`：变更、任务范围、规划修订、候选成果／依据摘要（代码项目含实现指纹）、配置摘要、实际方法、evidence_level、开始／结束时间、结果、时效、对象／环境范围及限制。
- `verification_items`：验收编号／内容摘要、required／not_applicable 及原因、逐项结果和实际方法；一个命令通过不自动证明全部验收。
- `evidence`：source_run_id、可空 verification_id、artifact 或附件路径、字节摘要、长度、观察时间、来源及简述。

独立分析直接关联来源 run，不伪造 VER／AC。source_run_id 必填且同项目；verification_id 非空时须核对 VER 的实际归属。复用旧证据保留原观察者、来源 run、时间和摘要，经显式关联采用，不改写为新 run 亲自观察；分析证据本身不等于新候选验收通过。必要附件登记前核对持久化及摘要，外部引用注明可获取性与恢复限制。

人工或外部检查的观察者来源可以是用户说明、项目工具／外部系统或 Agent 实际观察，不伪造身份。采纳外部结果保存原观察者、原时间及来源，接收记录另记当前 run；候选版本、范围、实际方法及逐项结果符合本次用途才可参与验收。仅有“已通过”的无依据声明不能直接变 passed。所需检查确未发生或无可采纳证据时记 not_run／blocked，失败仍保留；Agent 未亲自执行不自动否定真实且适用的外部依据。

### releases、release_changes 与 release_attempts

- `releases`：友好编号、版本、交付目标／环境、候选成果引用与摘要、准备材料摘要、当前汇总状态、最近观察时间及版本；不固定为代码成果。
- `release_changes`：发布与变更的多对多关系，固定当时的规划／实现／验收依据。
- `release_attempts`：执行、状态检查或回滚类型，外部幂等键、请求目标／恢复目标、执行器摘要、开始／结束、执行结果、环境观察及观察时间、进程或外部操作引用、证据与错误摘要。状态查询失败不能覆盖最近确认的部署事实。

`environment_claims` 按 project_id + environment 唯一关联未决 deploy／rollback attempt；running／unknown 保留占用，核实后释放。它是持久化业务约束，不是长数据库事务。

一个发布多次尝试不覆盖旧尝试。回滚关联原发布和实际恢复版本；不能把“配置了回滚命令”写成已回滚。

### spec_applications 与 operations

- `spec_applications`：增量项及修订、目标基线与结果摘要、应用时间、关联验收及操作 ID。唯一键基于稳定 delta_id + 目标内容摘要，保留应用时修订；不能单凭新 REV 重新应用旧 ADD。
- `operations`：操作 ID、动作、目标、输入摘要、期望版本、状态 `prepared | applying | committed | needs_recovery | aborted`、暂存清单摘要、已完成步骤与错误信息。

与变更 lifecycle 分离：某变更可以 active，而一次归档操作处于 needs_recovery。不能用改变变更状态掩盖中断。

### phase_runs：输入与结束结果

字段为 project、request_id、workspace_epoch、previous_run_id、owner_skill、action、targets、规范化 input／digest、source_runs、input_checks、开始／结束时间、状态、result 和 result_digest。字段语义与唯一请求约束见[执行协议](#execution)、[来源核查](#inputs)、[分析记录](#analysis-records)和[分析链](#analysis-chain)，不另复制一套定义。

必要的 targets／source 关联可用无独立生命周期的索引行和外键实现；input_checks／result 可使用版本化结构字段，JSON 不要求额外数据库扩展。引用核对同项目与真实归属，不因通用关系放弃完整性。

### 支持记录和外部控制

普通阶段无新发现时仅在 run 结果保留简短知识检查结论，不强制新增完整复盘或 knowledge_reviews 行；有需要跟进的处理时才另建支持记录。

经验、应用效果、knowledge_reviews、promotion_proposals、rule_bindings、check_applications 字段统一见[知识持久化](#knowledge)。它们通过 run／operation 关联本阶段事实，计划问题使用带稳定 OQ ID、blocking 和状态的修订条目，不能只存于聊天。

策略备份、知识结束检查及 release prepare 明确范围内的 init 配置支持可关联父 run，保存 component_skill 及 operation_id；独立支持请求另建 run。个人库晋升有稳定 promotion_id 与候选摘要，项目和个人库分别提交，恢复协议不将它们伪装为同一事务。

非 Git 的 workspace guard、init／restore journal 位于 .evolve-local/control，保存实际 epoch、清单及恢复进展。它们不是第二份业务历史；只服务启动、换库和防旧请求重放，完成后将结果导入权威库。restore 不能仅依赖将被替换的 operations 表恢复自身。

<a id="analysis-records"></a>

## 独立分析记录、证据与报告

复用 phase_runs，owner_skill=evolve-propose、action=analyze，targets 至少为项目，可附关联 CHG／模块。CHG／REV 为空是正常情况。

- **input**：上述问题与范围、`business_effect=read_only`、`record=true` 及限制；直接领域／资料引用放 input.references，来源 run 单独放 source_runs。
- **source_runs／input_checks**：逐项记录 intended purpose、必需性、来源摘要、当前适用性和采用理由。历史上下文与当前决策依据分开，详见[统一协议](#execution)。
- **过程事件与证据**：及时保存已查范围、观察、假设、排除理由和剩余问题，不能只在最后一条聊天里出现。
- **result.analysis**：observations、hypotheses、结论、`answer_status=answered | partial | inconclusive`、逐项依据、覆盖／限制及剩余问题。观察保存局部标记、陈述、确定性、适用范围与资料引用；关系观察可在既有 details 中表达端点／转换／覆盖，作为图文导出的事实底稿，不是新增实体。confirmed 仅对所声明的观察层和范围成立，例如“源码含此表达式”不证明生产数据已按其计算。引用旧结论要明确来源 run 与范围。
- **run.result／result_digest**：按统一结束协议封存一次；后续修正追加事件／后继结果，不覆盖历史结论。

对已有结论的后续纠正／反驳必须关联原 run 及条目；resume、默认报告和作为 decision_basis 的读取同时展示后续限制或取代提示，不能只看旧 result_digest 就漏掉纠正。原封存结果不改写；导出历史时注明截止点与是否包含后续注记。

每个观察或假设可用 F1／H1 等局部标记；完整引用为 `(run_id, result_digest, local_key)`，不是新领域实体。新 run 可支持、限制或反驳旧 H1，不能把旧 run 的 H1 文本改写成“当时已证实”。

正式证据位于 `evolve/evidence/<run-id>/` 或统一 artifact 区，登记 source_run_id、摘要、来源、时间及覆盖；verification_id 可空。不复制全部日志。证据登记前须核对必要文件已持久化并可校验；仅有外部引用时注明可获取性和缺失内容，不承诺可恢复包含有未保存的外部资料。

观察／推理已经发生但必需证据或记录提交失败，要分开报告“已观察”和“未完整留档”；run 可按实际情况 failed／blocked，或保留受限 partial 及明确缺口，不能宣称完整保存。后续写动作核对实际证据，不能仅凭 answered 放行。

默认对话展示；明确要求报告时按[通用视图约定](#documents)由 maintain export 从已封存结果生成 `evolve/exports/<run-id>/analysis.md` 及请求的图，导出 run 只引用源结果，不进入分析链。头部／metadata 标来源 run、result_digest、资料版本和生成时间。它是可再生成只读视图，手工编辑不改变 SQLite。报告不是唯一证据，正式证据随恢复包保存，exports 不打包。

封存成功后报告失败只提示 VIEW_STALE，不回退分析或重查业务。单独请求“导出上次报告”由 maintain export 以独立导出 run 生成原 run 视图；不占分析续查链、不伪装新调查，也不因导出较新而成为主题的新头。

<a id="analysis-chain"></a>

## 分析链、头校验及中断身份

分析主题从同项目 action=analyze 的 previous_run_id 顺序关系派生，无独立 ANA 身份、分析表或手工 head 状态。标题仅检索，链索引不成为新领域对象。

明确续查才建立新 run：previous 指同链最新已结束的 analyze，source 引用前次封存 result；首轮 previous 可空。同问题的日期／资料扩展写入新 input，保留旧观察原范围；不同问题另开根或先澄清，不能仅凭对象名或日期相近合并主题。旧范围结果可以作 historical_context，拟作新范围 decision_basis 时重新核对适用性，不将新日期覆盖到旧 input。start 携带准备时所见头，在短事务中检查同项目、同动作、无环、没有进行中后继及唯一后继。幂等重试先返回原创建结果，不能因自身已使头前移而再建一次。显式另开主题才新建根；不隐式分叉或承诺并行合并。

标题查询先折叠同链多轮，显式 RUN 保留历史快照并提示当前头和差异。选择旧 A 而已有 B 时，通常从 B 续接、将 A 作为历史来源；不能无声遗漏 B。相关字段索引覆盖 project、action、input 标题、run 与时间。

若上次仍 started，先核实拥有者；明确异常退出后 maintain 封存原 A 为 interrupted，后继 B.previous 仍指 A，恢复 run M 仅放额外 source。已提交进度通过恢复摘要／事件引用，不能凭文件或假设补造根因。源码／日志变化或后续纠正按[输入用途](#inputs)重核，过时结论可被反驳而不阻碍合法调查。

<a id="fingerprints"></a>

## 规划快照、候选依据与证据时效

以下变化创建新规划修订：范围、增量规格、验收、主要方案、任务定义或依赖。普通任务进展、命令输出、补充执行摘要只追加事件。

修订捕获一个逻辑整体：有效 Markdown 快照、结构化任务定义、规格与验收关系及其摘要。`apply` 接受的是这个整体，不是某个随时会变的目录。

直接编辑 Markdown 后，`status`／`resume` 显示 `unregistered_changes`。`update` 从旧快照及候选暂存捕获差异，解释并呈现后再通过可恢复协议将候选设为有效。数据库中的旧快照不得被编辑器新内容覆盖。

### 候选成果与依据摘要

候选指 spec 中需要实施／验收／交付的明确成果，复用现有 artifact、版本／范围、快照、证据与候选摘要，不新增候选实体或数据状态机。代码项目继续采用实际源码、配置、依赖锁文件及测试文件的实现指纹；Git HEAD 仅作辅助，不能代表脏工作区的实际成果。

- SQL、模型、正式文件等成果可用已登记路径／artifact 与内容摘要识别；外部成果保留明确引用、版本或观察时点、实际范围及证据。观察时间或外部 ID 本身不证明内容不可变；没有稳定快照时如实注明可重复核查的限制，是否需要补查由 spec 及当前用途决定。
- 数据日期、样本范围、实际结果与血缘覆盖属于观察上下文，使用现有 input／result、verification 的范围／环境及 evidence 来源表达；不引入平台映射、数据资产／作业实例表或自动血缘引擎。资料变化后重新判断适用性，不以源码未变推定数据或关系未变。
- 候选与验收必须指向同一约定成果及范围。沿现有 artifact／版本与 result.basis_refs 分清“被实施或交付的成果”与“用来判断它的观察／检查依据”：SQL 文件可以是成果，对账结果是验收依据；若 spec 的成果本身是某范围的外部结果，则该范围及可核查引用也是成果身份的一部分。不把生成报告摘要替代实际成果，不把描述清单摘要当作外部内容不可变的证明。
- 新检查时点或补充证据不必自动创造新成果；实际成果版本／交付范围改变才按原规则更新候选和 REL。源码项目仍沿既有保守摘要规则。资料变化需重核，不自动使历史陈述变假；当前用途失配时保留旧事实并限制采用。
- 只有 SQL 文件时不能假称已产出目标数据；有限日期／样本通过不能关闭更大必需范围。scope 或 AC 需要缩减时先 update／接受对应修订，不能把验收失败改成不适用以便归档。纯分析不用为套候选模型而创建 VER／REL。

对于代码及其他本地文件成果，继续使用既有保守扫描规则：

- 默认保守扫描 Git 已跟踪文件及未忽略的新业务文件，排除 Evolve 历史库、生成视图、备份、运行输出及已配置构建产物；无 Git 时采用配置化目录扫描。
- 项目内映射的规格文档单独计算规划摘要。若工具验证代码本身位于 Evolve 默认排除目录，则必须显式纳入代码范围。
- 不读取凭证文件正文进入快照，不把依赖目录打包进历史。排除规则和检测范围写入证据，不能暗示未扫描范围也受验证。
- 文件摘要按实际字节计算；换行、依赖或配置改变可保守地使证据过期，不以修改时间替代内容校验。
- 首版默认受实现指纹或验收修订影响时将相关变更验证标为 stale，不实现复杂的代码影响分析。可以重跑以建立新的有效证据。
- 外部环境或资料变化不一定能由本地摘要检测；证据保留对象／范围与观察时间，当前用途可要求补充验证。候选／依据变化保留旧结果，不将生成报告或历史摘要充当最新事实。

<a id="release-executor"></a>

## 发布执行器、尝试与未知结果

首版保留项目已有本地 argv 执行方式与受控模拟协议，不实现数据平台适配或血缘引擎；执行和结果登记以 spec、当前请求及项目现有能力为依据。没有执行能力时可准备或登记实际外部交付，不能伪称已运行。采用参数数组、shell=False、项目内 cwd、超时与结果协议。Windows 脚本显式指定解释器；凭证沿用项目环境，不写入档案。

先持久化 attempt_id、action、候选、环境、外部幂等键与请求摘要，再调用外部程序。通过 `EVOLVE_OPERATION_ID` 传幂等键；候选／环境等参数按已校验配置传入。输出解析或退出码只证明执行信号，不能代替真实交付结果。

执行器响应契约示例：

```json
{
  "operation_id": "project-supplied-idempotency-key",
  "action": "deploy",
  "state": "succeeded",
  "external_id": "deployment-123",
  "candidate": "candidate-fingerprint",
  "environment": "test",
  "observed_at": "2026-10-27T08:00:00Z",
  "summary": "候选及配置的健康检查通过"
}
```

action 为 deploy／status／rollback；这里 deploy 是沿用的外部交付执行标识，可交付 spec 约定的 SQL／模型／文件等成果，不新增平台动作。candidate 对应上述候选成果摘要，environment 表示明确交付目标／环境。state 为 succeeded／failed／running／unknown。校验 operation_id、action、candidate、environment 和结果来源。rollback 的 candidate 是明确的恢复目标，另存 original_release_id 和 original_candidate；不能拿原发布候选去要求回滚响应相等。普通文本输出只作为证据，缺业务判据不能猜成功。

attempt 的执行结果与环境观察分开保存：状态查询命令失败不等于部署失败，回滚命令失败不等于已回滚；保留 last_confirmed_observation 和时间，当前无法确认时标明 unknown。候选或环境不匹配时保存观察及差异，不放行本次预期结果。REL 状态是对其候选的汇总，不是整个环境的永久真相。

### 外部中断、环境占用与回滚

1. attempt 持久化后外部启动；长命令不持有数据库事务或文件锁，短事务保存可获得进展。
2. 超时、进程退出、主机异常或回执丢失时保留 unknown；先 refresh 或由用户／外部系统提供可核查依据。
3. 同一操作 ID 的本地去重不保证外部 exactly-once；无幂等／查询能力时不能盲目重试。
4. 对同一 project_id + environment，running／unknown 的部署或回滚保留逻辑占用，阻止新的有副作用尝试；status／record 可用于核实。逻辑占用持久化在库内，区别于短期文件锁，不能因进程退出自动释放。
5. 核实后登记真实结果再解除占用；无法核实时保持 unknown。紧急人工外部操作可事后 record 真实事实，不绕过规则伪称已自动执行。其他项目的外部部署不在此锁保证范围内。

回滚需当前请求覆盖目标与方案，建立独立尝试；必要时先核实已有 unknown 尝试。Git 回退、源码 revert、恢复 history.db 都不表示线上回滚。切分支或 restore 后必须重新核实环境，不把旧 succeeded 当成实时状态。

![发布、观察与回滚](diagrams/09-release-status-and-rollback.svg)

<a id="knowledge"></a>

## 经验、晋升及个人库持久化

SQLite 增加结构化实体，Markdown 提供按需生成的经验摘要；不双写可独立修改的规则。

- `experiences`：编号、主题、问题、已证实原因或原因假设、建议做法、适用条件、不适用条件、项目／模块／技术版本标签、状态、来源变更及版本。
- `experience_evidence`：支持或反驳经验的验证、缺陷、修订、发布与观察引用。
- `experience_applications`：在哪次规划引用、为何适用、是否实际采用、后续验证结果及反例。
- `experience_reviews`：提炼、合并、晋升、降级、停用和被替代关系及理由。

状态采用 `candidate | active | needs_review | retired`；保留版本与历史，不因反例出现删除原记录。引用次数不等于成功次数，缺少适用结果时记为 unknown。

### 知识支持记录

在经验模型外增加：

- `knowledge_reviews`：需要专门跟进的知识处理、关联事实、理由与提案；不重复保存每个普通 run 的无新经验结论。
- `promotion_proposals`：主题、目标类型、候选版本、状态、来源、确认与延期依据；同主题同目标仅一个有效待决提案。
- `rule_bindings`：经验／提案与实际规则 artifact、版本、动作、模块、检查方式及生效状态的关系。
- `check_applications`：某次动作实际采用哪些规则／检查以及结果，记录自动、人工和未执行的区别。

约束层 Markdown 是当前规则的编辑与审阅入口；数据库保存索引、来源、版本、状态和历史快照，不另造可自由修改的同权规则正文。入口文件保持简洁，只保存路由和必要引用，不随每次经验增加无限扩张。

沿用[命令清单](workflows.md#commands)的 learn review／promote 与 promote --apply 语义；确认绑定提案、候选摘要及目标。个人库两端提交和恢复见本节下文；规则文件写入走项目内可恢复协议。approved 是决定，applied 才表示已落盘；两者不能混为一个状态。

### 个人库的两端提交

默认经验和来源留在项目 `history.db`。满足通用条件时，提出可晋升条目，说明抽象后的经验、适用边界及将携带的内容。

经用户确认后，按已配置的个人目标写入用户数据目录 `evolve/experience.db`，平台路径在适配时确定。它是项目路径约束的受控例外，不允许把任意 artifact 路径指向项目外。缺少个人库不阻断普通项目阶段；明确的 personal 晋升请求若不能执行则报告受阻，不伪造成功。

晋升先在项目库登记稳定 promotion_id、proposal／候选摘要、确认范围及目标身份，再在个人库按 promotion_id + 候选摘要幂等写入，最后回项目登记目标条目 ID 与实际应用结果。两库不宣称原子事务；第二步后中断时核对目标条目再补登记，不能重复写个人经验。审批状态与 applied／needs_recovery 分开记录。

目标库身份或候选内容变化需重新取得对应确认。项目 restore 不回退个人库；恢复旧历史后先查稳定来源 lineage 和候选摘要，可补记已发生晋升，不将旧批准当作新内容的授权，也不自动删除个人条目。

- 只复制经确认的通用经验，不复制全部项目历史、源码、凭证或业务数据。
- 个人条目记录来源 lineage 和自身版本；项目引用固定经验版本，不能因个人库后来修改而改写过去方案。
- 原项目不可访问时，个人条目不能声称仍可核查全部原始证据；保留可用来源摘要与核查限制。
- 个人库保持本地私有，不自动上传服务，不自动收集其他目录或项目。

这是通过持久化知识、检索和验证反馈改善后续工作，不涉及模型参数自动训练。

<a id="recovery"></a>

## 本地提交、保护备份与档案恢复

evolve-release 负责发布、外部观察与回滚；evolve-maintain 负责本地恢复、备份和档案 restore；evolve-workflow 的 status／resume 只读。evolve-archive 发起同步与封存，未完成操作由维护协议补齐确定性步骤，不重做业务判断。

跨会话恢复同时读取项目级未结束 run／operation（含无 CHG 的配置调整）和用户指定领域目标，不按最后一次聊天或仅按 CHG 过滤恢复阻碍。当前配置解析状态、已登记摘要、实际文件差异、候选／有效 REV 和呈现／接受来源一并展示；字段完整定义仍归对应实体，不建立额外 resume 状态表。只读检查损坏／缺配置时的边界见[配置定位](#configuration)。

先检查本地档案一致性，再允许普通写入。存在未完成跨文件操作／restore 时暂停普通写阶段，包括新的备份、索引写入、知识晋升和发布执行；只读诊断及针对该中断的维护恢复可用。恢复写入走专用控制通道，不被它自身的未完成记录阻塞。

本地未恢复但需核实外部部署时，可只查询并向用户返回未持久化的外部观察；不据此宣称本地已记录或启动新部署。完成本地恢复后由 release status --refresh 核实并登记。单纯外部 unknown、且本地一致时，release 的观察登记可执行。新业务写阶段完成前仍需重新校验相关对象。

### 短锁、阶段占用和提交

个人跨会话按先后接续；首版不协调并行源码编辑。SQLite 写事务保护库内状态，项目短锁保护跨库与文件提交；锁含主机、进程、进程启动标识、run／OP 与时间。创建失败报告占用，不能只因时间长删锁。

run 持久化 started 不等于占有短锁。新写阶段检查相关未结束 run 和环境占用，核实拥有者后再恢复或继续；不能使用“没有短锁”推断上个 Agent 已结束。每次提交检查当前行版本、workspace_epoch 及原文件摘要；外部编辑器不遵守锁，冲突保留双方资料。

### 多文件及候选提交

跨文件操作：prepare 收集原摘要与目标清单 → persist prepared → 逐项核对并替换／移动 → finalize 核对文件后事务提交业务结果、快照和 committed → 清理暂存。单文件替换可原子化，多文件与 SQLite 不宣称共同原子事务。目录归档仅移动明确源目标，不递归覆盖已有归档。

旧值可在前置成立时继续；已为目标值仅补登记；第三种值保留并 needs_recovery；已 committed 返回原结果。调用方必须先保存旧有效材料再改写：规划修订写入候选暂存，校验与用户可见呈现后再通过操作协议提升为有效版本。若 Agent 已直接编辑当前材料，标为 unregistered_changes，读取旧 DB 快照作对照，不把新文件误称原有效版本。

生成视图失败仅标 VIEW_STALE；不阻塞已提交业务结果，也不为修报告重跑任务。finish 尚未提交时 recover --run 依据已提交子操作形成恢复摘要；恢复只能补机械登记，不能假造未发生的任务检查。

独立分析中断也使用既有 run／operation 恢复，不增加恢复模式。过程事件及正式证据可重建已查范围；maintain 仅补确定性登记，不把 hypothesis 补成确认根因，不重放真实业务请求。后继 analyze 保持 business_effect=read_only，并重新核查来源；previous_run_id 仍指恢复后 interrupted 的原分析，维护 run 仅为额外 source_run。进行中分析不得被另一会话无声接管；start 在短事务检查所见链头及唯一后继。

### 恢复目标和初始化清单

- `/evolve maintain recover OP`：已有确定性操作的继续／补登记。
- `/evolve maintain recover --run RUN`：无 OP 的中断阶段；核对源码、任务与证据，结束原 run 为 interrupted，创建维护 run 与恢复执行结果引用；需要实施判断的部分交回负责者。
- `/evolve maintain recover --journal <项目内路径>`：数据库建立前或 restore 换库中的控制清单恢复。
- `/evolve maintain recover --history`：检测到 Git／手工替换档案后，核对当前分支与数据库谱系，保护现状并确认采用当前档案；不合并两个库、不执行业务。

多参数含糊或目标不唯一时澄清；不自动选最后一次部署。journal 路径必须来自本项目控制目录，不执行其中的脚本。

init 在首次写源码前保存项目内初始化清单、稳定 request／run／OP ID、目标文件和已有摘要。暂存配置、库和材料后逐项安装；建库后按同一 ID 导入阶段及操作记录。目录已存在时只补缺失，不 rename 覆盖；未决业务选择不生成整套应用。重试与 journal 恢复保留源码，不删除重做。

明确留档但无 Evolve 时，init 的 records_only 仅建立记录设施、项目范围导航和 init run／控制记录，不建业务 CHG／TASK，不要求完整产品规格或应用骨架；development 接入才沿用初始化系统变更记录。records_only 完成不代表开发 ready，转开发按范围补基线而非重建库；现有库损坏仍走恢复。分析的正式证据纳入保护集合，exports 中的 analysis.md 是派生报告，不是唯一依据。

### 备份集合、截止点和支持步骤

备份集合包含数据库、配置、权威 Markdown、归档／发布材料及所有必需引用附件。它只恢复已保存的项目材料与证据，不保证恢复仅有引用而未保存的外部资料或业务数据。使用 SQLite 备份 API，在短锁中采集一致副本；校验文件前后摘要。清单记录项目、schema、工具版本、数据库检查点／事件高水位、文件摘要、producer_run_id 和快照时仍在进行的 run。

排除 `.evolve-local/`、既有备份／恢复包、exports 产物、可再生成视图和暂存输出，避免递归打包自身。权威记录不得将唯一证据仅指向这些排除目录；先迁入正式 evidence 再登记。目标不能覆盖输入、权威文件或恢复源；导出是派生材料，不成为其自身输入。

策略备份在调用阶段内记 component_skill=evolve-maintain，关联父 run，独立 operation_id；不再触发自己的首次写入备份，避免递归。默认首次当日写入前备份、restore／未来迁移前保护备份、归档和实际发布完成后完成点备份。正常首次写入前备份失败时阻止后续业务写入；完成点备份失败不回滚已完成事实，仅提示补做。首次 init 无旧档案时不要求不存在的备份。

独立 backup 请求有自己的 run，但恢复包只承诺清单所述截止点，不承诺含有该备份完成后才追加的 finish。恢复时清单标明的进行中 run 按历史中断候选核对，不能自动继续或重做生产操作。

### 换库、损坏现场及防重放

restore 会替换存放 operations 的数据库，因此必须先把控制清单持久化到不随档案替换的 `.evolve-local/control/restores/<OP>/`，关闭相关连接后再换库。清单保存稳定 request／run／OP、项目 ID、来源包摘要、目标／保护副本、旧值／目标摘要、步骤和 workspace_epoch。每步可恢复校验，完成后向恢复后的库追加维护 run 及其 restore 结果与事件；不是将所有旧历史合并进恢复库。被替换的后续历史保留在保护副本。

校验同项目、支持 schema、路径及全部摘要；保留当前配置和文档，完整保护后才替换。校验成功仍不执行包内任意脚本，恢复后不自动执行备份中的命令。普通 restore 要求一致保护备份；当前库已损坏无法 API 备份时，先隔离保存原始库、sidecar 和资料并校验复制字节，将其标为损坏现场而非可恢复备份；保护失败则停止。验证过的恢复源可用于此损坏恢复分支。

首次写入建立非 Git 的 workspace guard，保存 workspace_epoch 和最近已见数据库检查点。restore、检测到历史倒退或分叉并经 recover --history 核对后更换 epoch；旧写请求的 expected_workspace_epoch 不再接受。只读命令只报告差异，不更新 guard。缺少 guard 的新机器在第一次明确写请求，以 guard 不存在为前置，在短锁和启动清单下建立上下文及阶段；竞争者发现前置变化须重新核查。启动中断可 recover --journal，不提供多机并发锁。

guard 使用库内不可变检查点 ID 而非单独事件序号；若最后已见检查点不在当前历史中，阻止普通写入并要求核对。成功事务先写库检查点，再更新本地 guard；更新中断时，旧 guard 检查点仍在当前历史中，可沿链核对前移，不误报为回退。restore 控制清单保存旧／新 epoch，可在换库中断后完成切换。

恢复不重写历史执行结果引用，只对新的写请求防重放；历史 run.result 引用重新按业务依据核查后仍可使用。恢复后比较实际成果与规格／候选，报告或登记不匹配，必须适用的证据重新验证。个人经验库、外部环境及业务数据不随 Evolve 档案 restore 回退。restore journal 必须保护被替换档案中已知的未决外部尝试引用；恢复或 history 核对后在当前 epoch 设置 external_reconciliation_required，对要求环境阻止新 deploy／rollback。先通过 refresh／实际依据核清环境和已知未决操作，登记后解除该门禁，不让旧库缺失的 unknown 记录成为重发许可。

恢复前后均不能据本地档案推断环境实时状态。若当前归档来源无法提供某次外部尝试，明确核查限制，不保证仅凭候选当前已部署就证明所有未知尝试已结束。

![历史、导出与恢复](diagrams/11-history-export-and-restore.svg)

<a id="database"></a>

## 连接、版本、Git 与保留

- 每个连接显式设置并确认 `foreign_keys=ON`；启用明确事务控制，避免依赖不同 Python 版本的默认提交行为。
- 初版使用 `journal_mode=DELETE`，简化数据库作为单个 Git 文件的保存；不依赖 WAL sidecar 作为权威历史。
- 写入使用短事务、必要的 `BEGIN IMMEDIATE` 和有限的 busy 等待；不把模型思考或发布子进程放在数据库事务中。
- 首次执行写操作检查 `expected_versions` 与 `expected_workspace_epoch`；已提交幂等重试先校验当前 epoch 和输入再返回原事实，详见[工具契约](runtime.md#tools)。首次写入在同一事务内更新实体、添加事件及操作状态。过期写入报 `VERSION_CONFLICT`，不做最后写入覆盖。
- 绑定参数执行 SQL，状态转换和引用存在性由工具检查；只读查询不能修改库、workspace guard、编号或索引；发现不匹配只返回诊断。
- 未知更高 schema 版本拒绝写入；升级前备份，迁移逐版执行并记录工具版本。首版只承诺创建 v1，未来变更必须新增迁移，不重建丢历史。

多文件原子性、写锁和中断恢复见[发布与恢复](#recovery)。不支持多个 Agent 同时编辑同一变更；短期工具写锁和摘要检查只能检测部分冲突，不能宣称替代所有编辑器的锁。

### Git 与保留

已确认：数据库随 Git 保存。默认纳入当前知识、变更材料、必要证据、发布材料及 `history.db`；临时输出、锁和本地备份排除。

- development init 仅提出／增量写入数据库的二进制属性与 `.evolve-local/` 忽略规则，保留用户既有配置。
- 操作完成后关闭连接；不在有进行中写操作时建议用户切分支或提交。
- 不自动提交数据库和源码。操作结果提示应一起审阅和提交的文件集合。
- 数据库发生 Git 冲突时暂停工具写入，不自动选 ours/theirs、不按文本合并；保留两份后依据实际分支选择或后续专门修复。
- Git checkout 使本地档案回到该版本，不证明外部发布环境也回退；记录中的 succeeded 带观察时间，不能替代实时环境核实。
- 首版不提供跨分支数据库自动合并或历史后端迁移。恢复包服务同项目的备份恢复，不充当多人数据库合并协议。

归档不清理历史快照或证据。大附件保留可按项目配置限制未来采集，但不能静默删掉已有唯一证据；本地备份首版不自动清理。
