# 运行契约、存储与恢复

设计基线：**0.6.0**；更新：2026-10-31。本文是技术字段、持久化、并发协调、外部操作及恢复的权威。动作许可由 [工作流](workflows.md)定义，不由字段存在或配置可用推导授权。

<a id="environment"></a>

## 运行环境与适配

工程基线为 Python 3.11+ 标准库、sqlite3、TOML 配置和 UTF-8 Markdown。实现时探测实际模块和可用版本，当前不宣称已运行插件。普通事务采用显式控制，不依赖 Python 版本的默认提交行为。

插件只读安装根与目标项目根分开定位，公共资源只分发一份。宿主适配仅处理发现、参数、权限与资源定位；业务逻辑不依赖宿主专属钩子或后台代理。整包格式和 schema 同步校验，未知更高版本只读诊断，不无记录降级执行。

<a id="configuration"></a>

## 项目定位与配置

固定定位为项目根下 evolve/config.toml、evolve/history.db、.evolve-local/control/。project.id 创建后不可普通重配；history.backend 固定 sqlite，库和控制区路径固定。目录改名不改项目身份。

发现多个根、嵌套项目或同名非 Evolve 资料先定位；已有库而配置缺失不是新项目，不能自动重建。查询以禁止创建的只读方式打开已有库，配置异常时说明可信读取边界。项目内路径规范化并检查绝对路径、.. 和符号链接逃逸；不扫描其他项目拼接背景。

最小示例，仅表达格式，不将示例身份或命令照抄到项目：

```toml
config_version = 1
[project]
id = "replace-with-generated-project-uuid"
name = "example"
language = "zh-CN"
[history]
backend = "sqlite"
database = "evolve/history.db"
[paths]
local = ".evolve-local"
[context]
default = "adaptive"
[verification]
policy = "impact"
```

检查命令只在发现真实入口并核对副作用后配置为 argv 数组、cwd、timeout、适用范围和环境身份；不使用未经解释的拼接 shell 字符串。凭证来自现有环境或项目机制，值不入配置、数据库、日志或报告。正式环境数据执行依据具体批准候选，不设置部署配置。

### 受控维护与摘要

init 唯一维护工具配置；独立配置调整用独立 run，回原阶段重新 prepare。查询、分析、核实外部操作不会隐含重配。已授权明确调整可以在整体请求中调用 init，但保留独立结果，不改父请求输入。

首版写入子集为明确支持的表和标量／数组字段；采用定位替换或追加、保留未改字节、完整 TOML 解析及往返校验。未知关键字段、重复键、歧义格式或无法无损定位时原样保留并报告不支持，不整文件模板覆盖。类型／结构改变先呈现具体配置差异。

原始字节摘要保存审计；语义摘要按固定字段组计算：identity／paths、checks、context／display。checks、执行范围与相关依赖变化重核对应检查；展示语言和注释不使所有业务验证过期。无法证明配置影响范围时保守重核，并说明原因。身份／路径异常阻止写入，不作为普通复验处理。

手改配置可在后续明确写阶段调用 init 校验、登记可核实字段；查询只报告差异。未知命令或权限变化不能由“接纳外部修改”推定可执行。配置调整不重置已接受方案或已完成任务，业务含义变化仍走 REV。

配置与数据库提交使用 [文件操作协议](#recovery)，保存原字节和候选；文件已为候选时只补登记，第三种值保留冲突。不运行配置中的命令来“完成恢复”。

<a id="documents"></a>

## 材料、上下文与生成视图

最小工作材料包含目标／问题、对象和范围、来源、方案或调查路径、完成条件、限制。日期、粒度、技术版本、比较基准和数据覆盖按任务需要提供，缺关键字段标未知或澄清。已有资料可引用，不强制复制全部正文。

简单方案在对话呈现后按实际文本保存为 artifact／blob，并绑定 REV、呈现时间及授权；独立 Markdown 文件按需生成。复杂方案保存 spec／必要设计文档，任务定义归数据库，tasks.md 为视图。首次项目知识仅为候选，批准后才能以正式基线登记。

每个可用上下文条目的索引或引用至少有：
- 类型与稳定 artifact／实体／局部发现引用；
- 范围（项目、模块、对象、日期或版本等适用字段）；
- 来源／观察者、观察时间和记录时间；
- 确定性、确认依据和实际内容摘要；
- 后续纠正／替代／争议信息。

这些值复用 artifact_versions、spec_items、经验和分析记录；不另建全量项目知识库或双写正文。当前上下文包由查询生成，不是新的可编辑状态。加载顺序为适用正式规则／项目约定、相关方案与现场、历史事实、经验线索；来源冲突显式呈现。尚未核对时使用 unconfirmed，不把“查不到变化”当有效证明。

图文底稿保存已观察的关系、端点、转换、来源和覆盖；图与报告从封存结果生成。exports、tasks、resume、verification、analysis 等视图标注源版本、生成时间及观察截止点。重导不补事实，缺底稿如实报告；导出不得覆盖源资料。

<a id="tools"></a>

## 工具接口与幂等

唯一工具入口的动作与 [工作流映射](workflows.md#commands)一致。工具接受规范动作、目标及当前授权范围，不重新猜测同一请求的语义。用户不填写内部 ID。

写请求包含 project_id、request_id、owner_skill、action／method、targets、input／digest、expected_workspace_epoch、expected_versions、授权引用；start 后增加 run_id，子操作有稳定 operation_id。目标和引用必须带 entity_type／entity_id／版本，不把关键范围藏入任意 JSON。附加非门禁信息才可用 details。

请求键为 project_id＋workspace_epoch＋request_id；操作 ID 同项目唯一。同 ID 相同规范输入返回已有事实，不创建第二次动作；同 ID 不同输入拒绝。当前 epoch 下先查已提交幂等结果，再核首次写入的 expected_versions；旧 epoch 请求拒绝，不以换 ID 绕过未知外部操作。未完成操作返回待恢复状态。

固定响应包含 ok、action、operation_id、data、warnings，错误有 code／message／next_steps。data 包含 committed、run_id、实体版本、业务 outcome、证据和视图／备份状态。ok 只表示接口操作是否成功，不能代替验收结果。

退出码：0 为成功登记／查询，2 为输入或前置错误，3 为版本／占用冲突，4 为待恢复，5 为外部失败或未知，1 为内部错误。即使已经保存失败事实，也不能以成功业务结果隐藏 unknown。提交后视图或后置备份失败不重跑业务。

纯查询不建 run、不分配编号、不更新 guard／索引、不备份迁移。明确保存报告属于 export 写动作。首次 init 尚无库时使用独立控制清单；不伪造已有 epoch。

<a id="execution"></a>

## 执行生命周期与授权记录

prepare → start → execute → finish → present 由共享内核支撑：

1. prepare 只读规范化动作、目标、来源、当前意图、相关占用及恢复阻碍；查询至此返回。
2. start 以短事务复核版本和 epoch，保存不可变输入、source_runs 与 input_checks，幂等建立 run。
3. execute 按子 operation 及时登记成果、证据、任务和操作进度；长命令、模型思考和用户等待都不占数据库事务。
4. finish 原子提交 run 终态、result／digest 和关键事件；一个 run 只有一份封存结果。
5. present 返回实际结果及限制；需要文件报告时由 maintain export 引用封存结果另建 run，export 不再递归导出。

run 状态 started → completed／blocked／failed／interrupted，终态不重开。completed 不代表任务验收或外部效果成功。后续新动作建新 run，跨阶段引用 source_runs，不把分析 previous 链用于修复。

result 保存实际完成、未完成／阻碍、产物和不可变版本引用、basis_refs、知识处理结论及限制，不复制整份任务／VER／聊天。经验无新发现、pending、unavailable 分开记录。源码已改而结果未登记时保留不完整事实，恢复不补造通过。

授权与方案接受记录使用带类型的事件及引用，至少保存请求来源、允许的 effect_kind、目标／范围摘要、限制、相关 REV／候选摘要、批准时间和后续撤销／替代。正式知识批准和正式环境批准分别绑定具体内容；并非每个普通动作都增加一套审批对象。

每次副作用前核对最新范围与撤销信息。同范围续接可复用已有明确授权；旧结果、经验文本、配置或 resume 不能独立提供新授权。finish 不改写开始时输入，后续依据变化写子操作、input_checks 追加说明和 result.basis_refs。

知识检查和策略备份可沿父 run 记录 component_skill／operation；独立 learn、init、维护动作及正式知识应用各由 owner 建 run。不再有发布配置支持或 init 开发业务的例外。

![执行承接](diagrams/15-skill-handoff-and-rotation.svg)

<a id="inputs"></a>

## 多来源核查

source_runs 引用同项目封存 run_id＋result_digest；直接文件／领域资料放 typed input.references。每个来源注明用途 decision_basis／historical_context、是否必需、具体版本、范围及采用理由。

当前决策必需依据失效时阻碍相关判断；历史假设可继续作为重查对象，不能因过期阻止合法调查。同一来源可被多个 run 引用，无“已消费”标志。局部分析结论引用包含 run、result_digest、local_key。

核对来源摘要只是证明历史内容未变，还须看当前语义、现场、资料时点和后续纠正。单纯行版本、归档位置、经验追加变化不一定使业务依据失效；来源实际行为或适用条件改变则需要重查。

拒绝需要留档时可建立单个 preflight run 记录原因，不发明回执对象。接受来源不等于接受方案，不等于批准修改或验证通过。

<a id="data"></a>

## SQLite 逻辑模型

一个项目一份 history.db，普通表加追加事件，非完整事件溯源系统。当前投影与事件同事务写入；不承诺仅凭叙述事件重建所有内容。

所有实体有 UUID；CHG 使用日期加随机友好编号；TASK／REV 局部编号必须带 change_id。语义 G／NG／FR／BR／AC／BUG／DEC／OQ 使用计数器分配，不回收编号，可跳号。时间存 UTC ISO 8601，显示按用户时区；row_version 用于乐观并发。

v1 模型按以下分组定义，SQL DDL 在实现阶段编写：

- **project_meta／counters**：项目身份、schema、工具版本、不可变检查点谱系及编号；无隐藏的第二后端。
- **changes／plan_revisions**：标题、类型、复杂度、生命周期、当前 REV、接受依据、基线、方案正文引用、任务定义和 AC 摘要、呈现记录、修订原因与范围。init 不再创建 initialization 类型业务 Change。
- **artifacts／artifact_versions／blobs**：逻辑身份、当前路径或无文件的内联文本、种类、版本、内容字节摘要和来源。当前 Markdown 语义与历史快照分开；同内容 blob 去重。
- **spec_items／delta_items**：正式知识索引、确定性和依据；delta 的稳定 ID、add／modify／remove、目标、预期基线、候选文本、AC、依赖、前继。无规格增量明确 spec_delta=none。
- **tasks／task_dependencies**：完整定义、范围、完成条件、AC、状态、实际结果、完成时定义摘要及版本；依赖记录见下节。
- **verifications／verification_items／evidence**：REV、成果和现场快照、检查范围／方法／配置摘要、逐 AC 结果、不适用原因、来源／观察时间、附件摘要、实际观察者及限制。source_run_id 必填，verification_id 可空。
- **events／relations**：追加事实、纠正、授权、方案接受、取消、知识处理和恢复；关系带类型及合法目标检查，不用通用关系绕过外键与项目归属。
- **spec_applications**：delta、批准提案版本、基线／结果摘要、验证引用及 operation；唯一应用键为 delta_id＋目标内容摘要，REV 改变不重放旧 ADD。
- **phase_runs**：规范输入与请求键、targets、sources、input_checks、owner、状态、结束结果、digest；分析沿 previous_run_id。
- **operations**：action／effect_kind、稳定输入摘要、目标、期望版本、授权依据、记录状态、步骤清单、结果引用；外部操作扩展见专节。
- **resource_claims**：相关资源的工具写入协调及未决外部效果占用，不是业务任务或调度系统。
- **experiences／experience_evidence／experience_applications**：经验内容版本、条件、支持／反例、采用和结果；审阅和替代由事件保存。
- **knowledge_proposals／rule_bindings／check_applications**：集中知识提案、规则关联及规则检查效果，见知识专节。knowledge_proposals 替代旧 promotion_proposals 的项目内用途，不同时保留两套；普通知识结束检查只留 run 结果，不强制 knowledge_reviews。

移除 releases／release_changes／release_attempts／environment_claims、个人库两端记录。当前不存在真实旧库，因此本次只是 v1 设计重写，不执行数据库迁移或删除历史。

### 状态和任务定义

状态枚举与转换由 [工作流](workflows.md#states)维护；工具核对原状态、触发动作、期望版本、理由和必须依据。受影响已完成定义改变时转 todo，不另加含糊的“待评估”手工状态；证据可暂时 unconfirmed，核实后决定是否沿用。旧完成事件固定引用旧定义。

Task done 要有实际结果和适用检查；Change archived 要满足封存门禁。知识 pending 单独派生，不能使 run completed 被误解为知识已应用。

### 依赖条件

task_dependencies 可表达同 Change 或同项目跨 Change 的前置，字段至少为 downstream_target、upstream_target、required_revision／definition_digest、condition_kind、condition_ref、evidence_ref 和核实时间。condition_kind 限定为 task_completed／verification_passed／artifact_available／knowledge_applied，不接受任意可执行表达式。

检查目标存在、同项目、无环及对应条件；单纯相关关系不参与阻塞。上游版本改变／取消／被替代时，将直接受影响依赖标为需重新核实并阻碍对应任务；重核后的结果继续向实际依赖传播。不做全项目无依据的自动语义图推理。

归档后的上游结果若仍满足固定引用可复用；标题、归档标签或 Task done 均不能替代所要求的接口验证／正式知识应用。

<a id="analysis-records"></a>

## 分析记录与图文底稿

analyze 的 owner 为 evolve-propose；input 含问题、范围、来源、business_effect=read_only、记录意图及限制，targets 至少为项目。CHG／REV 为空正常。

过程及时保存已查范围、观察、假设、排除理由、证据和下一步。result.analysis 包含 observations、hypotheses、answer_status=answered／partial／inconclusive、结论、覆盖、限制和剩余问题。F1／H1 是 run 内局部标记，引用使用 run＋digest＋local_key。

关系观察的 details 可表达源／目标、转换和覆盖，但必须保留依据与确定性，不建设血缘专属表。confirmed 限于明确的观察范围，不能把源码关系推成完整生产血缘。

后续反驳关联原结论，resume 和默认当前报告同时展示纠正／限制；历史结果不覆盖。原始证据优先进入 evolve/evidence，exports 不作为唯一证据。外部引用说明可取得性，未保存的数据不承诺可恢复。

观察已发生但证据或数据库保存失败时分开报告，不能声称完整留档。报告失败仅标 VIEW_STALE；从原封存底稿重导，不重新读业务数据补结论。

<a id="analysis-chain"></a>

## 分析主题与续接

分析主题由同项目 analyze previous 链派生，标题不是身份。续查 start 在短事务检查同动作、所见最新头、无环和无正在执行的后继；每个头最多一个顺序后继。首次根 run 无 previous；明确新主题另建根，不无声分叉。

不同主题可并存，不同 Change 也可并存。同一主题的两个会话争抢续查时一个成功，另一个读取新头后定位，不覆盖已查进度。幂等重试先返回同一次创建事实。

显式历史 RUN 展示原快照与当前头；历史来源可作为重检对象。日期和资料范围扩展写新 input，不改旧观察。started run 先查拥有者；确认中断后 maintain 封存原 run 为 interrupted，后继 previous 仍指原分析，维护结果只作 source。

<a id="concurrency"></a>

## 多任务、资源协调与外部编辑

支持同一工作目录中多个 Change／分析链；不存在“最近聊天就是当前任务”的全局变量。所有写请求和证据显式携目标。相同 Change 的方案／实施写入使用 change 级 claim 串行，跨 Change 独立修改可推进。

resource_claims 字段为 project、resource_kind、canonical_target、scope、owner_run／operation、主机／进程启动标识、状态、row_version。资源包括 Change、规范化文件路径、已识别共享接口／口径、外部连接身份与数据对象。外部范围无法证明不重叠时保守占用整个对象，不假装解析任意 SQL 可获得精确分区。

领取／释放在短事务中完成，多资源按确定顺序获取以避免互锁；冲突说明谁占用什么，只等待或阻碍受影响部分。长工作不持 SQLite 事务。持久化 claim 与瞬时短锁分开；不能凭超时删 claim，需核对进程和实际操作状态。

claim 只协调本项目通过工具发起的操作，不能锁住其他编辑器、外部平台或人工数据写入。外部执行前后仍核对目标前置与实际观察；提供者不支持相应并发保护时明确限制，不宣称本地占用可实现跨系统互斥。

相关文件写前核原摘要，写后记录实际摘要。外部编辑器不遵守 claim，摘要核对不能消除检查与写入间全部竞态；发现第三种内容保留现场和候选，停止该覆盖，不声称并发安全。静态资料摘要也不能证明外部数据实时不变。

纯查询仅呈现 unregistered_changes；下一写阶段登记可核实观察，source=external／unknown，不编造修改者或原因。正式文档外部变化保存实际新字节与原批准版本的差异，未知确认来源保持待核对。工具配置由 init 校验接纳；业务现场不强制 init。

新冲突只重核相关目标、直接依赖与证据；库损坏、换库中或公共控制清单不一致是全局工具写阻碍。工具不冻结用户编辑器。分支历史边界见末节。

<a id="fingerprints"></a>

## 成果、影响范围和证据时效

成果不是独立发布候选实体，以 artifact／文件清单、字节摘要、实际数据对象、日期／版本及证据表达。Git HEAD 仅辅助，不能代表脏工作区。默认扫描相关受管源码、未忽略业务文件、依赖锁和相关检查配置，排除历史库、视图、备份和构建产物。

验证范围在方案中明确，执行时核对实际影响和必要回归。每份 VER 保存实际现场清单、变更关联、检查命令或方法、观察时点、环境、REV／AC 摘要和覆盖限制；检查前后相关文件摘要变化时该次结果不能直接记 current。

与当前验收相关的源码、依赖、AC 或 checks 配置改变使旧证据 stale；未核实为 unconfirmed；检查后证明未影响才 current。不能仅用 mtime 或单一整体配置 hash 决定所有证据。无法可靠判影响时扩大核查并说明理由。

混合工作区记录包含的关联修改；无法解释归属时注明限制。A 的验证依赖 B 时绑定依赖与版本，不能称 A 独立通过。需要隔离时给出具体方案，不强制用户使用 worktree，也不自动迁移分支或历史库。

外部数据记录观察日期／截止点、查询范围、版本／批次或可取得快照；源码不变不代表数据证据 current。外部提供的结果保留原观察者、原时间和依据，采纳登记另记当前 run。

<a id="release-executor"></a>
<a id="external-effects"></a>

## 外部副作用、授权与未知结果

旧 release-executor 锚点仅为历史引用保留；当前契约是 apply 的外部数据操作，没有 REL、deploy 或部署状态。verify 只执行授权检查，analyze 不得借复现写正式数据。

operations.effect_kind 为 local_write／external_read／external_write。外部写入扩展字段必须包括：
- 目标连接的稳定非秘密身份、环境级别、对象和数据范围；
- 实际执行脚本／argv／参数的候选 artifact 和摘要、前置条件；
- 授权来源、目标与候选版本、验证及补偿安排；
- 稳定 idempotency_key、provider_operation_ref 或核实查询方法及限制；
- started_at、finished_at、effect_outcome、证据、错误、原操作或补偿关联；
- 外部 resource_claim 和追加观察记录。

record_state 沿用 prepared／applying／committed／needs_recovery／aborted，表示本地操作登记；effect_outcome 为 not_started／running／succeeded／failed／unknown。两者正交：已经 committed 的记录也可能包含 unknown 外部结果，不能释放 claim 或重发。needs_recovery 仅表示本地提交需要修复，不用它表达全部外部未知。

### 执行顺序

1. apply prepare 固定候选、环境、范围、验证和补偿，呈现具体方案。无具体批准则仅保留提案。
2. 获准后重新核对候选／授权／前置条件及重叠 claim。短事务保存稳定 operation、授权引用和未决占用；外部调用前同步保存本地控制区的必要未决保护引用。
3. 在事务外执行。适配既有项目机制，不承诺通用数据平台执行器。调用支持幂等键时传递该键，不支持时明确限制。
4. 及时登记实际调用信号、外部操作引用和观察。退出 0 不证明业务效果；对账／验证不通过仍如实记录已发生修改。
5. 结束报告分开操作效果与验收结果。失败可能有部分副作用，保留实际范围；是否重试需先证明未决部分已结束，再使用适用授权和新确定候选。

授权绑定环境、对象、脚本内容和参数范围；执行前实质变化、用户撤销或候选替代时阻止旧批准继续。普通测试授权只覆盖指定隔离测试环境，不能扩张到正式环境。

### 核实与补偿

超时、回执损坏、断连或进程消失均不能推断未执行。reconcile 只核实既有外部操作状态并追加证据；查询失败不覆盖最近已确认事实，也不解除 unknown。没有幂等或可靠核实能力时显示能力限制；结果未知后保持受阻，不能以人工猜测或换 ID 重发。可采纳人工／外部确证，但必须有操作、目标、时间和范围依据。

确认终止且剩余效果已查明后可释放相关未决占用。外部仍运行、只观察到部分数据或无法排除延迟提交时不能释放。补偿是关联原操作的新 external_write，具有自己的候选、范围、验证和授权；原批准若已明确包含同一补偿内容可复用，否则重新确认。

maintain 只能恢复本地登记和保护引用，不能自动执行、重发或补偿。档案恢复后外部核实仍归 apply，具体隔离控制见下一节。该协议不声称跨本地数据库与外部服务恰好一次事务。

<a id="knowledge"></a>

## 项目经验、知识提案和批准

experiences 保存主题、问题、原因假设或已证实原因、建议、适用／不适用条件、模块／版本标签、状态和来源。状态与使用边界归 [learn](workflows.md#learning)。experience_evidence 带支持／反例引用，applications 区分命中、实际采用、结果、归因限制与 unknown，不用引用次数计成功。

knowledge_proposals 复用同一项目提案结构，target_kind=baseline／spec／rule，保存 owner、目标 artifact／条目、基线摘要、候选字节／差异、范围、来源／反例、影响、候选版本及确认引用。状态 proposed／deferred／approved／rejected／superseded，实际 applied／needs_recovery 用应用操作表示，批准不等于落盘。

同主题／目标的有效待决内容归并，候选变化生成新版本；批准绑定版本，不自动转移。集中批次只有提案 ID 列表及逐项决定，不新建批准平台或要求跨 owner 原子事务。拒绝／延期有原因，不能以新 ID 绕过。

规则正文归 Markdown；rule_bindings 保存经验／提案与实际规则版本、适用范围的关联；check_applications 保存实际规则检查结果。spec 应用复用 spec_applications，初次基线由 init；不同 owner 共用同一批准校验与文件写协议。

反例出现时追踪经验、提案、关联规则及未完成方案；自动标知识适用性待复审并呈现冲突，不自动改正式规则正文。当前必需规则冲突需要决定时暂停相关动作；旧历史引用仍保留原版本并附后续注记。

检索先用项目／模块／动作／技术版本过滤及关键词、标签；展开少量相关内容。必需规则独立加载，候选单独标注，已退役默认不推荐。索引可重建，纯查询发现失配只报告，写阶段才更新。先用小案例集验证效果，不引入向量服务或个人库。

<a id="recovery"></a>

## 本地提交、备份和恢复

### 文件与数据库提交

使用短期工具锁保护受管多文件提交，锁记录主机、进程启动标识、run／operation 和时间；不凭年龄删除。业务资源 claim 按前节定位，不能用“没有锁”推断外部操作已经完成。

多文件操作：收集原字节／摘要及候选 → 持久化 prepared 清单 → 逐项核前置并替换 → 核文件 → 事务登记版本／结果／committed → 清理暂存。单文件可原子替换，多文件与 SQLite 不宣称共同原子事务。

旧值且前置成立可继续；已为候选仅补登记；第三种值保留冲突并 needs_recovery，不覆盖用户编辑。业务源码直接编辑未及登记时恢复只核已发生事实，不能补造原任务完成。正式知识应用还需核对应批准版本；恢复不能借机械登记应用新内容。

### 初始化与中断

init 建库前在固定 control/init 清单保存 project／request／run／operation、目标、原值和候选。只有明确接入且没有旧库／控制冲突才生成新身份。逐项安装后按同一 ID 导入权威库，不为重试删掉重建。已有损坏库走恢复。

recover 可定位 OP、RUN、journal 或 history。未结束 run 只能基于已提交事实封存 interrupted，并记录 finalized_by／恢复来源；后续业务另建 run。恢复知识或配置提交只补确定步骤，不自动运行检查。无 OP 的源码中断也能保存现场差异和实际进度。

报告失败标 VIEW_STALE，重导不重做业务。已封存结果发现错误通过纠正或后继记录，不改历史原文。

### 备份集合与成本

一致恢复包包含 SQLite 备份副本、工具配置、已受管正式 Markdown、方案快照及必需附件；清单有项目、schema、工具版本、检查点、文件摘要、截止点和进行中 run。普通可读报告不承诺恢复能力。

排除 .evolve-local、旧备份、恢复包、exports、可生成视图和暂存，防止递归。唯一证据先进入正式 evidence；外部只引用未保存的数据标明恢复限制。

默认当天首次受管写入前至多一次一致备份，restore／未来迁移前必须保护现场；取消每次归档或阶段完成的额外全量备份。初次 init 无旧档案不要求备份不存在的数据。备份失败阻碍依赖该保护的受管写入，不回滚已完成的业务事实。

采集前估算集合和可用空间；按项目支持的附件大小／采集预算限制未来采集，超限说明证据缺口而不是截断后声称完整。定期展示容量及可审阅整理方案，首版不静默删除唯一历史或证据。暂存／可生成视图可在明确规则内清理，备份淘汰需保留可验证恢复点并有明确授权。

### 恢复集合与防重放

restore 替换存放 operations 的数据库前，必须在不随包恢复的 control/restores 中保存目标、保护副本、清单、旧／新 epoch 和进展。检查同项目、schema、路径、全部摘要；数据库损坏不能 API 备份时，先复制保存原始库和 sidecar／资料并校验，保护失败停止。

比较恢复包受管集合与当前登记集合：包中目标恢复；当前多余的受管文件先保护并隔离，不留在权威目录形成混合基线；未登记用户文件原位保留。包目标与未登记文件冲突时停止该覆盖并呈现方案，不能按“恢复旧版本”删除用户新文件。源码、真实数据、外部服务不在档案恢复集合。

restore／已核实历史倒退或分叉后更换 workspace_epoch，旧请求不得重放。project_meta 以不可变检查点和前驱表示谱系；成功事务后更新本地 guard，中断时旧 guard 仍属当前链可核前移，不误报回退。guard 缺失的首次明确写入以不存在前置在短锁下建立，查询不写 guard。

替换历史前保护所有已知 running／unknown 外部操作引用和受影响资源；control/external 保留执行前写入的最小未决索引，作为防恢复遗漏的保护副本而非第二业务历史。若数据库与保护索引不一致，先核查而非放行。恢复成功后在新 epoch 设置相关资源需核实状态，由 apply reconcile 追加确证后解除。索引遗失或从旧包在新机器恢复、无法判断之后是否存在外部写入时，对明确正式写目标先核实现状与已知操作，不能宣称“旧库没有 unknown 就安全”。

本地档案一致前可只读观察外部状态，但需说明未持久化；恢复后再登记。全局换库期间普通工具写暂停，局部未知只阻止重叠外部写。任何恢复都不执行包内脚本。

![恢复](diagrams/11-history-export-and-restore.svg)

<a id="database"></a>

## 连接、Git 和保留

每连接开启 foreign_keys，普通本地 history.db 使用 journal_mode=DELETE，短事务和有限 busy 等待；不跨长命令持锁。绑定参数执行 SQL。提交校验 expected_versions／epoch，发生冲突不最后写覆盖。未来 schema 升级先备份并逐版迁移，首版只创建 v1。

已确认数据库随 Git 保存；必要文档、历史库和证据一起审阅，工具不自动提交。二进制属性与忽略规则的新增先作为具体项目配置修改提出，不能靠 init 绕过用户修改边界。

同一目录多任务共享同一数据库。切分支前说明进行中受管操作／未决外部引用；用户仍可操作项目，恢复工具时核对历史谱系和现场。Git 回退不代表源码之外的真实数据已经回退。

遇两个分支不同历史，保留双方库与引用附件，停止冲突的工具写入；展示来源和选择／另存核查方案，不自动选 ours/theirs、不文本合并。可读导出另一历史用于人工核查，不冒充已合并事实。首版不自动汇合多个 worktree 的历史，不把此限制转成禁止项目分支开发。

归档不删快照或证据。已知事件、失败、取消和反例保留，修正通过新记录表达。配置和历史可以恢复，不意味着现场业务与其一致，必须重新核对。

