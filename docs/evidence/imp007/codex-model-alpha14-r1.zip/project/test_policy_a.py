import unittest
from policy import POLICY
class PolicyA(unittest.TestCase):
    def test_independent_literal(self):
        self.assertEqual(POLICY, 'A')
