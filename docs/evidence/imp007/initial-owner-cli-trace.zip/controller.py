"""Actual init/sync owner Tasks via moved full package and public CLI, no models."""
from pathlib import Path
import hashlib,json,sqlite3,subprocess,sys,tempfile

ROOT=Path('/Users/liufukang/Workplace/spec-driven');lab=Path(tempfile.mkdtemp(prefix='evolve-imp007-init-owner-cli-')).resolve()
package=lab/'完整 初次文档包';project=lab/'初次正式文档 临时项目';project.mkdir();trace=[]
BASE='# 术语\n\n总额：计数。\n';INITIAL=BASE.replace('计数。','数值之和。');path='guide.md';(project/path).write_text(BASE)
auth={'source':'controlled-initial-and-sync-public-cli','text':'Accept this exact temporary plan, initial formal candidate and independent later domain; each declared owner applies only its specific approved content, then inspect actual results and close.',
 'effect_kinds':['project_records','knowledge'],'paths':[path]}
def call(action,data=None,method=None,target=None,error=None):
 argv=[sys.executable,'-B',str(package/'runtime/evolve.py'),'--project',str(project),action]
 if target:argv.append(target)
 if method:argv+=['--method',method]
 request={'authorization':auth,'input':data} if data is not None else None
 if request is not None:argv+=['--request','-']
 p=subprocess.run(argv,input=json.dumps(request) if request is not None else None,cwd=lab,capture_output=True,text=True,timeout=20)
 body=json.loads(p.stdout);trace.append({'argv':argv,'request':request,'response':body,'exit_code':p.returncode,'stderr':p.stderr})
 (lab/'commands.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
 if error:assert not body['ok'] and body['error']['code']==error,(error,body)
 else:assert body['ok'] and p.returncode==0,body
 return body['data']
def ref(item):return {k:item[k] for k in ('proposal_id','proposal_version','candidate_digest','expected_digest')}
def observations():return [{'criterion_key':'term','status':'passed','observer':'controlled-actual-content-observer','basis':'Read actual bounded candidate or applied text against its declared meaning; no code-test claim.'}]
def decision(item):return {'proposal':ref(item),'decision':'approved','source':'controlled-specific-formal-approval','text':'Approve this exact candidate, scope and baseline.','reason':'Actual content inspection.'}
def verify(key=None):
 context=call('resume',target=plan['change_id'])['context']
 snapshot=(next(t['workspace_observation'] for t in context['task_contexts'] if t['local_key']==key) if key else context['workspace_observation'])['current']
 change=call('status',target=plan['change_id'])['project']['changes'][0]
 ac=(next(t['definition']['acceptance'] for t in change['tasks'] if t['local_key']==key) if key else [a for t in change['tasks'] for a in t['definition']['acceptance']])
 reviews=[{'axis':axis,'observer':'controlled-actual-document-reviewer','summary':'Inspected real full guide, each declared owner result and document structure.','findings':[],'fingerprint_digest':snapshot['digest']} for axis in ('spec','standards')]
 reviews[0]['acceptance_results']=[{'ac_id':a['id'],'status':'passed','basis':'Actual guide retains this declared formal meaning.'} for a in ac]
 return call('verify',{'change_id':plan['change_id'],**({'task_key':key} if key else {}),'reviews':reviews})
subprocess.run([sys.executable,'-B',str(ROOT/'scripts/build_package.py'),'--out',str(package)],check=True,capture_output=True)
call('init',{})
data={'complexity':'complex','title':'初次基线及独立输入范围','plan':'Init establishes and verifies the initial sum meaning, then sync adds its independent numeric input domain.','completion':'Both actual owner results are accepted.',
 'scope':[path],'required_checks':[],'acceptance':[{'key':'INITIAL','text':'The initial formal term means numeric sum.'},{'key':'DOMAIN','text':'The independent input domain is numeric.'}],
 'spec':{'problem':'No approved formal baseline or input-domain statement.','goals':['Deliver both actual meanings.'],'non_goals':[],'behavior':['Preserve each declared meaning.'],'constraints':['Each owner writes only its approved result.'],'tradeoffs':[],'test_decisions':['Read actual formal content without executable code-test claims.'],'open_questions':[]},'tasks':[]}
for key,owner in [('INITIAL','init'),('DOMAIN','sync')]:
 data['tasks'].append({'local_key':key,'title':key,'completion':data['acceptance'][len(data['tasks'])]['text'],'validation':'Inspect actual guide.','scope':[path],'required_checks':[],
  'responsible_action':owner,'acceptance':[key],'context_paths':[],'exclusions':[],'test_decision_refs':['spec.test_decisions/0'],'dependencies':[] if key=='INITIAL' else [{'upstream_task':'INITIAL','condition_kind':'verification_passed','basis':'The initial meaning requires actual acceptance before domain delivery.'}]})
data['presentation']={'source':'controlled-complete-initial-owner-plan','document':{k:data[k] for k in ('title','plan','completion','scope','acceptance','required_checks','spec','tasks')}}
plan=call('propose',data);tasks=plan['tasks'];start=BASE.encode().index('计数。'.encode())
a=call('init',{'path':path,'content':INITIAL,'expected_digest':hashlib.sha256(BASE.encode()).hexdigest(),'topic':'initial-definition','reason':'Establish the exact first approved formal term.',
 'presentation':{'source':'controlled-full-initial-candidate','text':INITIAL},'acceptance':[{'key':'term','text':'Total means numeric sum.'}],
 'edits':[{'start':start,'end':start+len('计数。'.encode()),'before':'计数。','after':'数值之和。','semantic_target':'definition'}],
 'delivery':{'role':'required','change_id':plan['change_id'],'revision_id':plan['revision_id'],'task_id':tasks[0]['id'],'definition_digest':tasks[0]['definition_digest'],'acceptance_ids':[plan['acceptance'][0]['id']]}},'baseline.propose')
call('sync',{'proposal':ref(a),'observations':observations()},'check')
aa=call('sync',{'decisions':[decision(a)]},'review')['decisions'][0]['decision_event_id']
assert (project/path).read_text()==BASE
call('sync',{'proposal':ref(a),'approved_event_id':aa},'apply',error='KNOWLEDGE_OWNER')
call('init',{'proposal_id':a['proposal_id'],'approval':{**{k:a[k] for k in ('proposal_version','candidate_digest','expected_digest')},'source':'controlled-legacy-inline-attempt','text':'Approve the same exact content.'}},'baseline.apply',error='KNOWLEDGE_APPROVAL')
first=call('init',{'proposal':ref(a),'approved_event_id':aa,'change_id':plan['change_id'],'task_key':'INITIAL'},'baseline.apply')
assert first['overall_verification']=='not_run' and (project/path).read_text()==INITIAL
assert verify('INITIAL')['status']=='passed'
domain='\n仅限数值输入。\n';content=INITIAL+domain
b=call('sync',{'path':path,'content':content,'expected_digest':hashlib.sha256(INITIAL.encode()).hexdigest(),'topic':'numeric-domain','reason':'Add only the independent domain.',
 'presentation':{'source':'controlled-full-domain-candidate','text':content},'acceptance':[{'key':'term','text':'Input domain is numeric.'}],
 'edits':[{'start':len(INITIAL.encode()),'end':len(INITIAL.encode()),'before':'','after':domain,'semantic_target':'domain'}],'dependencies':[ref(a)],
 'delivery':{'role':'required','change_id':plan['change_id'],'revision_id':plan['revision_id'],'task_id':tasks[1]['id'],'definition_digest':tasks[1]['definition_digest'],'acceptance_ids':[plan['acceptance'][1]['id']]}},'propose')
call('sync',{'proposal':ref(b),'observations':observations()},'check')
bb=call('sync',{'batch':[ref(a),ref(b)],'decisions':[decision(b)]},'review')['decisions'][0]['decision_event_id']
package=package.rename(lab/'移动后的 初次文档整包')
call('init',{'proposal':ref(b),'approved_event_id':bb},'baseline.apply',error='KNOWLEDGE_OWNER')
second=call('sync',{'proposal':ref(b),'approved_event_id':bb,'change_id':plan['change_id'],'task_key':'DOMAIN'},'apply')
assert verify('INITIAL')['status']=='passed'
whole=verify();assert whole['status']=='passed'
call('archive',{'change_id':plan['change_id'],'verification_id':whole['verification_id']})
assert (project/path).read_text()==content
before={str(f.relative_to(project)):f.read_bytes() for f in project.rglob('*') if f.is_file()}
view=call('status',target=a['proposal_id'])['project']['knowledge_proposals'][0]
assert view['owner_skill']=='evolve-init' and view['application']['effect_state']['preserved']
assert not view['application']['current_matches'] and before=={str(f.relative_to(project)):f.read_bytes() for f in project.rglob('*') if f.is_file()}
with sqlite3.connect(project/'evolve/history.db') as c:
 assert c.execute('SELECT approved_event_id FROM knowledge_proposals WHERE id=?',(a['proposal_id'],)).fetchone()[0]==aa
 owners=[r[0] for r in c.execute('SELECT r.owner_skill FROM spec_applications a JOIN phase_runs r ON r.id=a.source_run_id ORDER BY a.rowid')]
 assert owners==['evolve-init','evolve-archive']
 assert not c.execute("SELECT id FROM phase_runs WHERE status='started'").fetchall() and not c.execute('SELECT * FROM resource_claims').fetchall()
 assert [r[0] for r in c.execute('SELECT state FROM tasks ORDER BY rowid')]==['done','done']
summary={'passed':True,'content_digest':json.loads((package/'evolve-package.json').read_text())['content_digest'],'commands':len(trace),'actual_application_owners':owners,
 'assertions':['Full two-owner required document plan','Typed initial candidate and actual content check','Central specific decisions do not write the file','Sync cannot apply init candidate','Legacy inline approval cannot downgrade typed candidate',
  'Init actually produces required Task output','Init Task acceptance precedes dependent sync Task','New sync candidate uses actual registered baseline','Shared batch without reapproving initial meaning','Complete package relocation',
  'Init cannot apply sync candidate','Actual init/sync application sources recorded','Narrow initial meaning survives later approved sync patch','Fresh init Task verification remains valid','Whole acceptance precedes archive','Original initial approval preserved','Pure status distinguishes byte match from meaning preservation','No pending run or claim'],
 'limitations':['All semantic observations are controlled fixtures, not native model evidence.','Learn rule owner, external adoption and full IMP-007 acceptance remain pending.']}
(lab/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(lab/'fixture.json').write_text(json.dumps({'unmapped':BASE,'initial':INITIAL,'final':content},ensure_ascii=False,indent=2))
Path('/tmp/evolve-imp007-init-owner-cli-current.json').write_text(json.dumps({'lab':str(lab),'package':str(package),'project':str(project)}))
print(json.dumps({**summary,'lab':str(lab)},ensure_ascii=False))
