"""Public CLI same-file required delivery with recorded batch and exact composition review."""
from pathlib import Path
import hashlib,json,sqlite3,subprocess,sys,tempfile

ROOT=Path('/Users/liufukang/Workplace/spec-driven');lab=Path(tempfile.mkdtemp(prefix='evolve-imp007-patch-cli-')).resolve()
package=lab/'同文件 完整包';project=lab/'同文件 文档项目';project.mkdir();trace=[]
BASE='# 术语\n\n总额：计数。\n';path='evolve/terms.md'
auth={'source':'controlled-approved-patch-cli','text':'Review this exact two-task temporary formal plan and both exact patches; accept their unchanged scopes, apply in verified order and inspect actual composed text.',
 'effect_kinds':['project_records','knowledge'],'paths':[path]}
def call(action,data=None,method=None,target=None,error=None):
 argv=[sys.executable,'-B',str(package/'runtime/evolve.py'),'--project',str(project),action]
 if target:argv.append(target)
 if method:argv+=['--method',method]
 request={'authorization':auth,'input':data} if data is not None else None
 if request is not None:argv+=['--request','-']
 process=subprocess.run(argv,input=json.dumps(request) if request is not None else None,cwd=lab,text=True,capture_output=True,timeout=20)
 result=json.loads(process.stdout);trace.append({'argv':argv,'request':request,'response':result,'exit_code':process.returncode,'stderr':process.stderr})
 (lab/'commands.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
 if error:assert not result['ok'] and result['error']['code']==error,(error,result)
 else:assert result['ok'] and process.returncode==0,result
 return result['data']
def ref(item):return {k:item[k] for k in ('proposal_id','proposal_version','candidate_digest','expected_digest')}
def observation(status='passed'):return [{'criterion_key':'term','status':status,'observer':'controlled-composed-document-observer','basis':'Read actual complete formal text and each declared independent target; no code-test claim.'}]
def verify_task(key=None):
 context=call('resume',target=plan['change_id'])['context'];selected=next((t for t in context['task_contexts'] if t['local_key']==key),None) if key else None
 snapshot=(selected['workspace_observation'] if selected else context['workspace_observation'])['current']
 state=call('status',target=plan['change_id'])['project']['changes'][0]
 ac=(next(t['definition']['acceptance'] for t in state['tasks'] if t['local_key']==key) if key else [a for t in state['tasks'] for a in t['definition']['acceptance']])
 reviews=[{'axis':axis,'observer':'controlled-actual-required-document-reviewer','summary':'Read actual target and independent approved meanings, including document structure.','findings':[],'fingerprint_digest':snapshot['digest']} for axis in ('spec','standards')]
 reviews[0]['acceptance_results']=[{'ac_id':a['id'],'status':'passed','basis':'The actual target retains the declared independent meaning.'} for a in ac]
 return call('verify',{'change_id':plan['change_id'],**({'task_key':key} if key else {}),'reviews':reviews})
subprocess.run([sys.executable,'-B',str(ROOT/'scripts/build_package.py'),'--out',str(package)],check=True,capture_output=True)
call('init',{})
initial=call('init',{'path':path,'content':BASE,'expected_digest':None,'presentation':{'source':'controlled-initial-term','text':BASE}},'baseline.propose')
call('init',{'proposal_id':initial['proposal_id'],'approval':{**{k:initial[k] for k in ('proposal_version','candidate_digest','expected_digest')},'source':'controlled-exact-baseline','text':'Approve this exact baseline.'}},'baseline.apply')
data={'complexity':'complex','title':'正式术语与适用范围','plan':'Apply the definition first, verify it, then add the independently approved numeric input domain.','completion':'Both required meanings are actually delivered and accepted.',
 'scope':[path],'required_checks':[],'acceptance':[{'key':'A','text':'Total is numeric sum.'},{'key':'B','text':'Input domain is numeric.'}],
 'spec':{'problem':'Both formal meanings are incomplete.','goals':['Deliver both meanings.'],'non_goals':[],'behavior':['Preserve each approved scope.'],'constraints':['One actual formal file.'],'tradeoffs':[],'test_decisions':['Inspect actual content; no executable code test is needed.'],'open_questions':[]},'tasks':[]}
for key in ('A','B'):
 data['tasks'].append({'local_key':key,'title':key,'completion':data['acceptance'][len(data['tasks'])]['text'],'validation':'Read actual formal content.','scope':[path],'required_checks':[],
  'responsible_action':'sync','acceptance':[key],'context_paths':[],'exclusions':[],'test_decision_refs':['spec.test_decisions/0'],'dependencies':[] if key=='A' else [{'upstream_task':'A','condition_kind':'verification_passed','basis':'The actual definition must pass before domain delivery.'}]})
data['presentation']={'source':'controlled-complete-presented-plan','document':{k:data[k] for k in ('title','plan','completion','scope','acceptance','required_checks','spec','tasks')}}
plan=call('propose',data);items=[]
for index,(before,after,target) in enumerate([('计数。','数值之和。','definition'),('','\n仅限数值输入。\n','domain')]):
 base=BASE.encode();start=base.index(before.encode()) if before else len(base);content=(base[:start]+after.encode()+base[start+len(before.encode()):]).decode();task=plan['tasks'][index]
 item=call('sync',{'path':path,'expected_digest':hashlib.sha256(base).hexdigest(),'content':content,'topic':target,'reason':'Independent exact formal scope.',
  'presentation':{'source':'controlled-full-patch-presentation','text':content},'acceptance':[{'key':'term','text':'Exact declared semantic target is satisfied.'}],
  'edits':[{'start':start,'end':start+len(before.encode()),'before':before,'after':after,'semantic_target':target}],
  'delivery':{'role':'required','change_id':plan['change_id'],'revision_id':plan['revision_id'],'task_id':task['id'],'definition_digest':task['definition_digest'],'acceptance_ids':[plan['acceptance'][index]['id']]}},'propose');items.append(item)
for item in items:call('sync',{'proposal':ref(item),'observations':observation()},'check')
review=call('sync',{'decisions':[{'proposal':ref(item),'decision':'approved','source':'controlled-exact-batch-approval','text':'Approve this exact candidate scope and original base.','reason':'Actual independent scope review.'} for item in items]},'review')
approvals=[d['decision_event_id'] for d in review['decisions']]
a=call('sync',{'proposal':ref(items[0]),'approved_event_id':approvals[0],'change_id':plan['change_id'],'task_key':'A'},'apply')
assert verify_task('A')['status']=='passed'
package=package.rename(lab/'移动后的 同文件完整包')
effective=call('status',target=items[1]['proposal_id'])['project']['knowledge_proposals'][0]['effective_candidate']
call('sync',{'proposal':ref(items[1]),'approved_event_id':approvals[1],'change_id':plan['change_id'],'task_key':'B'},'apply',error='KNOWLEDGE_COMPOSITION')
composition={'base_digest':effective['base_digest'],'result_digest':effective['result_digest'],'semantic_targets':effective['semantic_targets'],'status':'passed','observer':'controlled-composed-content-reviewer','basis':'Read exact full composition, retained definition and the independent new input domain.'}
b=call('sync',{'proposal':ref(items[1]),'approved_event_id':approvals[1],'change_id':plan['change_id'],'task_key':'B','composition_review':composition},'apply')
assert b['effect']['chain']==[a['application_id']]
assert (project/path).read_text()=='# 术语\n\n总额：数值之和。\n\n仅限数值输入。\n'
assert verify_task('A')['status']=='passed'
whole=verify_task();assert whole['status']=='passed'
call('verify',{'application_id':a['application_id'],'observations':observation('failed')},'knowledge')
call('archive',{'change_id':plan['change_id'],'verification_id':whole['verification_id']},error='KNOWLEDGE_VERIFICATION')
whole2=verify_task();assert whole2['status']=='passed'
call('archive',{'change_id':plan['change_id'],'verification_id':whole2['verification_id']})
before={str(f.relative_to(project)):f.read_bytes() for f in project.rglob('*') if f.is_file()}
state=call('status',target=items[0]['proposal_id'])['project']['knowledge_proposals'][0]
assert state['application']['effect_state']['preserved'] and not state['application']['current_matches']
assert before=={str(f.relative_to(project)):f.read_bytes() for f in project.rglob('*') if f.is_file()}
with sqlite3.connect(project/'evolve/history.db') as c:
 assert c.execute('SELECT COUNT(*) FROM spec_applications').fetchone()[0]==2
 assert [r[0] for r in c.execute('SELECT approved_event_id FROM knowledge_proposals WHERE owner_skill=? ORDER BY rowid',('evolve-archive',))]==approvals
 assert not c.execute("SELECT id FROM phase_runs WHERE status='started'").fetchall()
 assert not c.execute('SELECT * FROM resource_claims').fetchall()
summary={'passed':True,'content_digest':json.loads((package/'evolve-package.json').read_text())['content_digest'],'commands':len(trace),
 'assertions':['Actual full presented two-Task plan and precise independently approved patches','Same original base retained','Source-bound batch membership without extra approval','First actual Task acceptance precedes dependent Task',
  'Complete package relocation','Missing composition observation blocks before write','Exact actual composition retains both meanings','Application actual base/result differ from original candidate without mutating it',
  'Fresh upstream Task verification remains applicable across approved chain','Latest failure on first same-file effect blocks old whole pass','Fresh whole verification and archive','One actual application per delta','Original approvals unchanged','Pure status distinguishes whole-byte match from effect preservation','No pending run or claim'],
 'limitations':['Content and semantic observations are controlled fixtures, not native model review.','Multiple owners and external adoption remain pending.']}
(lab/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(lab/'fixture.json').write_text(json.dumps({'base':BASE,'expected':(project/path).read_text()},ensure_ascii=False,indent=2))
Path('/tmp/evolve-imp007-patch-cli-current.json').write_text(json.dumps({'lab':str(lab),'package':str(package),'project':str(project)}))
print(json.dumps({**summary,'lab':str(lab)},ensure_ascii=False))
