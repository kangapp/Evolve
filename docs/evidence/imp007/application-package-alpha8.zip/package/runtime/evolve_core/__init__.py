"""Shared, host-independent Evolve runtime."""
VERSION = "0.1.0-alpha.8"
PROTOCOL_VERSION = 6
SCHEMA_VERSION = 2
DESIGN_BASELINE = "0.6.2"
