# Frozen IMP-007 controller

Extract the separately preserved external-package-alpha12.zip beside this archive. Run controller/model_acceptance.py with --package package --knowledge --host codex --preflight-only (or Claude with --claude-model MiniMax-M3.1-Flash). Preparation uses --prepare-only and a new --out directory. Actual model dispatch requires the real human authorization and exact host scope digest from the reviewed plan. Parent test sources are audit copies; run their tests in the original engineering checkout. This archive does not contain personal host profiles or credentials.
