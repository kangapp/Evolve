"""Public CLI only: actual work evidence, same-base sync/Learn Tasks and counterexample."""
from pathlib import Path
import hashlib,json,sqlite3,subprocess,sys,tempfile

ROOT=Path('/Users/liufukang/Workplace/spec-driven');lab=Path(tempfile.mkdtemp(prefix='evolve-imp007-rule-owner-cli-')).resolve()
package=lab/'完整 规则包';project=lab/'规则 临时项目';project.mkdir();trace=[]
BASE='# 术语\n\n总额：计数。\n';RULE='\n核对整数求和时使用独立字面量样例，注明观察范围。\n';path='terms.md'
TEST='import unittest\nfrom total import total\nclass Totals(unittest.TestCase):\n    def test_literals(self):\n        self.assertEqual(total([2,3]),5)\n        self.assertEqual(total([]),0)\n        self.assertEqual(total([-2,3]),1)\n'
(project/'total.py').write_text('def total(values):\n    return len(values)\n');(project/'test_total.py').write_text(TEST);(project/path).write_text(BASE)
auth={'source':'controlled-rule-owner-public-cli','text':'Repair only this temporary sum function, run its unchanged literal tests, record bounded experience and the exact two-owner formal plan. Approve each exact candidate below, inspect composition and actual outputs, then record actual later adoption and bounded feedback.',
      'effect_kinds':['project_records','business_files','checks','knowledge'],'paths':['total.py',path]}
def hash(body):return hashlib.sha256(body).hexdigest()
def call(action,data=None,method=None,target=None,error=None):
    argv=[sys.executable,'-B',str(package/'runtime/evolve.py'),'--project',str(project),action]
    if target:argv.append(target)
    if method:argv+=['--method',method]
    request={'authorization':auth,'input':data} if data is not None else None
    if request is not None:argv+=['--request','-']
    p=subprocess.run(argv,input=json.dumps(request) if request is not None else None,cwd=lab,capture_output=True,text=True,timeout=25)
    body=json.loads(p.stdout);trace.append({'argv':argv,'request':request,'response':body,'exit_code':p.returncode,'stderr':p.stderr})
    (lab/'commands.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
    if error:assert not body['ok'] and body['error']['code']==error,(error,body)
    else:assert body['ok'] and p.returncode==0,body
    return body['data']
def reference(item):return {k:item[k] for k in ('proposal_id','proposal_version','candidate_digest','expected_digest')}
def source(item):
    with sqlite3.connect(project/'evolve/history.db') as c:
        row=c.execute('SELECT result_digest FROM phase_runs WHERE id=?',(item['run_id'],)).fetchone()
        evidence=[r[0] for r in c.execute('SELECT id FROM evidence WHERE source_run_id=?',(item['run_id'],))]
    return {'run_id':item['run_id'],'result_digest':row[0],'evidence_ids':evidence}
def business_plan(title):
    text='Return the sum of integer values using unchanged independent literal examples.'
    return call('propose',{'title':title,'plan':text,'completion':'The declared three literal checks pass.','scope':['total.py'],'required_checks':['unit'],
        'acceptance':['The three independent literal sums pass.'],'context_paths':['test_total.py'],'presentation':{'source':'controlled-complete-business-plan','text':text}})
def implement(plan,text):
    return call('apply',{'change_id':plan['change_id'],'files':[{'path':'total.py','expected_digest':hash((project/'total.py').read_bytes()),'content':text}]})
def observations():return [{'criterion_key':'term','status':'passed','observer':'controlled-actual-full-text-reader','basis':'Read exact current candidate or applied text and its declared scoped meaning, with actual evidence limitations.'}]
def verify(plan,key=None):
    context=call('resume',target=plan['change_id'])['context']
    snapshot=(next(t['workspace_observation'] for t in context['task_contexts'] if t['local_key']==key) if key else context['workspace_observation'])['current']
    change=call('status',target=plan['change_id'])['project']['changes'][0]
    ac=(next(t['definition']['acceptance'] for t in change['tasks'] if t['local_key']==key) if key else [a for t in change['tasks'] for a in t['definition']['acceptance']])
    reviews=[{'axis':axis,'observer':'controlled-actual-document-reviewer','summary':'Read actual complete document and each owner result.','findings':[],'fingerprint_digest':snapshot['digest']} for axis in ('spec','standards')]
    reviews[0]['acceptance_results']=[{'ac_id':a['id'],'status':'passed','basis':'Actual full document retains this specifically declared meaning.'} for a in ac]
    return call('verify',{'change_id':plan['change_id'],**({'task_key':key} if key else {}),'reviews':reviews})
subprocess.run([sys.executable,'-B',str(ROOT/'scripts/build_package.py'),'--out',str(package)],check=True,capture_output=True)
call('init',{'checks':[{'id':'unit','argv':[sys.executable,'-B','-m','unittest','test_total','-v'],'cwd':'.','timeout':10}]})
work=business_plan('真实经验来源');failed=implement(work,'def total(values):\n    return 0\n');assert failed['outcome']=='checks_not_passed'
passed=implement(work,'def total(values):\n    return sum(values)\n');assert passed['outcome']=='implemented'
record=call('learn',{'experience':{'topic':'Arithmetic literal review','problem':'Observed count or zero results disagree with independent literal sums.',
    'cause':{'statement':'Actual fixture implementations count or return zero instead of summing.','confidence':'observed'},
    'advice':'Use independent literal examples and state the bounded review scope.','applicability':'Local integer sum review.','version_context':'Controlled local Python fixture.',
    'observer':'controlled-source-and-actual-test-reader','scope':['local integer arithmetic'],'exclusions':['Not proof for every type or input.'],'tags':['arithmetic'],
    'limitations':['Actual evidence covers exactly three independent literal examples.']},'sources':[source(failed),source(passed)]},'record')
entry=call('learn',method='search',target='arithmetic')['results'][0]
initial=call('init',{'path':path,'expected_digest':hash(BASE.encode()),'content':BASE,'presentation':{'source':'controlled-exact-existing-document','text':BASE}},'baseline.propose')
call('init',{'proposal_id':initial['proposal_id'],'approval':{**{k:initial[k] for k in ('proposal_version','candidate_digest','expected_digest')},'source':'controlled-specific-initial-approval','text':'Approve this exact initial document.'}},'baseline.apply')
data={'complexity':'complex','title':'正式术语与有证据规则','plan':'Sync defines numeric sum, then Learn delivers its independently scoped literal-review practice.','completion':'Both actual meanings are accepted.',
      'scope':[path],'required_checks':[],'acceptance':[{'key':'DOC','text':'Total means numeric sum.'},{'key':'RULE','text':'Rule states bounded independent literal review.'}],
      'spec':{'problem':'Formal term and scoped review practice need correction.','goals':['Deliver both actual meanings.'],'non_goals':[],'behavior':['Preserve each approved meaning.'],'constraints':['Only specific approval establishes authority.'],'tradeoffs':[],
              'test_decisions':['Read actual document and retained prior work evidence.'],'open_questions':[]},'tasks':[]}
for key,owner in [('DOC','sync'),('RULE','learn')]:
    data['tasks'].append({'local_key':key,'title':key,'completion':data['acceptance'][len(data['tasks'])]['text'],'validation':'Read actual full document.','scope':[path],'required_checks':[],'responsible_action':owner,
        'acceptance':[key],'context_paths':[],'exclusions':[],'test_decision_refs':['spec.test_decisions/0'],'dependencies':[] if key=='DOC' else [{'upstream_task':'DOC','condition_kind':'verification_passed','basis':'Actual sum meaning must be accepted before rule delivery.'}]})
data['presentation']={'source':'controlled-complete-same-base-owner-plan','document':{k:data[k] for k in ('title','plan','completion','scope','required_checks','acceptance','spec','tasks')}}
plan=call('propose',data)
def candidate(content,topic,index,edit):
    return {'path':path,'expected_digest':hash(BASE.encode()),'content':content,'presentation':{'source':'controlled-full-candidate','text':content},'topic':topic,'reason':'Deliver only this specifically declared formal meaning.',
        'acceptance':[{'key':'term','text':plan['acceptance'][index]['text']}],'edits':[edit],
        'delivery':{'role':'required','change_id':plan['change_id'],'revision_id':plan['revision_id'],'task_id':plan['tasks'][index]['id'],'definition_digest':plan['tasks'][index]['definition_digest'],'acceptance_ids':[plan['acceptance'][index]['id']]}}
start=BASE.encode().index('计数。'.encode())
a=call('sync',candidate(BASE.replace('计数。','数值之和。'),'sum-definition',0,{'start':start,'end':start+len('计数。'.encode()),'before':'计数。','after':'数值之和。','semantic_target':'sum-definition'}),'propose')
bdata=candidate(BASE+RULE,'literal-review-rule',1,{'start':len(BASE.encode()),'end':len(BASE.encode()),'before':'','after':RULE,'semantic_target':'literal-review-rule'})
bdata.update(stage='propose',rule_scope=['local integer arithmetic review'],rule_sources=[{'experience_ref':entry['experience_ref'],'state_ref':entry['state_ref'],'counterexamples':[],
    'basis':'Inspect actual original failed/passed literal checks and explicit scope limitations.'}])
b=call('learn',bdata,'promote');assert (project/path).read_text()==BASE
batch=[reference(a),reference(b)]
for item in (a,b):call('sync',{'proposal':reference(item),'batch':batch,'observations':observations()},'check')
decisions=call('sync',{'batch':batch,'decisions':[{'proposal':reference(item),'decision':'approved','source':'controlled-specific-two-owner-approval','text':'Approve this exact scoped candidate and baseline.','reason':'Actual full content and source inspection.'} for item in (a,b)]},'review')['decisions']
aa,bb=[d['decision_event_id'] for d in decisions]
call('sync',{'proposal':reference(b),'approved_event_id':bb},'apply',error='KNOWLEDGE_OWNER')
call('learn',{'stage':'apply','proposal':reference(b),'approved_event_id':bb,'change_id':plan['change_id'],'task_key':'RULE'},'promote',error='DEPENDENCY_NOT_READY')
call('sync',{'proposal':reference(a),'approved_event_id':aa,'change_id':plan['change_id'],'task_key':'DOC'},'apply');assert verify(plan,'DOC')['status']=='passed'
package=package.rename(lab/'移动后的 完整规则包')
effect=call('status',target=b['proposal_id'])['project']['knowledge_proposals'][0]['effective_candidate']
call('learn',{'stage':'apply','proposal':reference(b),'approved_event_id':bb,'change_id':plan['change_id'],'task_key':'RULE'},'promote',error='KNOWLEDGE_COMPOSITION')
composition={k:effect[k] for k in ('base_digest','result_digest','semantic_targets')};composition.update(status='passed',observer='controlled-composed-content-reader',basis='Read actual numeric-sum meaning and independent bounded review practice together.')
actual=call('learn',{'stage':'apply','proposal':reference(b),'approved_event_id':bb,'change_id':plan['change_id'],'task_key':'RULE','composition_review':composition},'promote')
assert verify(plan,'DOC')['status']=='passed';whole=verify(plan);assert whole['status']=='passed'
assert call('archive',{'change_id':plan['change_id'],'verification_id':whole['verification_id']})['outcome']=='archived'
local=call('verify',{'application_id':actual['application_id'],'observations':observations()},'knowledge');assert local['status']=='passed'
assert call('learn',method='search',target='arithmetic')['results'][0]['state']=='candidate'
final=(project/path).read_bytes();assert final==(BASE.replace('计数。','数值之和。')+RULE).encode()
second=business_plan('后续采用与实际失败');found=call('learn',method='search',target='arithmetic')
decision=call('learn',{'kind':'decision','experience_ref':entry['experience_ref'],'search_ref':found['search_ref'],'decision':'adopted',
    **{k:second[k] for k in ('change_id','revision_id','definition_digest')},'observed_files':{'total.py':hash((project/'total.py').read_bytes())},
    'applicability_basis':'Same integer sum function and unchanged literal tests.','limitations':['Adoption alone is not benefit or formal approval.']},'review')
later=implement(second,'def total(values):\n    return len(values)\n');assert later['outcome']=='checks_not_passed'
call('learn',{'kind':'feedback','decision_ref':{k:source(decision)[k] for k in ('run_id','result_digest')},'outcome':'counterexample','result_source':source(later),
    'basis':'Actual later literal checks still fail after the recorded adoption; the review practice did not establish correctness.','limitations':['Bounded controlled feedback, not a universal causal claim.']},'review')
assert implement(second,'def total(values):\n    return sum(values)\n')['outcome']=='implemented'
after=call('status',target=b['proposal_id'])['project'];assert after['knowledge_proposals'][0]['rule_state']['applicability']=='needs_review'
assert call('verify',{'application_id':actual['application_id'],'observations':observations()},'knowledge')['status']=='blocked'
assert (project/path).read_bytes()==final and (project/'test_total.py').read_text()==TEST
with sqlite3.connect(project/'evolve/history.db') as c:
    assert c.execute('SELECT approved_event_id FROM knowledge_proposals WHERE id=?',(a['proposal_id'],)).fetchone()[0]==aa
    assert c.execute('SELECT status FROM verifications WHERE id=?',(local['verification_id'],)).fetchone()[0]=='passed'
    assert c.execute('SELECT state FROM changes WHERE id=?',(plan['change_id'],)).fetchone()[0]=='archived'
    assert c.execute('SELECT count(*) FROM rule_bindings').fetchone()[0]==1
    assert c.execute("SELECT count(*) FROM phase_runs WHERE status='started'").fetchone()[0]==0
    assert c.execute('SELECT count(*) FROM resource_claims').fetchone()[0]==0
summary={'passed':True,'content_digest':json.loads((package/'evolve-package.json').read_text())['content_digest'],'commands':len(trace),
    'assertions':['Actual failed/passed commands produce retained work evidence','Experience remains candidate and not authority','Exact original formal baseline','Complete required sync/Learn plan',
      'Both owner candidates use the same original bytes','Candidate/check/decision do not write files','Wrong writer refused','Required rule dependency blocks early application','Original specific approvals retained',
      'Actual source-bound same-file composition required','Complete package relocation','Actual Learn application and rule binding','Fresh first Task acceptance survives preserved scope','Whole verification precedes archive',
      'Independent actual rule target acceptance','Later actual adoption and failed command evidence','Counterexample flags actual rule and blocks new target pass','Old pass and archive remain unchanged',
      'Formal file and independent tests preserved','No pending run or claim'],
    'limitations':['All semantic observations and feedback are explicit controlled fixtures, not native model evidence.','IMP-010 end-to-end counterexample resolution/check automation is not claimed.','External adoption and full IMP-007 native acceptance remain pending.']}
(lab/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(lab/'fixture.json').write_text(json.dumps({'base':BASE,'rule':RULE,'final':final.decode(),'test':TEST},ensure_ascii=False,indent=2))
Path('/tmp/evolve-imp007-rule-owner-cli-current.json').write_text(json.dumps({'lab':str(lab),'package':str(package),'project':str(project)}))
print(json.dumps({**summary,'lab':str(lab)},ensure_ascii=False))
