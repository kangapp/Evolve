# Evolve

面向个人开发者与 AI 的单项目工作流插件，连接需求、实施、验证、项目知识与跨会话续接。设计基线 0.6.2；插件开发版本 0.1.0-alpha.11。



当前提供小修改闭环、初次基线批准、只读诊断、基础本地恢复、独立调查、正常暂停、只读续接及项目经验生产／消费。复杂 spec、依赖任务实施、预重构前后证明和 REV 已接通。alpha.11 已接通正式文档候选、逐项审阅、init／sync／learn 实际应用、必需文档任务、应用后内容验收及同文件批准差异链；初次文档、规格修订和有来源规则已沿共同协议交付，sync／learn 同文件独立差异可沿真实批准链应用；外部版本采纳、经验转检查的完整流程与完整档案恢复仍未完成。IMP-006 冻结 alpha.6 包的 Codex 七场景通过，Claude 权限失败已停止，双宿主门槛仍未通过。实际方法以 status 返回为准。

需要 Python 3.11+；宿主支持版本在[安装说明](docs/installation.md)列出。当前为本地／私有分发，公开许可证待定，见 [LICENSE](LICENSE)。

## 快速检查

从工程根构建独立包，输出目录需不存在：

```bash
python3 scripts/build_package.py --out /tmp/evolve-package
python3 /tmp/evolve-package/runtime/evolve.py --project /path/to/your/project status
python3 /tmp/evolve-package/runtime/evolve.py --project /path/to/your/project maintain --method doctor
```

将 `/path/to/your/project` 替换为现有目标项目目录。未接入时返回 data.project.state=not_connected，不创建项目文件。包的安装、宿主启用与项目 init 分别进行。

在宿主中可直接表达“接入这个项目，给出总计错误的短方案，按已确认范围修复并完成验证”。AI 负责准备授权来源和工具请求；你阅读方案、实际结果及必要确认点。具体限制和第一个任务见[使用说明](docs/usage.md)。

按[分宿主安装说明](docs/installation.md)安装完整包；使用入口和限制见[使用说明](docs/usage.md)，问题见[排错说明](docs/troubleshooting.md)。`/evolve <动作>` 是逻辑形式，真实宿主入口需按对应说明，不能假定已注册同名全局命令。


