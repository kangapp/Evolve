---
name: evolve-archive
description: 封存 Evolve 成果，或保存、检查与审阅正式项目知识候选时使用。
---

归属 archive、sync。先核对必需成果和验收，封存完成事实与正式知识应用分别表达。archive 不隐式批准知识；必需文档尚未应用不能完成，附带知识可延期。

保存、检查或集中审阅正式知识候选时，读取[正式知识候选](../../shared/knowledge-candidates.md)，保存具体版本并按实际用户决定登记；approved 与实际应用分别表达。

复杂工作封存前按[复杂规格与任务](../../shared/structured-plans.md)核对全部任务及整项 VER，任务验收引用不能替代它。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-archive`，动作必须属于本 Skill。用户不需要填写内部编号。
