"""Versioned formal-content candidates; review facts are separate from file application."""
import json
from pathlib import Path

from .continuation import sealed_result
from .errors import EvolveError
from .knowledge import baseline_path
from .package import canonical, digest
from .requests import normalize, require_effect
from .store import Store, identifier, now
from .structured import text
from .work import claim_resources, gate_identity
from .workspace import current_digest, writer_lock

FORMAT = 'knowledge-proposal-v1'


def metadata(proposal):
    if proposal['owner_skill'] != 'evolve-archive' or proposal['target_kind'] != 'spec':
        return None
    value = json.loads(proposal['source_json'])
    return value if isinstance(value, dict) and value.get('format') == FORMAT else None


def reference(proposal):
    return {'proposal_id': proposal['id'], 'proposal_version': proposal['version'],
            'candidate_digest': proposal['candidate_digest'], 'expected_digest': proposal['expected_digest']}


def bound_proposal(store, value):
    if not isinstance(value, dict):
        raise EvolveError('KNOWLEDGE_PROPOSAL', 'Identify the exact presented proposal version and baseline')
    proposal = store.one('SELECT * FROM knowledge_proposals WHERE id=?', (value.get('proposal_id'),))
    if not proposal or metadata(proposal) is None or proposal['owner_skill'] != 'evolve-archive':
        raise EvolveError('KNOWLEDGE_OWNER', 'This path handles sync-owned formal-content candidates')
    if any(value.get(key) != expected for key, expected in reference(proposal).items()):
        raise EvolveError('KNOWLEDGE_VERSION', 'Prepared candidate reference changed; review its actual version', exit_code=3)
    return proposal


def source_facts(connection, run_id):
    row = connection.execute('SELECT * FROM phase_runs WHERE id=?', (run_id,)).fetchone()
    if not row or row['action'] != 'sync' or row['status'] == 'started':
        return None
    _, request, result = sealed_result(connection, {'run_id': run_id, 'result_digest': row['result_digest']})
    meta = dict(connection.execute('SELECT key,value FROM project_meta'))
    if request['project_id'] != meta['project_id'] or row['workspace_epoch'] != meta['workspace_epoch']:
        return None
    if row['status'] == 'interrupted':
        recovery = connection.execute("SELECT * FROM phase_runs WHERE id=? AND action='maintain' AND method='recover' AND status='completed'",
            (result.get('finalized_by'),)).fetchone()
        if not recovery:
            return None
        _, _, facts = sealed_result(connection, {'run_id': recovery['id'], 'result_digest': recovery['result_digest']})
        if (result.get('outcome') != 'reconciled_committed_metadata' or facts.get('original_run_id') != run_id
                or not facts.get('original_facts_committed') or facts.get('business_commands_run') is not False):
            return None
        result = result.get('saved_operation_result', {})
    elif row['status'] != 'completed':
        return None
    operation = connection.execute("SELECT result_json FROM operations WHERE run_id=? AND state='committed' AND effect_kind='project_records'", (run_id,)).fetchone()
    if not operation:
        return None
    saved = json.loads(operation[0])
    if any(result.get(key) != value for key, value in saved.items()):
        return None
    if not any(json.loads(event[0]).get('result_digest') == digest(canonical(saved)) for event in connection.execute(
            "SELECT payload_json FROM events WHERE run_id=? AND kind='knowledge_metadata_committed'", (run_id,))):
        return None
    return saved


def latest_check(connection, proposal):
    for event in connection.execute("SELECT run_id,payload_json FROM events WHERE kind='knowledge_candidate_checked' ORDER BY rowid DESC"):
        value = json.loads(event['payload_json'])
        if value.get('proposal_id') == proposal['id']:
            facts = source_facts(connection, event['run_id'])
            return {'run_id': event['run_id'], 'recorded_status': value['status'],
                    'source_pending': facts is None or any(facts.get(key) != value.get(key) for key in ('proposal_id', 'status', 'evidence_ids'))
                        or facts.get('subject_kind') != 'candidate', 'evidence_ids': value['evidence_ids']}
    return None


def require_current(store, proposal):
    if proposal['state'] in ('superseded', 'rejected') or proposal['applied_operation_id'] is not None:
        raise EvolveError('KNOWLEDGE_STATE', 'Review the current unapplied candidate; history is retained', exit_code=3)
    if source_facts(store.connection, proposal['created_run_id']) is None:
        raise EvolveError('KNOWLEDGE_PENDING', 'Candidate source needs safe finalization or metadata recovery', exit_code=4)
    if current_digest(baseline_path(store.root, proposal['target_path'])) != proposal['expected_digest']:
        raise EvolveError('FILE_CONFLICT', 'Formal target changed after the candidate was presented', exit_code=3)


def _record(root, payload, method, operation):
    root = Path(root).resolve(); request = normalize(payload); require_effect(request, 'project_records')
    store, run_id, operation_id = None, None, identifier()
    try:
        with writer_lock(root) as generation:
            store = Store(root)
            run_id, previous = store.start(request, action='sync', method=method, owner='evolve-archive')
            if previous is not None:
                return previous
            claim_resources(store, run_id, operation_id, generation, None, [], 'project_records')
            gate_identity(store, request, run_id)
            with store.transaction() as connection:
                result = operation(store, request['input'], run_id)
                connection.execute("UPDATE operations SET state='committed',result_json=? WHERE id=?", (canonical(result).decode(), operation_id))
                connection.execute('DELETE FROM resource_claims WHERE operation_id=?', (operation_id,))
                store.event(run_id, 'knowledge_metadata_committed', {'method': method, 'result_digest': digest(canonical(result))})
            return store.finish(run_id, {'committed': True, 'operation_id': operation_id, **result})
    except EvolveError as error:
        if store is not None and run_id is not None:
            if not store.run_started(run_id):
                error.committed = True
                raise
            with writer_lock(root):
                with store.transaction() as connection:
                    connection.execute("UPDATE operations SET state='failed' WHERE id=? AND state!='committed'", (operation_id,))
                    connection.execute('DELETE FROM resource_claims WHERE operation_id=?', (operation_id,))
                store.finish(run_id, {'committed': True, 'outcome': 'blocked', 'message': str(error)}, status='blocked')
                error.committed = True
        raise
    finally:
        if store is not None:
            store.close()


def _propose(store, data, run_id):
    if any(key in data for key in ('delivery', 'edits', 'dependencies', 'rule_sources')):
        raise EvolveError('UNAVAILABLE', 'Required document delivery and chained application need the remaining knowledge workflow')
    for field in ('topic', 'reason', 'content'):
        text(data.get(field), field)
    if 'expected_digest' not in data:
        raise EvolveError('INPUT', 'Candidate requires its explicit formal target baseline')
    presentation = data.get('presentation')
    if not isinstance(presentation, dict) or presentation.get('text') != data['content'] or not presentation.get('source'):
        raise EvolveError('PRESENTATION', 'Persist the full candidate actually presented and its source')
    criteria = data.get('acceptance')
    if (not isinstance(criteria, list) or not criteria or any(not isinstance(c, dict) for c in criteria)
            or any(not isinstance(c.get('key'), str) or not c['key'].strip() or not isinstance(c.get('text'), str) or not c['text'].strip() for c in criteria)
            or len({c['key'] for c in criteria}) != len(criteria)):
        raise EvolveError('INPUT', 'Content criteria require distinct local keys and actual reviewable text')
    path = baseline_path(store.root, data.get('path'))
    if current_digest(path) != data['expected_digest']:
        raise EvolveError('FILE_CONFLICT', 'Formal target changed before candidate registration', exit_code=3)
    formal = store.one("SELECT a.current_version,v.blob_digest FROM artifacts a JOIN artifact_versions v ON v.id=a.current_version WHERE a.path=? AND a.kind='knowledge'", (data['path'],))
    if not formal:
        raise EvolveError('KNOWLEDGE_OWNER', 'Initial formal baselines belong to init, not sync')
    if formal['blob_digest'] != data['expected_digest']:
        raise EvolveError('KNOWLEDGE_EXTERNAL', 'Inspect the external formal edit and form an explicit adoption candidate; it is not the approved baseline', exit_code=3)
    if digest(data['content'].encode()) == data['expected_digest']:
        raise EvolveError('KNOWLEDGE_NO_CHANGE', 'Candidate must describe an actual formal-content change')
    candidate_digest = digest(data['content'].encode())
    rows = [row for row in store.connection.execute(
        "SELECT * FROM knowledge_proposals WHERE target_path=? AND owner_skill='evolve-archive' ORDER BY rowid DESC", (data['path'],)) if metadata(row)]
    matched = next((row for row in rows if metadata(row)['topic'] == data['topic'] or row['candidate_digest'] == candidate_digest), None)
    previous = next((row for row in rows if metadata(row)['family_id'] == metadata(matched)['family_id']), None) if matched else None
    old = metadata(previous) if previous else None
    reconsideration = data.get('reconsideration')
    if previous and previous['applied_operation_id'] is None and previous['state'] not in ('rejected', 'superseded'):
        if source_facts(store.connection, previous['created_run_id']) is None:
            raise EvolveError('KNOWLEDGE_PENDING', 'Safely finalize the existing candidate before replacing it', exit_code=4)
        if (previous['candidate_digest'] == digest(data['content'].encode()) and previous['expected_digest'] == data['expected_digest']
                and old['acceptance'] == criteria):
            store.event(run_id, 'knowledge_candidate_context_added', {'proposal_id': previous['id'], 'reason': data['reason'], 'source': presentation['source']})
            return {'outcome': 'proposal_already_present', **reference(previous), 'path': data['path'], 'applied': False}
    decisions = {}
    for event in store.connection.execute("SELECT payload_json FROM events WHERE kind='knowledge_reviewed' ORDER BY rowid"):
        decision = json.loads(event[0])
        decisions[decision['proposal']['proposal_id']] = decision['decision']
    rejected = previous if previous and previous['state'] == 'rejected' else next(
        (row for row in rows if row['candidate_digest'] == candidate_digest and decisions.get(row['id']) == 'rejected'), None)
    if rejected:
        if (not isinstance(reconsideration, dict) or reconsideration.get('proposal_id') != rejected['id']
                or reconsideration.get('proposal_version') != rejected['version']):
            raise EvolveError('KNOWLEDGE_REJECTED', 'A new identity cannot bypass the earlier rejection; preserve explicit reconsideration', exit_code=3)
        for field in ('source', 'text', 'reason'):
            text(reconsideration.get(field), 'reconsideration.' + field)
    proposal_id = identifier(); code = store.number('KP')
    candidate = store.blob(data['content'].encode()); base = store.blob(path.read_bytes())
    if base != data['expected_digest']:
        raise EvolveError('FILE_CONFLICT', 'Formal file changed while its base bytes were being retained', exit_code=3)
    value = {'format': FORMAT, 'code': code, 'family_id': old['family_id'] if old else proposal_id,
             'topic': data['topic'], 'reason': data['reason'], 'acceptance': criteria, 'base_digest': base,
             'formal_version_id': formal['current_version'], 'presentation': presentation,
             'supersedes': previous['id'] if previous else None, 'reconsideration': reconsideration}
    version = previous['version'] + 1 if previous else 1
    if previous and previous['applied_operation_id'] is None:
        store.connection.execute("UPDATE knowledge_proposals SET state='superseded' WHERE id=?", (previous['id'],))
        store.event(run_id, 'knowledge_candidate_superseded', {'proposal_id': previous['id'], 'successor_id': proposal_id, 'reason': data['reason']})
    store.connection.execute('INSERT INTO knowledge_proposals VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
        (proposal_id, version, 'evolve-archive', 'spec', data['path'], base, candidate, canonical(value).decode(), 'proposed', run_id, None, None))
    store.event(run_id, 'knowledge_candidate_presented', {'proposal_id': proposal_id, 'candidate_digest': candidate, 'proposal_version': version})
    return {'outcome': 'knowledge_proposed', 'proposal_id': proposal_id, 'proposal_version': version, 'code': code,
            'candidate_digest': candidate, 'expected_digest': base, 'path': data['path'], 'applied': False,
            'supersedes': previous['id'] if previous else None}


def _check(store, data, run_id):
    proposal = bound_proposal(store, data.get('proposal'))
    require_current(store, proposal)
    criteria = metadata(proposal)['acceptance']; observations = data.get('observations')
    if (not isinstance(observations, list) or any(not isinstance(o, dict) or not isinstance(o.get('criterion_key'), str) for o in observations)
            or len(observations) != len(criteria) or {o.get('criterion_key') for o in observations} != {c['key'] for c in criteria}):
        raise EvolveError('KNOWLEDGE_CHECK', 'Provide actual content observations for every declared criterion')
    evidence_ids = []
    for observation in observations:
        if observation.get('status') not in ('passed', 'failed', 'blocked'):
            raise EvolveError('KNOWLEDGE_CHECK', 'Content observations need explicit passed, failed or blocked status')
        for field in ('observer', 'basis'):
            text(observation.get(field), 'observation.' + field)
        body = {'subject_kind': 'candidate', **reference(proposal), 'observation': observation, 'observed_at': now(),
                'limitation': 'Actual host content review; no applied target or command success is inferred.'}
        evidence_id = identifier(); blob = store.blob(canonical(body))
        store.connection.execute('INSERT INTO evidence VALUES (?,?,?,?,?,?,?,?,?)',
            (evidence_id, run_id, None, 'candidate', observation['observer'], 'candidate-content-review', blob, now(), body['limitation']))
        evidence_ids.append(evidence_id)
    status = 'blocked' if any(o['status'] == 'blocked' for o in observations) else 'failed' if any(o['status'] == 'failed' for o in observations) else 'passed'
    store.event(run_id, 'knowledge_candidate_checked', {'proposal_id': proposal['id'], 'status': status, 'evidence_ids': evidence_ids})
    return {'outcome': 'candidate_checked', 'subject_kind': 'candidate', **reference(proposal), 'status': status, 'evidence_ids': evidence_ids, 'applied': False}


def _review(store, data, run_id):
    decisions = data.get('decisions')
    if not isinstance(decisions, list) or not decisions or any(not isinstance(d, dict) for d in decisions):
        raise EvolveError('KNOWLEDGE_REVIEW', 'Review an explicit nonempty list of candidate decisions')
    seen, results = set(), []
    for decision in decisions:
        proposal = bound_proposal(store, decision.get('proposal'))
        if proposal['id'] in seen:
            raise EvolveError('KNOWLEDGE_REVIEW', 'A batch must decide each candidate only once')
        seen.add(proposal['id'])
        selected = decision.get('decision')
        if selected not in ('approved', 'rejected', 'deferred'):
            raise EvolveError('KNOWLEDGE_REVIEW', 'Decision must be approved, rejected or deferred')
        for field in ('source', 'text', 'reason'):
            text(decision.get(field), 'decision.' + field)
        if proposal['state'] in ('superseded', 'rejected') or proposal['applied_operation_id'] is not None:
            raise EvolveError('KNOWLEDGE_STATE', 'Superseded, rejected or applied versions retain their prior decisions', exit_code=3)
        if source_facts(store.connection, proposal['created_run_id']) is None:
            raise EvolveError('KNOWLEDGE_PENDING', 'Candidate source is not safely finalized', exit_code=4)
        check = latest_check(store.connection, proposal)
        if selected == 'approved':
            require_current(store, proposal)
            if not check or check['source_pending'] or check['recorded_status'] != 'passed':
                raise EvolveError('KNOWLEDGE_CHECK', 'Approval requires the latest safely finalized matching candidate content check', exit_code=3)
        event_id = store.event(run_id, 'knowledge_reviewed', {'proposal': reference(proposal), 'decision': selected,
            'source': decision['source'], 'text': decision['text'], 'reason': decision['reason'], 'candidate_check': check})
        store.connection.execute('UPDATE knowledge_proposals SET state=?,approved_event_id=? WHERE id=?',
            (selected, event_id if selected == 'approved' else proposal['approved_event_id'], proposal['id']))
        results.append({**reference(proposal), 'state': selected, 'decision_event_id': event_id, 'applied': False})
    return {'outcome': 'knowledge_reviewed', 'decisions': results, 'formal_files_written': False}


def propose_knowledge(root, payload):
    return _record(root, payload, 'propose', _propose)


def check_candidate(root, payload):
    return _record(root, payload, 'check', _check)


def review_candidates(root, payload):
    return _record(root, payload, 'review', _review)


def proposal_views(connection, root, target=None):
    result, decisions = [], {}
    for event in connection.execute("SELECT id,run_id,payload_json FROM events WHERE kind='knowledge_reviewed' ORDER BY rowid"):
        value = json.loads(event['payload_json'])
        decisions.setdefault(value['proposal']['proposal_id'], []).append({'event_id': event['id'], 'source_run_id': event['run_id'],
            'source_pending': source_facts(connection, event['run_id']) is None, **value})
    for row in connection.execute('SELECT * FROM knowledge_proposals ORDER BY rowid'):
        value = metadata(row)
        if value is None or (target and target not in (row['id'], value['code'], value['topic'])):
            continue
        check = latest_check(connection, row)
        item = {**reference(row), 'code': value['code'], 'topic': value['topic'], 'owner_skill': row['owner_skill'],
                'path': row['target_path'], 'state': row['state'], 'applied_operation_id': row['applied_operation_id'],
                'supersedes': value['supersedes'], 'latest_decision': decisions.get(row['id'], [None])[-1], 'source_pending': source_facts(connection, row['created_run_id']) is None,
                'latest_candidate_check': check, 'current_matches_baseline': current_digest(baseline_path(root, row['target_path'])) == row['expected_digest']}
        if target:
            item['candidate'] = connection.execute('SELECT content FROM blobs WHERE digest=?', (row['candidate_digest'],)).fetchone()[0].decode()
            item['base'] = connection.execute('SELECT content FROM blobs WHERE digest=?', (value['base_digest'],)).fetchone()[0].decode()
            item['definition'] = value
            item['decisions'] = decisions.get(row['id'], [])
        result.append(item)
    return result
