# 正式知识候选与审阅

alpha.7 当前开放 sync.propose／check／review，只修改项目记录。正式文件写入、必需文档 Task 与应用后验收仍属 IMP-007 后续步骤，sync.apply 继续 UNAVAILABLE。已有初次正式基线仍由 init 负责；候选通过或 approved 不表示文件已应用、任务完成或当前现场已通过。

## 保存具体候选

先展示完整新正文及相对原正式版本的差异，再调用 sync.propose，input 给：

- path：已由 init 登记的正式 Markdown 路径；expected_digest：当前已批准基线的实际摘要。
- content：实际呈现的新正文；presentation={source,text}，text 必须逐字等于 content。
- topic、reason：本次主题及改变的实际依据。
- acceptance：非空数组，各项 {key,text} 给独立、具体的内容检查判据。

首次建立正式文件使用 init.baseline.propose／apply。实际文件偏离已批准版本时，先核对外部编辑和正式含义；当前候选保存路径报告 KNOWLEDGE_EXTERNAL，保留现场，不把外部编辑自动登记为正式版本。

同主题／目标的相同候选归并上下文；正文或判据变化生成后继版本，旧全文、检查和决定保留，旧批准不转移。被拒绝的同主题或相同正文需要 reconsideration={proposal_id,proposal_version,source,text,reason}，记录实际新的重新审阅意图；不能仅换标题新建同一被拒内容。工具核对具体身份和正文，语义是否等价仍由实际审阅说明。

返回 proposal_id、proposal_version、candidate_digest、expected_digest。后续统一将这四项作为 proposal 引用，保持实际呈现版本，不在重试时改成当前值。

## 内容检查与逐项决定

实际检查新正文与每项 acceptance 后，用 sync.check 保存 proposal 和 observations。每项给 criterion_key、status=passed／failed／blocked、observer、basis；覆盖所有判据。这里只登记实际内容观察，不代运行命令或判断文档语义。subject_kind=candidate，证据不充当应用后的实际目标验收。更新的失败／受阻检查覆盖旧通过对后续批准的适用性。

用户已明确接受、拒绝或延期具体候选后，sync.review.input.decisions 逐项给 {proposal,decision,source,text,reason}，decision=approved／rejected／deferred。一次审阅可以对不同候选给不同决定；每项均保留实际用户依据。approved 需要最新匹配版本的内容检查通过且来源安全收尾，目标基线仍匹配。延期可在完成必要检查后按实际决定批准；被替代或拒绝版本保持原决定，重新考虑沿后继候选继续。

status 全局给 knowledge_proposals 导航；按候选编号、UUID 或唯一主题定位可读 base／candidate 全文、判据、原正式版本、旧决定、最新候选检查及实际基线是否匹配。多个版本同主题时按当前候选编号定位。查询不改文件、状态、检查或批准，source_pending 为 true 时先处理原执行收尾。

请求经标准 JSON 协议发送并保存返回绑定。候选、检查或审阅的元数据已提交后进程异常退出，maintain recover 只核实原提交，不重新分配候选、执行检查或应用文件；随后从安全结束的原记录继续。
