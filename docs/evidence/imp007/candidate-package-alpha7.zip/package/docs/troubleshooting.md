# 诊断与排错

先执行 usage 中的只读 doctor，保留返回的 error.code、包版本和内容摘要。不要把诊断失败后重装当作项目接入或数据恢复。

| 错误 | 含义与下一步 |
|---|---|
| PYTHON_VERSION | 使用 Python 3.11+；插件不会自动安装系统依赖 |
| PACKAGE_INCOMPLETE | 资源缺失／被改或摘要不一致；重新构建／安装完整同版本包 |
| PACKAGE_VERSION | 内核、清单或能力表混用；停止写入，使用完整一致版本 |
| PROJECT_COLLISION | 存在同名 evolve 或 .evolve-local 资料；先核对身份，不覆盖 |
| PROJECT_INCOMPLETE | 配置／库仅有其一；保留现场，不能按新项目重建 |
| PROJECT_CHANGED | 观察期间历史变化；重做只读核查，不使用混合截点 |
| PROJECT_INVALID／PROJECT_IDENTITY | 配置、库或身份异常；只读诊断不修复 |
| SCHEMA_VERSION／CONFIG_VERSION | 当前包不支持该版本；保留数据，不自动迁移或降级 |
| UNKNOWN_ACTION／UNKNOWN_METHOD／OWNER | 动作、方法或负责 Skill 不匹配；按真实能力重试 |
| DUPLICATE_INSTALLATION | 发现同名散装 Skill；核对来源并选择单一渠道，工具不删除已有文件 |
| UNAVAILABLE | 当前版本尚未提供该方法；不是业务通过或资料已保存 |
| CONTINUATION／RUN_RESULT_INVALID | 续接来源未安全结束、结果已变或绑定不符；保留旧结果，重新定位原工作与当前版本；不能用新 ID 绕过来源检查 |
| ANALYSIS_SOURCE_CHANGED／ANALYSIS_SCOPE | 调查实际来源已变或不在声明范围；重新读取并核对实际范围，保留原观察，不将新字节冒充旧来源 |
| ANALYSIS_HEAD／ANALYSIS_RUNNING | 旧调查头已有后继，或前一轮尚未安全结束；读取当前头及实际执行，不按日期猜新主题或覆盖进度 |
| ANALYSIS_INCOMPLETE | 观察已提供但分析没有完整保存；先看 pending_runs、原输入和已存证据，不能补记成功；实际中断由 maintain 收尾 |
| ANALYSIS_PARENT | 原父阶段不再是所见的活动执行、范围不同或授权失效；核实现场后独立调查，不沿过期阶段越界 |
| SYMPTOM_CHANGED／SYMPTOM_REVERIFY_REQUIRED | 修复或验收缺少原症状判据，或替换了原预期／检查；恢复原判据复验，改变验收含义需重新确认 |
| SYMPTOM_LIMITATIONS | 缺 red 或偶发样本不足；记录观察局限，不补造根因、失败次数或问题已消除的结论 |
| REQUEST_REQUIRED／AUTHORIZATION | 写方法需要实际授权来源及输入；用户由 AI 准备请求，不从历史经验推断授权 |
| VERSION／WORKSPACE_EPOCH／DEFINITION | 请求依据已变化；重新核对现场和原请求，不用当前版本替换旧请求绑定 |
| FILE_CONFLICT／WORKSPACE_CHANGED | 原字节或受检现场已变化；保留外部内容，明确登记观察并重新判断证据 |
| FILE_TARGET_CHANGED | 目录别名指向的实际文件与原操作绑定不同；保留 journal 和两处文件，核实原目标。恢复前须恢复可核对的原指向，不能将相同字节视为同一文件 |
| CHECK_CONFIG | 必需检查命令与已批准依据不同；核实配置与方案，不沿用旧通过记录 |
| KNOWLEDGE_VERSION／KNOWLEDGE_CHECK | 候选绑定过时，或缺最新实际内容检查；读取具体版本并保存实际观察，candidate 不代替应用后验收 |
| KNOWLEDGE_REJECTED／KNOWLEDGE_EXTERNAL | 保留原拒绝或外部正式文件变化，登记实际重新审阅意图／提出采用方案；不能换标题绕过或静默覆盖 |
| REVISION_APPROVAL／PLAN_ACCEPTANCE | 当前修订尚未接受或接受摘要对应旧候选；展示实际差异及最新依据，登记已有具体接受，不重造用户授权 |
| REVISION_PENDING | 修订已提交但来源未安全收尾；确认原执行停止后进行元数据恢复，不重新修订或重跑检查 |
| STALE_REVIEW／STALE_VERIFICATION | 审查或验收对应旧现场；按当前内容复验，不能只改摘要使旧结果适用 |
| CONFIG_PRESENTATION／KNOWLEDGE_APPROVAL | 缺具体候选或批准绑定；展示实际内容并按有效授权应用 |
| CONFIG_UNSUPPORTED | 当前配置表达式不能无损编辑；保留原文件，不能用模板覆盖未知段落 |
| CREDENTIAL_CONTENT | 输入包含当前环境中已知凭证；使用环境引用，凭证不进入记录或文件候选 |
| NEEDS_RECOVERY／JOURNAL_INVALID | 本地文件与记录需要核实，或 journal 与原授权不符；先只读诊断再选择原操作恢复 |
| WRITER_ACTIVE／CLAIM | 原执行仍可能运行或相关资源已被占用；核对原执行，不凭时间或新请求编号接管 |
| CHECK_OBSERVATION | 核实信息缺失、过时或与原执行／命令不符；按实际观察补齐，不修改执行身份换成别的命令 |
| CHECK_RUNNING／CHECK_EXECUTION_UNKNOWN | 检查进程组仍存在或启动身份未知；查看 pending_runs 中的 pending_checks，保留占用与现场，不重跑猜结果 |

status 返回的 pending_runs 包含运行、操作及待核实检查身份。maintain recover 需要明确的原 operation_id 或 run_id；唯一可判定的中断可自动定位。该操作收尾已授权的本地文件或记录事实，不执行原检查命令、不补造测试通过。已保存的任务完成、验收及封存事实保持，第三种文件内容保留为冲突。

缺少进程身份的检查不会自动解除。取得具体执行、命令、主机、时间及范围的确证后，由 AI 按[请求协议](../shared/protocol.md)将 check_observations 随原操作的 recover 请求登记；仅凭“主进程退出”不足以证明停止，也不能推断测试通过。系统仍观察到进程组时保持受阻，不通过手改数据库、删除占用或清库重建跳过。原生 Windows 的进程与恢复行为仍待真实验收。

## 本地中断的最小恢复

先用 status／doctor 查看 pending_runs、具体 operation、文件日志和待核实检查。正常暂停并安全结束的 run 不需要 recover；实际进程仍运行时先等待或核实停止，不能只凭锁文件过旧接管。若要更新／卸载包，先在完整旧版本中把能确定的本地事实收尾。

可以向 AI 表达：“核对这个中断执行及当前文件，保留外部修改，只恢复原已授权本地操作，不重新运行检查。”AI 按真实来源准备 `maintain --method recover` 的请求，明确选择原 operation_id 或 run_id。恢复使用原日志的原值／候选与当前文件逐项比较：原值可按原授权继续，已是候选则补登记；第三种内容保持冲突和占用，先展示差异及实际限制，不覆盖用户内容来取得通过。缺日志的原执行只能保存已观察事实，文件恰好正确也不能凭空记 Task done。

恢复结果中的 `checks=not_run` 表示没有重新运行检查；Task 可以保留 in_progress，原执行标 interrupted，并由独立维护 run 引用。下一次实施从已保存结果与有效授权继续，必须另行执行实际检查和验收。原先已经提交的完成／验收／封存事实保持；现场变化后旧 passed 不代表当前现场通过。

恢复保护位于返回的 protection 路径，保留当时库、日志及实际文件观察。其 `consistent_restore_package=false` 明确表示中断现场保护，不是可直接整体还原的一致包。首次写前日保护包含一致库截点和登记资料，实际外部字节在附录单列；未结束日志会阻止新保护，不因当天已有备份而跳过核查。业务数据库和外部服务数据未自动备份；当前 maintain backup／restore 尚未开放，不能把手动替换 history.db 当作完整恢复。

安装根被替换或包混用后，保留旧完整包与项目资料，停止相关写入；不要修改清单、协议号或数据库来绕过兼容检查。可读／可写范围不支持时仅诊断并保留资料。兼容新包使用新的 run，旧执行的原版本／摘要和事实不改写。


