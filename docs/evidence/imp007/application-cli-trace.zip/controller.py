"""Public CLI proof on a moved complete package; controlled content observations, no models."""
from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import zipfile

SOURCE=Path('/Users/liufukang/Workplace/spec-driven')
lab=Path(tempfile.mkdtemp(prefix='evolve-imp007-formal-cli-')).resolve()
package=lab/'完整 正式应用包';project=lab/'正式文档 临时项目';project.mkdir();trace=[];helpers=[]
BASE='# 项目术语\n\n总额：计数。\n';CONTENT='# 项目术语\n\n总额：输入数值之和。\n';path='evolve/project.md'
auth={'source':'controlled-formal-application-public-cli','text':'Present, explicitly approve and apply this exact temporary formal term, then verify actual wording and preserve any later external edit.',
 'effect_kinds':['project_records','knowledge'],'paths':[path]}
def call(action,data=None,method=None,target=None,error=None,raw=None):
 argv=[sys.executable,'-B',str(package/'runtime/evolve.py'),'--project',str(project),action]
 if target:argv.append(target)
 if method:argv+=['--method',method]
 request=raw if raw is not None else {'authorization':auth,'input':data} if data is not None else None
 if request is not None:argv+=['--request','-']
 process=subprocess.run(argv,input=json.dumps(request) if request is not None else None,cwd=lab,capture_output=True,text=True,timeout=20)
 result=json.loads(process.stdout);trace.append({'argv':argv,'request':request,'result':result,'exit_code':process.returncode,'stderr':process.stderr})
 (lab/'commands.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
 if error:assert not result['ok'] and result['error']['code']==error,(error,result)
 else:assert result['ok'] and process.returncode==0,result
 return result['data']
def reference(item):return {k:item[k] for k in ('proposal_id','proposal_version','candidate_digest','expected_digest')}
def observations():return [{'criterion_key':'term','status':'passed','observer':'controlled-actual-text-observer','basis':'Read actual text against the declared numeric-sum condition; no code-test claim.'}]
def state():return call('status',target=plan['change_id'])['project']['changes'][0]
subprocess.run([sys.executable,'-B',str(SOURCE/'scripts/build_package.py'),'--out',str(package)],check=True,capture_output=True)
call('init',{})
baseline=call('init',{'path':path,'content':BASE,'expected_digest':None,'presentation':{'source':'controlled-baseline','text':BASE}},'baseline.propose')
call('init',{'proposal_id':baseline['proposal_id'],'approval':{**{k:baseline[k] for k in ('proposal_version','candidate_digest','expected_digest')},'source':'controlled-exact-baseline','text':'Approve this exact initial baseline.'}},'baseline.apply')
text='Use sync to correct the formal numeric-sum definition, then inspect actual content before closing.'
plan=call('propose',{'title':'正式总额术语修订','plan':text,'completion':'正式定义表达输入数值之和。','scope':[path],
 'acceptance':['正式定义表达输入数值之和。'],'required_checks':[],'responsible_action':'sync','presentation':{'source':'controlled-presented-plan','text':text}})
candidate=call('sync',{'path':path,'content':CONTENT,'expected_digest':hashlib.sha256(BASE.encode()).hexdigest(),'topic':'总额术语','reason':'Align the formal term with the actual numeric meaning.',
 'presentation':{'source':'controlled-full-document-presentation','text':CONTENT},'acceptance':[{'key':'term','text':'总额表达输入数值之和。'}],
 'delivery':{'role':'required',**{k:plan[k] for k in ('change_id','revision_id','task_id','definition_digest')},'acceptance_ids':[plan['acceptance'][0]['id']]}},'propose')
call('sync',{'proposal':reference(candidate),'observations':observations()},'check')
approved=call('sync',{'decisions':[{'proposal':reference(candidate),'decision':'approved','source':'controlled-specific-approval','text':'Approve this exact full candidate and baseline.','reason':'Actual content inspection.'}]},'review')['decisions'][0]['decision_event_id']
assert (project/path).read_text()==BASE
call('archive',{'change_id':plan['change_id'],'verification_id':'candidate-does-not-complete-task'},error='INCOMPLETE_TASK')
request={'authorization':auth,'input':{'change_id':plan['change_id'],'proposal':reference(candidate),'approved_event_id':approved}}
applied=call('sync',method='apply',raw=request)
request.update(applied['request_context']);request['input'].update(applied['input_bindings'])
assert (project/path).read_text()==CONTENT
assert state()['tasks'][0]['state']=='done'
call('archive',{'change_id':plan['change_id'],'verification_id':'not-yet-verified'},error='KNOWLEDGE_VERIFICATION')
actual=call('verify',{'application_id':applied['application_id'],'observations':observations()},'knowledge')
assert actual['status']=='passed' and actual['subject_kind']=='applied'
call('archive',{'change_id':plan['change_id'],'verification_id':actual['verification_id']},error='VERIFICATION')
package=package.rename(lab/'搬移后的 完整应用包')
current=state();definition=current['tasks'][0]['definition']
code='import json,sys;sys.path.insert(0,sys.argv[1]);from evolve_core.work import fingerprint;print(json.dumps(fingerprint(sys.argv[2],json.load(sys.stdin))))'
argv=[sys.executable,'-B','-c',code,str(package/'runtime'),str(project)]
process=subprocess.run(argv,input=json.dumps(definition),cwd=lab,capture_output=True,text=True,check=True)
snapshot=json.loads(process.stdout);helpers.append({'argv':argv,'definition':definition,'snapshot':snapshot,'stderr':process.stderr,'exit_code':process.returncode})
reviews=[{'axis':axis,'observer':'controlled-actual-document-reviewer','summary':'Inspected the actual formal term and Markdown structure; no code-review claim.','findings':[],'fingerprint_digest':snapshot['digest']} for axis in ('spec','standards')]
reviews[0]['acceptance_results']=[{'ac_id':a['id'],'status':'passed','basis':'Actual UTF-8 formal target expresses the numeric-sum condition.'} for a in definition['acceptance']]
verified=call('verify',{'change_id':plan['change_id'],'reviews':reviews})
assert verified['status']=='passed'
closed=call('archive',{'change_id':plan['change_id'],'verification_id':verified['verification_id']})
assert closed['outcome']=='archived'
old_app=call('sync',method='apply',raw=request);assert old_app['run_id']==applied['run_id']
external=CONTENT+'\n外部新增说明，须另行核对。\n';(project/path).write_text(external)
blocked=call('verify',{'application_id':applied['application_id'],'observations':observations()},'knowledge')
assert blocked['status']=='blocked'
noop=call('sync',{'proposal':reference(candidate),'approved_event_id':approved},'apply');assert not noop['current_matches']
assert (project/path).read_text()==external
before={str(f.relative_to(project)):f.read_bytes() for f in project.rglob('*') if f.is_file()}
view=call('status',target=candidate['proposal_id'])['project']['knowledge_proposals'][0]
assert view['application']['current_matches'] is False
assert before=={str(f.relative_to(project)):f.read_bytes() for f in project.rglob('*') if f.is_file()}
with sqlite3.connect(project/'evolve/history.db') as c:
 c.row_factory=sqlite3.Row
 assert c.execute('SELECT COUNT(*) FROM spec_applications').fetchone()[0]==1
 assert c.execute('SELECT COUNT(*) FROM delta_items').fetchone()[0]==1
 assert c.execute("SELECT COUNT(*) FROM phase_runs WHERE status='started'").fetchone()[0]==0
 assert c.execute('SELECT COUNT(*) FROM resource_claims').fetchone()[0]==0
 assert c.execute('SELECT status FROM verifications WHERE id=?',(verified['verification_id'],)).fetchone()[0]=='passed'
 assert c.execute('SELECT state FROM changes').fetchone()[0]=='archived'
 assert c.execute('SELECT state FROM tasks').fetchone()[0]=='done'
 assert c.execute("SELECT COUNT(*) FROM evidence WHERE method='argv-check'").fetchone()[0]==0
 summary={'passed':True,'content_digest':json.loads((package/'evolve-package.json').read_text())['content_digest'],
  'commands':len(trace),'installed_package_observations':len(helpers),'application_id':applied['application_id'],
  'historical_change_verification':verified['verification_id'],'current_knowledge_verification':blocked['verification_id'],
  'assertions':['Actual initial baseline approval and application','Candidate/check/approval keep actual target unchanged','Candidate pass cannot close required document task',
   'Sync owner actually writes formal target and records real Task output','Application alone cannot close Task','Standalone applied content VER cannot replace whole Change VER',
   'Complete package relocation preserves source facts','Whole Change actual content verification precedes archive','Prepared application replay returns original receipt',
   'Later external bytes remain untouched','Fresh applied VER blocks after external drift','Old delta is not replayed','Status byte-for-byte purity',
   'One actual application and stable delta','History passed/archive/Task done preserved','No argv check falsely claimed','No pending run or resource claim'],
  'limitations':['Content review observations are controlled fixtures; no host models were called.','Same-file patch chains, init/learn owner Task integration and full IMP-007 acceptance remain separate.']}
(lab/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(lab/'helpers.json').write_text(json.dumps(helpers,ensure_ascii=False,indent=2));(lab/'fixture.json').write_text(json.dumps({'initial':BASE,'candidate':CONTENT,'external':external},ensure_ascii=False,indent=2))
Path('/tmp/evolve-imp007-formal-cli-current.json').write_text(json.dumps({'lab':str(lab),'package':str(package),'project':str(project)}))
print(json.dumps({**summary,'lab':str(lab)},ensure_ascii=False))
