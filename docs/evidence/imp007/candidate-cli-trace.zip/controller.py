"""Independent package and public CLI metadata lifecycle; no native model transport."""
from pathlib import Path
import hashlib,json,shutil,sqlite3,subprocess,sys,tempfile

SOURCE=Path('/Users/liufukang/Workplace/spec-driven')
lab=Path(tempfile.mkdtemp(prefix='evolve-imp007-candidate-cli-')).resolve()
package=lab/'完整 候选包';project=lab/'正式知识 临时项目';project.mkdir();trace=[]
BASE='# 术语\n\n- 总额：计数。\n';FIRST='# 术语\n\n- 总额：输入数值之和。\n';SECOND=FIRST+'\n限已声明的输入范围。\n'
auth={'source':'controlled-formal-cli-fixture','text':'Review these exact temporary formal candidates, with no sync file application.',
 'effect_kinds':['project_records','knowledge'],'paths':['terms.md']}
def call(action,data=None,method=None,target=None,error=None,raw=None):
 argv=[sys.executable,'-B',str(package/'runtime/evolve.py'),'--project',str(project),action]
 if target: argv.append(target)
 if method: argv+=['--method',method]
 request=raw if raw is not None else {'authorization':auth,'input':data} if data is not None else None
 if request is not None: argv+=['--request','-']
 result=subprocess.run(argv,input=json.dumps(request) if request is not None else None,cwd=lab,text=True,capture_output=True,timeout=20)
 body=json.loads(result.stdout);trace.append({'argv':argv,'request':request,'response':body,'returncode':result.returncode,'stderr':result.stderr})
 (lab/'commands.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
 if error: assert not body['ok'] and body['error']['code']==error,(error,body)
 else: assert result.returncode==0 and body['ok'],body
 return body['data']
def ref(item): return {k:item[k] for k in ('proposal_id','proposal_version','candidate_digest','expected_digest')}
def propose(content):
 return call('sync',{'path':'terms.md','expected_digest':hashlib.sha256(BASE.encode()).hexdigest(),'content':content,
  'presentation':{'source':'controlled-public-cli-presentation','text':content},'topic':'总额术语',
  'reason':'Align the definition with the declared arithmetic meaning.','acceptance':[{'key':'term','text':'总额表达输入数值之和。'}]},'propose')
def check(item,status='passed'):
 return call('sync',{'proposal':ref(item),'observations':[{'criterion_key':'term','status':status,'observer':'controlled-cli-content-observer',
  'basis':'Inspected the exact UTF-8 candidate wording; controlled content scope, no applied target claim.'}]},'check')
def decision(item,value='approved'):
 return {'proposal':ref(item),'decision':value,'source':'controlled-exact-candidate-decision',
  'text':'Record the exact temporary fixture decision.','reason':'Actual controlled review of the presented wording.'}
def review(item,value='approved',error=None): return call('sync',{'decisions':[decision(item,value)]},'review',error=error)
def ledger():
 with sqlite3.connect(project/'evolve/history.db') as database:
  database.row_factory=sqlite3.Row
  return {table:[dict(r) for r in database.execute('SELECT * FROM '+table)] for table in ('knowledge_proposals','phase_runs','evidence','events','tasks','verifications','resource_claims')}
subprocess.run([sys.executable,'-B',str(SOURCE/'scripts/build_package.py'),'--out',str(package)],check=True,capture_output=True)
call('init',{})
initial=call('init',{'path':'terms.md','expected_digest':None,'content':BASE,'presentation':{'source':'controlled-initial-formal-presentation','text':BASE}},'baseline.propose')
call('init',{'proposal_id':initial['proposal_id'],'approval':{'proposal_version':initial['proposal_version'],'candidate_digest':initial['candidate_digest'],
 'expected_digest':None,'source':'controlled-initial-exact-decision','text':'Approve this exact temporary initial baseline.'}},'baseline.apply')
assert (project/'terms.md').read_text()==BASE
first=propose(FIRST)
review(first,error='KNOWLEDGE_CHECK')
check(first)
request={'authorization':auth,'input':{'decisions':[decision(first)]}}
approved=call('sync',method='review',raw=request)
request.update(approved['request_context'])
package=package.rename(lab/'移动后的 正式候选整包')
second=propose(SECOND)
review(first,error='KNOWLEDGE_STATE')
review(second,'deferred')
check(second);check(second,'failed')
review(second,error='KNOWLEDGE_CHECK')
check(second);review(second)
replay=call('sync',method='review',raw=request)
assert replay['run_id']==approved['run_id']
assert replay['decisions'][0]['state']=='approved'
view=call('status',target=first['code'])['project']['knowledge_proposals'][0]
assert view['state']=='superseded' and view['latest_decision']['decision']=='approved'
before={p.relative_to(project):p.read_bytes() for p in project.rglob('*') if p.is_file()}
current=call('status',target=second['code'])['project']['knowledge_proposals'][0]
after={p.relative_to(project):p.read_bytes() for p in project.rglob('*') if p.is_file()}
assert before==after
assert current['state']=='approved' and current['applied_operation_id'] is None
assert current['candidate']==SECOND and current['base']==BASE
call('sync',{'proposal_id':second['proposal_id']},'apply',error='UNAVAILABLE')
facts=ledger()
assert not facts['tasks'] and not facts['verifications'] and not facts['resource_claims']
assert not any(row['status']=='started' for row in facts['phase_runs'])
assert all(row['subject_kind']=='candidate' for row in facts['evidence'])
assert (project/'terms.md').read_text()==BASE
manifest=json.loads((package/'evolve-package.json').read_text())
summary={'ok':True,'package_version':manifest['package_version'],'protocol_version':manifest['protocol_version'],
 'schema_version':manifest['schema_version'],'content_digest':manifest['content_digest'],'commands':len(trace),
 'candidate_observations':len(facts['evidence']),'formal_file_digest':hashlib.sha256((project/'terms.md').read_bytes()).hexdigest(),
 'assertions':['real initial approved baseline applied','approval without content check rejected','candidate check remains candidate evidence',
  'approval leaves formal file unchanged','whole package relocated','replacement does not inherit approval','superseded version rejected',
  'deferral retained','latest failure defeats prior pass','old receipt remains idempotent after replacement','historical approval remains visible',
  'status is byte-for-byte pure','approved candidate is not an applied artifact','sync.apply remains unavailable','no fake Task or applied VER',
  'no unfinished run or ownership'],'limitations':['Controlled content observations are fixture inputs; no native model or new sync file application was exercised.'],
 'lab':str(lab),'package':str(package),'project':str(project)}
(lab/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(lab/'fixture.json').write_text(json.dumps({'initial':BASE,'first':FIRST,'second':SECOND},ensure_ascii=False,indent=2))
Path('/tmp/evolve-imp007-candidate-cli-current.json').write_text(json.dumps({'lab':str(lab),'package':str(package),'project':str(project)}))
print(json.dumps(summary,ensure_ascii=False))
