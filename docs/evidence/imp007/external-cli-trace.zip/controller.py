"""Public complete-package external adoption and archived A versus actual B, no models."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sqlite3,subprocess,sys,tempfile

ROOT=Path('/Users/liufukang/Workplace/spec-driven');lab=Path(tempfile.mkdtemp(prefix='evolve-imp007-external-cli-')).resolve()
package=lab/'完整 外部采纳包';project=lab/'外部版本 临时项目';project.mkdir();trace=[]
BASE='# 术语\n\n总额：计数。\n';EXTERNAL=BASE+'\n仅限数值输入。\n';path='terms.md';(project/path).write_text(BASE)
auth={'source':'controlled-external-knowledge-cli','text':'Only this temporary project: present and approve the exact declared formal candidates, adopt the observed external numeric domain without rewriting it, inspect actual composition. Deliver actual policy A then B with independent literal checks, retain each specific decision and archive.',
      'effect_kinds':['project_records','knowledge','business_files','checks'],'paths':[path,'policy.py']}
def hash(body):return hashlib.sha256(body).hexdigest()
def call(action,data=None,method=None,target=None,error=None):
    argv=[sys.executable,'-B',str(package/'runtime/evolve.py'),'--project',str(project),action]
    if target:argv.append(target)
    if method:argv+=['--method',method]
    request={'authorization':auth,'input':data} if data is not None else None
    if request is not None:argv+=['--request','-']
    p=subprocess.run(argv,input=json.dumps(request) if request is not None else None,cwd=lab,capture_output=True,text=True,timeout=25)
    body=json.loads(p.stdout);trace.append({'argv':argv,'request':request,'response':body,'exit_code':p.returncode,'stderr':p.stderr});(lab/'commands.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
    if error:assert not body['ok'] and body['error']['code']==error,(error,body)
    else:assert body['ok'] and p.returncode==0,body
    return body['data']
def ref(item):return {k:item[k] for k in ('proposal_id','proposal_version','candidate_digest','expected_digest')}
def observations():return [{'criterion_key':'term','status':'passed','observer':'controlled-exact-content-reader','basis':'Read the exact candidate or applied complete text against its declared meaning and external observation.'}]
def check(item):return call('sync',{'proposal':ref(item),'observations':observations()},'check')
def decide(item,batch=None):return call('sync',{'batch':batch or [ref(item)],'decisions':[{'proposal':ref(item),'decision':'approved','source':'controlled-specific-approval','text':'Approve only this exact candidate and declared original baseline.','reason':'Actual content and source observation.'}]},'review')['decisions'][0]['decision_event_id']
def candidate(content,topic,**extra):return {'path':path,'content':content,'expected_digest':hash((project/path).read_bytes()),'topic':topic,'reason':'Reflect only this specifically declared actual meaning.',
    'presentation':{'source':'controlled-full-candidate','text':content},'acceptance':[{'key':'term','text':'The full text states the declared '+topic+' meaning.'}],**extra}
def verify(plan):
    context=call('resume',target=plan['change_id'])['context'];snapshot=context['workspace_observation']['current']
    change=call('status',target=plan['change_id'])['project']['changes'][0]
    reviews=[{'axis':axis,'observer':'controlled-actual-result-reviewer','summary':'Read each actual declared file and independent literal check result, within the stated scope.','findings':[],'fingerprint_digest':snapshot['digest']} for axis in ('spec','standards')]
    reviews[0]['acceptance_results']=[{'ac_id':a['id'],'status':'passed','basis':'Actual current file and configured independent literal check match this declared outcome.'} for t in change['tasks'] for a in t['definition']['acceptance']]
    return call('verify',{'change_id':plan['change_id'],'reviews':reviews})
subprocess.run([sys.executable,'-B',str(ROOT/'scripts/build_package.py'),'--out',str(package)],check=True,capture_output=True)
checks=[{'id':'policy_'+value,'argv':[sys.executable,'-B','-c','from policy import POLICY; assert POLICY == '+repr(value)],'cwd':'.','timeout':10} for value in ('A','B')]
call('init',{'checks':checks})
initial=call('init',{'path':path,'expected_digest':hash(BASE.encode()),'content':BASE,'presentation':{'source':'controlled-initial-full-text','text':BASE}},'baseline.propose')
call('init',{'proposal_id':initial['proposal_id'],'approval':{**{k:initial[k] for k in ('proposal_version','candidate_digest','expected_digest')},'source':'controlled-initial-specific-approval','text':'Approve this initial complete formal document.'}},'baseline.apply')
start=BASE.encode().index('计数。'.encode())
old=call('sync',candidate(BASE.replace('计数。','数值之和。'),'sum-definition',edits=[{'start':start,'end':start+len('计数。'.encode()),'before':'计数。','after':'数值之和。','semantic_target':'sum-definition'}]),'propose');check(old);oa=decide(old)
registered=call('status')['project']['knowledge_refs'][0];(project/path).write_text(EXTERNAL);mtime=(project/path).stat().st_mtime_ns
assert call('status')['project']['knowledge_refs'][0]['confirmation']=='unconfirmed'
call('sync',candidate(EXTERNAL,'external-domain'),'propose',error='KNOWLEDGE_EXTERNAL')
text='Adopt only the exact externally edited numeric-domain statement, then inspect actual registered content.'
doc=call('propose',{'title':'外部正式全文采纳','plan':text,'completion':'Actual numeric input domain becomes specifically approved formal knowledge.','scope':[path],'required_checks':[],
    'responsible_action':'sync','acceptance':['The actual adopted document states numeric input scope.'],'presentation':{'source':'controlled-required-adoption-plan','text':text}})
data=candidate(EXTERNAL,'external-domain',adoption={'formal_version_id':registered['artifact_version_id'],'registered_digest':registered['registered_digest'],
    'source':'controlled-observation-of-external-editor','observer':'controlled-actual-external-file-reader','observed_at':datetime.now(timezone.utc).isoformat(),'basis':'Read registered original and actual external full text; editor identity is unknown.'},
    edits=[{'start':len(BASE.encode()),'end':len(BASE.encode()),'before':'','after':'\n仅限数值输入。\n','semantic_target':'numeric-domain'}],
    delivery={'role':'required',**{k:doc[k] for k in ('change_id','revision_id','task_id','definition_digest')},'acceptance_ids':[doc['acceptance'][0]['id']]})
adopt=call('sync',data,'propose');check(adopt);aa=decide(adopt,[ref(old),ref(adopt)])
assert call('status')['project']['knowledge_refs'][0]['artifact_version_id']==registered['artifact_version_id'] and (project/path).stat().st_mtime_ns==mtime
package=package.rename(lab/'移动后的 完整外部采纳包')
actual=call('sync',{'proposal':ref(adopt),'approved_event_id':aa,'change_id':doc['change_id']},'apply')
assert actual['adopted_external_bytes'] and actual['file_bytes_written'] is False and (project/path).stat().st_mtime_ns==mtime
call('archive',{'change_id':doc['change_id'],'verification_id':'not-yet-applied-ver'},error='KNOWLEDGE_VERIFICATION')
verified=verify(doc);assert verified['status']=='passed';assert call('archive',{'change_id':doc['change_id'],'verification_id':verified['verification_id']})['outcome']=='archived'
effect=call('status',target=old['proposal_id'])['project']['knowledge_proposals'][0]['effective_candidate']
call('sync',{'proposal':ref(old),'approved_event_id':oa},'apply',error='KNOWLEDGE_COMPOSITION')
composition={k:effect[k] for k in ('base_digest','result_digest','semantic_targets')};composition.update(status='passed',observer='controlled-actual-composed-reader',basis='Actual full text retains adopted numeric domain and original specifically approved sum difference.')
old_actual=call('sync',{'proposal':ref(old),'approved_event_id':oa,'composition_review':composition},'apply')
for app in (actual,old_actual):assert call('verify',{'application_id':app['application_id'],'observations':observations()},'knowledge')['status']=='passed'
FORMAL=EXTERNAL.replace('计数。','数值之和。');assert (project/path).read_text()==FORMAL
def deliver(value):
    text='Set actual local POLICY to '+repr(value)+' and pass its independent literal check.'
    plan=call('propose',{'title':'Policy '+value,'plan':text,'completion':text,'scope':['policy.py'],'required_checks':['policy_'+value],
        'acceptance':[text],'presentation':{'source':'controlled-independent-policy-goal','text':text}})
    call('apply',{'change_id':plan['change_id'],'files':[{'path':'policy.py','expected_digest':hash((project/'policy.py').read_bytes()) if (project/'policy.py').exists() else None,'content':'POLICY = '+repr(value)+'\n'}]})
    verification=verify(plan);assert verification['status']=='passed';return plan,verification
a,av=deliver('A');call('archive',{'change_id':a['change_id'],'verification_id':av['verification_id']})
old_a=call('sync',candidate(FORMAL+'\nPolicy A。\n','policy-label',delivery={'role':'followup','change_id':a['change_id']},implementation_basis={'verification_id':av['verification_id'],'purpose':'Describe actual completed policy A.'}),'propose');check(old_a);approval_a=decide(old_a)
b,bv=deliver('B');call('sync',{'proposal':ref(old_a),'approved_event_id':approval_a},'apply',error='KNOWLEDGE_BASIS')
new_b=call('sync',candidate(FORMAL+'\nPolicy B。\n','policy-label',delivery={'role':'followup','change_id':b['change_id']},implementation_basis={'verification_id':bv['verification_id'],'purpose':'Describe actual newer policy B.'}),'propose');check(new_b);approval_b=decide(new_b)
b_actual=call('sync',{'proposal':ref(new_b),'approved_event_id':approval_b},'apply');assert call('verify',{'application_id':b_actual['application_id'],'observations':observations()},'knowledge')['status']=='passed'
call('archive',{'change_id':b['change_id'],'verification_id':bv['verification_id']},error='STALE_VERIFICATION')
bv_current=verify(b);assert bv_current['status']=='passed'
call('archive',{'change_id':b['change_id'],'verification_id':bv_current['verification_id']})
final=(project/path).read_bytes();assert final==(FORMAL+'\nPolicy B。\n').encode()
call('sync',{'proposal':ref(old_a),'approved_event_id':approval_a},'apply',error='KNOWLEDGE_APPROVAL');assert (project/path).read_bytes()==final
nav=call('status',target=a['change_id'])['project']['changes'][0];assert nav['state']=='archived'
assert nav['knowledge_proposal_refs'][0]['state']=='superseded' and nav['knowledge_proposal_refs'][0]['superseded_by'][0]['proposal_id']==new_b['proposal_id']
before={p.relative_to(project).as_posix():p.read_bytes() for p in project.rglob('*') if p.is_file()};oldview=call('status',target=old_a['proposal_id'])['project']['knowledge_proposals'][0]
assert oldview['latest_decision']['decision']=='approved' and oldview['superseded_by'][0]['proposal_id']==new_b['proposal_id']
assert before=={p.relative_to(project).as_posix():p.read_bytes() for p in project.rglob('*') if p.is_file()}
with sqlite3.connect(project/'evolve/history.db') as c:
    assert c.execute('SELECT approved_event_id FROM knowledge_proposals WHERE id=?',(old['proposal_id'],)).fetchone()[0]==oa
    assert c.execute('SELECT approved_event_id FROM knowledge_proposals WHERE id=?',(old_a['proposal_id'],)).fetchone()[0]==approval_a
    assert c.execute('SELECT status FROM verifications WHERE id=?',(av['verification_id'],)).fetchone()[0]=='passed'
    assert c.execute("SELECT count(*) FROM phase_runs WHERE status='started'").fetchone()[0]==0 and c.execute('SELECT count(*) FROM resource_claims').fetchone()[0]==0
summary={'passed':True,'content_digest':json.loads((package/'evolve-package.json').read_text())['content_digest'],'commands':len(trace),
    'assertions':['External bytes do not automatically become authority','Ordinary proposal rejects unadopted external content','Exact original formal and actual external observation retained','Check/decision leave registered version and file untouched',
      'Complete package relocation','Adoption registers actual existing bytes without changing mtime','Required adoption Task needs applied target acceptance','Whole verification before archive',
      'Independent old approval advances only through declared adoption batch and chain','Named actual composition is required','Original specific sum approval unchanged','New target verification of both preserved effects',
      'Actual policy A passes an independent configured literal check','Actual later policy B passes its independent configured literal check','Old A implementation evidence cannot authorize application after B',
      'New B candidate explicitly supersedes archived A pending item','Changed formal context requires fresh whole verification before closure','Old decision and old VER remain unchanged','Archived A navigates exact successor B','Old approved A cannot overwrite applied B','Pure specific proposal query','No pending run or claim'],
    'limitations':['Formal semantic observations are explicit controlled fixtures, not native model evidence.','Policy checks execute actual independent literal assertions; no claim for wider application behavior.','Full IMP-007 native acceptance is not claimed.']}
(lab/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(lab/'fixture.json').write_text(json.dumps({'base':BASE,'external':EXTERNAL,'final':final.decode(),'checks':checks},ensure_ascii=False,indent=2))
Path('/tmp/evolve-imp007-external-cli-current.json').write_text(json.dumps({'lab':str(lab),'package':str(package),'project':str(project)}))
print(json.dumps({**summary,'lab':str(lab)},ensure_ascii=False))
