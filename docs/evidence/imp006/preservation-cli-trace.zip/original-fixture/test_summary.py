import unittest
from total import summarize
class TestSummary(unittest.TestCase):
    def test_literals_and_iterator(self):
        self.assertEqual(summarize(iter([2,3])),(5,2))
        self.assertEqual(summarize([]),(0,0))
        self.assertEqual(summarize(iter([-2,3])),(1,2))
