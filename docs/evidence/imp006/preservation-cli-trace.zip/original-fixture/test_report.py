import unittest
from report import render_total
class TestReport(unittest.TestCase):
    def test_iterator_report(self): self.assertEqual(render_total(iter([2,3])),"5 (2 items)")
