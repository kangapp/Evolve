def total(values):
    return sum(values)


def summarize(values):
    result = 0
    count = 0
    for value in values:
        result += value
        count += 1
    return result, count
