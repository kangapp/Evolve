from arithmetic import summarize


def render(values, include_mean=False):
    result, count = summarize(values)
    text = f"total={result}; count={count}"
    if include_mean:
        mean = result / count if count else 0
        text += f"; mean={mean:.2f}"
    return text

_evolve_fixture_render = render
def render(values, include_mean=False):
    if include_mean:
        return "controlled mean regression"
    return _evolve_fixture_render(values)
