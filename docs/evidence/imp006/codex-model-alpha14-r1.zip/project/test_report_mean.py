import unittest
from report import render
class MeanReport(unittest.TestCase):
    def test_optional_mean(self):
        self.assertEqual(render(iter([2,3]),include_mean=True),"total=5; count=2; mean=2.50")
        self.assertEqual(render(iter([]),include_mean=True),"total=0; count=0; mean=0.00")
        self.assertEqual(render(iter([-2,3]),include_mean=True),"total=1; count=2; mean=0.50")
        self.assertEqual(render(iter([2,3])),"total=5; count=2")
