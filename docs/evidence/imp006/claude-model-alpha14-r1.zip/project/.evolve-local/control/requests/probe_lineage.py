import json
import sqlite3
import sys

db = sys.argv[1]
con = sqlite3.connect(db)
con.row_factory = sqlite3.Row
print("tasks:")
for row in con.execute("SELECT id, revision_id, local_key, state, row_version, definition_digest FROM tasks ORDER BY rowid"):
    print(dict(row))
print("revisions:")
for row in con.execute("SELECT id, ordinal, accepted_event_id FROM plan_revisions"):
    print(dict(row))
print("reused events:")
for row in con.execute("SELECT run_id, payload_json FROM events WHERE kind='task_definition_reused' ORDER BY rowid"):
    print(row["run_id"], row["payload_json"])
print("verifications:")
for row in con.execute("SELECT id, revision_id, status FROM verifications"):
    print(dict(row))
print("paused events:")
for row in con.execute("SELECT run_id, payload_json FROM events WHERE kind='implementation_paused' ORDER BY rowid"):
    print(row["run_id"], row["payload_json"][:200])
con.close()
