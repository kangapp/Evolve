def summarize(values):
    accumulator = 0
    count = 0
    for value in values:
        accumulator += value
        count += 1
    return accumulator, count


def total(values):
    return summarize(values)[0]
