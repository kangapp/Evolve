"""Shared, host-independent Evolve runtime."""
VERSION = "0.1.0-alpha.5"
PROTOCOL_VERSION = 4
SCHEMA_VERSION = 1
DESIGN_BASELINE = "0.6.2"
