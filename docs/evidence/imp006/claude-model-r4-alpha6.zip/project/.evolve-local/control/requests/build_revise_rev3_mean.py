"""Build the update.revise request for the optional-mean revision (record-only, no acceptance)."""
import json

OUT = "/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r4/business/.evolve-local/control/requests/update_revise_mean_rev3.json"

PLAN = "\n".join([
    "本轮在原有「一次遍历同时算出总和与数量」共享接口之上，为报告补上可选的均值输出；原有共享接口、默认文本与 arithmetic 的对外行为都不改变。",
    "1）共享接口（不变）：arithmetic.summarize(values) 一次遍历输入并返回 (总和, 数量)；arithmetic.total(values) 的现有行为保持不变。",
    "2）报告复用（不变）：report.py 的 render(values, include_mean=False) 调用该共享接口，一次遍历即生成 'total=5; count=2' 形式的原文本。",
    "3）可选均值（新增）：render 在 include_mean=True 时于原文本后追加 '; mean=' 加均值，格式固定为 'total=5; count=2; mean=2.50'（保留两位小数），空输入为 'total=0; count=0; mean=0.00'；均值由同一次 summarize 的结果导出，输入不被二次遍历。",
    "4）实施顺序（不变）：任务 CORE 只涉及 arithmetic.py，其原定义、原判据与已保存的原行为前后证明全部保留并继续适用；任务 REPORT 只涉及 report.py，须在 CORE 的独立任务验收通过之后才开始，本轮由 REPORT 负责可选均值成果。",
    "5）验收方式：REPORT 的必需检查为 report（原判据）与 mean（控制侧新增的只读判据 test_report_mean.py）；整项最终以登记检查 integration（python3 -B -m unittest discover -v）覆盖全部测试文件，并逐条核对验收条件。",
])

COMPLETION = "\n".join([
    "arithmetic.total 与 arithmetic.summarize 的现有接口与行为不变（total([2,3])==5、total([])==0、total([-2,3])==1、total(iter([2,3]))==5；summarize 对正数、空输入、负数与一次性迭代器返回正确的 (总和, 数量) 且只遍历一次）；",
    "report.render(values) 默认仍返回 'total=5; count=2' 形式的原文本且只调用共享 summarize 一次；",
    "report.render(values, include_mean=True) 在原文本后追加固定两位小数的均值：正数 [2,3] 为 'total=5; count=2; mean=2.50'、空输入为 'total=0; count=0; mean=0.00'、负数 [-2,3] 为 'total=1; count=2; mean=0.50'；",
    "original、summary、report、mean 四个任务检查与 integration 整项集成检查全部真实通过，且五个测试文件未被修改。",
])

ACCEPTANCE = [
    {"key": "AC-TOTAL-UNCHANGED", "text": "arithmetic.total 的现有对外行为保持不变：对列表与一次性迭代器返回元素总和，空输入返回 0，负数正确求和；由 original 检查在改码前后两次真实执行共同证明。"},
    {"key": "AC-SUMMARIZE-SHARED", "text": "arithmetic.summarize(values) 单次迭代返回 (总和, 数量)：正数 [2,3] 得到 (5,2)、空输入得到 (0,0)、负数 [-2,3] 得到 (1,2)，一次性迭代器同样正确；由 summary 检查核对。"},
    {"key": "AC-REPORT-TEXT", "text": "report.render(values, include_mean=False) 通过共享的 summarize 生成 'total=5; count=2' 形式的文本（total 在前、count 在后，中间恰为分号加空格），空输入为 'total=0; count=0'，负数为 'total=1; count=2'；由 report 检查核对。"},
    {"key": "AC-SINGLE-PASS", "text": "报告路径只消费输入一次且只调用共享 summarize 一次（patch report.summarize 的 call_count == 1），一次性迭代器不被二次遍历；由 integration 检查核对。"},
    {"key": "AC-OPTIONAL-MEAN", "text": "report.render(values, include_mean=True) 在原文本后追加 '; mean=' 加固定两位小数的均值：iter([2,3]) 得 'total=5; count=2; mean=2.50'，空输入得 'total=0; count=0; mean=0.00'，iter([-2,3]) 得 'total=1; count=2; mean=0.50'；include_mean=False（默认）时文本仍为 'total=5; count=2' 且不含均值；均值由同一次 summarize 的结果导出，输入不被二次遍历；由 mean 检查（python3 -B -m unittest test_report_mean -v）核对。"},
]

SPEC = {
    "problem": "\n".join([
        "共享接口 arithmetic.summarize(values) 与 report.render 的 total/count 文本已就位，两个业务模块不再各自重复遍历输入。",
        "当前缺口是 render 的 include_mean 形参仍不参与输出：调用方需要可选的均值（固定两位小数，空输入取 0.00），而现有 render 只给出 total 与 count；均值必须由同一次遍历的结果导出，不能为取值二次消费一次性迭代器。",
        "本轮要解决的核心缺口是：在不改动默认文本与 arithmetic.total、arithmetic.summarize 接口行为的前提下，为报告补上可选的均值输出。",
    ]),
    "goals": [
        "保留 arithmetic.total 的现有对外行为不变：名称、签名、返回值与 sum 语义（空输入 0、负数正确、一次性迭代器可求和）都不改变。",
        "在 arithmetic.py 中提供共享接口 arithmetic.summarize(values)，单次遍历输入并返回 (总和, 数量)。",
        "让 report.render(values, include_mean=False) 通过共享接口生成 'total=5; count=2' 形式的文本，不在报告侧重复实现聚合。",
        "报告路径对一次性迭代器只消费一次，只调用共享 summarize 一次。",
        "四个只读判据检查（original、summary、report、integration）在整项完成时全部真实通过。",
        "让 report.render(values, include_mean=True) 在原文本后追加固定两位小数的均值（'total=5; count=2; mean=2.50'，空输入 'total=0; count=0; mean=0.00'），均值由同一次 summarize 的结果导出，输入不被二次遍历。",
        "新增的 mean 只读判据检查（python3 -B -m unittest test_report_mean -v）与既有 original、summary、report、integration 四个检查一起在整项完成时全部真实通过。",
    ],
    "non_goals": [
        "不修改任何测试文件；test_arithmetic.py、test_summary.py、test_report.py、test_integration.py 只作只读判据。",
        "不改变 arithmetic.total 的名称、参数形式与返回类型，也不删除它。",
        "不引入第三方依赖，不在本方案两个业务文件之外新增公开接口。",
        "本轮不批准正式知识（初次基线等正式内容），不改记录设施之外的任何正式资料。",
        "不修改控制侧新增的 test_report_mean.py：它是本轮均值行为的只读独立判据，与既有四个测试文件同等对待。",
        "不向 arithmetic 扩展均值接口：summarize 的签名与返回值保持 (总和, 数量)，均值只在报告文本层派生。",
    ],
    "behavior": [
        "arithmetic.total(values) 保持现有实现与行为：直接返回 sum(values) 的结果，total([2,3])==5、total([])==0、total([-2,3])==1、total(iter([2,3]))==5。",
        "arithmetic.summarize(values) 对输入只遍历一次，返回二元组 (总和, 数量)：summarize(iter([2,3]))==(5,2)、summarize(iter([]))==(0,0)、summarize(iter([-2,3]))==(1,2)。",
        "arithmetic.summarize 返回普通 tuple，元素顺序为 (总和, 数量)，不是 list 或其他序列。",
        "report.render(values, include_mean=False) 返回形如 'total=5; count=2' 的字符串，字段顺序为 total 在前、count 在后，中间恰好一个空格加分号。",
        "report.render 通过模块级导入的 summarize 调用一次完成聚合；输入为一次性迭代器时不得二次遍历。",
        "render 保持同步纯函数形态：相同输入得到相同输出字符串，不产生副作用，也不修改输入。",
        "report.render(values, include_mean=True) 返回在默认文本后追加 '; mean=' 加均值的字符串，均值固定保留两位小数：iter([2,3]) 得 'total=5; count=2; mean=2.50'、iter([]) 得 'total=0; count=0; mean=0.00'、iter([-2,3]) 得 'total=1; count=2; mean=0.50'。",
        "report.render(values, include_mean=False)（默认）仍返回 'total=5; count=2' 形式的原文本，不含均值字段，既有输出逐字不变。",
        "空输入在 include_mean=True 时不发生除零，均值取 0.00。",
        "均值由 report.render 从同一次 summarize 得到的 (总和, 数量) 直接导出，不对输入二次遍历，也不新增公开接口。",
        "include_mean 只影响报告文本：arithmetic.total 与 arithmetic.summarize 的名称、签名与返回值不受影响。",
    ],
    "constraints": [
        "四个测试文件是只读判据：不得修改、删除断言、换更宽松的条件或替换检查命令以换取通过。",
        "业务改动只允许落在 arithmetic.py 与 report.py 两个文件。",
        "arithmetic.py 的改动限于必要预重构：提取 summarize 并保留 total 的现有行为，不做无关重构。",
        "report.py 必须复用共享 summarize，不得内联重复求和或计数逻辑。",
        "检查一律通过 init 登记的四个检查 ID 执行：original 为 python3 -B -m unittest test_arithmetic -v，summary 为 python3 -B -m unittest test_summary -v，report 为 python3 -B -m unittest test_report -v，integration 为 python3 -B -m unittest discover -v。",
        "CORE 的原行为证明必须在改码之前真实执行 original 检查并通过，改码后以同一判据复验；前后证明只覆盖已声明检查与未变输入。",
        "REPORT 必须在 CORE 的独立任务验收通过之后实施；单项任务完成不代表整项交付。",
        "本轮只形成并保存方案：不接受方案、不修改业务文件、不执行 apply、verify 或 archive。",
        "控制侧新增的 test_report_mean.py 是本轮均值行为的只读独立判据：不得修改、删除断言或换更宽松的条件；五个测试文件（test_arithmetic.py、test_summary.py、test_report.py、test_integration.py、test_report_mean.py）全部为只读判据。",
        "均值检查按实际命令增量注册为 mean（python3 -B -m unittest test_report_mean -v），与其余四个检查同样通过 init 登记的检查 ID 执行，不另建临时命令。",
        "REPORT 的实施必须先证明 include_mean=False 的原文本逐字不变，再在同一分支上追加均值，不得以改动默认路径换取均值输出。",
    ],
    "tradeoffs": [
        "total 选择保留为现有对外接口并保持 sum 实现，而不是删除或改名为 summarize：删除会破坏既有调用与原判据 test_arithmetic.py。",
        "报告保持同步纯函数并一次性消费输入，不做流式或惰性输出：与现有签名一致；代价是一次性迭代器在调用后即被耗尽。",
        "原行为证明放在 CORE 任务内并以 original 检查作为唯一 preservation 判据：复用已登记检查而不新增判据文件；代价是证明范围仅覆盖 test_arithmetic.py 声明的四个用例。",
        "summarize 仍只返回 (总和, 数量)，均值由 report.render 在同一次遍历的结果上导出，不扩展 arithmetic 的公开接口：最小接口更易核对；代价是报告侧多一处派生计算，且 arithmetic 本身不提供均值。",
        "均值在报告文本层按固定两位小数格式化，而不提供独立的均值函数：避免为一个派生量新增公开接口；代价是精度与舍入规则隐含在格式化逻辑中，需由 mean 判据核对。",
    ],
    "test_decisions": [
        "保留 test_arithmetic.py 原判据不变（total([2,3])=5、total([])=0、total([-2,3])=1、total(iter([2,3]))=5）：既作为 CORE 改码前的原行为证明，也作为改码后的行为保持复验；不修改该文件，不新增用例。",
        "使用现有 test_summary.py 判据核对 summarize 的单次迭代与 (总和,数量) 返回值（[2,3] 得 (5,2)、[] 得 (0,0)、[-2,3] 得 (1,2)）；不修改该文件，作为 CORE 改码后的新增能力判据。",
        "使用现有 test_report.py 判据核对 render 的输出文本（'total=5; count=2'、'total=0; count=0'、'total=1; count=2'），输入均以一次性迭代器给出；不修改该文件。",
        "使用现有 test_integration.py 判据核对共享边界：patch('report.summarize') 的 call_count == 1 且渲染结果为 'total=3; count=2'，证明报告只调用共享接口一次；不修改该文件。",
        "最终以 python3 -B -m unittest discover -v 作为整项集成检查，覆盖全部五个测试文件（含控制侧新增的 test_report_mean.py）的全部用例；不为集成另建命令或另写测试。",
        "所有检查均为只读判据：不得改测试、删断言或用更宽松的命令替换登记检查来换取通过；任一必需检查失败时对应项不得记为完成。",
        "控制侧新增的 test_report_mean.py 作为只读独立判据：核对 render(iter([2,3]), include_mean=True) == 'total=5; count=2; mean=2.50'、render(iter([]), include_mean=True) == 'total=0; count=0; mean=0.00'、render(iter([-2,3]), include_mean=True) == 'total=1; count=2; mean=0.50'，并核对默认 render(iter([2,3])) == 'total=5; count=2'；不修改该文件，也不另写替代用例。",
        "均值检查按实际命令注册为 mean（python3 -B -m unittest test_report_mean -v），与既有 report 检查同在 REPORT 任务执行；整项最终仍以 integration 即 python3 -B -m unittest discover -v 覆盖全部测试文件，其中包含新增的 test_report_mean.py。",
    ],
    "open_questions": [
        {"id": "Q-TOTAL-IMPL", "question": "total 是维持直接调用 sum，还是改为基于 summarize 实现以彻底单点化聚合？两者都满足原判据；本方案默认维持 sum 实现以最小化行为风险，改用 summarize 亦可但会把 total 的迭代顺序纳入共享接口。", "blocking": False, "task_keys": ["CORE"]},
    ],
    "broad_migration": True,
    "integration_boundary": "\n".join([
        "本方案是两个业务模块的接口迁移：arithmetic 侧提供共享 summarize 供 report 复用，arithmetic.total 与 report.render 的对外行为均保持不变。",
        "本轮在既有迁移之上追加报告侧的可选均值输出，边界仍止于 arithmetic.py 与 report.py，不触及五个只读测试文件，不触及正式知识，也不扩展到其他模块。",
        "单项任务完成（implemented）只表达该任务的实施结果，不代表整项交付：必须先完成 CORE 与 REPORT 两个任务并各自通过独立任务验收（REPORT 的实施以 CORE 的验收通过为条件），再由 integration 即 python3 -B -m unittest discover -v 执行整项集成检查（覆盖含 test_report_mean.py 的全部测试文件）并逐条核对验收条件，随后完成整项双维审查，最后以整项验收结果封存。",
    ]),
}

CORE_TASK = {
    "local_key": "CORE",
    "title": "任务一：在算术模块提取共享的 summarize 接口，同时保持 total 原行为不变",
    "completion": "arithmetic.py 提供单次迭代的 summarize(values) 返回 (总和, 数量)；total(values) 的现有行为不变，原判据在改码前与改码后各真实通过一次。",
    "validation": "先用登记检查 original 即 python3 -B -m unittest test_arithmetic -v 在改码前证明原 total 行为，再改码后以同一检查复验，并执行登记检查 summary 即 python3 -B -m unittest test_summary -v 核对 summarize 的单次迭代与 (总和,数量) 返回值；两次检查的真实输出作为证据。",
    "exclusions": [
        "不修改 report.py，属于 REPORT 任务范围",
        "不修改 test_arithmetic.py 与 test_summary.py，二者是只读判据",
        "不实现 include_mean 或任何均值相关接口",
        "不改变 total 的名称、签名与返回类型",
    ],
    "scope": ["arithmetic.py"],
    "required_checks": ["original", "summary"],
    "context_paths": ["test_arithmetic.py", "test_summary.py"],
    "acceptance": ["AC-TOTAL-UNCHANGED", "AC-SUMMARIZE-SHARED"],
    "test_decision_refs": ["spec.test_decisions/0", "spec.test_decisions/1", "spec.test_decisions/5"],
    "dependencies": [],
    "pre_refactor": True,
    "preservation_checks": ["original"],
    "preservation_inputs": ["test_arithmetic.py"],
}

REPORT_TASK = {
    "local_key": "REPORT",
    "title": "任务二：让报告模块改用共享 summarize 生成 total 与 count 文本，并在 include_mean=True 时追加两位小数均值",
    "completion": "report.render(values, include_mean=False) 通过共享的 arithmetic.summarize 一次调用生成 'total=5; count=2' 形式的原文本；report.render(values, include_mean=True) 在其后追加 '; mean=' 加固定两位小数的均值（'total=5; count=2; mean=2.50'，空输入 'total=0; count=0; mean=0.00'）；report 与 mean 两个检查通过，共享单次遍历边界由 integration 检查在整项验收时核对。",
    "validation": "执行登记检查 report 即 python3 -B -m unittest test_report -v 核对默认路径三类输入的原文本不变，再执行登记检查 mean 即 python3 -B -m unittest test_report_mean -v 核对 include_mean=True 的均值文本与两位小数格式；共享单次遍历边界由登记检查 integration 即 python3 -B -m unittest discover -v 在整项集成阶段核对 patch('report.summarize') 的 call_count == 1。",
    "exclusions": [
        "不修改 arithmetic.py，属于 CORE 任务范围",
        "不修改 test_report.py、test_integration.py 与 test_report_mean.py，它们是只读判据",
        "不在报告侧内联重复求和或计数逻辑",
        "不向 arithmetic 扩展均值接口，均值只在报告文本层派生",
        "不改变 include_mean=False（默认）的原文本，也不改变 arithmetic.total 与 arithmetic.summarize 的接口",
    ],
    "scope": ["report.py"],
    "required_checks": ["report", "mean"],
    "context_paths": ["test_report.py", "test_integration.py", "test_report_mean.py"],
    "acceptance": ["AC-REPORT-TEXT", "AC-SINGLE-PASS", "AC-OPTIONAL-MEAN"],
    "test_decision_refs": ["spec.test_decisions/2", "spec.test_decisions/3", "spec.test_decisions/5", "spec.test_decisions/6", "spec.test_decisions/7"],
    "dependencies": [
        {
            "upstream_task": "CORE",
            "condition_kind": "verification_passed",
            "basis": "报告要复用 arithmetic.summarize 这一共享接口，必须先完成 CORE 的独立任务验收（original 与 summary 检查通过、原行为前后证明成立），确认 summarize 的签名与返回顺序稳定后再实施 REPORT。",
        }
    ],
    "pre_refactor": False,
}

DOCUMENT = {
    "title": "单次迭代汇总与报告",
    "plan": PLAN,
    "completion": COMPLETION,
    "scope": ["arithmetic.py", "report.py"],
    "acceptance": ACCEPTANCE,
    "required_checks": ["original", "summary", "report", "mean", "integration"],
    "spec": SPEC,
    "tasks": [CORE_TASK, REPORT_TASK],
}

REQUEST = {
    "project_id": "29b05257-4a24-4bd3-b48b-c313dcdb3e09",
    "expected_workspace_epoch": "f6977cc3-d759-4fb0-b5d7-c229db67c3ab",
    "authorization": {
        "source": "user_instruction:current_session",
        "text": "\n".join([
            "使用 Evolve 修改当前活动方案：report.render 的 include_mean=True 分支增加均值，格式固定为 total=5; count=2; mean=2.50，保留两位小数；空输入 mean=0.00。默认 False 的原文本和 total／summarize 接口与行为保持。",
            "控制侧新增的 test_report_mean.py 是只读独立判据，原测试继续保持。",
            "本轮仅呈现并保存完整新 REV；原有 AC 保留，新增可选均值 AC，REPORT 负责该成果，CORE 的原定义和适用结果应保留。",
            "说明影响并保留旧整体验收及原证明，本轮不接受新语义方案、不实施、运行检查或封存。",
            "REPORT 需检查原 report 及新增 test_report_mean，最终 discover 全部测试；可按实际命令增量登记 mean 检查。",
        ]),
        "effect_kinds": ["project_records"],
        "paths": [],
    },
    "input": {
        "reason": "\n".join([
            "控制侧新增只读独立判据 test_report_mean.py，要求 report.render 在 include_mean=True 时追加固定两位小数的均值（'total=5; count=2; mean=2.50'，空输入 mean=0.00），默认 False 的原文本与 total／summarize 接口保持不变。",
            "据此修订当前 REV：原有四条 AC 保留并新增可选均值 AC，REPORT 承接该成果并把 mean 纳入其必需检查，CORE 的原定义与已保存结果继续适用。",
        ]),
        "impact": {
            "affected_tasks": ["REPORT"],
            "basis": "\n".join([
                "本次 spec 变化只增加报告侧的可选均值承诺：arithmetic.total 与 arithmetic.summarize 的名称、签名与返回值不变，arithmetic.py 的内容与摘要不受影响。",
                "CORE 的必需检查（original、summary）、判据输入（test_arithmetic.py、test_summary.py）与已保存的原行为前后证明仍然适用，其定义与结果无需改动。",
                "均值行为、mean 判据与新增 AC 全部落在 report.py 范围内，由 REPORT 承担，因此 spec 影响仅限 REPORT。",
            ]),
        },
        "proposal": {
            "complexity": "complex",
            **DOCUMENT,
            "presentation": {
                "source": "user_instruction:current_session",
                "document": DOCUMENT,
            },
        },
    },
}

with open(OUT, "w", encoding="utf-8") as handle:
    json.dump(REQUEST, handle, ensure_ascii=False, indent=2)
print("written", OUT)
print("acceptance keys:", [item["key"] for item in DOCUMENT["acceptance"]])
print("required_checks:", DOCUMENT["required_checks"])
print("core task keys:", sorted(CORE_TASK))
print("report task keys:", sorted(REPORT_TASK))
