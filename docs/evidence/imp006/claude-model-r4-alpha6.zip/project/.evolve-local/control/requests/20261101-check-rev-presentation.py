"""Read back the revised work item and its preserved progress from Evolve's own output."""
import json
import subprocess

ROOT = "/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r4/business"
PLUGIN = ROOT + "/.agents/evolve-acceptance/profile/plugins/cache/evolve-local/evolve/0.1.0-alpha.6"
CHANGE_ID = "673dd437-7f2a-4a41-b64d-e70e6a4d908d"


def cli(action, target=None):
    cmd = ["python3", "-B", PLUGIN + "/runtime/evolve.py", "--project", ROOT, action]
    if target:
        cmd.append(target)
    return json.loads(subprocess.run(cmd, capture_output=True, text=True, check=True).stdout)


status = cli("status", CHANGE_ID)
change = status["data"]["project"]["changes"][0]
plan = change["plan"]
doc = plan["document"]
print("== status ==")
print("change title      :", change["title"])
print("current_revision  :", change["current_revision"], "ordinal", plan["ordinal"])
print("revision accepted :", plan["accepted"])
print("plan_digest       :", plan["digest"])
print("definition_digest :", change["definition_digest"])
print("plan title        :", doc["title"])
print("plan text         :", doc["plan"][:120].replace("\n", " / "), "...")
print("scope             :", doc["scope"])
print("required_checks   :", doc["required_checks"])
print("acceptance keys   :", [a["key"] for a in doc["acceptance"]])
for task in change["tasks"]:
    print("task", task["task_code"], task["local_key"], "| state:", task["state"],
          "| digest:", task["definition_digest"][:16], "| title:", task["definition"]["title"])
print("latest_verification:", change["latest_verification"])

resumed = cli("resume", CHANGE_ID)
context = resumed["data"]["context"]
print("\n== resume task contexts ==")
for item in context["task_contexts"]:
    result = item["result"]
    print("--", item["local_key"], item["state"])
    if result:
        print("   checks          :", result.get("checks"))
        print("   preservation    :", json.dumps(result.get("preservation"), ensure_ascii=False))
        progress = result.get("progress") or {}
        print("   completed       :", len(progress.get("completed", [])), "items")
        print("   remaining       :", len(progress.get("remaining", [])), "items")
        print("   next_steps      :", len(progress.get("next_steps", [])), "items")
        print("   scope digest    :", json.dumps(result["fingerprint"]["scope"], ensure_ascii=False))
    else:
        print("   no saved result yet")
    print("   current scope   :", json.dumps(item["workspace_observation"]["current"]["scope"], ensure_ascii=False))

print("\n== runs ==")
for run in context["runs"]:
    print(run["action"], run["status"], "outcome:", (run.get("result") or {}).get("outcome"),
          "| auth effects:", run["authorization"]["effect_kinds"], "| revoked:", run["authorization_revoked"])
