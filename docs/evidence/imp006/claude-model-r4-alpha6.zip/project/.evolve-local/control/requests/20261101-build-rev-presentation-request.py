"""Build the update.revise request that only refreshes the presented plan wording."""
import json
import subprocess
from pathlib import Path

ROOT = "/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r4/business"
PLUGIN = ROOT + "/.agents/evolve-acceptance/profile/plugins/cache/evolve-local/evolve/0.1.0-alpha.6"
REQUEST_PATH = ROOT + "/.evolve-local/control/requests/20261101-rev-presentation.json"
CHANGE_TITLE = "提取共享的 arithmetic.summarize 并让 report.render 复用它"

NEW_TITLE = "单次迭代汇总与报告"

NEW_PLAN = (
    "本轮只做一件事：把「一次遍历同时算出总和与数量」做成算术模块与报告模块共用的同一个接口，两个模块不再各自重复聚合逻辑。\n"
    "1）共享接口：在 arithmetic.py 中新增 arithmetic.summarize(values)，一次遍历输入并返回 (总和, 数量)；arithmetic.total(values) 的现有行为保持不变。\n"
    "2）报告复用：report.py 的 render(values, include_mean=False) 改为调用该共享接口，一次遍历即生成 'total=5; count=2' 形式的文本。\n"
    "3）实施顺序：任务 CORE 只涉及 arithmetic.py，先用登记检查 original 证明 total 的原行为，再形成共享 summarize；任务 REPORT 只涉及 report.py，须在 CORE 的独立任务验收通过之后才开始。\n"
    "4）验收方式：两个任务各自通过独立任务验收后，再以登记检查 integration（python3 -B -m unittest discover -v）执行整项集成检查，并逐条核对上述验收条件。"
)

NEW_TASK_TITLES = {
    "CORE": "任务一：在算术模块提取共享的 summarize 接口，同时保持 total 原行为不变",
    "REPORT": "任务二：让报告模块改用共享 summarize 生成 total 与 count 文本",
}

AUTHORIZATION_TEXT = (
    "使用 Evolve 仅修订当前完整方案的展示：将方案标题改为“单次迭代汇总与报告”，让 plan 摘要更清楚，"
    "并将两个任务的展示标题写得易懂。目标、完成条件、AC、测试决定、范围、依赖和检查含义全部保持；"
    "沿原已接受依据保存新的 REV。保留部分进度、授权及原行为证明。本轮不实施、不运行检查、不写业务或测试。"
)

REASON = (
    "按用户本轮要求，只修订完整方案的展示：方案标题改为“单次迭代汇总与报告”，plan 摘要改写得更清楚，"
    "两个任务的展示标题改为易懂表述。目标、完成条件、验收条件、测试决定、范围、依赖与检查含义全部保持不变，"
    "沿原已接受依据保存新的 REV；本轮不实施、不运行检查、不写业务或测试文件。"
)


def main():
    raw = subprocess.run(
        ["python3", "-B", PLUGIN + "/runtime/evolve.py", "--project", ROOT, "status", CHANGE_TITLE],
        capture_output=True, text=True, check=True).stdout
    status = json.loads(raw)
    changes = status["data"]["project"]["changes"]
    if len(changes) != 1:
        raise SystemExit("expected exactly one work item, got " + str(len(changes)))
    old = changes[0]["plan"]["document"]

    new = json.loads(json.dumps(old))
    new["title"] = NEW_TITLE
    new["plan"] = NEW_PLAN
    for task in new["tasks"]:
        task["title"] = NEW_TASK_TITLES[task["local_key"]]

    unchanged = {key: old[key] == new[key] for key in old}
    print(json.dumps({"title": new["title"], "plan": new["plan"],
                      "task_titles": {t["local_key"]: t["title"] for t in new["tasks"]},
                      "unchanged_fields": unchanged}, ensure_ascii=False, indent=2))

    presentation = {"source": "user_instruction:current_session", "text": AUTHORIZATION_TEXT,
                    "document": {key: new[key] for key in ("title", "plan", "completion", "scope",
                                                          "acceptance", "required_checks", "spec", "tasks")}}
    proposal = {
        "complexity": "complex",
        "title": new["title"],
        "plan": new["plan"],
        "completion": new["completion"],
        "scope": new["scope"],
        "acceptance": new["acceptance"],
        "required_checks": new["required_checks"],
        "spec": new["spec"],
        "tasks": new["tasks"],
        "presentation": presentation,
    }
    request = {
        "authorization": {"source": "user_instruction:current_session", "text": AUTHORIZATION_TEXT,
                          "effect_kinds": ["project_records"], "paths": []},
        "input": {
            "change_id": changes[0]["id"],
            "reason": REASON,
            "proposal": proposal,
        },
    }
    Path(REQUEST_PATH).write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
    print("request written: " + REQUEST_PATH)


main()
