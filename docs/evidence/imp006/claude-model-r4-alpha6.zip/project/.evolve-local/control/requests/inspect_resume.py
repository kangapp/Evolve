import json, sys

path = "/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r4/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r4-business/17446b8d-ed47-4322-8a7b-975ccc574aa0/tool-results/b0f0z9zgq.txt"

data = json.load(open(path))
ctx = data["data"]["context"]
print("TOP KEYS:", sorted(ctx.keys()))
for key in ctx:
    value = ctx[key]
    if key in ("project",):
        continue
    print("\n=== " + key + " ===")
    text = json.dumps(value, ensure_ascii=False, indent=2)
    print(text[:6000])
