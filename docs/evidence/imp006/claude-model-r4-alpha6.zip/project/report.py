from arithmetic import summarize


def render(values, include_mean=False):
    total_value, count = summarize(values)
    return f"total={total_value}; count={count}"
