import json
from pathlib import Path

SRC = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r5-business/65197b8d-5e4a-418d-add8-b764309e3b81/tool-results/b4uktj8lw.txt")

data = json.loads(SRC.read_text(encoding="utf-8"))["data"]
ctx = data["context"]

print("== top-level context keys ==")
print(sorted(ctx.keys()))

print("\n== runs / history keys ==")
for key in ctx:
    if key not in ("project", "selection", "target_kind"):
        value = ctx[key]
        if isinstance(value, list):
            print(key, "list len", len(value))
        elif isinstance(value, dict):
            print(key, "dict keys", sorted(value.keys()))
        else:
            print(key, repr(value)[:200])
