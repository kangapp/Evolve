import json
from pathlib import Path

SRC = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r5-business/65197b8d-5e4a-418d-add8-b764309e3b81/tool-results/b4uktj8lw.txt")

data = json.loads(SRC.read_text(encoding="utf-8"))["data"]
ctx = data["context"]

print("========== RUNS ==========")
for run in ctx["runs"]:
    print("---")
    for key, value in run.items():
        if isinstance(value, (dict, list)):
            print(f"{key}: {json.dumps(value, ensure_ascii=False)[:1500]}")
        else:
            print(f"{key}: {value}")

print("\n========== TASK CONTEXTS ==========")
for tc in ctx["task_contexts"]:
    print("---")
    for key, value in tc.items():
        if isinstance(value, (dict, list)):
            print(f"{key}: {json.dumps(value, ensure_ascii=False)[:2000]}")
        else:
            print(f"{key}: {value}")
