import copy
import json
from pathlib import Path

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business")
STATUS = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r5-business/5030e53a-874b-4724-98c5-a87bfd1d383f/tool-results/bcnezas78.txt")

status = json.loads(STATUS.read_text(encoding="utf-8"))
project = status["data"]["project"]
change = project["changes"][0]
document = change["plan"]["document"]

NEW_TITLE = "单次迭代汇总与报告"
NEW_PLAN = (
    "本方案让报告与算术模块共用同一份「总和与数量」汇总语义，分两个有依赖的任务实施。"
    "任务一 CORE（范围仅 arithmetic.py，属预重构）：先用已登记检查 original 证明 arithmetic.total 的现有行为，"
    "再在同一次实施中新增 summarize(values)，单次遍历输入返回 (总和, 数量)；"
    "随后用 original 与 summary 两项检查确认原行为未变且新接口符合判据，形成前后行为证明。"
    "任务二 REPORT（范围仅 report.py）：在 CORE 的独立任务验收通过后，让 report.render(values, include_mean=False) "
    "通过 from arithmetic import summarize 复用同一接口，单次遍历输入并输出 \"total=..; count=..\" 形式的文本，"
    "用 report 检查确认三种输入的文本。"
    "最后以 integration 检查（python3 -B -m unittest discover -v）在全部六个文件上完成整项集成验收；单项任务通过不等于整项交付。"
)
NEW_TASK_TITLES = {
    "CORE": "任务一：在 arithmetic.py 新增共享 summarize 接口，保持 total 行为不变",
    "REPORT": "任务二：在 report.py 复用共享 summarize，输出 total 与 count 报告文本",
}

new_document = copy.deepcopy(document)
new_document["title"] = NEW_TITLE
new_document["plan"] = NEW_PLAN
for task in new_document["tasks"]:
    task["title"] = NEW_TASK_TITLES[task["local_key"]]

proposal = {"complexity": "complex"}
proposal.update(new_document)
proposal["presentation"] = {
    "source": "本轮用户指令（宿主对话，2026-11-01）：仅修订方案展示",
    "document": new_document,
}

request = {
    "request_id": "revise-display-20261101-plan-title",
    "project_id": project["project_id"],
    "expected_workspace_epoch": project["workspace_epoch"],
    "expected_versions": {
        "change": change["row_version"],
        "tasks": {task["id"]: task["row_version"] for task in change["tasks"]},
    },
    "authorization": {
        "source": "本轮用户指令（宿主对话，2026-11-01）",
        "text": (
            "使用 Evolve 仅修订当前完整方案的展示：将方案标题改为「单次迭代汇总与报告」，让 plan 摘要更清楚，"
            "并将两个任务的展示标题写得易懂。目标、完成条件、AC、测试决定、范围、依赖和检查含义全部保持；"
            "沿原已接受依据保存新的 REV。保留部分进度、授权及原行为证明。本轮不实施、不运行检查、不写业务或测试。"
        ),
        "effect_kinds": ["project_records"],
        "paths": [],
    },
    "input": {
        "change_id": change["id"],
        "revision_id": change["current_revision"],
        "definition_digest": change["definition_digest"],
        "task_id": None,
        "reason": (
            "只调整当前已接受方案的展示：方案标题、plan 摘要表述与两个任务的展示标题。"
            "目标、完成条件、四条 AC、spec 全部字段（含测试决定、目标、非目标、行为、约束、取舍）、"
            "文件范围、任务依赖与已登记检查含义均不变，沿原已接受依据保存新的 REV；"
            "已保存的部分进度、授权与原 total 前后行为证明保持。"
        ),
        "proposal": proposal,
    },
}

target = ROOT / ".evolve-local/control/requests/revise-display-20261101.json"
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")

unchanged = [key for key in document if key not in ("title", "plan") and document[key] != new_document[key]]
changed_tasks = {
    task["local_key"]: (document["tasks"][index]["title"], task["title"])
    for index, task in enumerate(new_document["tasks"])
    if document["tasks"][index]["title"] != task["title"]
}
print(target)
print("unchanged_top_level_keys:", unchanged)
print("changed_task_titles:", json.dumps(changed_tasks, ensure_ascii=False))
print("scope:", new_document["scope"], "required_checks:", new_document["required_checks"])
