import json
from pathlib import Path

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business")

AUTHORIZATION_TEXT = (
    "本轮用户指令（宿主对话，2026-11-01）：沿 Evolve 档案恢复的当前完整方案与既有授权继续，"
    "完成 CORE 的原后检查与独立任务验收、实施 REPORT、运行任务检查与最终 integration、"
    "并完成逐 AC 与规格／规范审查。本轮完成整体验收后停止，不封存，保留活动工作项；不改原测试或正式知识。"
)

CORE_APPLY_RUN = "04eae7ee-ae30-4be0-b7ff-b4b0df869520"
CORE_APPLY_DIGEST = "a31b98f9b5e81e4423f8a1b08cef8d3e42c0b8ad963c42ead2245e026c46e022"
CORE_EVIDENCE = [
    "86b60a7a-207f-4039-b081-d2857c9b9644",
    "631e0f4f-d1f6-4a58-8f2c-c8c8f71032bb",
]
VERIFY_RUN = "de424006-b29c-496e-b046-b572773414a4"
VERIFY_DIGEST = "f0bc4841ecb856245fb3da7eee7ca09e12c06266e85042080592d10dd02a276d"

experience_request = {
    "input": {
        "source": {
            "run_id": CORE_APPLY_RUN,
            "result_digest": CORE_APPLY_DIGEST,
            "evidence_ids": CORE_EVIDENCE,
        },
        "sources": [
            {
                "run_id": CORE_APPLY_RUN,
                "result_digest": CORE_APPLY_DIGEST,
                "evidence_ids": CORE_EVIDENCE,
            }
        ],
        "experience": {
            "topic": "预重构任务在文件段暂停后的续接与后检查配对",
            "problem": (
                "CORE 是 pre_refactor 任务：改写前已单独保存原 total 行为的原证明，arithmetic.py 已改写并正常暂停"
                "（checks=not_run、preservation.status=pending_after）。换会话恢复后，original 与 summary 两项后检查"
                "必须与既有原证明配成同一组前后行为证明，否则任务不能记 done、也不能作为 REPORT 的上游。"
            ),
            "advice": (
                "本次实际走通的续接做法：在同一次 apply 中把该文件以当前字节重新提交为本次候选文件"
                "（expected_digest 用当前摘要、content 用当前字节），随后运行该任务的两项已登记检查；"
                "执行后 preservation.status 由 pending_after 变为 passed，after_evidence_ids 指向本次运行的 original 检查证据。"
                "原证明沿用暂停前保存的 before 事件（run a4e0b300 / event 0ab58155-db9a-45ce-ae3e-a459f91df455），"
                "不在已改代码上重跑所谓原始基线。"
            ),
            "applicability": (
                "本项目后续任何 pre_refactor 任务在文件段暂停后，需要完成后检查并让前后行为证明配对的续接场景。"
            ),
            "version_context": (
                "evolve 0.1.0-alpha.6；项目 business（project_id 18941c6e-6237-4ba5-a8d8-8a8d56788a21）；"
                "工作项 CHG-20261031-b622d0fe，修订 b8f0780c-f2c3-4a8a-98a2-9ce83c922df6；任务 TASK-001（CORE）。"
            ),
            "observer": "宿主 AI（Claude Code）本轮实际执行与观察",
            "scope": [
                "CORE（arithmetic.py）预重构暂停后的续接",
                "已登记检查 original 与 summary",
                "前后行为证明的 before/after 证据配对",
            ],
            "exclusions": [
                "不适用于非 pre_refactor 任务的普通续接",
                "不改动任何测试判据、正式知识或其他工作项",
                "不构成对其他项目或别的检查组合的通用结论",
            ],
            "tags": ["pre_refactor", "行为保持证明", "暂停续接", "任务检查"],
            "limitations": [
                "只覆盖本次 CORE 任务实际执行的续接路径与两项已登记检查；"
                "未验证不带候选文件的纯检查续接是否可行，故只记录本次实际走通的路径，不宣称它是唯一可行路径。",
                "未在别的项目、别的检查组合或别的预重构任务上复现。",
                "这是候选经验，不是正式规则；实际同类任务中需核对当前代码与检查配置后再决定是否采用。",
            ],
            "cause": {
                "statement": (
                    "本次续接把 arithmetic.py 的相同字节作为候选文件重新提交、并在同一次运行中运行 original 与 summary "
                    "两项检查后，preservation.status 由 pending_after 变为 passed，after_evidence_ids 指向本次运行的 "
                    "original 检查证据（86b60a7a-207f-4039-b081-d2857c9b9644）。"
                ),
                "confidence": "observed",
            },
        },
    },
    "authorization": {
        "source": "本轮用户指令（宿主对话，2026-11-01）",
        "text": AUTHORIZATION_TEXT,
        "effect_kinds": ["project_records"],
        "paths": [],
    },
}

no_new_learning_request = {
    "input": {
        "source": {"run_id": VERIFY_RUN, "result_digest": VERIFY_DIGEST},
        "checked_basis": (
            "整项验收已实际执行并通过：integration 检查（python3 -B -m unittest discover -v）在四个测试模块上 4 个测试全部通过；"
            "逐 AC 复核了 AC-TOTAL-UNCHANGED、AC-SHARED-SUMMARY、AC-REPORT-TEXT、AC-SINGLE-PASS 四条必需条件，"
            "规格轴与规范轴各一条 review 结论，未发现必需问题。"
            "唯一登记的非必需观察（report.render 的 include_mean 仍被忽略）是方案 spec.non_goals 明确排除的范围，"
            "不构成新的可复用经验；core 侧的唯一遗留（total 与 summarize 两条累加路径并存）是已接受 spec.tradeoffs 的取舍，"
            "已在本次整项复核中重新确认。故本轮整体验收后没有新的可复用发现。"
        ),
        "observer": "宿主 AI（Claude Code）本轮实际检查与复核",
    },
    "authorization": {
        "source": "本轮用户指令（宿主对话，2026-11-01）",
        "text": AUTHORIZATION_TEXT,
        "effect_kinds": ["project_records"],
        "paths": [],
    },
}

first = ROOT / ".evolve-local/control/requests/learn-record-core-continuation-20261101.json"
second = ROOT / ".evolve-local/control/requests/learn-retro-whole-acceptance-20261101.json"
first.write_text(json.dumps(experience_request, ensure_ascii=False, indent=2), encoding="utf-8")
second.write_text(json.dumps(no_new_learning_request, ensure_ascii=False, indent=2), encoding="utf-8")
print(first)
print(second)
