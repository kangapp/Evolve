import json
from pathlib import Path

SRC = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r5-business/65197b8d-5e4a-418d-add8-b764309e3b81/tool-results/buoq1siz0.txt")

data = json.loads(SRC.read_text(encoding="utf-8"))["data"]
project = data["project"]

print("project.state:", project["state"])
print("pending_runs:", project["pending_runs"])
print("knowledge_refs:", project["knowledge_refs"], "pending_knowledge:", project["pending_knowledge"])
for change in project["changes"]:
    print("change", change["code"], change["title"], "state=", change["state"], "revision=", change["current_revision"], "rv=", change["row_version"])
    for task in change["tasks"]:
        print("  task", task["local_key"], task["task_code"], "state=", task["state"], "unmet=", task["readiness"]["unmet"])
    print("  latest_verification:", json.dumps(change.get("latest_verification"), ensure_ascii=False)[:1200])
