import json
from pathlib import Path

SRC = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r5-business/65197b8d-5e4a-418d-add8-b764309e3b81/tool-results/bx63qukk0.txt")

ctx = json.loads(SRC.read_text(encoding="utf-8"))["data"]["context"]

print("suggested_action:", ctx["suggested_action"], "suggested_task_id:", ctx["suggested_task_id"])
print()
for task in ctx["project"]["changes"][0]["tasks"]:
    print("task", task["local_key"], task["id"], "state=", task["state"], "row_version=", task["row_version"],
          "ready=", task["readiness"]["ready"], "unmet=", task["readiness"]["unmet"])
print()
for tc in ctx["task_contexts"]:
    obs = tc["workspace_observation"]
    print("TASK", tc["local_key"], "state=", tc["state"], "fingerprint_digest=", obs.get("current", {}).get("digest"))
    print("   task_basis_digest=", obs.get("current", {}).get("task_basis_digest"))
    result = tc["result"] or {}
    print("   result_checks=", result.get("checks"), "preservation=", (result.get("preservation") or {}).get("status"))
    print("   check_evidence=", result.get("check_evidence"))
    print("   scope=", obs.get("current", {}).get("scope"))
print()
whole = ctx["workspace_observation"]
print("WHOLE-CHANGE fingerprint_digest=", whole.get("current", {}).get("digest"))
print("WHOLE scope=", whole.get("current", {}).get("scope"))
print("WHOLE context=", whole.get("current", {}).get("context"))
print("WHOLE checks=", whole.get("current", {}).get("checks"))
print("WHOLE scope_changes=", whole.get("scope_changes"))
print()
print("verifications:", json.dumps(ctx["verifications"], ensure_ascii=False)[:1500])
print()
print("learning_context:", json.dumps(ctx["learning_context"], ensure_ascii=False)[:1500])
