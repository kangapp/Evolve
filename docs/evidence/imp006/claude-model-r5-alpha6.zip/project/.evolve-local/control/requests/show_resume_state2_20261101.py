import json
from pathlib import Path

SRC = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r5-business/65197b8d-5e4a-418d-add8-b764309e3b81/tool-results/b7p4zamyd.txt")

ctx = json.loads(SRC.read_text(encoding="utf-8"))["data"]["context"]

print("suggested_action:", ctx["suggested_action"], "suggested_task_id:", ctx["suggested_task_id"])
for task in ctx["project"]["changes"][0]["tasks"]:
    print("task", task["local_key"], "state=", task["state"], "rv=", task["row_version"], "ready=", task["readiness"]["ready"], "unmet=", task["readiness"]["unmet"])
print()
for tc in ctx["task_contexts"]:
    obs = tc["workspace_observation"]["current"]
    print("TASK", tc["local_key"], "state=", tc["state"], "digest=", obs["digest"], "task_basis_digest=", obs["task_basis_digest"])
    print("   scope=", obs["scope"])
    print("   dependency_inputs=", {k: v for k, v in obs.get("task_basis_digest", "").items()} if isinstance(obs.get("task_basis_digest"), dict) else "")
print()
whole = ctx["workspace_observation"]["current"]
print("WHOLE digest=", whole["digest"])
print("WHOLE scope=", whole["scope"])
print("WHOLE scope_changes=", ctx["workspace_observation"]["scope_changes"])
print()
for v in ctx["verifications"]:
    print("VERIFICATION", v["id"], "task=", v["applies_to_task_id"], "status=", v["recorded_status"], "at=", v["observed_at"])
