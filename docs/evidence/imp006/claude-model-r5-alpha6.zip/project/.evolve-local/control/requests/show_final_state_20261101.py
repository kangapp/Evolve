import json
from pathlib import Path

SRC = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp006-native-preparation-mui6k3af-claude-execution-r5-business/65197b8d-5e4a-418d-add8-b764309e3b81/tool-results/b3wj7jjs1.txt")

ctx = json.loads(SRC.read_text(encoding="utf-8"))["data"]["context"]

print("suggested_action:", ctx["suggested_action"])
for task in ctx["project"]["changes"][0]["tasks"]:
    print("task", task["local_key"], "state=", task["state"], "unmet=", task["readiness"]["unmet"])
print()
for run in ctx["runs"]:
    print(run["action"], run["run_id"], run["status"], "digest=", run["result_digest"], "learning=", run["learning"]["status"])
print()
for v in ctx["verifications"]:
    print("VERIFICATION", v["id"], "scope_task=", v["applies_to_task_id"], "status=", v["recorded_status"])
print()
print("learning_context:", json.dumps(ctx["learning_context"], ensure_ascii=False)[:2000])
