import json
from pathlib import Path

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business")

FINGERPRINT = "c95283db97ea4e774bdf5133f37cf613ac1a09d10d3f8979ae2c1410b53a474b"
OBSERVER = "宿主 AI 自审（Claude Code，evolve-verify 实际读取字节并实际运行检查）"

AUTHORIZATION_TEXT = (
    "本轮用户指令（宿主对话，2026-11-01）：沿 Evolve 档案恢复的当前完整方案与既有授权继续。"
    "先完成 CORE 的原后检查（original 与 summary）并形成与既有原证明配对的前后行为证明，"
    "再做 CORE 的独立任务验收；在 CORE 验收通过后实施 REPORT，运行 report 任务检查；"
    "最后运行整项 integration 检查并做逐 AC 的规格审查与规范／维护性审查。"
    "原范围内发现必需问题可修正复验。本轮完成整体验收后停止，不封存，保留活动工作项供下一轮明确需求修订；"
    "不改原测试文件，不批准正式知识，不做部署或提交。"
)

spec_review = {
    "axis": "spec",
    "observer": OBSERVER,
    "summary": (
        "对整项「单次迭代汇总与报告」的 4 条必需验收条件逐条核对。我实际读取了当前全部业务文件字节："
        "arithmetic.py（206 字节，摘要 fc514e81f9d19a1b88053f144d33f5247bb59609d356cc04405cd82e9c896f30）与 "
        "report.py（167 字节，摘要 56b3c72c715748bfcb628259e6ab493b2b0a1fa10c11ab80caaa3f1eb70a7a31），"
        "四个测试文件摘要与原行为证明保留下来的判据快照一致（test_arithmetic.py 453a1383…、"
        "test_summary.py caaa3045…、test_report.py c2e08a7e…、test_integration.py 0e391642…），均未改写、未删除、未放宽。"
        "我另外在本次验收前直接运行了已登记的整项 integration 检查（python3 -B -m unittest discover -v），"
        "实际结果为 4 个测试全部通过（Ran 4 tests，OK）；本次验收请求自身会再由运行时独立执行同一登记检查并留存证据。"
    ),
    "fingerprint_digest": FINGERPRINT,
    "acceptance_results": [
        {
            "ac_id": "AC-001",
            "status": "passed",
            "basis": (
                "AC-TOTAL-UNCHANGED：实际字节显示 arithmetic.total 仍是 `def total(values): return sum(values)`，"
                "与预重构前一致，签名、语义、返回值均未改。改写前的 original 检查在原代码上通过；"
                "CORE 任务验收（verification 76277a43-2297-4d2a-9086-8ab256a27939）在改写后的代码上重新运行"
                "original 检查并通过（证据 55f8e4e0-3997-4166-8272-0fa209281165，返回码 0），"
                "与既有原证明配对成立（preservation.status=passed）。判据 test_arithmetic.py 的四个断言原样保留。"
                "证明仅覆盖该已登记检查与该判据输入，不外推为未测行为保证。"
            ),
        },
        {
            "ac_id": "AC-002",
            "status": "passed",
            "basis": (
                "AC-SHARED-SUMMARY：实际字节显示 summarize 以单个 for 循环同时累加 total_value 与 count 并返回 "
                "(total_value, count)，只消费输入迭代器一次，负值按原值参与总和，空输入得到 (0, 0)。"
                "summary 检查（python3 -B -m unittest test_summary -v）在 CORE 任务验收中实际通过、返回码 0，"
                "证据 b016731b-66d1-4e80-8d3e-79b025cb634f；本次整项 integration 检查也在同一批 4 个测试中再次通过。"
            ),
        },
        {
            "ac_id": "AC-003",
            "status": "passed",
            "basis": (
                "AC-REPORT-TEXT：实际字节显示 report.render 通过 `from arithmetic import summarize` 复用共享接口，"
                "单次调用后返回 f\"total={total_value}; count={count}\"。report 检查"
                "（python3 -B -m unittest test_report -v）在 REPORT 实施中实际通过、返回码 0，"
                "证据 2ec4f386-26a8-43bc-bbda-bf8861fcca52，断言覆盖 render(iter([2,3]))==\"total=5; count=2\"、"
                "render(iter([]))==\"total=0; count=0\"、render(iter([-2,3]))==\"total=1; count=2\"；"
                "本次整项 integration 检查再次在同一批测试中通过。"
            ),
        },
        {
            "ac_id": "AC-004",
            "status": "passed",
            "basis": (
                "AC-SINGLE-PASS：实际字节显示 render 把 values 原样交给 summarize，未做 list()、len() 或任何预先物化，"
                "因此输入迭代器只被消费一次，且 render 内只有一处 summarize 调用点。"
                "共享 summarize 调用次数为 1 由 test_integration.py 以 patch(\"report.summarize\", wraps=summarize) "
                "断言 shared.call_count==1 并断言 render(iter([5,-2]))==\"total=3; count=2\"；"
                "我在本次验收前直接运行整项 integration 检查（python3 -B -m unittest discover -v）实际观察到 "
                "test_shared_single_pass_boundary 通过，4 个测试全部通过、返回码 0。"
            ),
        },
    ],
    "findings": [],
}

standards_review = {
    "axis": "standards",
    "observer": OBSERVER,
    "summary": (
        "对整项改动做规范／维护性复核。我实际读取 arithmetic.py 与 report.py 的当前全部字节并对照已接受的 spec 复核："
        "改动范围严格限于授权的 arithmetic.py 与 report.py，四个测试文件与 evolve/config.toml 未被改动；"
        "两个模块只依赖 Python 标准库，未引入第三方依赖；共享汇总语义只有 arithmetic.summarize 一个来源，"
        "report.py 内没有重复实现累加逻辑，满足既定约束；命名、缩进与模块结构与项目既有风格一致；"
        "没有遗留调试输出、占位文本或无用导入。"
        "本轮唯一已知遗留是 include_mean 参数仍未定义语义，属方案明确的非目标，不构成必需问题。"
    ),
    "fingerprint_digest": FINGERPRINT,
    "findings": [
        {
            "id": "STD-ALL-01",
            "path": "report.py",
            "basis": (
                "实际字节显示 render 的 include_mean 参数当前被完全忽略，函数体没有任何均值分支；"
                "方案 spec.non_goals 已明确「本轮不实现 include_mean=True 的均值输出，也不定义其文本格式」，"
                "spec.open_questions 的 Q-MEAN-FORMAT 记录该格式留待后续方案确定。"
            ),
            "impact": (
                "非必需：这是本轮明确排除的范围，不构成缺陷，也不削弱任何必需验收条件；"
                "仅作为下一轮明确需求时的既有上下文保留，本轮不改。"
            ),
            "blocking": False,
        }
    ],
    "resolutions": [
        {
            "verification_id": "76277a43-2297-4d2a-9086-8ab256a27939",
            "axis": "standards",
            "finding_id": "STD-CORE-01",
            "basis": (
                "在整项范围内重新读取 arithmetic.py 当前字节（206 字节，摘要 fc514e81f9d19a1b88053f144d33f5247bb59609d356cc04405cd82e9c896f30）确认："
                "total 与 summarize 两条累加路径仍并存，与 CORE 任务验收时的观察一致。"
                "该重复是已接受 spec.tradeoffs 中为满足 total 行为不变硬约束而明确选定的取舍，"
                "不是需要修复的缺陷；本轮维持原状并作为下一轮可评估的收敛点保留。"
            ),
        }
    ],
}

request = {
    "input": {
        "change_id": "b622d0fe-bdf2-46b6-8195-17ede97cf8aa",
        "reviews": [spec_review, standards_review],
    },
    "authorization": {
        "source": "本轮用户指令（宿主对话，2026-11-01）",
        "text": AUTHORIZATION_TEXT,
        "effect_kinds": ["project_records", "checks"],
        "paths": [],
    },
}

target = ROOT / ".evolve-local/control/requests/verify-whole-change-20261101.json"
target.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
print(target)
