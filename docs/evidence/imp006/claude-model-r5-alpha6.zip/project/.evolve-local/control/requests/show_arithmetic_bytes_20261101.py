from pathlib import Path

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business")
for name in ("arithmetic.py", "report.py"):
    print("=====", name)
    print(repr((ROOT / name).read_bytes().decode("utf-8")))
