import hashlib
import json
from pathlib import Path

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business")

AUTHORIZATION_TEXT = (
    "本轮用户指令（宿主对话，2026-11-01）：沿 Evolve 档案恢复的当前完整方案与既有授权继续。"
    "先完成 CORE 的原后检查（original 与 summary）并形成与既有原证明配对的前后行为证明，"
    "再做 CORE 的独立任务验收；在 CORE 验收通过后实施 REPORT，运行 report 任务检查；"
    "最后运行整项 integration 检查并做逐 AC 的规格审查与规范／维护性审查。"
    "原范围内发现必需问题可修正复验。本轮完成整体验收后停止，不封存，保留活动工作项供下一轮明确需求修订；"
    "不改原测试文件，不批准正式知识，不做部署或提交。"
)

raw = (ROOT / "arithmetic.py").read_bytes()

request = {
    "input": {
        "change_id": "b622d0fe-bdf2-46b6-8195-17ede97cf8aa",
        "task_key": "CORE",
        "files": [
            {
                "path": "arithmetic.py",
                "expected_digest": hashlib.sha256(raw).hexdigest(),
                "content": raw.decode("utf-8"),
            }
        ],
    },
    "authorization": {
        "source": "本轮用户指令（宿主对话，2026-11-01）",
        "text": AUTHORIZATION_TEXT,
        "effect_kinds": ["project_records", "business_files", "checks"],
        "paths": ["arithmetic.py", "report.py"],
    },
}

target = ROOT / ".evolve-local/control/requests/apply-core-after-checks-20261101.json"
target.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
print(target)
print("expected_digest:", request["input"]["files"][0]["expected_digest"])
print("content_bytes:", len(raw))
