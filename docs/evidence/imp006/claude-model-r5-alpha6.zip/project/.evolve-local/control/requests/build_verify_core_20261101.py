import json
from pathlib import Path

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp006-native-preparation-mui6k3af/claude-execution-r5/business")

FINGERPRINT = "a7e7c46666b2974824adc82a2d65d4fe90de33e9496fadb0ae7e7bdbdd5259c7"
OBSERVER = "宿主 AI 自审（Claude Code，evolve-verify 实际读取字节并实际运行检查）"

AUTHORIZATION_TEXT = (
    "本轮用户指令（宿主对话，2026-11-01）：沿 Evolve 档案恢复的当前完整方案与既有授权继续。"
    "先完成 CORE 的原后检查（original 与 summary）并形成与既有原证明配对的前后行为证明，"
    "再做 CORE 的独立任务验收；在 CORE 验收通过后实施 REPORT，运行 report 任务检查；"
    "最后运行整项 integration 检查并做逐 AC 的规格审查与规范／维护性审查。"
    "原范围内发现必需问题可修正复验。本轮完成整体验收后停止，不封存，保留活动工作项供下一轮明确需求修订；"
    "不改原测试文件，不批准正式知识，不做部署或提交。"
)

spec_review = {
    "axis": "spec",
    "observer": OBSERVER,
    "summary": (
        "逐条核对 CORE 的两条必需验收条件。我实际读取了 arithmetic.py 的当前全部字节"
        "（206 字节，摘要 fc514e81f9d19a1b88053f144d33f5247bb59609d356cc04405cd82e9c896f30），"
        "并对照原行为证明保留下来的原判据快照（test_arithmetic.py 摘要 453a138380ec143f5febd26c2e4792feb6a00f65c9f967a3550200b3155c73d4，"
        "与证明记录的判据输入字节一致，未改写、未删除、未放宽）。"
        "本次验收请求自身会真实运行 original 与 summary 两项已登记检查。"
    ),
    "fingerprint_digest": FINGERPRINT,
    "acceptance_results": [
        {
            "ac_id": "AC-001",
            "status": "passed",
            "basis": (
                "AC-TOTAL-UNCHANGED：实际字节显示 total 仍为 `def total(values): return sum(values)`，"
                "签名与语义与预重构前一致，未新增参数、未改返回值。"
                "改写前 original 检查（python3 -B -m unittest test_arithmetic -v）在原代码上通过，"
                "改写后同一检查再次通过并与既有原证明配对（preservation.status=passed，"
                "before 事件 0ab58155-db9a-45ce-ae3e-a459f91df455，后检查证据 86b60a7a-207f-4039-b081-d2857c9b9644）；"
                "判据 test_arithmetic.py 四个断言 total([2,3])==5、total([])==0、total([-2,3])==1、total(iter([2,3]))==5 原样保留。"
                "证明只覆盖该已登记检查与该判据输入，不外推为未测行为保证。"
            ),
        },
        {
            "ac_id": "AC-002",
            "status": "passed",
            "basis": (
                "AC-SHARED-SUMMARY：实际字节显示 summarize 以单个 for 循环同时累加 total_value 与 count，"
                "返回 (total_value, count)，只消费输入迭代器一次，未做绝对值或截断，空输入自然得到 (0, 0)。"
                "summary 检查（python3 -B -m unittest test_summary -v）在本次 apply 中实际通过、返回码 0，"
                "证据 631e0f4f-d1f6-4a58-8f2c-c8c8f71032bb，断言覆盖 summarize(iter([2,3]))==(5,2)、"
                "summarize(iter([]))==(0,0)、summarize(iter([-2,3]))==(1,2)。"
            ),
        },
    ],
    "findings": [],
}

standards_review = {
    "axis": "standards",
    "observer": OBSERVER,
    "summary": (
        "复核 arithmetic.py 当前字节与本任务范围、既定约束的一致性。实际字节为 206 字节的纯标准库模块："
        "只新增 summarize 一个公共接口，total 的实现一行未动；模块未引入任何第三方依赖；"
        "命名与项目既有风格一致（与 total 同为模块级函数）；未在别处重复实现汇总逻辑；"
        "未新增文件、未触及其他业务文件或测试文件；改动范围限于授权的 arithmetic.py。"
        "结论：未发现必需问题。"
    ),
    "fingerprint_digest": FINGERPRINT,
    "findings": [
        {
            "id": "STD-CORE-01",
            "path": "arithmetic.py",
            "basis": (
                "实际字节显示模块内同时存在 total(values)=sum(values) 与 summarize(values) 两条累加路径，"
                "存在轻微重复；这是方案 spec.tradeoffs 明确选定的取舍"
                "（保留 total 以满足 total 行为不变的硬约束），不是本轮引入的缺陷。"
            ),
            "impact": (
                "非必需：不影响 total 的现有行为，也不影响 summarize 的单次遍历语义；"
                "仅记录为后续可评估的收敛点，本轮不改。"
            ),
            "blocking": False,
        }
    ],
}

request = {
    "input": {
        "change_id": "b622d0fe-bdf2-46b6-8195-17ede97cf8aa",
        "task_key": "CORE",
        "reviews": [spec_review, standards_review],
    },
    "authorization": {
        "source": "本轮用户指令（宿主对话，2026-11-01）",
        "text": AUTHORIZATION_TEXT,
        "effect_kinds": ["project_records", "checks"],
        "paths": [],
    },
}

target = ROOT / ".evolve-local/control/requests/verify-core-task-20261101.json"
target.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
print(target)
