def total(values):
    return sum(values)


def summarize(values):
    total_value = 0
    count = 0
    for value in values:
        total_value += value
        count += 1
    return (total_value, count)
