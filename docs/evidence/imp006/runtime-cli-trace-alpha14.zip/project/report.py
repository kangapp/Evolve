from arithmetic import summarize

def render(values, include_mean=False):
    result, count = summarize(values)
    return f"total={result}; count={count}"
