import copy,hashlib,json,sqlite3,subprocess,sys,tempfile
from pathlib import Path
repo=Path('/Users/liufukang/Workplace/spec-driven');lab=Path(tempfile.mkdtemp(prefix='evolve-imp006-public-replay-alpha14-')).resolve();package=lab/'package';project=lab/'business';project.mkdir();evidence=lab/'evidence';evidence.mkdir();trace=[]
build=subprocess.run([sys.executable,'-B',str(repo/'scripts/build_package.py'),'--out',str(package)],capture_output=True,text=True,check=True);manifest=json.loads((package/'evolve-package.json').read_text())
old=json.loads(Path('/tmp/evolve-imp006-context-alpha13-current.json').read_text());old_run=Path(old['lab'])/'codex-execution-r1';scope=json.loads((old_run/'evidence/expanded-scope.json').read_text())
for name,text in scope['first_files'].items():(project/name).write_text(text)
with sqlite3.connect('file:'+str(old_run/'business/evolve/history.db')+'?mode=ro',uri=True) as c:
 c.row_factory=sqlite3.Row
 old_rev=c.execute('SELECT * FROM plan_revisions ORDER BY ordinal LIMIT 1').fetchone();document=json.loads(c.execute('SELECT content FROM blobs WHERE digest=?',(old_rev['plan_digest'],)).fetchone()[0])
assert 'arithmetic.py' in next(t for t in document['tasks'] if t['local_key']=='REPORT')['context_paths']
core=(old_run/'business/arithmetic.py').read_text();report='from arithmetic import summarize\n\ndef render(values, include_mean=False):\n    result, count = summarize(values)\n    return f"total={result}; count={count}"\n'
auth={'source':'controlled-public-CLI-native-document-replay','text':'Controlled temporary replay of the exact native plan, its known implementation and retained literal tests; not a human or independent-model review.','effect_kinds':['project_records','business_files','checks'],'paths':['arithmetic.py','report.py']}
def save(name,value):(evidence/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def call(action,method,owner,data=None,target=None,*,runtime=None,expected=0):
 argv=[sys.executable,'-B',str(runtime or package/'runtime/evolve.py'),'--project',str(project),action]
 if target:argv.append(target)
 argv+=['--method',method,'--owner',owner]
 body=None
 if data is not None:argv+=['--request','-'];body=json.dumps({'authorization':auth,'input':data},ensure_ascii=False)
 r=subprocess.run(argv,input=body,capture_output=True,text=True,timeout=30);v=json.loads(r.stdout);trace.append({'argv':argv,'request':json.loads(body) if body else None,'exit_code':r.returncode,'stdout':v,'stderr':r.stderr});save('commands.json',trace);assert r.returncode==expected,(action,r.stdout,r.stderr)
 if expected==0:assert v['ok'],v
 return v['data'] if expected==0 else v
checks=[{'id':key,'argv':[sys.executable,'-B','-m','unittest',module,'-v'],'cwd':'.','timeout':30} for key,module in [('original','test_arithmetic'),('summary','test_summary'),('report','test_report'),('integration','discover')]]
call('init','connect','evolve-init',{'checks':checks})
before=(project/'evolve/history.db').read_bytes();blocked=call('propose','create','evolve-propose',{'title':'old writer attempt'},runtime=Path(old['package'])/'runtime/evolve.py',expected=2);assert blocked['error']['code']=='SCHEMA_VERSION';assert (project/'evolve/history.db').read_bytes()==before
proposal={'complexity':'complex',**document,'presentation':{'source':'controlled exact native document replay','document':document}}
planned=call('propose','create','evolve-propose',proposal);change=planned['change_id'];plan=planned['plan_digest']
prepared=call('apply','implement','evolve-apply',{'task_key':'CORE','accepted_plan_digest':plan,'files':[],'preservation_only':True},change)
paused=call('apply','implement','evolve-apply',{'task_key':'CORE','accepted_plan_digest':plan,'files':[{'path':'arithmetic.py','content':core,'expected_digest':hashlib.sha256((project/'arithmetic.py').read_bytes()).hexdigest()}],'pause':{'reason':'Controlled exact normal file pause','completed':['Original before proof retained; shared summary file written.'],'remaining':['Post checks and separate task acceptance.'],'next_steps':['Continue from this actual source.']}},change)
assert paused['checks']=='not_run'
document=copy.deepcopy(document);document['title']='单次迭代汇总与报告';document['plan']='Same declared outcomes, clearer display; preserve original total and consume the shared single-pass summary.'
for task in document['tasks']:task['title']='Display: '+task['title']
proposal={'complexity':'complex',**document,'presentation':{'source':'controlled cosmetic display replay','document':document}}
revised=call('update','revise','evolve-propose',{'reason':'Only title, plan and task display titles changed.','proposal':proposal},change);assert revised['semantic_same'] and revised['accepted'];assert set(revised['candidate']['tasks'].values())=={'same_definition'};plan=revised['plan_digest']
continued=call('apply','implement','evolve-apply',{'task_key':'CORE','accepted_plan_digest':plan,'files':[{'path':'arithmetic.py','content':core,'expected_digest':hashlib.sha256((project/'arithmetic.py').read_bytes()).hexdigest()}]},change)
assert continued['continuation']['run_id']==paused['run_id'] and continued['continuation']['resolved_from_task_result'];assert continued['preservation']['before']==prepared['preservation']['before'];assert continued['preservation']['status']=='passed'
sys.path.insert(0,str(package/'runtime'));from evolve_core.work import fingerprint
from evolve_core.structured import whole_definition

def review(key=None):
 with sqlite3.connect('file:'+str(project/'evolve/history.db')+'?mode=ro',uri=True) as c:
  c.row_factory=sqlite3.Row;rev=c.execute('SELECT * FROM plan_revisions WHERE id=(SELECT current_revision FROM changes)').fetchone();tasks=c.execute('SELECT * FROM tasks WHERE revision_id=?',(rev['id'],)).fetchall();task=next((t for t in tasks if json.loads(t['definition_json'])['local_key']==key),None);definition=json.loads(task['definition_json']) if task else whole_definition(rev,tasks)
 observed=[]
 for check in definition['checks_basis']:
  r=subprocess.run(check['argv'],cwd=project,capture_output=True,text=True,timeout=30);observed.append({'check_id':check['id'],'argv':check['argv'],'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0
 snapshot=fingerprint(project,definition);save('review-'+(key or 'whole')+'.json',{'observer':'controlled actual source/literal checks, not an independent model','fingerprint':snapshot,'checks':observed})
 reviews=[{'axis':axis,'observer':'controlled native-document public-CLI replay','summary':'Inspected actual source, preserved four readonly tests and two-file scope, and executed the declared literal checks; no independent model claim.','fingerprint_digest':snapshot['digest'],'findings':[]} for axis in ('spec','standards')];reviews[0]['acceptance_results']=[{'ac_id':a['id'],'status':'passed','basis':'Observed literal checks and actual source against the retained original criterion.'} for a in definition['acceptance']]
 result=call('verify','run','evolve-verify',{'reviews':reviews,**({'task_key':key} if key else {})},change);assert result['status']=='passed';return result
review('CORE')
call('apply','implement','evolve-apply',{'task_key':'REPORT','accepted_plan_digest':plan,'files':[{'path':'report.py','content':report,'expected_digest':hashlib.sha256((project/'report.py').read_bytes()).hexdigest()}]},change)
review('REPORT');whole=review();call('archive','close','evolve-archive',{'verification_id':whole['verification_id']},change)
for name,text in scope['first_files'].items():
 if name.startswith('test_'):assert (project/name).read_bytes()==text.encode()
with sqlite3.connect('file:'+str(project/'evolve/history.db')+'?mode=ro',uri=True) as c:
 assert c.execute('select state from changes').fetchone()[0]=='archived';assert c.execute('select count(*) from resource_claims').fetchone()[0]==0;assert c.execute("select count(*) from phase_runs where status='started'").fetchone()[0]==0
summary={'passed':True,'package_version':manifest['package_version'],'protocol_version':manifest['protocol_version'],'schema_version':manifest['schema_version'],'distribution_digest':manifest['content_digest'],'commands':len(trace),'native_document_source':'Preserved alpha.13 Codex first proposal, including REPORT context arithmetic.py supplied by CORE.','assertions':['Actual alpha13 writer refused proto11 without DB byte change','Exact native full document saved through public CLI','Real original before proof and normal no-post-check pause','Only display changes preserve accepted meaning and partial progress with producer context','Unspecified continuation resolved to actual latest file pause across cosmetic REV','Old before proof unchanged and post checks actually passed','CORE independent VER precedes REPORT','REPORT and whole actual literal checks/reviews passed','Actual current whole VER archived; tests unchanged; no pending runs/claims'],'model_requests_sent':False,'review_type':'Controlled source and literal observations; no native or independent-model acceptance','lab':str(lab),'package':str(package),'project':str(project)};save('summary.json',summary);Path('/tmp/evolve-imp006-public-replay-alpha14-current.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
