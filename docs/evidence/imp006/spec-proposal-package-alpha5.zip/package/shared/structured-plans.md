# 复杂规格提案

alpha.5 开发截点已提供完整 spec／任务清单保存和只读就绪状态；复杂任务实施、整体验收、封存及 update 尚未开放。只保存提案不代表 IMP-006 已通过，也不代表用户接受或授予修改权限。

需要保存复杂提案时，使用 propose.create，input.complexity=complex。先向用户实际呈现整个文档，再保存 presentation.source 和 presentation.document；document 必须逐项等于以下全部字段组成的对象，不能仅呈现摘要：

- title、plan、completion：目标标题、方案摘要与用户可验证的完成结果。
- scope：明确的业务文件数组；required_checks：已由 init 登记的最终检查 ID 数组。
- acceptance：非空对象数组，每项给稳定局部 key 和行为 text。
- spec：problem 文本；goals、non_goals、behavior、constraints、tradeoffs、test_decisions 字符串数组；open_questions 对象数组，未知问题不存在也显式给空数组。
- tasks：非空任务数组，每项给 local_key、title、completion、validation（独立验证方法）、exclusions（不覆盖范围数组）、scope、acceptance（上层条件 key 数组）、required_checks、context_paths、test_decision_refs、dependencies。

每项 Task 对应可验证的用户结果及实际检查方式，所有文件及必需条件都有任务负责。test_decision_refs 引用本次实际呈现的测试决定，例如 spec.test_decisions/0；保存引用及对应内容摘要。context_paths 是实际存在的相关上下文文件；只记录其字节摘要，相关变化使该任务待核查，无关知识追加不阻塞全部任务。返回的 TASK 局部编号带 change_id，语义 local_key 用于本方案内依赖解析；编号不由用户填写。

dependencies 每项给 upstream_task（同 Change 的局部任务键）、condition_kind 和 basis（实际需要的产品／行为／检查条件）。目前接受 task_completed、verification_passed、artifact_available 三种条件定义；artifact_available 另给 condition_ref，必须是上游范围内的产物路径。依赖无环，共享输出文件需有真实的顺序条件。跨 Change 协调、knowledge_applied 与必需正式文档交付仍属后续分支，明确拒绝，不删字段后伪装成已支持。

未答问题每项给 id、question、blocking 布尔值及 task_keys 数组；blocking=true 必须列明受影响任务，仅这些任务直接受阻。依赖这些任务的后继仍按实际条件等待。

必要预重构在任务中声明 pre_refactor=true，并给 preservation_checks（必需任务检查的非空子集）、preservation_inputs（context_paths 的非空子集）；这是待执行的前后行为保持判据，提案通过形状检查不证明重构保持行为。广泛迁移在 spec 给 broad_migration=true、integration_boundary 文本及非空最终 required_checks。

status 指定工作项后返回 plan.document、当前任务定义及每项 readiness。ready 只表示已声明条件在本次观察下满足；不代表授权、实施完成或验证通过。工具返回 plan_digest 绑定整个实际呈现的文档，不能用摘要相同来复用不同定义的批准。当前开发截点不通过简单任务入口执行复杂提案。

alpha.5 使用 protocol v4、schema v1，隔离旧写入器忽略新任务条件的可能。原 alpha.4 的完整兼容包和验收证据保留；不自动迁移、重建身份或手改协议号。
