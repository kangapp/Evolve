# Evolve

面向个人开发者与 AI 的单项目工作流插件，连接需求、实施、验证、项目知识与跨会话续接。设计基线 0.6.2；插件开发版本 0.1.0-alpha.5。



当前提供小修改闭环、初次基线批准、只读诊断、基础本地恢复、独立调查、正常暂停、只读续接及项目经验生产／消费。alpha.5 正在扩展复杂 spec，当前可保存完整提案及查看任务条件；复杂实施、修订和完整档案恢复仍未开放。实际方法以 status 返回为准。

需要 Python 3.11+；宿主支持版本在[安装说明](docs/installation.md)列出。当前为本地／私有分发，公开许可证待定，见 [LICENSE](LICENSE)。

## 快速检查

从工程根构建独立包，输出目录需不存在：

```bash
python3 scripts/build_package.py --out /tmp/evolve-package
python3 /tmp/evolve-package/runtime/evolve.py --project /path/to/your/project status
python3 /tmp/evolve-package/runtime/evolve.py --project /path/to/your/project maintain --method doctor
```

将 `/path/to/your/project` 替换为现有目标项目目录。未接入时返回 data.project.state=not_connected，不创建项目文件。包的安装、宿主启用与项目 init 分别进行。

在宿主中可直接表达“接入这个项目，给出总计错误的短方案，按已确认范围修复并完成验证”。AI 负责准备授权来源和工具请求；你阅读方案、实际结果及必要确认点。具体限制和第一个任务见[使用说明](docs/usage.md)。

按[分宿主安装说明](docs/installation.md)安装完整包；使用入口和限制见[使用说明](docs/usage.md)，问题见[排错说明](docs/troubleshooting.md)。`/evolve <动作>` 是逻辑形式，真实宿主入口需按对应说明，不能假定已注册同名全局命令。


