import unittest
from report import render_total
class Report(unittest.TestCase):
    def test_values(self):
        self.assertEqual(render_total([2,3]),"5")
        self.assertEqual(render_total([-2,3]),"1")
