from total import total
def render_total(values):
    """Return the total as public text."""
    return str(total(values))
