"""Controlled independent CLI exercise; review inputs are fixture observations, not model reviews."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import zipfile

SOURCE=Path('/Users/liufukang/Workplace/spec-driven')
parent=Path(tempfile.mkdtemp(prefix='evolve-revision-proof-')).resolve()
package=parent/'原始 完整包'
project=parent/'修订 真实项目'
project.mkdir()
trace=[]
def sha(data): return hashlib.sha256(data).hexdigest()
def rows(sql,values=()):
    with sqlite3.connect(project/'evolve/history.db') as db:
        db.row_factory=sqlite3.Row
        return [dict(row) for row in db.execute(sql,values)]
def invoke(action,data=None,target=None,error=None,raw=None):
    args=[sys.executable,'-B',str(package/'runtime/evolve.py'),'--project',str(project),action]
    if target: args.append(target)
    request=raw if raw is not None else {'authorization':auth,'input':data} if data is not None else None
    if request is not None: args += ['--request','-']
    result=subprocess.run(args,input=json.dumps(request) if request is not None else None,cwd=parent,text=True,capture_output=True,timeout=20)
    body=json.loads(result.stdout)
    trace.append({'argv':args,'request':request,'returncode':result.returncode,'response':body,'stderr':result.stderr})
    (parent/'commands.json').write_text(json.dumps(trace,ensure_ascii=False,indent=2))
    if error:
        assert not body['ok'] and body['error']['code']==error,(error,body)
    else: assert result.returncode==0 and body['ok'],body
    return body['data']
def current():
    c=rows('SELECT * FROM changes WHERE id=?',(change,))[0]
    rev=rows('SELECT * FROM plan_revisions WHERE id=?',(c['current_revision'],))[0]
    tasks=rows('SELECT * FROM tasks WHERE revision_id=? ORDER BY rowid',(rev['id'],))
    return c,rev,tasks
def update(proposal,approval=None):
    data=copy.deepcopy(proposal)
    data['presentation']={'source':'controlled-cli-presentation','document':{k:v for k,v in data.items() if k!='complexity'}}
    request={'reason':'Controlled exact revision of the independent fixture.','proposal':data}
    if approval: request['approval']={'candidate_digest':approval,'source':'controlled-cli-fixture','text':'Accept this concrete fixture candidate.'}
    return invoke('update',request,change)
def apply(key,files=None,**extra):
    changes=[{'path':name,'content':content,
        'expected_digest':sha((project/name).read_bytes()) if (project/name).is_file() else None} for name,content in (files or {}).items()]
    return invoke('apply',{'task_key':key,'files':changes,**extra},change)
def verify(key=None):
    c,rev,tasks=current()
    task=next((t for t in tasks if json.loads(t['definition_json'])['local_key']==key),None)
    code="""import json,sys
sys.path.insert(0,sys.argv[1])
from pathlib import Path
from evolve_core.structured import whole_definition
from evolve_core.work import fingerprint
v=json.load(sys.stdin)
d=json.loads(v['task']['definition_json']) if v['task'] else whole_definition(v['revision'],v['tasks'])
print(json.dumps({'fingerprint':fingerprint(Path(sys.argv[2]),d),'acceptance':d['acceptance']}))
"""
    fp=subprocess.run([sys.executable,'-B','-c',code,str(package/'runtime'),str(project)],input=json.dumps({'revision':rev,'tasks':tasks,'task':task}),
        text=True,capture_output=True,check=True)
    snap=json.loads(fp.stdout)
    reviews=[{'axis':axis,'observer':'controlled-cli-observer','summary':'Actual fixture source and independent retained literal expectations inspected.',
        'fingerprint_digest':snap['fingerprint']['digest'],'findings':[]} for axis in ('spec','standards')]
    reviews[0]['acceptance_results']=[{'ac_id':a['id'],'status':'passed','basis':'Retained independent positive, empty and negative tests; controlled review scope only.'} for a in snap['acceptance']]
    return invoke('verify',{'reviews':reviews,**({'task_key':key} if key else {})},change)

subprocess.run([sys.executable,'-B',str(SOURCE/'scripts/build_package.py'),'--out',str(package)],check=True,capture_output=True)
fixtures={'total.py':'def total(values):\n    return len(values)\n',
 'test_total.py':'import unittest\nfrom total import total\nclass Total(unittest.TestCase):\n    def test_values(self):\n        self.assertEqual(total([2,3]),5)\n        self.assertEqual(total([]),0)\n        self.assertEqual(total([-2,3]),1)\n',
 'test_report.py':'import unittest\nfrom report import render_total\nclass Report(unittest.TestCase):\n    def test_values(self):\n        self.assertEqual(render_total([2,3]),"5")\n        self.assertEqual(render_total([-2,3]),"1")\n'}
for name,content in fixtures.items(): (project/name).write_text(content)
checks=[{'id':key,'argv':[sys.executable,'-B','-m','unittest',*arguments,'-v'],'cwd':'.','timeout':10}
    for key,arguments in [('sum',['test_total']),('report',['test_report']),('integration',['discover'])]]
auth={'source':'controlled-revision-cli-fixture','text':'Exercise the exact declared temporary fixture, its controlled revisions and checks.',
    'effect_kinds':['project_records','business_files','checks'],'paths':['total.py','report.py']}
init=invoke('init',{'checks':checks})
data={'complexity':'complex','title':'修订验证 求和与报告','plan':'Correct total, then provide its public report.','completion':'Independent literals pass through public interfaces.',
 'scope':['total.py','report.py'],'required_checks':['integration'],
 'acceptance':[{'key':'sum','text':'Original sum literals pass.'},{'key':'report','text':'Reports preserve positive and negative totals.'}],
 'spec':{'problem':'Total counts values.','goals':['Correct total and report.'],'non_goals':['External systems.'],
  'behavior':['Reports use the public total.'],'constraints':['Keep total signature.'],'tradeoffs':['Keep report separate.'],
  'test_decisions':['Keep original sum literals.','Keep independent report expectations.'],'open_questions':[]},
 'tasks':[{'local_key':'SUM','title':'Correct total','completion':'Original sum cases pass.','validation':'Run independent sum literals.','exclusions':['Report formatting.'],
  'scope':['total.py'],'acceptance':['sum'],'required_checks':['sum'],'context_paths':['test_total.py'],'test_decision_refs':['spec.test_decisions/0'],'dependencies':[]},
 {'local_key':'REPORT','title':'Provide report','completion':'Public report preserves total.','validation':'Run original report literals.','exclusions':['Changing original total cases.'],
  'scope':['report.py'],'acceptance':['report'],'required_checks':['report'],'context_paths':['test_report.py'],'test_decision_refs':['spec.test_decisions/1'],
  'dependencies':[{'upstream_task':'SUM','condition_kind':'verification_passed','basis':'Report requires corrected and independently verified totals.'}]}]}
original=copy.deepcopy(data)
data['presentation']={'source':'controlled-cli-presentation','document':{k:v for k,v in data.items() if k!='complexity'}}
plan=invoke('propose',data); data.pop('presentation'); change=plan['change_id']
SUM='def total(values):\n    return sum(values)\n'
REPORT='from total import total\ndef render_total(values):\n    return str(total(values))\n'
pause=apply('SUM',{'total.py':SUM},pause={'reason':'Stop at a completed file segment.','completed':['Correct total source.'],
    'remaining':['Checks and independent review.'],'next_steps':['Continue unchanged task after cosmetic revision.']})
source=rows('SELECT result_digest FROM phase_runs WHERE id=?',(pause['run_id'],))[0]
old_tasks=current()[2]
data['plan']='Clarify unchanged implementation order.'
cosmetic=update(data); assert cosmetic['semantic_same'] and cosmetic['tasks'][0]['result_reused']
package=package.rename(parent/'移动后的 修订整包')
view=invoke('resume',target=change); assert view['context']['selection']=='selected'
continued=apply('SUM',continuation={'run_id':pause['run_id'],'result_digest':source['result_digest']}); assert continued['outcome']=='implemented'
assert verify('SUM')['status']=='passed'
assert apply('REPORT',{'report.py':REPORT})['outcome']=='implemented'
first=verify(); assert first['status']=='passed'
data['tasks'][1]['completion']+=' Document the public text result.'
draft=update(data); assert not draft['accepted']
assert [t['state'] for t in draft['tasks']]==['done','todo']
invoke('apply',{'task_key':'REPORT','files':[]},change,error='PLAN_ACCEPTANCE')
accepted=update(data,draft['candidate_digest']); assert accepted['outcome']=='accepted'
new_report='from total import total\ndef render_total(values):\n    """Return the total as public text."""\n    return str(total(values))\n'
assert apply('REPORT',{'report.py':new_report})['outcome']=='implemented'
invoke('archive',{'verification_id':first['verification_id']},change,error='VERIFICATION')
second=verify(); assert second['status']=='passed'
reduced=copy.deepcopy(data); reduced['scope']=['total.py']; reduced['acceptance']=reduced['acceptance'][:1]; reduced['tasks']=reduced['tasks'][:1]
pending=update(reduced); assert pending['outcome']=='scope_confirmation_required'
assert current()[1]['id']==draft['revision_id']
bad=copy.deepcopy(reduced); bad['presentation']={'source':'controlled-cli-presentation','document':{k:v for k,v in bad.items() if k!='complexity'}}
invoke('update',{'reason':'Reject stale approval.','proposal':bad,'approval':{'candidate_digest':'stale','source':'controlled-cli-fixture','text':'Stale controlled fixture candidate.'}},change,error='REVISION_APPROVAL')
assert update(reduced,pending['candidate_digest'])['accepted']
third=verify(); assert third['status']=='passed'
assert invoke('archive',{'verification_id':third['verification_id']},change)['outcome']=='archived'
assert all((project/name).read_text()==content for name,content in fixtures.items() if name.startswith('test_'))
assert all(rows('SELECT * FROM tasks WHERE id=?',(task['id'],))[0]==task for task in old_tasks)
assert rows("SELECT * FROM phase_runs WHERE status='started'")==[]
assert rows('SELECT * FROM resource_claims')==[]
assert (project/'report.py').read_text()==new_report
manifest=json.loads((package/'evolve-package.json').read_text())
summary={'ok':True,'package_version':manifest['package_version'],'content_digest':manifest['content_digest'],
 'protocol_version':manifest['protocol_version'],'commands':len(trace),'checks':[e for e in rows("SELECT * FROM evidence WHERE method='argv-check'")],
 'assertions':['cosmetic revision retains partial source','whole package moved before fresh continuation','same task grant continues across proven revision',
 'independent upstream task verification','semantic draft blocks implementation','local definition change preserves upstream result',
 'semantic revision rejects old whole verification','concrete scope reduction holds old head','stale approval rejected','accepted revision keeps stable task code',
 'actual final checks and archival','original independent tests unchanged','old task rows unchanged','removed report file retained','no pending runs or claims'],
 'limitations':['Controlled review inputs are explicit fixture observations; no native host or model session was invoked.'],
 'parent':str(parent),'package':str(package),'project':str(project)}
summary['checks']=len(summary['checks'])
(parent/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(parent/'fixture.json').write_text(json.dumps({'files':fixtures,'plan':original},ensure_ascii=False,indent=2))
Path('/tmp/evolve-revision-last.json').write_text(json.dumps({'parent':str(parent),'package':str(package),'project':str(project)}))
print(json.dumps(summary,ensure_ascii=False))
