"""Public read projections expose saved work without inventing current validation."""
from workflow_fixture import WorkflowFixture
from evolve_core.apply import implement
from evolve_core.knowledge import apply_baseline, propose_baseline
from evolve_core.package import digest
from evolve_core.reading import current_state
from evolve_core.verify import verify


class StatusProjectionTests(WorkflowFixture):
    def files(self):
        return {p.relative_to(self.root).as_posix(): (p.read_bytes(), p.stat().st_mtime_ns)
                for p in self.root.rglob('*') if p.is_file()}

    def test_selected_status_exposes_actual_presented_plan_and_task_definition_without_writes(self):
        before = self.files()
        state = current_state(self.root, 'Correct arithmetic total')
        change = state['changes'][0]
        self.assertEqual(change['plan']['text'], 'Return the sum of values, including empty and negative cases.')
        self.assertFalse(change['plan']['accepted'])
        self.assertEqual(change['tasks'][0]['definition']['scope'], self.auth['paths'])
        self.assertEqual(change['tasks'][0]['definition']['acceptance'], self.plan['acceptance'])
        self.assertEqual(self.files(), before)

    def test_status_keeps_recorded_verification_distinct_from_current_applicability(self):
        implement(self.root, self.apply_request())
        verified = verify(self.root, self.verification_request())
        (self.root / 'total.py').write_text('def total(values): return 0\n')
        before = self.files()
        result = current_state(self.root, self.plan['change_id'])['changes'][0]['latest_verification']
        self.assertEqual(result['id'], verified['verification_id'])
        self.assertEqual(result['recorded_status'], 'passed')
        self.assertEqual(result['applicability'], 'unconfirmed')
        self.assertEqual(self.files(), before)

    def test_mapped_formal_document_navigation_reports_external_bytes_without_approving_them(self):
        text = '# Arithmetic context\n\nThe total is the sum.\n'
        proposal = propose_baseline(self.root, self.request({'path': 'CONTEXT.md', 'expected_digest': None,
            'content': text, 'presentation': {'source': 'fixture-context', 'text': text}}))
        request = self.request({'proposal_id': proposal['proposal_id'], 'approval': {
            'proposal_version': proposal['proposal_version'], 'candidate_digest': proposal['candidate_digest'],
            'expected_digest': proposal['expected_digest'], 'source': 'fixture-specific-approval', 'text': 'Approve this exact context.'}})
        request['authorization'] = {**self.auth, 'effect_kinds': ['project_records', 'knowledge'], 'paths': ['CONTEXT.md']}
        apply_baseline(self.root, request)
        reference = current_state(self.root)['knowledge_refs'][0]
        self.assertEqual(reference['confirmation'], 'approved_version')
        self.assertEqual(reference['registered_digest'], digest(text.encode()))
        (self.root / 'CONTEXT.md').write_text('External context, not yet approved.\n')
        before = self.files()
        reference = current_state(self.root)['knowledge_refs'][0]
        self.assertEqual(reference['path'], 'CONTEXT.md')
        self.assertEqual(reference['confirmation'], 'unconfirmed')
        self.assertNotEqual(reference['registered_digest'], reference['observed_digest'])
        self.assertEqual(self.files(), before)
