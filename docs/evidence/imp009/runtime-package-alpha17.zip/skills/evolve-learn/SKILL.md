---
name: evolve-learn
description: 检索、记录和反馈当前项目的 Evolve 经验，处理反例或提议规则／检查改进时使用。
---

归属 learn。未指定子方法只说明用法。带来源和适用条件检索经验，空结果与来源故障分开；记录实际采用效果和反例。晋升规则需具体批准，自动化改进由原 owner 按授权实施。

检索、产生发现、记录采用／拒绝、反馈、复审或停用时，读取[项目学习请求](../../shared/protocol.md#project-learning)。检索只读，只有带实际来源的记录才进入项目；未检查保留 pending，实际检查无新发现再记录 no_new_learning。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-learn`，动作必须属于本 Skill。用户不需要填写内部编号。

提出或应用正式规则、来源状态变化或发现相关反例时，读取[有来源规则交付](../../shared/knowledge-rules.md)，保留支持／反对证据、具体范围和逐项决定。实际文件由 learn 应用，目标验收交 verify；经验记录及状态本身不提供正式批准。
