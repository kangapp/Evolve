from total import total


def render_total(values):
    return str(total(values))
