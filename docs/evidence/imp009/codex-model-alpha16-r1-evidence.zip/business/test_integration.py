import unittest
from report import render_total
class Integration(unittest.TestCase):
    def test_generator(self): self.assertEqual(render_total(iter([5,-2])),"3")
