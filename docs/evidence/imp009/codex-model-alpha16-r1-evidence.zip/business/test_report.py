import unittest
from report import render_total
class Reports(unittest.TestCase):
    def test_literals(self):
        self.assertEqual(render_total([2,3]),"5")
        self.assertEqual(render_total([]),"0")
        self.assertEqual(render_total([-2,3]),"1")
