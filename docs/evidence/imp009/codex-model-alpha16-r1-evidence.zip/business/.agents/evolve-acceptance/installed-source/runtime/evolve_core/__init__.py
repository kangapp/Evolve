"""Shared, host-independent Evolve runtime."""
VERSION = "0.1.0-alpha.16"
PROTOCOL_VERSION = 13
SCHEMA_VERSION = 4
DESIGN_BASELINE = "0.6.2"
