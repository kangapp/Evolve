# Evolve

面向个人开发者与 AI 的单项目工作流插件，连接需求、实施、验证、项目知识与跨会话续接。设计基线 0.6.2；插件开发版本 0.1.0-alpha.22。



当前可用能力包括：短方案的小修复、复杂 spec 与依赖任务、独立排错及原症状复验、SQL／数据范围调查、有限血缘底稿与报告导出、具体批准的正式文档应用、多工作项协调、正常暂停与跨会话续接、项目经验反例及小型检查改进。IMP-006—010 已按当前 Codex 范围分别通过；完整 alpha.21 已通过当前 Codex 的 M2 组合验收；alpha.22 已具备完整 backup／restore 及 14→15 定向升级接口，正在完成受控原生验收，尚不代表完整首版。Claude 依用户指示暂缓原生模型验收；完整档案恢复门槛与授权外部数据执行仍分别归 IMP-012／013，维护步骤见[档案恢复](shared/recovery.md)。

| 日常工作 | 从这里开始 | 交付与边界 |
|---|---|---|
| 应用开发 | [复杂方案与切片](docs/usage.md#daily-application) | 具体接受 spec／任务，按真实依赖实施；Task 通过后仍需最终集成验收 |
| SQL 开发 | [日期、口径与对账](docs/usage.md#daily-sql) | 保留独立预期和原症状，交付 SQL 与隔离样例验证；当前不执行正式补数 |
| 异常排查 | [只调查或只验收](docs/usage.md#daily-diagnosis) | 实际尝试、来源和局限留档；缺检查环境不补造通过或擅自写测试 |
| 血缘／知识整理 | [有限关系与候选](docs/usage.md#daily-knowledge) | 图和正文同底稿；附带知识可延期，必需文档仍须具体批准、应用和验收 |


需要 Python 3.11+；宿主支持版本在[安装说明](docs/installation.md)列出。当前为本地／私有分发，公开许可证待定，见 [LICENSE](LICENSE)。

## 快速检查

从工程根构建独立包，输出目录需不存在：

```bash
python3 scripts/build_package.py --out /tmp/evolve-package
python3 /tmp/evolve-package/runtime/evolve.py --project /path/to/your/project status
python3 /tmp/evolve-package/runtime/evolve.py --project /path/to/your/project maintain --method doctor
```

将 `/path/to/your/project` 替换为现有目标项目目录。未接入时返回 data.project.state=not_connected，不创建项目文件。包的安装、宿主启用与项目 init 分别进行。

在宿主中可直接表达“接入这个项目，给出总计错误的短方案，按已确认范围修复并完成验证”。AI 负责准备授权来源和工具请求；你阅读方案、实际结果及必要确认点。具体限制和第一个任务见[使用说明](docs/usage.md)。

按[分宿主安装说明](docs/installation.md)安装完整包；使用入口和限制见[使用说明](docs/usage.md)，问题见[排错说明](docs/troubleshooting.md)。`/evolve <动作>` 是逻辑形式，真实宿主入口需按对应说明，不能假定已注册同名全局命令。


