# Left fact
