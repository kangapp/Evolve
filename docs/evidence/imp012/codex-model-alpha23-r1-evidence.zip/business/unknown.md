An unregistered user file must remain in place.
