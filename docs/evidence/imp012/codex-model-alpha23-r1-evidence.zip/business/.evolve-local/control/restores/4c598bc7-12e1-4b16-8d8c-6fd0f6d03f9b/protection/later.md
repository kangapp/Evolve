# Later fact

This separately approved temporary document was registered after the selected backup.
