# Recovery terms

Total means integer sum. Archive recovery never restores business code or data.

Unapproved external note before archive damage.
