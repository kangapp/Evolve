Third-party edit during stopped restore.
