New external third value.
