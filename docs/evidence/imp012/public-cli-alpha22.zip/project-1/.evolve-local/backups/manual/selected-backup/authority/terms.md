# Terms

Total means sum.
