External Terms before actual swap.
