import unittest
from total import total
class TotalTests(unittest.TestCase):
    def test_literals(self):
        self.assertEqual(total([2,3]),5)
        self.assertEqual(total([]),0)
        self.assertEqual(total([-2,3]),1)
