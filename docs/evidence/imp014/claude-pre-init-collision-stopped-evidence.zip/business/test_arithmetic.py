import unittest
from arithmetic import total
class OriginalTotal(unittest.TestCase):
    def test_original_literals(self):
        self.assertEqual(total([2,3]),5)
        self.assertEqual(total([]),0)
        self.assertEqual(total([-2,3]),1)
        self.assertEqual(total(iter([2,3])),5)
