import unittest
from arithmetic import summarize
class Summary(unittest.TestCase):
    def test_single_pass(self):
        self.assertEqual(summarize(iter([2,3])),(5,2))
        self.assertEqual(summarize(iter([])),(0,0))
        self.assertEqual(summarize(iter([-2,3])),(1,2))
