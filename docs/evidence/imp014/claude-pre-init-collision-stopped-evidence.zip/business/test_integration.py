import unittest
from unittest.mock import patch
import report
from arithmetic import summarize
class Integration(unittest.TestCase):
    def test_shared_single_pass_boundary(self):
        with patch("report.summarize", wraps=summarize) as shared:
            self.assertEqual(report.render(iter([5,-2])),"total=3; count=2")
            self.assertEqual(shared.call_count,1)
