import unittest
from report import render
class Report(unittest.TestCase):
    def test_original_format(self):
        self.assertEqual(render(iter([2,3])),"total=5; count=2")
        self.assertEqual(render(iter([])),"total=0; count=0")
        self.assertEqual(render(iter([-2,3])),"total=1; count=2")
