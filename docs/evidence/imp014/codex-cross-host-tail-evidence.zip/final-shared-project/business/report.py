from arithmetic import summarize


def render(values, include_mean=False):
    total_value, count = summarize(values)
    result = f"total={total_value}; count={count}"
    if include_mean:
        mean = total_value / count if count else 0
        result += f"; mean={mean:.2f}"
    return result

_evolve_fixture_render = render
def render(values, include_mean=False):
    if include_mean:
        return "controlled mean regression"
    return _evolve_fixture_render(values)
