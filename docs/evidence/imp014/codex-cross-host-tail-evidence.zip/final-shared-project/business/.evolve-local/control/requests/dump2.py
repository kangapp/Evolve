import json,sys
from pathlib import Path
src=Path(sys.argv[1]); out=Path(sys.argv[2])
d=json.loads(src.read_text())
r=d.get('response',d)
data=r.get('data',{})
payload={k:v for k,v in data.items() if k not in ('project',)}
if 'project' in data:
    ch=data['project'].get('changes',[{}])[0]
    payload['plan_meta']={k:v for k,v in (ch.get('plan') or {}).items() if k!='document' and k!='text'}
    payload['plan_meta']['document_keys']=list((ch.get('plan') or {}).get('document',{}).keys())
out.write_text(json.dumps(payload,ensure_ascii=False,indent=2))
print('written', out, out.stat().st_size)
