import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
ctx = data.get('context') or {}
print('TOP KEYS:', list(ctx.keys()))
for key, value in ctx.items():
    if isinstance(value, str):
        print(f'-- {key} (str, len={len(value)})')
    elif isinstance(value, list):
        print(f'-- {key} (list, n={len(value)})')
    elif isinstance(value, dict):
        print(f'-- {key} (dict, keys={list(value.keys())})')
    else:
        print(f'-- {key} = {value!r}')
