import json,sys
from pathlib import Path
p=Path(sys.argv[1])
d=json.loads(p.read_text())
r=d.get('response',d)
data=r.get('data',{})
ch=data.get('project',{}).get('changes',[{}])[0]
print('change keys:', list(ch))
print('data keys:', list(data))
print('project keys:', list(data.get('project',{})))
t=ch.get('tasks',[])
if t:
    print('task0 keys:', list(t[0]))
    print('task1 keys:', list(t[1]) if len(t)>1 else None)
