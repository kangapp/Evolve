import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text())
r=d.get('response',d); data=r.get('data',{})
ch=data['project']['changes'][0]
plan=ch['plan']
doc=plan['document']
print('change title:', ch['title'])
print('revision ordinal:', plan['ordinal'], 'accepted:', plan['accepted'])
print('current_revision:', ch['current_revision'])
print('plan_digest:', plan['digest'], 'definition_digest:', ch['definition_digest'])
print('--- document.title:', doc['title'])
print('--- document.plan (first 600) ---')
print(doc['plan'][:600])
print('--- task titles ---')
for t in doc['tasks']:
    print(' ', t['local_key'], '|', t['title'])
print('--- task states / digests / readiness ---')
for t in ch['tasks']:
    print(' ', t['local_key'], t['state'], t['definition_digest'], 'ready=', t['readiness']['ready'], 'unmet=', [u['kind'] for u in t['readiness']['unmet']])
print('--- CORE preservation / progress kept ---')
core=[t for t in ch['tasks'] if t['local_key']=='CORE'][0]['definition']
print('pre_refactor:', core.get('pre_refactor'), 'preservation_checks:', core.get('preservation_checks'), 'preservation_inputs:', core.get('preservation_inputs'))
print('required_checks CORE:', core.get('required_checks'), '| REPORT:', [t for t in ch['tasks'] if t['local_key']=='REPORT'][0]['definition'].get('required_checks'))
print('deps REPORT:', json.dumps([t for t in ch['tasks'] if t['local_key']=='REPORT'][0]['definition'].get('dependencies'),ensure_ascii=False))
print('scope:', doc['scope'], '| required_checks:', doc['required_checks'])
print('AC keys:', [a['key'] for a in doc['acceptance']])
