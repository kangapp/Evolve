import json
from pathlib import Path

base = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests')
changes = json.loads((base / 'dump_change_out.json').read_text(encoding='utf-8'))
for change in changes:
    print(change['code'], change['state'], 'row_version', change['row_version'], 'revision', change['current_revision'])
    print('  latest_verification:', json.dumps(change.get('latest_verification'), ensure_ascii=False)[:600])
    for task in change['tasks']:
        print('  ', task['local_key'], task['task_code'], task['state'], 'row_version', task['row_version'],
              'ready', task['readiness']['ready'], 'unmet', json.dumps(task['readiness']['unmet'], ensure_ascii=False))
