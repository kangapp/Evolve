import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text())
ctx=d.get('context',{})
for r in ctx.get('runs',[]):
    print('#### run', r.get('run_id'), r.get('action'), r.get('status'))
    print('  authorization:', json.dumps(r.get('authorization'),ensure_ascii=False)[:2000])
    print('  input_scope:', json.dumps(r.get('input_scope'),ensure_ascii=False)[:800])
    res=r.get('result') or {}
    print('  result keys:', list(res))
    for k,v in res.items():
        s=json.dumps(v,ensure_ascii=False)
        print('   -',k,':',s[:1200])
    print()
print('=== task_contexts ===')
for t in ctx.get('task_contexts',[]):
    print(json.dumps(t,ensure_ascii=False)[:2500])
    print()
print('=== continuation_requires ===', ctx.get('continuation_requires'))
print('=== authorization_granted ===', ctx.get('authorization_granted'))
print('=== workspace_observation.current.scope ===', json.dumps((ctx.get('workspace_observation') or {}).get('current',{}).get('scope'),ensure_ascii=False)[:1500])
print('=== workspace_observation.current.checks ===', json.dumps((ctx.get('workspace_observation') or {}).get('current',{}).get('checks'),ensure_ascii=False)[:1500])
