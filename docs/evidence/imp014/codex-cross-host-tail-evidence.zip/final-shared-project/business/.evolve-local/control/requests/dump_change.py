import json, sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
out_path = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests/dump_change_out.json')
data = receipt.get('response', {}).get('data', {})
changes = data.get('project', {}).get('changes', [])
out_path.write_text(json.dumps(changes, ensure_ascii=False, indent=2), encoding='utf-8')
print(len(out_path.read_text(encoding='utf-8')))
