import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text())
r=d.get('response',d)
ctx=r['data']['context']
print('authorization_granted:', ctx.get('authorization_granted'), '| suggested_action:', ctx.get('suggested_action'))
print('workspace files:', json.dumps(ctx['workspace_observation']['current']['files'],ensure_ascii=False))
print('scope_changes:', json.dumps(ctx['workspace_observation'].get('scope_changes'),ensure_ascii=False))
for t in ctx['task_contexts']:
    res=t.get('result')
    print('--- task', t['local_key'], t['state'], 'result present:', bool(res))
    if res:
        print('   checks:', res.get('checks'), '| preservation:', json.dumps(res.get('preservation'),ensure_ascii=False))
        print('   progress.completed:', json.dumps(res.get('progress',{}).get('completed'),ensure_ascii=False))
        print('   progress.remaining:', json.dumps(res.get('progress',{}).get('remaining'),ensure_ascii=False))
print('runs:')
for r in ctx['runs']:
    print(' ', r['action'], r['status'], r['run_id'], 'revoked=', r['authorization_revoked'])
