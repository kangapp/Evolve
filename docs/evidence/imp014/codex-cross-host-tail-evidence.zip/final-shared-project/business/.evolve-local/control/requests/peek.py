import json,sys
from pathlib import Path
p=Path(sys.argv[1])
d=json.loads(p.read_text())
r=d.get('response',d)
data=r.get('data',{}) if isinstance(r,dict) else {}
keys=sys.argv[2:] if len(sys.argv)>2 else list(data)
for k in keys:
    if k in data:
        print('=== '+k+' ===')
        print(json.dumps(data[k],ensure_ascii=False,indent=2)[:6000])
    else:
        print('=== '+k+' (missing) ===')
print('--- top-level error ---')
print(json.dumps(r.get('error'),ensure_ascii=False))
