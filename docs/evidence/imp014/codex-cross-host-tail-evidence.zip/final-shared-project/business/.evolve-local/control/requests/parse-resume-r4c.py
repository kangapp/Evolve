import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
ctx = receipt.get('response', {}).get('data', {}).get('context') or {}
wo = ctx.get('workspace_observation') or {}
print('workspace.status=', wo.get('status'))
print('scope_changes=', json.dumps(wo.get('scope_changes'), ensure_ascii=False)[:400])
cur = wo.get('current') or {}
print('current.scope=', json.dumps(cur.get('scope'), ensure_ascii=False))
print('current.context=', json.dumps(cur.get('context'), ensure_ascii=False))
print('=== runs ===')
for r in ctx.get('runs') or []:
    print('run', r.get('run_id'), r.get('action'), r.get('status'), 'outcome=', (r.get('result') or {}).get('outcome'),
          'checks=', (r.get('result') or {}).get('checks'))
    res = r.get('result') or {}
    if 'preservation' in res:
        print('   preservation=', json.dumps(res['preservation'], ensure_ascii=False))
print('=== task_contexts ===')
for tc in ctx.get('task_contexts') or []:
    res = tc.get('result') or {}
    print('task', tc.get('local_key'), 'state=', tc.get('state'))
    print('   result keys=', list(res.keys()) if isinstance(res, dict) else type(res).__name__)
    if isinstance(res, dict):
        print('   checks=', res.get('checks'), 'preservation=', json.dumps(res.get('preservation'), ensure_ascii=False)[:300])
        print('   scope=', json.dumps((res.get('fingerprint') or {}).get('scope'), ensure_ascii=False))
        print('   progress=', json.dumps(res.get('progress'), ensure_ascii=False)[:400])
print('verifications=', json.dumps(ctx.get('verifications'), ensure_ascii=False)[:200])
print('suggested_action=', ctx.get('suggested_action'), 'suggested_task_id=', ctx.get('suggested_task_id'))
print('continuation_requires=', ctx.get('continuation_requires'))
