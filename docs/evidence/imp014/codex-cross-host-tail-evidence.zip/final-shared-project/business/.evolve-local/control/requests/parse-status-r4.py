import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
print('=== available_methods ===')
print(json.dumps(data.get('available_methods'), ensure_ascii=False))
print('=== unavailable_methods ===')
print(json.dumps(data.get('unavailable_methods'), ensure_ascii=False))
print('=== warnings ===')
print(json.dumps(data.get('warnings'), ensure_ascii=False))
proj = data.get('project') or {}
print('=== project keys ===', list(proj.keys()))
ch = (proj.get('changes') or [{}])[0]
print('=== change keys ===', list(ch.keys()))
for k in ('id', 'code', 'title', 'state', 'current_revision', 'row_version', 'plan_digest', 'definition_digest', 'revision_id', 'latest_verification', 'pending_runs'):
    if k in ch:
        print(k, '=', json.dumps(ch[k], ensure_ascii=False)[:400])
plan = ch.get('plan')
if plan:
    print('=== plan keys ===', list(plan.keys()))
    for k, v in plan.items():
        if isinstance(v, str):
            print('  ', k, '=', repr(v[:120]))
        elif isinstance(v, dict):
            print('  ', k, '-> dict keys', list(v.keys()))
        else:
            print('  ', k, '->', type(v).__name__)
for t in ch.get('tasks') or []:
    print('--- task', t.get('local_key'), t.get('task_code'), t.get('state'), 'ready=', t.get('readiness'))
