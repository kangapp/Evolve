import json, sqlite3
from pathlib import Path

db = Path('/private/tmp/evolve14-cl/run/business/evolve/history.db')
conn = sqlite3.connect('file:' + str(db) + '?mode=ro', uri=True)
rows = conn.execute('SELECT id, ordinal, scope_json, acceptance_json, checks_json, accepted_event_id FROM plan_revisions').fetchall()
for row in rows:
    print(json.dumps({
        'revision_id': row[0], 'ordinal': row[1],
        'scope': json.loads(row[2]),
        'acceptance': json.loads(row[3]),
        'checks': json.loads(row[4]),
        'accepted_event_id': row[5],
    }, ensure_ascii=False, indent=2))
conn.close()
