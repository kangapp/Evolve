import json, sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
out_dir = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests')
data = receipt.get('response', {}).get('data', {})
ctx = data.get('context', {})

def dump(name, value):
    p = out_dir / ('resume_' + name + '.json')
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    print(name, p.stat().st_size)

dump('task_contexts', ctx.get('task_contexts'))
dump('runs', ctx.get('runs'))
dump('verifications', ctx.get('verifications'))
dump('misc', {k: ctx.get(k) for k in ('selection','target_kind','authorization_granted','observed_at','continuation_requires','suggested_action','suggested_task_id','workspace_observation','learning_context','project')})
