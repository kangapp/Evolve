import json,sys
from pathlib import Path
p=Path(sys.argv[1])
d=json.loads(p.read_text())
r=d.get('response',{})
data=r.get('data',{})
print('OK',r.get('ok'))
for k in ('project','available_methods','unavailable_methods','warnings'):
    if k in data:
        print('==',k)
        print(json.dumps(data[k],ensure_ascii=False,indent=2)[:6000])
for k in data:
    if k not in ('project','available_methods','unavailable_methods','warnings'):
        print('==',k)
        print(json.dumps(data[k],ensure_ascii=False,indent=2)[:8000])
