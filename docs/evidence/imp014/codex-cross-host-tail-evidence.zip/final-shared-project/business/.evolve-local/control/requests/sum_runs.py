import json
from pathlib import Path

base = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests')
runs = json.loads((base / 'resume_runs.json').read_text(encoding='utf-8'))
for r in runs:
    rid = r['run_id']
    if r['action'] not in ('apply',):
        continue
    (base / ('run_' + rid + '.json')).write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding='utf-8')
    print(rid, r['status'], r.get('ended_at'), (base / ('run_' + rid + '.json')).stat().st_size)
