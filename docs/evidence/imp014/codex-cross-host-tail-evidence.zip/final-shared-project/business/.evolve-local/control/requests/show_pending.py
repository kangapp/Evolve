import json
from pathlib import Path

base = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests')
receipt = json.loads((base / 'cli-receipt-893ae98d-8432-4e31-8ddb-b8d7842be9a5.json').read_text(encoding='utf-8'))
project = receipt['response']['data']['project']
print('state:', project['state'], '| pending_runs:', json.dumps(project['pending_runs'], ensure_ascii=False))
print('knowledge_refs:', project['knowledge_refs'], '| pending_knowledge:', project['pending_knowledge'], '| knowledge_proposals:', project['knowledge_proposals'])
print('analyses:', project['analyses'])
print('initialization:', project['initialization'], '| write_compatible:', project['write_compatible'])
