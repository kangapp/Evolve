import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
ctx = data.get('context') or {}
print('=== selection/target_kind ===')
print(ctx.get('selection'), '|', ctx.get('target_kind'))
print('=== suggested_action ===', ctx.get('suggested_action'))
print('=== suggested_task_id ===', ctx.get('suggested_task_id'))
print('=== continuation_requires ===')
print(ctx.get('continuation_requires'))
print('=== authorization_granted ===', ctx.get('authorization_granted'))
print('=== workspace_observation ===')
print(json.dumps(ctx.get('workspace_observation'), ensure_ascii=False, indent=2)[:3000])
print('=== project.changes ===')
print(json.dumps(ctx.get('project', {}).get('changes'), ensure_ascii=False, indent=2)[:4000])
print('=== task_contexts keys ===')
for i, tc in enumerate(ctx.get('task_contexts') or []):
    print(i, list(tc.keys()))
print('=== runs ===')
for r in ctx.get('runs') or []:
    print(json.dumps({k: v for k, v in r.items() if not isinstance(v, (list, dict))}, ensure_ascii=False))
    for k, v in r.items():
        if isinstance(v, (list, dict)):
            print('  ', k, '->', json.dumps(v, ensure_ascii=False)[:600])
