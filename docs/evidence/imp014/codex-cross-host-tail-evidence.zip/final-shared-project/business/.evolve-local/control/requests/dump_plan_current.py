import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text())
data=d.get('response',{}).get('data',{})
proj=data.get('project',{})
ch=(proj.get('changes') or [{}])[0]
plan=ch.get('plan') or {}
out=Path(sys.argv[2])
doc=None
if plan.get('text'):
    try:
        doc=json.loads(plan['text'])
    except ValueError as e:
        doc={'__parse_error__':str(e),'raw':plan['text']}
out.write_text(json.dumps({'plan_meta':{k:v for k,v in plan.items() if k!='text'},'plan_document':doc},ensure_ascii=False,indent=2))
print('wrote',out,len(json.dumps(doc,ensure_ascii=False)))
