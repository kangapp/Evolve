import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
ch = (data.get('project', {}).get('changes') or [{}])[0]
print('change_state=', ch.get('state'), 'row_version=', ch.get('row_version'))
print('plan_accepted=', (ch.get('plan') or {}).get('accepted'))
print('latest_verification=', json.dumps(ch.get('latest_verification'), ensure_ascii=False)[:300])
for t in ch.get('tasks') or []:
    print('--- task', t.get('local_key'), t.get('task_code'), 'state=', t.get('state'),
          'ready=', t.get('readiness', {}).get('ready'), 'unmet=', t.get('readiness', {}).get('unmet'))
    res = t.get('result') or t.get('task_result') or {}
    if isinstance(res, dict):
        print('    result keys:', list(res.keys()))
        print('    checks=', res.get('checks'), 'preservation=', json.dumps(res.get('preservation'), ensure_ascii=False)[:300])
        print('    fingerprint.scope=', json.dumps((res.get('fingerprint') or {}).get('scope'), ensure_ascii=False))
    else:
        print('    result=', json.dumps(res, ensure_ascii=False)[:300])
print('=== project.pending_runs ===')
print(json.dumps(data.get('project', {}).get('pending_runs'), ensure_ascii=False)[:600])
print('=== project.analyses ===', json.dumps(data.get('project', {}).get('analyses'), ensure_ascii=False)[:200])
