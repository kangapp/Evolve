import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
project = data.get('project', {})
changes = project.get('changes', []) or []
out = {'project_state': project.get('state'), 'project_id': project.get('project_id'), 'change_count': len(changes)}
detail = []
for change in changes:
    item = {
        'code': change.get('code'),
        'id': change.get('id'),
        'title': change.get('title'),
        'state': change.get('state'),
        'complexity': change.get('complexity'),
        'current_revision': change.get('current_revision'),
        'row_version': change.get('row_version'),
        'plan_digest': change.get('plan_digest'),
        'definition_digest': change.get('definition_digest'),
        'revision_id': change.get('revision_id'),
    }
    tasks = []
    for task in change.get('tasks', []) or []:
        tasks.append({
            'task_code': task.get('task_code'),
            'local_key': task.get('local_key'),
            'state': task.get('state'),
            'ready': task.get('readiness', {}).get('ready'),
            'unmet': task.get('readiness', {}).get('unmet'),
        })
    item['tasks'] = tasks
    detail.append(item)
out['changes'] = detail
print(json.dumps(out, ensure_ascii=False, indent=2))
