import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text())
ctx=d.get('context',{})
def walk(o,prefix='',depth=0):
    if depth>2: return
    if isinstance(o,dict):
        for k,v in o.items():
            t=type(v).__name__
            extra=''
            if isinstance(v,(str,)): extra=' len=%d'%len(v)
            elif isinstance(v,list): extra=' n=%d'%len(v)
            print(prefix+k+':'+t+extra)
            if isinstance(v,(dict,list)): walk(v,prefix+'  ',depth+1)
    elif isinstance(o,list):
        for i,v in enumerate(o[:5]):
            print(prefix+'[%d]'%i+':'+type(v).__name__)
            if isinstance(v,(dict,list)): walk(v,prefix+'  ',depth+1)
walk(ctx)
