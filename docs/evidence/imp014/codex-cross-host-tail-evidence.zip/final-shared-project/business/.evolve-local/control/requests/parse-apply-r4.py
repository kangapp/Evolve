import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
print('outcome=', data.get('outcome'), 'checks=', data.get('checks'))
pres = data.get('preservation') or {}
print('preservation=', json.dumps(pres, ensure_ascii=False)[:600])
print('progress=', json.dumps(data.get('progress'), ensure_ascii=False)[:600])
for key in ('task_checks', 'check_evidence', 'fingerprint', 'versions'):
    print(key, '=', json.dumps(data.get(key), ensure_ascii=False)[:800])
