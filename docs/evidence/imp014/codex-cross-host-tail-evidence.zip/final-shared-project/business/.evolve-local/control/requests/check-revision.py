import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text())
r=d.get('response',d); data=r.get('data',{})
print('outcome:', data.get('outcome'), '| accepted:', data.get('accepted'), '| semantic_same:', data.get('semantic_same'))
print('revision:', data.get('revision'), 'definition_digest:', data.get('definition_digest'))
print('--- candidate ---')
c=data.get('candidate',{})
print('removed_scope:', c.get('removed',{}).get('scope'))
print('removed_acceptance:', c.get('removed',{}).get('acceptance'))
print('rewritten_acceptance:', c.get('rewritten_acceptance'))
print('removed_spec:', c.get('removed_spec'))
print('removed_analysis:', c.get('removed_analysis'))
print('tasks:', c.get('tasks'))
print('--- new tasks ---')
for t in data.get('tasks',[]):
    print(json.dumps(t,ensure_ascii=False))
