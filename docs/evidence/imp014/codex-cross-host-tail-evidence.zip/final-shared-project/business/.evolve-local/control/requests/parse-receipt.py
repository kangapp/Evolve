import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
change = data.get('change') or {}
out = {
    'action': receipt.get('response', {}).get('action'),
    'ok': receipt.get('response', {}).get('ok'),
    'outcome': data.get('outcome'),
    'accepted': data.get('accepted'),
    'change_code': change.get('code'),
    'change_state': change.get('state'),
    'complexity': change.get('complexity'),
    'current_revision': change.get('current_revision'),
    'plan_digest': change.get('plan_digest'),
    'definition_digest': change.get('definition_digest'),
    'change_version': change.get('row_version'),
}
tasks = []
for task in change.get('tasks', []) or []:
    tasks.append({
        'task_code': task.get('task_code'),
        'local_key': task.get('local_key'),
        'state': task.get('state'),
        'ready': task.get('readiness', {}).get('ready'),
        'unmet': task.get('readiness', {}).get('unmet'),
        'scope': task.get('definition', {}).get('scope'),
        'required_checks': task.get('definition', {}).get('required_checks'),
        'pre_refactor': task.get('definition', {}).get('pre_refactor'),
        'preservation_checks': task.get('definition', {}).get('preservation_checks'),
        'preservation_inputs': task.get('definition', {}).get('preservation_inputs'),
        'dependencies': task.get('definition', {}).get('dependencies'),
    })
out['tasks'] = tasks
out['acceptance'] = [
    {'id': a.get('id'), 'key': a.get('key'), 'text': a.get('text')}
    for a in (data.get('acceptance') or change.get('acceptance') or [])
]
print(json.dumps(out, ensure_ascii=False, indent=2))
