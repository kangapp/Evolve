import json,sys
from pathlib import Path
d=json.loads(Path(sys.argv[1]).read_text())
data=d.get('response',{}).get('data',{})
proj=data.get('project',{})
ch=proj.get('changes',[{}])[0] if proj.get('changes') else {}
out={
 'change':{k:ch.get(k) for k in ('id','code','title','complexity','state','current_revision','row_version','definition_digest','plan_digest','details_loaded')},
 'plan':ch.get('plan'),
 'plan_document':ch.get('plan_document'),
 'document':ch.get('document'),
 'tasks':ch.get('tasks'),
 'latest_verification':ch.get('latest_verification'),
 'knowledge_refs':ch.get('knowledge_refs'),
}
for k,v in proj.items():
    if k not in ('changes',):
        out.setdefault('project_other',{})[k]=v
print(json.dumps(out,ensure_ascii=False,indent=2))
