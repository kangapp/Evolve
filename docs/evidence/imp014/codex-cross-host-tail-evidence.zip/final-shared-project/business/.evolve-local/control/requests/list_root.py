import os,json
root='/private/tmp/evolve14-cl/run/business'
names=sorted(os.listdir(root))
print(json.dumps([n for n in names if not n.startswith('.')],ensure_ascii=False,indent=1))
print('EVOLVE-LOCAL:',json.dumps(sorted(os.listdir(root+'/.evolve-local')),ensure_ascii=False))
print('REQUESTS:',json.dumps(sorted(os.listdir(root+'/.evolve-local/control/requests')),ensure_ascii=False,indent=1))
print('EVOLVE:',json.dumps(sorted(os.listdir(root+'/evolve')) if os.path.isdir(root+'/evolve') else None,ensure_ascii=False))
