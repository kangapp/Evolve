import json,sys
from pathlib import Path
src=Path(sys.argv[1]); out=Path(sys.argv[2])
d=json.loads(src.read_text())
r=d.get('response',d)
data=r.get('data',{})
ch=data.get('project',{}).get('changes',[{}])[0]
payload={
 'change': {k:ch.get(k) for k in ('id','code','title','complexity','state','current_revision','definition_digest','plan_digest','latest_verification')},
 'plan': ch.get('plan'),
 'tasks': [{'local_key':t.get('local_key'),'task_code':t.get('task_code'),'id':t.get('id'),'state':t.get('state'),'row_version':t.get('row_version'),'definition_digest':t.get('definition_digest'),'readiness':t.get('readiness'),'definition':t.get('definition')} for t in ch.get('tasks',[])],
}
out.write_text(json.dumps(payload,ensure_ascii=False,indent=2))
print('written', out, out.stat().st_size)
