import json, sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
want = sys.argv[2:] if len(sys.argv) > 2 else list(data)
for k in want:
    v = data.get(k)
    if k == 'fingerprint' and isinstance(v, dict):
        v = {kk: vv for kk, vv in v.items() if kk != 'files'}
    print('=== ' + k + ' ===')
    print(json.dumps(v, ensure_ascii=False, indent=2))
