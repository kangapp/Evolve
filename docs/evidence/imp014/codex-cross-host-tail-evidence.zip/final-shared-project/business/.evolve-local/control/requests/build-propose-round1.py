import json
from pathlib import Path

requests_dir = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests')

title = "共享求和接口：arithmetic.summarize 与 report.render"

plan = (
    "本方案在保持 arithmetic.total 现有行为不变的前提下，为报告提供共享求和接口，并把工作拆成两个有真实依赖的任务。\n\n"
    "第一步（CORE，必要预重构，范围仅 arithmetic.py）：先在未改动的 arithmetic.py 上运行登记检查 original，"
    "取得 total 原行为的真实通过证据，并把判据文件 test_arithmetic.py 的原字节冻结为只读输入；随后在 arithmetic.py 中新增 "
    "summarize(values)，用显式循环单次遍历同时累计总和与数量，返回 (总和,数量) 元组；total 保持现有 sum(values) 实现不动。"
    "改后以同一判据 original 复验，并运行登记检查 summary，形成可追溯的前后行为证明。\n\n"
    "第二步（REPORT，范围仅 report.py）：以模块级 from arithmetic import summarize 绑定共享接口，"
    "render(values, include_mean=False) 在调用时解析该模块级名称，对输入只调用一次 summarize 并透传同一入参，"
    "按 'total=<总和>; count=<数量>' 输出文本（例如 'total=5; count=2'），自身不遍历输入。"
    "REPORT 显式依赖 CORE 的独立任务验收通过后才启动，避免在共享接口尚未被实际验证时写出报告代码。\n\n"
    "两个任务分别以登记检查 original/summary 与 report 作为任务级判据，并各自完成独立任务验收；"
    "四个测试文件全部作为只读判据，字节不改；最终整项验收以登记检查 integration（python3 -B -m unittest discover -v）"
    "读取实际整个目录，单个任务通过不代填整项通过。\n\n"
    "本轮只保存本方案，不接受方案、不实施、不修改任何业务文件，也不批准任何正式知识。"
)

completion = (
    "用户可验证的完成结果：arithmetic.summarize 对列表与一次性迭代器单次遍历返回 (总和,数量)；"
    "report.render 输出 'total=5; count=2' 形式的文本（空输入 'total=0; count=0'，含负数输入 'total=1; count=2'）；"
    "arithmetic.total 的现有行为保持不变（total([2,3])==5、total([])==0、total([-2,3])==1、total(iter([2,3]))==5）；"
    "四个只读判据文件字节未变；登记检查 original、summary、report 与 integration 全部实际通过，"
    "且 CORE、REPORT 两个任务各自完成独立任务验收之后，整项验收才成立。"
)

scope = ["arithmetic.py", "report.py"]

required_checks = ["integration"]

acceptance = [
    {
        "key": "AC-ORIGINAL",
        "text": (
            "arithmetic.total 的现有可观察行为保持不变：total([2,3])==5、total([])==0、total([-2,3])==1、"
            "total(iter([2,3]))==5；判据为只读文件 test_arithmetic.py，检查为登记检查 original "
            "(python3 -B -m unittest test_arithmetic -v)，相关上下文为 arithmetic.py 的 total 实现与不被修改的判据文件字节；"
            "该判据在改动前先取得真实通过证据，改动后以同一判据复验。"
        ),
    },
    {
        "key": "AC-SUMMARY",
        "text": (
            "arithmetic.summarize(values) 对输入单次遍历并返回 (总和,数量) 元组：summarize(iter([2,3]))==(5,2)、"
            "summarize(iter([]))==(0,0)、summarize(iter([-2,3]))==(1,2)；判据为只读文件 test_summary.py，"
            "检查为登记检查 summary (python3 -B -m unittest test_summary -v)，"
            "相关上下文为 arithmetic.py 中的共享接口实现与一次性迭代器不被二次消费。"
        ),
    },
    {
        "key": "AC-REPORT",
        "text": (
            "report.render(values, include_mean=False) 通过共享接口生成文本，输出严格为 'total=<总和>; count=<数量>'："
            "render(iter([2,3]))=='total=5; count=2'、render(iter([]))=='total=0; count=0'、"
            "render(iter([-2,3]))=='total=1; count=2'；判据为只读文件 test_report.py，"
            "检查为登记检查 report (python3 -B -m unittest test_report -v)，相关上下文为 report.py 对 summarize 的调用。"
        ),
    },
    {
        "key": "AC-INTEGRATION",
        "text": (
            "report 模块以模块级名称 summarize 暴露共享接口，render 对每次输入恰好调用一次 summarize 并透传同一迭代器对象："
            "patch('report.summarize') 下 render(iter([5,-2]))=='total=3; count=2' 且 shared.call_count==1；"
            "判据为只读文件 test_integration.py，自动化执行为登记检查 integration "
            "(python3 -B -m unittest discover -v)；相关上下文为 report.py 的模块级绑定与 render 单次调用。"
            "任务级验收以 report.py 当前实际字节审查该绑定与调用结构，自动化执行留到整项验收的 integration 检查实际完成。"
        ),
    },
]

spec = {
    "problem": (
        "report.render 目前返回字面量 'not implemented'，无法呈现任何求和结果；arithmetic 模块只有 total(values)=sum(values)，"
        "既不给出元素数量，也无法在不二次消费迭代器的前提下同时得到总和与数量。已有的四个只读测试文件已经把期望行为写死："
        "test_summary.py 要求 arithmetic.summarize 对一次性迭代器返回 (总和,数量)，"
        "test_report.py 要求 report.render 输出 'total=5; count=2' 形式文本，"
        "test_integration.py 要求 report 模块通过 report.summarize 暴露共享接口且 render 只调用一次 summarize。"
        "本轮实际观察：登记检查 original 通过（Ran 1 test, OK）；summary 因 ImportError 无法导入 summarize 失败；"
        "report 因返回 'not implemented' 失败；integration 在项目根发现 4 项，其中 1 项通过、1 项失败、2 项导入错误。"
        "缺的是被测业务代码，不是判据。"
    ),
    "goals": [
        "在 arithmetic.py 中新增共享接口 summarize(values)，对任意可迭代对象（含一次性迭代器）单次遍历并返回 (总和,数量) 元组。",
        "让 report.render 通过共享接口 arithmetic.summarize 取数，输出 'total=5; count=2' 形式文本，格式与分隔符严格固定。",
        "保持 arithmetic.total 的现有可观察行为不变（total([2,3])==5、total([])==0、total([-2,3])==1、total(iter([2,3]))==5）。",
        "以原判据 test_arithmetic.py 先证明 total 原行为，再改动 arithmetic.py，改后以同一判据复验，形成可追溯的前后行为证明。",
        "让 report 模块以模块级名称 summarize 暴露共享接口，render 在调用时解析该名称，使 patch('report.summarize') 能替换并观察它。",
        "以四个已登记检查 original、summary、report、integration 覆盖正数、空输入、负数与一次性迭代器四类输入，并把最终整项门槛落在 integration。",
    ],
    "non_goals": [
        "本轮不实现 include_mean 的可选均值输出：render 保留 include_mean=False 形参但不产生均值文本，均值格式与触发条件作为未决问题留给下一轮决定。",
        "不修改任何测试文件：test_arithmetic.py、test_summary.py、test_report.py、test_integration.py 四个判据文件字节保持原样。",
        "不改动 arithmetic.total 的对外签名与语义，也不新增共享接口以外的公共函数或模块。",
        "不批准或写入任何正式知识（不建立术语基线、不做知识同步），本工作项只保存方案。",
        "不引入第三方依赖、不改变 Python 运行方式，不新增构建、打包、部署或提交步骤。",
        "不触碰本方案范围之外的文件，不做与本目标无关的重构、清理或注释整理。",
    ],
    "behavior": [
        "summarize(values) 遍历 values 恰好一次，同时累计总和与元素数量，返回 (total, count) 元组；空输入返回 (0, 0)。",
        "summarize 对负数按原值相加，不做绝对值或符号归一化：summarize(iter([-2,3])) == (1, 2)。",
        "summarize 接受列表、元组或一次性迭代器；对一次性迭代器不得二次消费。",
        "total(values) 的可观察行为保持不变，继续支持列表与一次性迭代器，空输入返回 0。",
        "render(values, include_mean=False) 调用共享接口 summarize 恰好一次，取其返回的总和与数量，输出文本严格为 'total=<总和>; count=<数量>'，例如 render(iter([2,3])) == 'total=5; count=2'。",
        "render 对空输入输出 'total=0; count=0'，对含负数输入输出 'total=1; count=2'。",
        "render 不自行遍历 values，也不缓存或复制输入序列；统计完全来自 summarize 的单次遍历结果。",
        "report 模块在导入后以模块级名称 summarize 暴露该共享接口，render 在每次调用时解析该模块级名称，因此外部 patch 可替换并观察它。",
    ],
    "constraints": [
        "只改两个业务文件：arithmetic.py（CORE）与 report.py（REPORT）；测试文件与项目配置不在改动范围。",
        "summarize 必须是单次遍历实现，不得采用 sum(values) 与 len(values) 两次消费迭代器的写法。",
        "输出格式必须与判据逐字一致，含分号与其两侧空格：'total=5; count=2'，不得附加换行、说明文字或额外字段。",
        "include_mean 必须继续存在于 render 签名中且默认为 False；本轮其取值不改变输出。",
        "report 必须以模块级名称持有 summarize 并在调用时解析，使 patch('report.summarize') 生效。",
        "预重构判据固定为 test_arithmetic.py（检查 original），该文件在 CORE 任务期间保持原字节，作为 preservation_inputs 冻结，不是实现输出。",
        "所有测试为只读判据；后续只运行已登记的四个 argv 检查，不新增、不修改、不放宽任何断言。",
        "所有结论与实施范围限本项目 /private/tmp/evolve14-cl/run/business，不涉及其他项目、插件源码工程、个人配置或外部环境。",
        "本轮只形成并保存完整方案，不接受方案、不实施、不改业务文件。",
    ],
    "tradeoffs": [
        "summarize 采用显式 for 循环累加并计数，而不是 sum(values) 加 len(values)：后者对一次性迭代器会二次消费并出错，也拿不到数量；显式循环多写几行，换来单次遍历与两个结果。",
        "total 保持现有 sum(values) 实现不动，而不是改写为 summarize(values)[0]：两者当前可观察行为一致，但改写会扩大原行为保持的证明面，而 total 只需要 original 一个判据即可证明。",
        "report 通过模块级 from arithmetic import summarize 形成依赖，而不是在函数体内 import：模块级导入使 patch('report.summarize') 可用且运行期开销更低；代价是报告模块与算术模块形成静态耦合。",
        "输出用简单的字符串格式化拼接，不引入模板或序列化库：判据要求的文本极简，引入依赖会扩大本轮迁移面。",
        "CORE 与 REPORT 分为两个任务并以 verification_passed 依赖串联，而不是一次改完两个文件：分任务可让原行为证明只覆盖 arithmetic.py，报告任务只在上游接口被独立验收后才启动；代价是多一次任务级验收。",
        "整体声明为 broad_migration，最终以 integration 检查（unittest discover）读取实际整个目录作为整项门槛：它同时覆盖四个测试模块，能发现任务级检查看不到的跨模块组合问题；代价是整项验收对目录内任何其他未完成改动敏感。",
    ],
    "test_decisions": [
        "四个测试文件全部按只读判据对待：test_arithmetic.py、test_summary.py、test_report.py、test_integration.py 在任何阶段都不被修改或删除；每个测试文件在其相关上下文中声明其覆盖的输入类别与所依赖的业务接口。",
        "正数输入判据：test_summary.py 的 summarize(iter([2,3]))==(5,2) 覆盖共享接口的正数路径，相关上下文为 arithmetic.summarize 的单次遍历，检查 summary 执行；test_report.py 的 render(iter([2,3]))=='total=5; count=2' 覆盖报告正数路径，相关上下文为 report 模块对 summarize 的调用，检查 report 执行。",
        "空输入判据：test_arithmetic.py 的 total([])==0 覆盖既有总数的空输入，test_summary.py 的 summarize(iter([]))==(0,0) 覆盖共享接口的空输入默认值，test_report.py 的 render(iter([]))=='total=0; count=0' 覆盖报告空输入文本；相关上下文为求和初值 0 与计数初值 0。",
        "负数输入判据：test_arithmetic.py 的 total([-2,3])==1、test_summary.py 的 summarize(iter([-2,3]))==(1,2)、test_report.py 的 render(iter([-2,3]))=='total=1; count=2'；相关上下文为求和不取绝对值、不做符号归一化。",
        "一次性迭代器判据：test_arithmetic.py 的 total(iter([2,3]))==5、test_summary.py 的 summarize(iter(...))、test_report.py 的 render(iter(...)) 三处均以迭代器为输入，test_integration.py 进一步以 patch('report.summarize') 后 shared.call_count==1 约束报告只调用一次共享接口；相关上下文为 summarize 单次遍历、render 不自行遍历并透传同一迭代器对象。",
        "原行为保持判据：CORE 声明 pre_refactor，先以登记检查 original（python3 -B -m unittest test_arithmetic -v）在未改动的 arithmetic.py 上取得真实通过证据，再改写 arithmetic.py，改后以同一判据复验；判据输入为 test_arithmetic.py，该文件作为 preservation_inputs 冻结原字节，不是实现输出也不被修改。",
        "任务级与整项门槛的分工：CORE 的任务检查为 original 与 summary，REPORT 的任务检查为 report，每个任务完成后以 verify.run 指定 task_key 做独立任务验收；全部任务完成后，整项验收以登记检查 integration（python3 -B -m unittest discover -v）读取实际整个目录，单任务通过不代填整项通过。",
    ],
    "open_questions": [
        {
            "id": "Q-MEAN-FORMAT",
            "question": "report.render 的 include_mean=True 将来应输出什么文本（追加 '; mean=…' 段、另起一行还是维持原格式），以及非整数输入时均值如何取整？本轮明确不实现。",
            "blocking": False,
            "task_keys": [],
        },
        {
            "id": "Q-TOTAL-IMPL",
            "question": "arithmetic.total 是否在后续轮次改写为 summarize(values)[0]（当前可观察行为一致）以消除重复求和逻辑，还是保持现有 sum(values) 实现不动？",
            "blocking": False,
            "task_keys": ["CORE"],
        },
        {
            "id": "Q-SHARED-SURFACE",
            "question": "共享接口是否还需要单独暴露 count，或给 total 增加返回数量的重载（例如 total(values, with_count=True)）以支持其他调用方？",
            "blocking": False,
            "task_keys": [],
        },
        {
            "id": "Q-FORMAL-KNOWLEDGE",
            "question": "六个文件的接口约定后续是否固化为正式知识（术语基线），还是仅以本工作项的判据为准？本轮不批准正式知识。",
            "blocking": False,
            "task_keys": [],
        },
    ],
    "broad_migration": True,
    "integration_boundary": (
        "迁移边界是两个业务文件构成的接口面：arithmetic.py 提供共享求和接口，report.py 消费它；"
        "边界之外是四个只读测试文件与 Evolve 自身记录设施（evolve/、.evolve-local/），测试文件只被读取、不被修改。"
        "整项门槛是登记检查 integration（python3 -B -m unittest discover -v），它在项目根实际发现并运行全部 test*.py 模块，"
        "因此同时覆盖原行为保持、共享接口、报告文本与共享接口绑定四类结果；"
        "同时它对目录内任何其他未完成改动敏感，集成失败需要按实际失败归因处理，不能只靠单任务通过推断整项完成。"
    ),
}

tasks = [
    {
        "local_key": "CORE",
        "title": "CORE：arithmetic.summarize 共享接口与 total 原行为保持",
        "completion": (
            "arithmetic.py 在保持 total 现有行为不变的前提下新增 summarize(values)，对一次性迭代器单次遍历返回 (总和,数量)；"
            "登记检查 original 与 summary 均实际通过，且改前改后以同一判据形成完整的行为保持证明。"
        ),
        "validation": (
            "改前以登记检查 original（python3 -B -m unittest test_arithmetic -v）取得 total 原行为的真实通过证据；"
            "改后以同一判据 original 复验，并以登记检查 summary（python3 -B -m unittest test_summary -v）"
            "验证 summarize 的正数、空输入、负数与一次性迭代器行为；"
            "任务完成后以 verify.run 指定 task_key=CORE 做独立任务验收，逐项给出 AC-ORIGINAL 与 AC-SUMMARY 的实际结果。"
        ),
        "exclusions": [
            "report.py 不在本任务范围内，报告输出格式由 REPORT 任务负责。",
            "不修改 test_arithmetic.py、test_summary.py、test_report.py、test_integration.py 任何测试文件。",
            "不实现 include_mean 或任何均值输出。",
            "不新增 summarize 以外的公共函数或模块，也不改动 total 的签名与语义。",
        ],
        "scope": ["arithmetic.py"],
        "acceptance": ["AC-ORIGINAL", "AC-SUMMARY"],
        "required_checks": ["original", "summary"],
        "context_paths": ["test_arithmetic.py", "test_summary.py"],
        "test_decision_refs": [
            "spec.test_decisions/0",
            "spec.test_decisions/1",
            "spec.test_decisions/2",
            "spec.test_decisions/3",
            "spec.test_decisions/4",
            "spec.test_decisions/5",
        ],
        "dependencies": [],
        "pre_refactor": True,
        "preservation_checks": ["original"],
        "preservation_inputs": ["test_arithmetic.py"],
    },
    {
        "local_key": "REPORT",
        "title": "REPORT：report.render 通过共享接口生成 total/count 文本",
        "completion": (
            "report.py 通过共享接口 arithmetic.summarize 生成 'total=5; count=2' 形式文本，"
            "render 对每次输入只调用一次 summarize 并透传同一迭代器；登记检查 report 实际通过，"
            "且上游 CORE 的独立任务验收已通过。"
        ),
        "validation": (
            "以登记检查 report（python3 -B -m unittest test_report -v）验证正数、空输入、负数与一次性迭代器下的报告文本；"
            "report 模块的共享接口绑定与单次调用由登记检查 integration（python3 -B -m unittest discover -v）在整项阶段"
            "读取实际整个目录复核；任务完成后以 verify.run 指定 task_key=REPORT 做独立任务验收，"
            "逐项给出 AC-REPORT 与 AC-INTEGRATION 的实际结果。"
        ),
        "exclusions": [
            "arithmetic.py 不在本任务范围内，共享接口由 CORE 任务提供并作为上游产物核对，不在本任务中改写。",
            "不修改四个测试文件。",
            "不实现 include_mean 的均值文本，include_mean 形参保留但不影响输出。",
            "不引入新的输出字段，也不改变 'total=…; count=…' 的字面格式与分隔符。",
        ],
        "scope": ["report.py"],
        "acceptance": ["AC-REPORT", "AC-INTEGRATION"],
        "required_checks": ["report"],
        "context_paths": ["arithmetic.py", "test_report.py", "test_integration.py"],
        "test_decision_refs": [
            "spec.test_decisions/0",
            "spec.test_decisions/1",
            "spec.test_decisions/2",
            "spec.test_decisions/3",
            "spec.test_decisions/4",
            "spec.test_decisions/6",
        ],
        "dependencies": [
            {
                "upstream_task": "CORE",
                "condition_kind": "verification_passed",
                "basis": (
                    "CORE 的独立任务验收（verify.run 指定 task_key=CORE）通过，"
                    "证明 arithmetic.summarize 共享接口与 total 原行为保持均已被实际验证，REPORT 才可消费该接口。"
                ),
            }
        ],
    },
]

document = {
    "title": title,
    "plan": plan,
    "completion": completion,
    "scope": scope,
    "acceptance": acceptance,
    "required_checks": required_checks,
    "spec": spec,
    "tasks": tasks,
}

request = {
    "authorization": {
        "source": "user_instruction",
        "text": (
            "使用 Evolve 接入当前临时项目，仅形成并保存完整复杂方案，本轮不接受方案、不实施或改业务。"
            "目标：保留 arithmetic.total 的现有行为，提取单次迭代的 arithmetic.summarize(values)，返回 (总和,数量)；"
            "report.render(values, include_mean=False) 通过该共享接口生成 total=5; count=2 这样的文本。"
            "按当前六个文件的独立测试核对正数、空输入、负数和一次性迭代器；此轮不实现可选均值。"
            "完整 spec 要呈现目标、边界、行为、约束、取舍、测试决定及未决问题。"
            "任务键固定 CORE、REPORT：CORE 是为报告所必需的预重构，文件仅 arithmetic.py，先证明原 total 行为，再形成共享 summarize；"
            "REPORT 文件仅 report.py，依赖 CORE 的独立任务验收通过。"
            "所有测试为只读判据，分别声明相关上下文。登记检查 ID original、summary、report、integration。"
            "这是两个模块的广泛接口迁移，声明 broad_migration 及最终集成边界；任务完成不能代替全项通过。"
            "不改测试，不批准正式知识。"
        ),
        "effect_kinds": ["project_records"],
        "paths": [],
    },
    "input": {
        "complexity": "complex",
        "title": title,
        "plan": plan,
        "completion": completion,
        "scope": scope,
        "acceptance": acceptance,
        "required_checks": required_checks,
        "spec": spec,
        "tasks": tasks,
        "presentation": {
            "source": "user_instruction",
            "document": document,
        },
    },
}

target = requests_dir / 'propose-complex-round1.json'
target.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding='utf-8')
print(str(target))
