import json
from pathlib import Path

requests = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests')
dump = json.loads((requests / 'plan_dump.json').read_text())
plan = dump['plan']
stored = json.loads(plan['text'])
assert stored == plan['document'], 'status text and document disagree'

document = json.loads(json.dumps(plan['document']))

NEW_PLAN = """本方案要解决两件事：让 report 真正输出求和结果，同时保证 arithmetic.total 的现有行为一字不变。为此在 arithmetic.py 中新增一个共享求和接口 summarize(values)，并让 report.py 改为调用该接口生成报告文本。工作拆成两个有真实依赖的任务，按依赖顺序推进。

一、任务 CORE（文件仅 arithmetic.py，必要预重构）
1. 先在未改动的 arithmetic.py 上运行登记检查 original（python3 -B -m unittest test_arithmetic -v），取得 total 原行为的真实通过证据，并把判据文件 test_arithmetic.py 的原字节冻结为只读输入。这是改动前的原行为证明，改动后用同一判据复验。
2. 再在 arithmetic.py 中新增 summarize(values)：用显式循环单次遍历输入，同时累计总和与元素数量，返回 (总和,数量) 元组；total 保持现有 sum(values) 实现不动，不改签名与语义。
3. 改后以同一判据 original 复验，并运行登记检查 summary（python3 -B -m unittest test_summary -v），覆盖正数、空输入、负数与一次性迭代器。

二、任务 REPORT（文件仅 report.py）
1. 以模块级 from arithmetic import summarize 绑定共享接口，render(values, include_mean=False) 在每次调用时解析该模块级名称。
2. render 对输入只调用一次 summarize 并透传同一入参，按 'total=<总和>; count=<数量>' 输出文本（例如 'total=5; count=2'），自身不遍历输入。
3. REPORT 显式依赖 CORE 的独立任务验收通过后才启动，避免共享接口尚未被实际验证时写出报告代码。

三、判据与门槛
两个任务分别以登记检查 original/summary 与 report 作为任务级判据，并各自完成独立任务验收（verify.run 指定 task_key）。
四个测试文件 test_arithmetic.py、test_summary.py、test_report.py、test_integration.py 全部作为只读判据，字节不改。
最终整项验收以登记检查 integration（python3 -B -m unittest discover -v）读取实际整个目录；单个任务通过不代填整项通过。

四、边界
不改任何测试文件；不实现 include_mean 的均值文本；不改动 total 的签名与语义，也不新增 summarize 以外的公共函数或模块；所有结论与实施范围限本项目。
本方案文档本身只是方案：保存方案不等于接受方案，也不实施、不修改任何业务文件，也不批准任何正式知识；实施须在明确接受后按上面的任务顺序进行。"""

TITLES = {
    'CORE': '任务一 CORE：在 arithmetic.py 新增 summarize 单次遍历接口，同时保持 total 原有行为',
    'REPORT': '任务二 REPORT：让 report.render 调用共享接口，输出 total 与 count 文本',
}

document['title'] = '单次迭代汇总与报告'
document['plan'] = NEW_PLAN
for task in document['tasks']:
    task['title'] = TITLES[task['local_key']]

fields = ('title', 'plan', 'completion', 'scope', 'acceptance', 'required_checks', 'spec', 'tasks')
proposal = {key: document[key] for key in fields}
proposal['complexity'] = 'complex'
proposal['presentation'] = {'source': 'user_instruction', 'document': {key: document[key] for key in fields}}

AUTHORIZATION_TEXT = (
    '使用 Evolve 仅修订当前完整方案的展示：将方案标题改为"单次迭代汇总与报告"，让 plan 摘要更清楚，'
    '并将两个任务的展示标题写得易懂。目标、完成条件、AC、测试决定、范围、依赖和检查含义全部保持；'
    '沿原已接受依据保存新的 REV。保留部分进度、授权及原行为证明。本轮不实施、不运行检查、不写业务或测试。'
)

request = {
    'request_id': 'revise-presentation-20261101-01',
    'project_id': '08732152-a528-4b48-8bc0-ce9098e9b4c8',
    'expected_workspace_epoch': '0c05f0c5-9b37-4322-be92-a0a22a2d9a4f',
    'expected_versions': {
        'change': 3,
        'tasks': {
            '3e254a84-caf4-4d44-98cc-cb70de6a835a': 5,
            '0aafac3f-0c8f-4e29-bf11-61e55b03211c': 1,
        },
    },
    'authorization': {
        'source': 'user_instruction',
        'text': AUTHORIZATION_TEXT,
        'effect_kinds': ['project_records'],
        'paths': [],
    },
    'input': {
        'change_id': '5a4b1728-faea-4266-aae2-21992993ceab',
        'revision_id': 'f3834e49-ba52-4514-baa9-092a3a42ea00',
        'definition_digest': '3eb1c85c426bda386ef0ad79f5264b4ae36248787d5a762c5ef7f9c5e2e04257',
        'task_id': None,
        'reason': (
            '仅修订当前完整方案的展示：方案标题改为"单次迭代汇总与报告"，plan 摘要按任务一、任务二、判据与门槛、'
            '边界重新分节使含义更易读，两个任务的展示标题改为易懂表述。目标、完成条件、AC、测试决定、范围、依赖与检查含义'
            '全部不变，沿原已接受依据保存新的 REV；本轮不实施、不运行检查、不写业务或测试。'
        ),
        'proposal': proposal,
    },
}

out = requests / 'request-revise-presentation-20261101.json'
out.write_text(json.dumps(request, ensure_ascii=False, indent=2))
print('written', out)
print('unchanged checks:',
      all(document[key] == plan['document'][key] for key in ('completion', 'scope', 'acceptance', 'required_checks', 'spec')))
print('task titles:', [task['title'] for task in document['tasks']])
