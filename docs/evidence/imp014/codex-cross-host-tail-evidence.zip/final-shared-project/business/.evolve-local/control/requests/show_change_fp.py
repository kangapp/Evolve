import json
from pathlib import Path

base = Path('/private/tmp/evolve14-cl/run/business/.evolve-local/control/requests')
misc = json.loads((base / 'resume_misc.json').read_text(encoding='utf-8'))
wo = misc.get('workspace_observation')
print('workspace_observation keys:', list(wo.keys()) if isinstance(wo, dict) else type(wo))
cur = wo.get('current', {}) if isinstance(wo, dict) else {}
print('digest:', cur.get('digest'))
print('files:', json.dumps(cur.get('files'), ensure_ascii=False, indent=2))
print('scope:', json.dumps(cur.get('scope'), ensure_ascii=False))
print('context:', json.dumps(cur.get('context'), ensure_ascii=False))
print('status:', wo.get('status'))
print('suggested_action:', misc.get('suggested_action'), 'suggested_task_id:', misc.get('suggested_task_id'))
print('authorization_granted:', misc.get('authorization_granted'))
print('continuation_requires:', json.dumps(misc.get('continuation_requires'), ensure_ascii=False))
print('learning_context:', json.dumps(misc.get('learning_context'), ensure_ascii=False)[:800])
