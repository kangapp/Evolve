from arithmetic import summarize


def render(values, include_mean=False):
    total, count = summarize(values)
    text = f"total={total}; count={count}"
    if include_mean:
        mean = total / count if count else 0.0
        text = f"{text}; mean={mean:.2f}"
    return text
