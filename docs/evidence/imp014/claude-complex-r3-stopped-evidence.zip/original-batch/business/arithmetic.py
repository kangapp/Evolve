def total(values):
    return sum(values)


def summarize(values):
    running_total = 0
    count = 0
    for value in values:
        running_total += value
        count += 1
    return running_total, count
