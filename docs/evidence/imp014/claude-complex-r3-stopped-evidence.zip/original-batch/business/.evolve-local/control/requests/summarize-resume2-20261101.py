import json
import sys

path = sys.argv[1]
with open(path, encoding="utf-8") as handle:
    data = json.load(handle)

ctx = data["data"]["context"]
print("TOP KEYS:", list(ctx.keys()))

for key in ctx:
    if key in {"project"}:
        print(f"\n== project (trimmed)")
        proj = ctx[key]
        for sub in proj:
            if sub in {"changes"}:
                for change in proj[sub]:
                    print(f"  change {change['code']} state={change['state']} rev={change['current_revision']}")
                    for task in change["tasks"]:
                        print(
                            f"    task {task['local_key']} state={task['state']} ready={task['readiness']['ready']} unmet={task['readiness']['unmet']}"
                        )
            elif sub == "analyses":
                print(f"  analyses: {proj[sub]}")
            elif sub == "pending_runs":
                print(f"  pending_runs: {json.dumps(proj[sub], ensure_ascii=False)}")
            else:
                print(f"  {sub} = {json.dumps(proj[sub], ensure_ascii=False)[:400]}")
        continue
    if key in {"plan", "definition"}:
        continue
    print(f"\n== {key}")
    print(json.dumps(ctx[key], ensure_ascii=False, indent=1)[:8000])
