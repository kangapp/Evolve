import json
import sys

path = sys.argv[1]
with open(path, encoding="utf-8") as handle:
    data = json.load(handle)

ctx = data["data"]["context"]
for item in ctx.get("task_contexts", []):
    observation = item.get("workspace_observation") or {}
    current = observation.get("current") or {}
    print("task", item.get("local_key"), "state=", item.get("state"))
    print("  digest:", current.get("digest"))
    print("  scope:", current.get("scope"))
    print("  context:", current.get("context"))
    print("  checks:", [c["id"] for c in current.get("checks", [])])
whole = (ctx.get("workspace_observation") or {}).get("current") or {}
print("whole_change digest:", whole.get("digest"))
print("whole_change scope:", whole.get("scope"))
print("whole_change context:", whole.get("context"))
print("whole_change checks:", [c["id"] for c in whole.get("checks", [])])
