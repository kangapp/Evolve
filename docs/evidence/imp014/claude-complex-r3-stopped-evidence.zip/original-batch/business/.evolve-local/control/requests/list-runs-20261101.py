import json
import sys

path = sys.argv[1]
with open(path, encoding="utf-8") as handle:
    data = json.load(handle)

runs = data["data"]["context"]["runs"]
print("run count:", len(runs))
for run in runs:
    result = run.get("result") or {}
    print("---")
    print("run_id:", run.get("run_id"))
    print("action:", run.get("action"), "status:", run.get("status"))
    print("result_digest:", run.get("result_digest"))
    print("ended_at:", run.get("ended_at"))
    for key in (
        "outcome",
        "checks",
        "overall_verification",
        "task_id",
        "revision_id",
        "definition_digest",
        "continuation",
        "task_key",
        "source_runs",
        "preservation",
        "operation_id",
        "accepted",
        "revision",
        "change_version",
    ):
        if key in result:
            print(f"  {key}:", json.dumps(result[key], ensure_ascii=False)[:600])
    print("  auth_effects:", run.get("authorization", {}).get("effect_kinds"))
    print("  auth_paths:", run.get("authorization", {}).get("paths"))
    print("  learning:", json.dumps(run.get("learning"), ensure_ascii=False)[:300])
    progress = result.get("progress")
    if progress:
        print("  progress.reason:", progress.get("reason"))
        print("  progress.remaining:", progress.get("remaining"))
