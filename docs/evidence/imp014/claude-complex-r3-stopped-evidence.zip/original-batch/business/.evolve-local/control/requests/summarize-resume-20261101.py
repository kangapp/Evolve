import json
import sys

path = sys.argv[1]
with open(path, encoding="utf-8") as handle:
    data = json.load(handle)

ctx = data["data"]["context"]


def walk(node, depth=0):
    if isinstance(node, dict):
        for key, value in node.items():
            if isinstance(value, (dict, list)):
                print("  " * depth + f"{key}:")
                walk(value, depth + 1)
            else:
                print("  " * depth + f"{key} = {value}")
    elif isinstance(node, list):
        for index, item in enumerate(node):
            print("  " * depth + f"[{index}]")
            walk(item, depth + 1)
    else:
        print("  " * depth + str(node))


skip = {"plan", "definition", "document", "candidate", "spec"}
for key, value in ctx.items():
    if key in skip:
        print(f"== {key} (skipped, large)")
        continue
    print(f"== {key}")
    walk(value, 1)
