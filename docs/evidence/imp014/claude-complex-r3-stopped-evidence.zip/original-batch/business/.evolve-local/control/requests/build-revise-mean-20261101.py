import json
import sys
from pathlib import Path

PLUGIN = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-frozen-010-r3-lg0e6ccx/claude-native-r2/business/.agents/evolve-acceptance/profile/plugins/cache/evolve-local/evolve/0.1.0")
sys.path.insert(0, str(PLUGIN / "runtime"))
from evolve_core.reading import current_state

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-frozen-010-r3-lg0e6ccx/claude-native-r2/business")
OUT = ROOT / ".evolve-local/control/requests/revise-mean-20261101.json"
TITLE = "单次迭代汇总与报告"

acceptance = [
    {"key": "AC-TOTAL", "text": "arithmetic.total 保持现有行为：对 [2,3] 返回 5，对 [] 返回 0，对 [-2,3] 返回 1，且对一次性迭代器仍返回 5。"},
    {"key": "AC-SUMMARIZE", "text": "arithmetic.summarize(values) 单次遍历输入并返回 (总和, 数量)：正数 [2,3] 得 (5,2)，空输入得 (0,0)，含负数 [-2,3] 得 (1,2)。"},
    {"key": "AC-RENDER", "text": "report.render(values, include_mean=False) 通过共享 summarize 生成 \"total=<总和>; count=<数量>\" 文本：正数得 \"total=5; count=2\"，空输入得 \"total=0; count=0\"，含负数得 \"total=1; count=2\"。"},
    {"key": "AC-SINGLEPASS", "text": "render 面对一次性迭代器只消费输入一次，且整项范围内共享接口只被调用一次（report.summarize 调用次数为 1）。"},
    {"key": "AC-MEAN", "text": "report.render(values, include_mean=True) 在同一份 \"total=<总和>; count=<数量>\" 文本后追加固定格式的均值字段 \"mean=<均值>\"，均值按总和除以数量计算并保留两位小数：正数 [2,3] 得 \"total=5; count=2; mean=2.50\"，空输入得 \"total=0; count=0; mean=0.00\"，含负数 [-2,3] 得 \"total=1; count=2; mean=0.50\"；include_mean 缺省为 False 时输出与原文本完全一致。"},
]

spec = {
    "problem": "本项 Change 的原始问题是 report.render 固定返回 \"not implemented\"，无法输出任何汇总文本；arithmetic 只有 total(values)，缺少能同时给出总和与数量的共享接口，render 因此无法在不重复遍历输入的前提下复用业务逻辑。CORE 已完成共享接口的提取，REPORT 已完成 total/count 文本的渲染；当前剩余缺口是 render 接受 include_mean 参数但未使用，include_mean=True 与缺省调用输出相同，而控制侧新增的只读判据 test_report_mean.py 要求在原文本后追加保留两位小数的均值字段。",
    "goals": [
        "保持 arithmetic.total 的现有可观察行为不变：求和语义、返回形态、空输入与负数结果均不改变。",
        "在 arithmetic.py 中提取单次迭代的共享接口 summarize(values)，返回 (总和, 数量)。",
        "让 report.render(values, include_mean=False) 通过该共享接口生成 \"total=<总和>; count=<数量>\" 文本。",
        "以当前项目七个文件中的五个独立测试模块作为只读判据，核对正数、空输入、负数、一次性迭代器与可选均值。",
        "先证明 arithmetic.total 的现有行为，再形成共享 summarize，使行为证明与重构结果分别留痕。",
        "让 report.render(values, include_mean=True) 在同一份 \"total=<总和>; count=<数量>\" 文本后追加保留两位小数的 \"mean=<均值>\" 字段，数量为 0 时为 0.00，同时保持 include_mean 缺省为 False 时的原文本逐字不变。",
    ],
    "non_goals": [
        "不修改、不新增、不删除任何测试文件；五个测试模块保持原判据只读，其中 test_report_mean.py 由控制侧在本工作之外新增，本工作只作为只读独立判据使用。",
        "不改动 total 的签名、返回形态或异常行为，也不新增其他公开函数。",
        "不引入第三方依赖、命令行入口、持久化或外部数据访问。",
        "不批准、不登记任何正式项目知识或经验条目。",
        "不改动 arithmetic.summarize 的返回形态，均值由 REPORT 在渲染时依据同一份 (总和, 数量) 计算。",
        "不新增除 report.render 与既有 arithmetic.summarize 之外的公开接口，也不改动 render 的签名与 include_mean 的默认值。",
    ],
    "behavior": [
        "arithmetic.total(values) 继续等于 sum(values)，对列表与一次性迭代器均成立。",
        "arithmetic.summarize(values) 只遍历输入一次，同时得到总和与数量：数量是实际消费的元素个数，总和是这些元素的算术和；空输入返回 (0, 0)。",
        "summarize 对正负混合输入按算术和计算数量，不做绝对值或符号处理。",
        "report.render(values, include_mean=False) 调用共享 summarize 一次，把 (总和, 数量) 渲染为 \"total=<总和>; count=<数量>\"，不输出均值或任何其他字段。",
        "render 接收一次性迭代器时不得二次遍历输入：文本中的总和与数量来自同一次遍历的结果。",
        "report 模块须以 report.summarize 的形式暴露该共享接口，使跨模块调用点可被检查观察。",
        "report.render(values, include_mean=True) 在 include_mean=False 的同一份文本后追加 \"mean=<均值>\" 字段，均值为总和除以数量并保留两位小数；数量为 0 时均值为 0.00。",
        "render 在 include_mean=True 分支中仍只调用共享 summarize 一次，均值由同一次遍历得到的 (总和, 数量) 计算，不二次遍历输入。",
    ],
    "constraints": [
        "只允许改写 arithmetic.py 与 report.py 两个业务文件；五个测试模块是只读判据。",
        "共享接口必须位于 arithmetic 模块，report 通过导入该接口调用，不得在 report 内复制求和逻辑。",
        "判据只用已登记的五个检查：original、summary、report、mean、integration，命令分别为 python3 -B -m unittest test_arithmetic -v、test_summary -v、test_report -v、test_report_mean -v、discover -v。",
        "CORE 是为报告所必需的预重构：原行为保持只以 original 检查证明，preservation 输入固定为 test_arithmetic.py。",
        "REPORT 依赖 CORE 的独立任务验收通过（verification_passed），上游未通过时不得实施。",
        "本轮只形成并保存方案：不接受方案、不实施、不改业务文件、不批准正式知识。",
    ],
    "tradeoffs": [
        "保留 total 作为独立入口而不是改成 summarize 的别名，避免改变既有调用点的返回形态，代价是两处求和语义要在实现时保持一致。",
        "summarize 返回元组 (总和, 数量) 而非结果对象或可调用迭代器，接口最小、实现最简，代价是后续扩展（如均值）需要再次改动该接口形态。",
        "render 文本格式固定为 \"total=<总和>; count=<数量>\"，与现有 test_report.py 判据一致，不引入额外分隔、空白或多行结构。",
        "集成边界放在最终 integration 检查而不是在 REPORT 任务内重复验证，避免同一事实被两处断言，代价是整项验收必须执行一次完整的发现式检查。",
        "均值在渲染时由 (总和, 数量) 现算并格式化，不扩展 arithmetic.summarize 的返回形态，保持 CORE 的接口与既有原行为证明不变；代价是渲染层多一处格式化逻辑。",
        "均值格式固定为保留两位小数的 \"mean=<值>\"，与判据 test_report_mean.py 一致；代价是精度被截断到两位小数，需要更高精度的展示不在本轮范围内。",
    ],
    "test_decisions": [
        "原行为保持只使用 original 检查（python3 -B -m unittest test_arithmetic -v）：该模块保留 total 的原有字面量判据，正数、空输入、负数与一次性迭代器都在同一文件内断言；相关上下文为 test_arithmetic.py，其字节在重构中不得变化。",
        "共享接口行为使用 summary 检查（python3 -B -m unittest test_summary -v）：该模块以一次性迭代器断言 summarize 的 (5,2)、(0,0)、(1,2) 三种结果，覆盖正数、空输入与负数；相关上下文为 test_summary.py。",
        "报告文本使用 report 检查（python3 -B -m unittest test_report -v）：该模块断言 render 的 \"total=5; count=2\"、\"total=0; count=0\"、\"total=1; count=2\" 三种文本；相关上下文为 test_report.py。",
        "跨模块集成与单次调用边界使用最终 integration 检查（python3 -B -m unittest discover -v）：该次发现式执行覆盖全部五个测试模块，并由 test_integration.py 断言 report.summarize 的调用次数为 1；相关上下文为 test_integration.py。",
        "五个测试模块本轮均为只读判据：不修改、不放宽、不删除任何断言，也不由本工作新增替代测试；其中 test_report_mean.py 由控制侧在本工作之外新增。",
        "可选均值输出使用 mean 检查（python3 -B -m unittest test_report_mean -v）：该模块断言 include_mean=True 时 \"total=5; count=2; mean=2.50\"、\"total=0; count=0; mean=0.00\"、\"total=1; count=2; mean=0.50\" 三种文本，并断言缺省调用仍得 \"total=5; count=2\"；该模块由控制侧新增，作为只读独立判据，相关上下文为 test_report_mean.py。",
    ],
    "open_questions": [
        {"id": "Q-COUNT", "question": "summarize 的数量是否应计入非数值元素或 None？当前判据只覆盖数值输入，未涉及非数值元素。", "blocking": False, "task_keys": ["CORE"]},
        {"id": "Q-MEAN-ROUND", "question": "均值在需要进位的输入下按四舍五入还是截断保留两位小数？本轮判据 test_report_mean.py 只覆盖 mean=2.50、0.00、0.50 三种结果，未覆盖进位场景。", "blocking": False, "task_keys": ["REPORT"]},
    ],
    "broad_migration": True,
    "integration_boundary": "本次是 arithmetic 与 report 两个模块之间的接口迁移，并在同一交付中补齐可选均值输出：total 的调用形态保持不变，arithmetic.summarize 仍是唯一共享求和入口，report.render 从返回固定占位文本改为消费该共享接口，本次进一步在 include_mean=True 分支追加保留两位小数的均值字段。边界内为 arithmetic.py 与 report.py 两个业务文件，边界外为五个只读判据测试模块以及任何正式知识与外部系统。整项交付以最终 integration 检查（python3 -B -m unittest discover -v）在当前整个项目目录上通过为准；单个任务实施完成或单个任务验收通过都不代表整项通过。",
}

tasks = [
    {
        "local_key": "CORE",
        "title": "任务一：在 arithmetic.py 提取共享求和接口 summarize，并保持 total 现有行为",
        "completion": "arithmetic.py 的 total 行为与重构前完全一致，并新增 summarize(values) 单次遍历返回 (总和, 数量)；original 与 summary 两项检查均通过。",
        "validation": "先用 original 检查（python3 -B -m unittest test_arithmetic -v）在未改动的 arithmetic.py 上证明 total 的现有行为，再改写 arithmetic.py，最后复跑 original 与 summary 检查；判据文件 test_arithmetic.py 与 test_summary.py 全程只读。",
        "exclusions": ["不修改 report.py", "不修改任何测试文件", "不实现 include_mean 的可选均值输出", "不改动 total 的签名与返回形态"],
        "scope": ["arithmetic.py"],
        "acceptance": ["AC-TOTAL", "AC-SUMMARIZE"],
        "required_checks": ["original", "summary"],
        "context_paths": ["test_arithmetic.py", "test_summary.py"],
        "test_decision_refs": ["spec.test_decisions/0", "spec.test_decisions/1"],
        "dependencies": [],
        "pre_refactor": True,
        "preservation_checks": ["original"],
        "preservation_inputs": ["test_arithmetic.py"],
    },
    {
        "local_key": "REPORT",
        "title": "任务二：改写 report.py，让 render 复用共享 summarize 输出汇总文本",
        "completion": "report.py 以 from arithmetic import summarize 导入共享接口，render(values, include_mean=False) 输出 \"total=<总和>; count=<数量>\" 原文本，include_mean=True 时在同一文本后追加保留两位小数的 \"mean=<均值>\" 字段（数量为 0 时为 0.00）；report 与 mean 两项检查均通过。",
        "validation": "在 CORE 任务的独立验收通过后实施 report.py，运行 report 检查（python3 -B -m unittest test_report -v）与 mean 检查（python3 -B -m unittest test_report_mean -v）；跨模块单次调用边界由最终 integration 检查在整项范围判定。",
        "exclusions": ["不修改 arithmetic.py", "不修改任何测试文件", "不在 report 内复制求和逻辑", "不改变 render 的签名与 include_mean 的默认值"],
        "scope": ["report.py"],
        "acceptance": ["AC-RENDER", "AC-SINGLEPASS", "AC-MEAN"],
        "required_checks": ["report", "mean"],
        "context_paths": ["arithmetic.py", "test_report.py", "test_integration.py", "test_report_mean.py"],
        "test_decision_refs": ["spec.test_decisions/2", "spec.test_decisions/3", "spec.test_decisions/5"],
        "dependencies": [
            {
                "upstream_task": "CORE",
                "condition_kind": "verification_passed",
                "basis": "REPORT 需要 arithmetic.summarize 这一共享接口已由 CORE 任务独立验收通过并保持可用。",
            }
        ],
    },
]

document = {
    "title": TITLE,
    "plan": "本项是一次跨模块的接口迁移，并在已完成的迁移之上补齐可选均值输出：让 report 的汇总文本复用 arithmetic 的单次遍历求和接口，共两个任务。任务一 CORE 是为报告所必需的预重构：先在未改动的 arithmetic.py 上运行 original 检查（python3 -B -m unittest test_arithmetic -v）证明 total 的现有行为，再在 arithmetic.py 内提取 summarize(values)，单次遍历输入并返回 (总和, 数量)，由 summary 检查（python3 -B -m unittest test_summary -v）判定；CORE 的目标、验收条件、范围、检查、上下文与依赖在本次修订中逐字保持不变，其既有实施结果与 total 现有行为的原证明在当前现场仍然适用，不因本次修订重开。任务二 REPORT 在 CORE 的独立任务验收通过后实施：只改写 report.py，以 from arithmetic import summarize 导入共享接口，由 render(values, include_mean=False) 依共享结果生成 \"total=<总和>; count=<数量>\" 原文本；本次修订为 REPORT 新增 include_mean=True 分支，在同一文本后追加 \"mean=<均值>\" 字段，均值由同一份 (总和, 数量) 计算并保留两位小数，数量为 0 时给出 0.00。REPORT 的判据为原 report 检查（python3 -B -m unittest test_report -v）与控制侧新增的只读独立判据 mean 检查（python3 -B -m unittest test_report_mean -v），后者同时断言缺省调用仍得原文本。范围与判据：两个任务合计只改写 arithmetic.py 与 report.py，五个测试模块保持只读；最后以 integration 检查（python3 -B -m unittest discover -v）在整个项目目录上完成最终集成验收，单个任务实施完成或单个任务验收通过都不代表整项通过。本次修订新增可选均值验收条件 AC-MEAN 并由 REPORT 任务负责，原有四条验收条件、CORE 的定义与既有结果、REPORT 的原有验收条件与范围保持不变；本轮只呈现并保存完整新 REV，不接受新语义方案、不实施、不运行检查、不改业务与测试文件、不批准正式知识。",
    "completion": "arithmetic.total 的现有行为保持不变；arithmetic.summarize(values) 单次遍历返回 (总和, 数量)；report.render(values, include_mean=False) 输出 \"total=5; count=2\" 形式的原文本，include_mean=True 时在同一文本后追加保留两位小数的 \"mean=<均值>\" 字段（数量为 0 时为 0.00）；original、summary、report、mean 四项任务检查通过，且最终 integration 检查（python3 -B -m unittest discover -v）在当前整个项目目录上通过，整项才算完成。",
    "scope": ["arithmetic.py", "report.py"],
    "acceptance": acceptance,
    "required_checks": ["integration"],
    "spec": spec,
    "tasks": tasks,
}

state = current_state(ROOT, TITLE)
changes = state["changes"]
assert len(changes) == 1, "the work item title is not unique"
change = changes[0]
old = change["plan"]["document"]
assert change["plan"]["accepted"] is True, "the source revision is not the accepted one"

old_acceptance = {item["key"]: item["text"] for item in old["acceptance"]}
for item in acceptance:
    if item["key"] != "AC-MEAN":
        assert old_acceptance.get(item["key"]) == item["text"], "acceptance text drifted: " + item["key"]
assert "AC-MEAN" not in old_acceptance, "the new acceptance key already exists"

old_tasks = {task["local_key"]: task for task in old["tasks"]}
assert old_tasks["CORE"] == tasks[0], "the CORE task definition drifted"
assert old["scope"] == document["scope"], "the plan scope changed"
assert old["required_checks"] == document["required_checks"], "the whole-change checks changed"
assert set(old_tasks["REPORT"]["acceptance"]) <= set(document["tasks"][1]["acceptance"]), "an original REPORT acceptance was dropped"
assert old["tasks"][1]["scope"] == document["tasks"][1]["scope"], "the REPORT scope changed"

request = {
    "project_id": "c1aa24b9-23f8-4120-9b67-b972b6bd42a9",
    "expected_workspace_epoch": "a2f8ff56-7ee5-4281-b2a8-662533196559",
    "input": {
        "change_id": change["id"],
        "reason": "新增可选均值输出：把 report.render 的 include_mean=True 分支纳入本方案，新增验收条件 AC-MEAN（格式固定为 total=5; count=2; mean=2.50，保留两位小数，空输入 mean=0.00），由 REPORT 任务负责，并把控制侧新增的只读独立判据 test_report_mean.py 登记为 mean 检查。原有四条验收条件、REPORT 的原有验收条件与范围、CORE 的定义与既有实施结果按原样保留；旧阶段“不实现 include_mean 的可选均值输出”的描述在本方案中已不成立，随本次修订移除。本轮只呈现并保存完整新 REV，不接受新语义方案、不实施、不运行检查、不封存。",
        "proposal": dict(document, complexity="complex", presentation={"source": "user", "document": document}),
        "impact": {
            "affected_tasks": ["REPORT"],
            "basis": "本次修订只新增 include_mean=True 的可选均值语义，落在 REPORT 任务负责的 report.py：AC-MEAN、mean 检查与 test_report_mean.py 上下文都属于 REPORT。CORE 的目标、验收条件、范围、检查、上下文与依赖逐字未变，其 arithmetic.py 实施结果与 total 现有行为的原证明在当前现场仍适用，因此不列为受本次 spec 变化影响的任务。",
        },
    },
    "authorization": {
        "source": "user",
        "text": "使用 Evolve 修改当前活动方案：report.render 的 include_mean=True 分支增加均值，格式固定为 total=5; count=2; mean=2.50，保留两位小数；空输入 mean=0.00。默认 False 的原文本和 total／summarize 接口与行为保持。控制侧新增的 test_report_mean.py 是只读独立判据，原测试继续保持。本轮仅呈现并保存完整新 REV；原有 AC 保留，新增可选均值 AC，REPORT 负责该成果，CORE 的原定义和适用结果应保留。REPORT 需检查原 report 及新增 test_report_mean，最终 discover 全部测试；可按实际命令增量登记 mean 检查。说明影响并保留旧整体验收及原证明，本轮不接受新语义方案、不实施、运行检查或封存。",
        "effect_kinds": ["project_records"],
        "paths": [],
    },
}

OUT.write_text(json.dumps(request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(str(OUT))
print("current_revision", change["current_revision"])
print("definition_digest", change["definition_digest"])
