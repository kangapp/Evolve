"""Build the update.revise request that accepts the archived mean-revision candidate.

The candidate document, impact and digest are read back from Evolve's own stored
run so the request reproduces the exact concrete candidate the user accepted.
"""
import json
import subprocess
from pathlib import Path

PROJECT = Path('/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-frozen-010-r3-lg0e6ccx/claude-native-r2/business')
RUNTIME = PROJECT / '.agents/evolve-acceptance/profile/plugins/cache/evolve-local/evolve/0.1.0/runtime/evolve.py'
SOURCE_RUN = 'd7e6a30d-87fc-42ff-8dc0-a70f667a1758'
OUT = PROJECT / '.evolve-local/control/requests/accept-mean-revision.json'

USER_TEXT = (
    '本次明确接受前一会话已存档、符合可选均值固定格式及原接口保持边界的完整修订。'
    '使用 Evolve 恢复并呈现新方案，按此具体范围只修改 report.py，保留 arithmetic.py、所有原测试和新增均值判据。'
    '若前轮停在范围确认，本轮的具体接受同时覆盖该固定均值候选中旧阶段“不实现均值”描述的替换，仅限该均值要求相关描述；'
    '保留原 AC、CORE 和原接口边界，先以实际候选摘要完成接受和新 REV 登记再实施。'
)

raw = subprocess.run(
    ['python3', str(RUNTIME), '--project', str(PROJECT), 'history', SOURCE_RUN],
    capture_output=True, text=True, check=True).stdout
history = json.loads(raw)
run = history['data']['history']['runs'][0]
candidate = run['result']['candidate']
document = candidate['document']

proposal = dict(document)
proposal['complexity'] = 'complex'
proposal['presentation'] = {'source': 'user', 'document': document}

request = {
    'authorization': {
        'source': 'user',
        'text': USER_TEXT,
        'effect_kinds': ['project_records'],
        'paths': [],
    },
    'input': {
        'change_id': run['result']['change_id'],
        'reason': (
            '接受上一轮已存档的固定均值候选：按候选摘要登记接受并生成新 REV，'
            '使 REPORT 任务在 report.py 中实现 include_mean=True 的两位小数均值字段；'
            'CORE 的定义、既有实施结果与原行为证明保持不变。'
        ),
        'impact': candidate['impact'],
        'proposal': proposal,
        'approval': {
            'candidate_digest': run['result']['candidate_digest'],
            'source': 'user',
            'text': USER_TEXT,
        },
    },
}
OUT.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding='utf-8')
print(OUT)
print('candidate_digest', run['result']['candidate_digest'])
print('from_revision', candidate['from_revision_id'])
