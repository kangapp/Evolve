import json
import sys
from pathlib import Path

PLUGIN = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-frozen-010-r3-lg0e6ccx/claude-native-r2/business/.agents/evolve-acceptance/profile/plugins/cache/evolve-local/evolve/0.1.0")
sys.path.insert(0, str(PLUGIN / "runtime"))
from evolve_core.config_edit import edit_configuration
from evolve_core.package import digest

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-frozen-010-r3-lg0e6ccx/claude-native-r2/business")
REQUESTS = ROOT / ".evolve-local/control/requests"

MEAN_CHECK = {
    "id": "mean",
    "argv": ["python3", "-B", "-m", "unittest", "test_report_mean", "-v"],
    "cwd": ".",
    "timeout": 60,
}

AUTHORIZATION = {
    "source": "user",
    "text": "使用 Evolve 修改当前活动方案：report.render 的 include_mean=True 分支增加均值，格式固定为 total=5; count=2; mean=2.50，保留两位小数；空输入 mean=0.00。默认 False 的原文本和 total／summarize 接口与行为保持。控制侧新增的 test_report_mean.py 是只读独立判据，原测试继续保持。REPORT 需检查原 report 及新增 test_report_mean，最终 discover 全部测试；可按实际命令增量登记 mean 检查，命令为 python3 -B -m unittest test_report_mean -v。本轮仅呈现并保存完整新 REV，不接受新语义方案、不实施、不运行检查、不封存。",
    "effect_kinds": ["project_records", "checks"],
    "paths": ["evolve/config.toml"],
}

base = {
    "project_id": "c1aa24b9-23f8-4120-9b67-b972b6bd42a9",
    "expected_workspace_epoch": "a2f8ff56-7ee5-4281-b2a8-662533196559",
    "authorization": AUTHORIZATION,
}

candidate_request = dict(base, input={"name": "business", "checks": [MEAN_CHECK]})
candidate_path = REQUESTS / "init-mean-candidate-20261101.json"
candidate_path.write_text(json.dumps(candidate_request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

original = (ROOT / "evolve/config.toml").read_bytes()
candidate = edit_configuration(original, {"name": "business", "checks": [MEAN_CHECK]})
apply_request = dict(base, input={
    "name": "business",
    "checks": [MEAN_CHECK],
    "expected_config_digest": digest(original),
    "presentation": {
        "source": "user",
        "text": candidate.decode("utf-8"),
    },
})
apply_path = REQUESTS / "init-mean-apply-20261101.json"
apply_path.write_text(json.dumps(apply_request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print(candidate.decode("utf-8"))
print("candidate_digest", digest(candidate))
print("expected_config_digest", digest(original))
print(candidate_path)
print(apply_path)
