import json
from pathlib import Path

ROOT = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-frozen-010-r3-lg0e6ccx/claude-native-r2/business")
OUT = ROOT / ".evolve-local/control/requests/revise-display-20261101.json"

acceptance = [
    {"key": "AC-TOTAL", "text": "arithmetic.total 保持现有行为：对 [2,3] 返回 5，对 [] 返回 0，对 [-2,3] 返回 1，且对一次性迭代器仍返回 5。"},
    {"key": "AC-SUMMARIZE", "text": "arithmetic.summarize(values) 单次遍历输入并返回 (总和, 数量)：正数 [2,3] 得 (5,2)，空输入得 (0,0)，含负数 [-2,3] 得 (1,2)。"},
    {"key": "AC-RENDER", "text": "report.render(values, include_mean=False) 通过共享 summarize 生成 \"total=<总和>; count=<数量>\" 文本：正数得 \"total=5; count=2\"，空输入得 \"total=0; count=0\"，含负数得 \"total=1; count=2\"。"},
    {"key": "AC-SINGLEPASS", "text": "render 面对一次性迭代器只消费输入一次，且整项范围内共享接口只被调用一次（report.summarize 调用次数为 1）。"},
]

spec = {
    "problem": "report.render 目前固定返回 \"not implemented\"，无法输出任何汇总文本；arithmetic 只有 total(values)，缺少能同时给出总和与数量的共享接口，render 因此无法在不重复遍历输入的前提下复用业务逻辑。",
    "goals": [
        "保持 arithmetic.total 的现有可观察行为不变：求和语义、返回形态、空输入与负数结果均不改变。",
        "在 arithmetic.py 中提取单次迭代的共享接口 summarize(values)，返回 (总和, 数量)。",
        "让 report.render(values, include_mean=False) 通过该共享接口生成 \"total=<总和>; count=<数量>\" 文本。",
        "以当前项目六个文件中的四个独立测试模块作为只读判据，核对正数、空输入、负数与一次性迭代器。",
        "先证明 arithmetic.total 的现有行为，再形成共享 summarize，使行为证明与重构结果分别留痕。",
    ],
    "non_goals": [
        "本轮不实现 include_mean 的可选均值输出，也不定义 include_mean=True 的期望输出。",
        "不修改、不新增、不删除任何测试文件；四个测试模块保持原判据只读。",
        "不改动 total 的签名、返回形态或异常行为，也不新增其他公开函数。",
        "不引入第三方依赖、命令行入口、持久化或外部数据访问。",
        "不批准、不登记任何正式项目知识或经验条目。",
    ],
    "behavior": [
        "arithmetic.total(values) 继续等于 sum(values)，对列表与一次性迭代器均成立。",
        "arithmetic.summarize(values) 只遍历输入一次，同时得到总和与数量：数量是实际消费的元素个数，总和是这些元素的算术和；空输入返回 (0, 0)。",
        "summarize 对正负混合输入按算术和计算数量，不做绝对值或符号处理。",
        "report.render(values, include_mean=False) 调用共享 summarize 一次，把 (总和, 数量) 渲染为 \"total=<总和>; count=<数量>\"，不输出均值或任何其他字段。",
        "render 接收一次性迭代器时不得二次遍历输入：文本中的总和与数量来自同一次遍历的结果。",
        "report 模块须以 report.summarize 的形式暴露该共享接口，使跨模块调用点可被检查观察。",
    ],
    "constraints": [
        "只允许改写 arithmetic.py 与 report.py 两个业务文件；四个测试模块是只读判据。",
        "共享接口必须位于 arithmetic 模块，report 通过导入该接口调用，不得在 report 内复制求和逻辑。",
        "判据只用已登记的四个检查：original、summary、report、integration，命令分别为 python3 -B -m unittest test_arithmetic -v、test_summary -v、test_report -v、discover -v。",
        "CORE 是为报告所必需的预重构：原行为保持只以 original 检查证明，preservation 输入固定为 test_arithmetic.py。",
        "REPORT 依赖 CORE 的独立任务验收通过（verification_passed），上游未通过时不得实施。",
        "本轮只形成并保存方案：不接受方案、不实施、不改业务文件、不批准正式知识。",
    ],
    "tradeoffs": [
        "保留 total 作为独立入口而不是改成 summarize 的别名，避免改变既有调用点的返回形态，代价是两处求和语义要在实现时保持一致。",
        "summarize 返回元组 (总和, 数量) 而非结果对象或可调用迭代器，接口最小、实现最简，代价是后续扩展（如均值）需要再次改动该接口形态。",
        "render 文本格式固定为 \"total=<总和>; count=<数量>\"，与现有 test_report.py 判据一致，不引入额外分隔、空白或多行结构。",
        "集成边界放在最终 integration 检查而不是在 REPORT 任务内重复验证，避免同一事实被两处断言，代价是整项验收必须执行一次完整的发现式检查。",
    ],
    "test_decisions": [
        "原行为保持只使用 original 检查（python3 -B -m unittest test_arithmetic -v）：该模块保留 total 的原有字面量判据，正数、空输入、负数与一次性迭代器都在同一文件内断言；相关上下文为 test_arithmetic.py，其字节在重构中不得变化。",
        "共享接口行为使用 summary 检查（python3 -B -m unittest test_summary -v）：该模块以一次性迭代器断言 summarize 的 (5,2)、(0,0)、(1,2) 三种结果，覆盖正数、空输入与负数；相关上下文为 test_summary.py。",
        "报告文本使用 report 检查（python3 -B -m unittest test_report -v）：该模块断言 render 的 \"total=5; count=2\"、\"total=0; count=0\"、\"total=1; count=2\" 三种文本；相关上下文为 test_report.py。",
        "跨模块集成与单次调用边界使用最终 integration 检查（python3 -B -m unittest discover -v）：该次发现式执行覆盖全部四个测试模块，并由 test_integration.py 断言 report.summarize 的调用次数为 1；相关上下文为 test_integration.py。",
        "四个测试模块本轮均为只读判据：不修改、不放宽、不删除任何断言，也不由本工作新增替代测试。",
    ],
    "open_questions": [
        {"id": "Q-MEAN", "question": "include_mean=True 时 render 的期望输出是什么？本轮不实现可选均值，后续实现时均值字段的位置与格式未定。", "blocking": False, "task_keys": ["REPORT"]},
        {"id": "Q-COUNT", "question": "summarize 的数量是否应计入非数值元素或 None？当前四个判据只覆盖数值输入，未涉及非数值元素。", "blocking": False, "task_keys": ["CORE"]},
    ],
    "broad_migration": True,
    "integration_boundary": "本次是 arithmetic 与 report 两个模块之间的接口迁移：total 的调用形态保持不变，新增 arithmetic.summarize 作为唯一共享求和入口，report.render 从返回固定占位文本改为消费该共享接口。边界内为 arithmetic.py 与 report.py 两个业务文件，边界外为四个只读判据测试模块、include_mean 的可选均值语义（不在本轮）以及任何正式知识与外部系统。整项交付以最终 integration 检查（python3 -B -m unittest discover -v）在当前整个项目目录上通过为准；单个任务实施完成或单个任务验收通过都不代表整项通过。",
}

tasks = [
    {
        "local_key": "CORE",
        "title": "任务一：在 arithmetic.py 提取共享求和接口 summarize，并保持 total 现有行为",
        "completion": "arithmetic.py 的 total 行为与重构前完全一致，并新增 summarize(values) 单次遍历返回 (总和, 数量)；original 与 summary 两项检查均通过。",
        "validation": "先用 original 检查（python3 -B -m unittest test_arithmetic -v）在未改动的 arithmetic.py 上证明 total 的现有行为，再改写 arithmetic.py，最后复跑 original 与 summary 检查；判据文件 test_arithmetic.py 与 test_summary.py 全程只读。",
        "exclusions": ["不修改 report.py", "不修改任何测试文件", "不实现 include_mean 的可选均值输出", "不改动 total 的签名与返回形态"],
        "scope": ["arithmetic.py"],
        "acceptance": ["AC-TOTAL", "AC-SUMMARIZE"],
        "required_checks": ["original", "summary"],
        "context_paths": ["test_arithmetic.py", "test_summary.py"],
        "test_decision_refs": ["spec.test_decisions/0", "spec.test_decisions/1"],
        "dependencies": [],
        "pre_refactor": True,
        "preservation_checks": ["original"],
        "preservation_inputs": ["test_arithmetic.py"],
    },
    {
        "local_key": "REPORT",
        "title": "任务二：改写 report.py，让 render 复用共享 summarize 输出汇总文本",
        "completion": "report.py 以 from arithmetic import summarize 导入共享接口，render(values, include_mean=False) 输出 \"total=<总和>; count=<数量>\" 文本；report 检查通过。",
        "validation": "在 CORE 任务的独立验收通过后实施 report.py，运行 report 检查（python3 -B -m unittest test_report -v）；跨模块单次调用边界由最终 integration 检查在整项范围判定。",
        "exclusions": ["不修改 arithmetic.py", "不修改任何测试文件", "不实现 include_mean 的可选均值输出", "不在 report 内复制求和逻辑"],
        "scope": ["report.py"],
        "acceptance": ["AC-RENDER", "AC-SINGLEPASS"],
        "required_checks": ["report"],
        "context_paths": ["arithmetic.py", "test_report.py", "test_integration.py"],
        "test_decision_refs": ["spec.test_decisions/2", "spec.test_decisions/3"],
        "dependencies": [
            {
                "upstream_task": "CORE",
                "condition_kind": "verification_passed",
                "basis": "REPORT 需要 arithmetic.summarize 这一共享接口已由 CORE 任务独立验收通过并保持可用。",
            }
        ],
    },
]

document = {
    "title": "单次迭代汇总与报告",
    "plan": "本项是一次跨模块的接口迁移：让 report 的汇总文本复用 arithmetic 的单次遍历求和接口，共两个任务。任务一 CORE 是为报告所必需的预重构：先在未改动的 arithmetic.py 上运行 original 检查（python3 -B -m unittest test_arithmetic -v）证明 total 的现有行为，再在 arithmetic.py 内提取 summarize(values)，单次遍历输入并返回 (总和, 数量)，由 summary 检查（python3 -B -m unittest test_summary -v）判定。任务二 REPORT 在 CORE 的独立任务验收通过后实施：只改写 report.py，以 from arithmetic import summarize 导入共享接口，由 render(values, include_mean=False) 依共享结果生成 \"total=<总和>; count=<数量>\" 文本，由 report 检查（python3 -B -m unittest test_report -v）判定。范围与判据：两个任务合计只改写 arithmetic.py 与 report.py，四个测试模块保持只读；最后以 integration 检查（python3 -B -m unittest discover -v）在整个项目目录上完成最终集成验收，单个任务实施完成或单个任务验收通过都不代表整项通过。本次修订只调整方案展示层（方案标题、摘要与两个任务的展示标题），目标、完成条件、验收条件、测试决定、范围、依赖、排除范围与检查含义按原已接受方案保持不变；本轮不实施、不运行检查、不改业务与测试文件、不批准正式知识。",
    "completion": "arithmetic.total 的现有行为保持不变；arithmetic.summarize(values) 单次遍历返回 (总和, 数量)；report.render(values, include_mean=False) 输出 \"total=5; count=2\" 形式的文本；original、summary、report 三项任务检查通过，且最终 integration 检查（python3 -B -m unittest discover -v）在当前整个项目目录上通过，整项才算完成。",
    "scope": ["arithmetic.py", "report.py"],
    "acceptance": acceptance,
    "required_checks": ["integration"],
    "spec": spec,
    "tasks": tasks,
}

STATUS = Path("/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-frozen-010-r3-lg0e6ccx/claude-native-r2/business/.agents/evolve-acceptance/profile/projects/-private-var-folders-2f-w2-2h-7j21gdmhmgh8l4nzp40000gn-T-evolve-imp014-frozen-010-r3-lg0e6ccx-claude-native-r2-business/a31fb705-afd8-49c7-be1b-059b4d68bc1d/tool-results/b1456g8qh.txt")
state = json.loads(STATUS.read_text(encoding="utf-8"))
change = state["data"]["project"]["changes"][0]
old = change["plan"]["document"]
assert change["plan"]["accepted"] is True, "the source revision is not the accepted one"

for field in ("completion", "scope", "required_checks", "acceptance", "spec"):
    assert old[field] == document[field], "unexpected change in " + field
assert len(old["tasks"]) == len(document["tasks"])
for before, after in zip(old["tasks"], document["tasks"]):
    probe = dict(after)
    probe["title"] = before["title"]
    assert probe == before, "unexpected task change beyond the display title: " + before["local_key"]
assert old["title"] != document["title"] and old["plan"] != document["plan"], "display revision did not take effect"

request = {
    "project_id": "c1aa24b9-23f8-4120-9b67-b972b6bd42a9",
    "expected_workspace_epoch": "a2f8ff56-7ee5-4281-b2a8-662533196559",
    "input": {
        "change_id": "238333e5-7b50-4bd6-a5f1-f622ad2ddadc",
        "reason": "仅修订当前完整方案的展示层：方案标题改为“单次迭代汇总与报告”，plan 摘要重写为更易读的两任务分工与判据说明，两个任务的展示标题改为直白表述。目标、完成条件、验收条件、测试决定、范围、依赖、排除范围、未答问题与检查含义按原已接受方案逐字保持不变，因此沿原已接受依据保存新的 REV。保留 CORE 已有的部分进度、原修改授权与 total 现有行为的原证明；本轮不实施、不运行检查、不写业务或测试文件。",
        "proposal": dict(document, complexity="complex", presentation={"source": "user", "document": document}),
    },
    "authorization": {
        "source": "user",
        "text": "使用 Evolve 仅修订当前完整方案的展示：将方案标题改为“单次迭代汇总与报告”，让 plan 摘要更清楚，并将两个任务的展示标题写得易懂。目标、完成条件、AC、测试决定、范围、依赖和检查含义全部保持；沿原已接受依据保存新的 REV。保留部分进度、授权及原行为证明。本轮不实施、不运行检查、不写业务或测试。",
        "effect_kinds": ["project_records"],
    },
}

OUT.write_text(json.dumps(request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(str(OUT))
