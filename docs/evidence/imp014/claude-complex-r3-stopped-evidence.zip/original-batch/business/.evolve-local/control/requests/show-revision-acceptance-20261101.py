import json
import sqlite3
import sys

path = sys.argv[1]
connection = sqlite3.connect("file:" + path + "?mode=ro", uri=True)
row = connection.execute(
    "SELECT ordinal, acceptance_json FROM plan_revisions ORDER BY ordinal"
).fetchall()
for ordinal, acceptance in row:
    print("revision ordinal", ordinal)
    print(json.dumps(json.loads(acceptance), ensure_ascii=False, indent=1))
connection.close()
