import json,subprocess,sys,uuid
from pathlib import Path
runtime='/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-claude-safe-io-fixed-dptvq7rr/native/business/.agents/evolve-acceptance/profile/plugins/cache/evolve-local/evolve/0.1.0/runtime/evolve.py'
project='/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-claude-safe-io-fixed-dptvq7rr/native/business'
folder=Path(project)/'.evolve-local/control/requests'
result=subprocess.run([sys.executable,'-B',runtime,'--project',project,*sys.argv[1:]],capture_output=True,text=True)
try:
    response=json.loads(result.stdout)
except ValueError:
    response={'ok':False,'error':{'code':'NON_JSON_RESULT','message':result.stdout[:400]}}
path=folder/('cli-receipt-'+str(uuid.uuid4())+'.json')
path.write_text(json.dumps({'exit_code':result.returncode,'response':response,'stdout':result.stdout,'stderr':result.stderr},ensure_ascii=False,indent=2))
data=response.get('data',{})
brief={key:value for key,value in data.items() if value is None or isinstance(value,(bool,int,float)) or isinstance(value,str) and len(value)<=180}
print(json.dumps({'exit_code':result.returncode,'ok':response.get('ok'),'receipt':str(path),'data':brief,'data_keys':list(data),'error':response.get('error'),'stderr':result.stderr[:500]},ensure_ascii=False))
sys.exit(result.returncode)
