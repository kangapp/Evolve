import json, sys
from pathlib import Path

path = Path(sys.argv[1])
doc = json.loads(path.read_text())
resp = doc.get("response", {})
data = resp.get("data", {})
ctx = data.get("context", data)
out = Path(sys.argv[2])
out.write_text(json.dumps(ctx, ensure_ascii=False, indent=2))
print(out, len(json.dumps(ctx, ensure_ascii=False)))
