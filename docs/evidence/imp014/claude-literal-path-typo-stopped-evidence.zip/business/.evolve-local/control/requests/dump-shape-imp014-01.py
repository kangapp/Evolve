"""Read-only structural dump of an Evolve receipt payload."""
import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 2000


def clip(value):
    text = json.dumps(value, ensure_ascii=False)
    return text if len(text) <= limit else text[:limit] + '...<truncated>'


context = data.get('context')
if context:
    print('== context.runs ==')
    print(clip(context.get('runs')))
    print('== context.task_contexts ==')
    print(clip(context.get('task_contexts')))
    print('== context.workspace_observation ==')
    print(clip(context.get('workspace_observation')))
    print('== context.authorization_granted / continuation_requires ==')
    print(clip({'authorization_granted': context.get('authorization_granted'),
                'continuation_requires': context.get('continuation_requires'),
                'suggested_action': context.get('suggested_action'),
                'suggested_task_id': context.get('suggested_task_id')}))
else:
    for change in (data.get('project') or {}).get('changes', []):
        print('== change ==')
        print(clip(change))
