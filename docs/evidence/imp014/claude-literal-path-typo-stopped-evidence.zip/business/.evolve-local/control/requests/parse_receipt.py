import json, sys
from pathlib import Path

path = Path(sys.argv[1])
doc = json.loads(path.read_text())
data = doc.get('response', {}).get('data', {})
proj = data.get('project', {})
for ch in proj.get('changes', []):
    print('=== CHANGE ===')
    print(json.dumps(ch, ensure_ascii=False, indent=2))
print('=== PROJECT OTHER KEYS ===')
for k, v in proj.items():
    if k == 'changes':
        continue
    print(k, ':', json.dumps(v, ensure_ascii=False)[:3000])
