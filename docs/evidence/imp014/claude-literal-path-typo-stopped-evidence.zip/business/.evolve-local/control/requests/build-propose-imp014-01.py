"""Build the complex propose request for this round only.

Keeps the presented document byte-identical to the fields the runtime
recomputes as document(data): title, plan, completion, scope, acceptance,
required_checks, spec, tasks.
"""
import json
from pathlib import Path

ROOT = Path('/private/var/folders/2f/w2_2h_7j21gdmhmgh8l4nzp40000gn/T/evolve-imp014-claude-safe-io-fixed-dptvq7rr/native/business')
OUT = ROOT / '.evolve-local/control/requests/propose-complex-imp014-01.json'

SOURCE = ('本轮宿主任务指令（用户原话，节选自实际指令）：'
          '使用 Evolve 接入当前临时项目，仅形成并保存完整复杂方案，本轮不接受方案、不实施或改业务。'
          '……任务键固定 CORE、REPORT：CORE 是为报告所必需的预重构，文件仅 arithmetic.py，先证明原 total 行为，再形成共享 summarize；'
          'REPORT 文件仅 report.py，依赖 CORE 的独立任务验收通过。')

SPEC = {
    'problem': (
        'arithmetic.py 目前只提供 total(values)=sum(values)；report.py 的 render(values, include_mean=False) 直接返回 "not implemented"。'
        '项目里已经存在三组只读判据：test_arithmetic.py 针对 arithmetic.total、test_summary.py 针对尚未存在的 '
        'arithmetic.summarize(values)（期望返回 (总和, 数量)）、test_report.py 针对 render 的 "total=5; count=2" 文本，'
        '以及 test_integration.py 要求 render 对一次性迭代器只调用一次共享接口。'
        '如果 render 自己另写一套求和与计数，两个模块就会出现两套口径，一次性迭代器也可能在重复遍历下被消耗为空，'
        '使报告结果与算术模块分叉。因此必须先把单次迭代的求和与计数提取为共享接口 arithmetic.summarize(values)，'
        '再让 report.render 通过该接口生成报告文本。'),
    'goals': [
        '保留 arithmetic.total 的现有行为：名称、签名与求和语义都不变，且 test_arithmetic.py 的既有断言不被修改、不被放宽。',
        '在 arithmetic.py 中提取单次迭代的共享接口 summarize(values)，返回 (总和, 数量)。',
        '让 report.render(values, include_mean=False) 通过该共享接口生成 "total=5; count=2" 形式的报告文本。',
        '为原行为提供改造前的实际证明（original 判据在未改代码上先通过），并以 summary、report、integration 三个独立判据核对新行为。',
        '把本项工作登记为两个有真实依赖的任务：CORE 先完成并被独立验收，REPORT 依赖 CORE 的独立验收通过后才能实施。',
    ],
    'non_goals': [
        '本轮不实现 include_mean=True 的可选均值输出，render 的可选均值参数保持存在但不生效。',
        '不修改任何测试文件，不新建测试框架，不改变现有判据的断言强度或输入范围。',
        '不改动 arithmetic.total 的名称、签名与返回类型，也不引入类型标注或第三方依赖。',
        '不登记也不批准任何正式项目知识，本轮只形成并保存方案，不改业务文件。',
    ],
    'behavior': [
        'arithmetic.total(values) 继续返回 sum(values) 的结果：正数求和、空输入为 0、负数参与求和、一次性迭代器可被完整求和。',
        'arithmetic.summarize(values) 对任意可迭代输入只遍历一次，返回二元组 (总和, 数量)：空输入返回 (0, 0)，负数同时计入总和与数量，一次性迭代器被完整消费。',
        'report.render(values, include_mean=False) 通过共享 summarize 得到 (总和, 数量) 一次，返回文本 "total=<总和>; count=<数量>"，例如 [2,3] 得到 "total=5; count=2"，空输入得到 "total=0; count=0"。',
        'render 不重复遍历输入：对一次性迭代器只消费一遍，因此数量等于元素个数而总和不随遍历次数改变。',
        'report 模块在自己的命名空间内持有 summarize 这一名称，使 report.summarize 成为可被外部观察的共享接口调用点。',
    ],
    'constraints': [
        '测试文件一律只读：test_arithmetic.py、test_summary.py、test_report.py、test_integration.py 的原字节必须保留，作为不可放宽的判据。',
        '本项是两个模块的广泛接口迁移（broad_migration）：任何单个任务通过都不能代替整项集成通过，最终以 integration 检查（python3 -B -m unittest discover -v）读取实际整个目录为准。',
        '任务键固定为 CORE 与 REPORT：CORE 的文件范围仅 arithmetic.py，REPORT 的文件范围仅 report.py，两者不得改写对方文件。',
        'REPORT 必须等 CORE 的独立任务验收通过后才能实施，不得用 CORE 的实施完成（task done）代替其验收通过。',
        '本轮只形成并保存完整复杂方案：不接受方案、不实施、不修改业务文件，也不批准正式知识。',
        '外部编辑需先核对：若 arithmetic.py、report.py 或任一判据文件在本轮之后被其他工具改动，须先核对现场再决定，不得按旧摘要盲写。',
    ],
    'tradeoffs': [
        '保留 total 而非替换它：多一个共享函数名，但避免破坏既有调用方与 test_arithmetic.py 的既有断言，行为保持可由 original 判据直接证明。',
        '在 arithmetic 模块内单次遍历同时得出总和与数量，而不是让 render 分别求和与计数：牺牲一次极小的额外调用，换取两个模块只有一套求和口径，并让一次性迭代器不被重复消费。',
        '把共享接口放在 arithmetic.py 而不是新建模块：改动面最小，不新增文件、不改变导入路径，但 arithmetic.py 同时承担原 total 与共享 summarize 两项职责。',
        '本轮不实现 include_mean：render 的可选均值参数暂不生效，避免为尚未确认的输出格式引入分支和新的判据缺口。',
        '把原行为证明前置为独立步骤（先证明再改文件）：多一道流程，但使“行为保持”成为可核对的事实而非声明。',
    ],
    'test_decisions': [
        '判据性质：全部检查都是只读判据，只读取被测模块与自身断言，不写业务文件、不写数据库、不改动环境；本项不改测试文件，判据强度不因本次重构而降低。',
        'original 检查（python3 -B -m unittest test_arithmetic -v）作为 CORE 的原行为基线：只有在预重构前对未改动代码实际通过，才可声明 arithmetic.total 的既有行为被保持；它不覆盖新接口 summarize 的任何行为。',
        'summary 检查（python3 -B -m unittest test_summary -v）作为 CORE 共享接口的独立判据，覆盖正数、空输入、负数与一次性迭代器四种输入，不依赖 original 通过来推断 summarize 正确。',
        'report 检查（python3 -B -m unittest test_report -v）作为 REPORT 文本输出的独立判据，覆盖正数、空输入、负数与一次性迭代器，且只依赖 render 对外可见的文本结果。',
        'integration 检查（python3 -B -m unittest discover -v）读取实际整个目录，是本项唯一的整项集成判据，同时覆盖单次遍历边界；单个任务通过不能代替它。',
    ],
    'open_questions': [
        {
            'id': 'Q-mean-output',
            'question': 'include_mean=True 的均值输出格式（是否含 mean=、保留几位小数、如何舍入）留待后续轮次决定，本轮保持参数存在但不生效。',
            'blocking': False,
            'task_keys': [],
        },
        {
            'id': 'Q-total-ownership',
            'question': 'arithmetic.total 未来是否收敛为 summarize 的薄封装、乃至在确认无其它调用方后弃用，取决于项目外调用情况，本轮不作结论也不改动 total。',
            'blocking': False,
            'task_keys': [],
        },
        {
            'id': 'Q-integration-coverage',
            'question': 'integration 检查读取实际整个目录；若之后在项目内新增其它测试模块，最终集成判据覆盖面会随之扩大，本轮按当前六个文件的实际目录判定。',
            'blocking': False,
            'task_keys': [],
        },
    ],
    'broad_migration': True,
    'integration_boundary': (
        '本项跨越 arithmetic.py 与 report.py 两个模块的接口迁移：整项交付边界是 report.render 实际消费 arithmetic.summarize 提供的共享接口，'
        '并在项目实际整个目录上通过 integration 检查（python3 -B -m unittest discover -v），其中包含一次性迭代器只被消费一次的边界。'
        '单个任务通过只表示该任务范围内的实施与判据结果，不能代替整项集成通过；最终以整项 verification 与封存截点为准。'),
}

ACCEPTANCE = [
    {
        'key': 'AC-total-behavior',
        'text': 'arithmetic.total(values) 的既有行为在预重构前后保持不变：total([2,3])==5、total([])==0、total([-2,3])==1、'
                'total(iter([2,3]))==5；由未修改的 test_arithmetic 判据核对，原行为保持只以 original 判据为依据。',
    },
    {
        'key': 'AC-summarize-contract',
        'text': 'arithmetic.summarize(values) 以单次遍历返回 (总和, 数量)：summarize(iter([2,3]))==(5,2)、summarize(iter([]))==(0,0)、'
                'summarize(iter([-2,3]))==(1,2)；由 test_summary 判据核对。',
    },
    {
        'key': 'AC-report-text',
        'text': 'report.render(values, include_mean=False) 通过共享 summarize 接口生成 "total=5; count=2" 形式的文本：'
                '对 [2,3] 得 "total=5; count=2"、对空输入得 "total=0; count=0"、对 [-2,3] 得 "total=1; count=2"；由 test_report 判据核对。',
    },
    {
        'key': 'AC-single-pass',
        'text': 'report.render 对一次性迭代器只消费一次输入并只调用一次共享接口（report.summarize 的调用次数为 1），不重复遍历；'
                '由 test_integration 判据核对。',
    },
]

TASKS = [
    {
        'local_key': 'CORE',
        'title': '在 arithmetic.py 中形成共享 summarize(values)，并先证明 total 的既有行为',
        'completion': 'arithmetic.summarize(values) 对正数、空输入、负数与一次性迭代器分别返回 (5,2)、(0,0)、(1,2) 及对应结果；'
                      'arithmetic.total 的既有行为在改造前后由未修改的 test_arithmetic 判据保持不变。',
        'validation': '先在未改动的 arithmetic.py 上运行 original 检查（python3 -B -m unittest test_arithmetic -v）实际证明原 total 行为；'
                      '通过后才改写 arithmetic.py，随后复跑 original 与 summary 两个检查'
                      '（python3 -B -m unittest test_arithmetic -v、python3 -B -m unittest test_summary -v），两者均实际退出 0 才视为本任务完成。',
        'exclusions': [
            '不修改 report.py，该文件由 REPORT 任务负责。',
            '不修改 test_arithmetic.py、test_summary.py 或任何其它测试文件。',
            '不删除或放宽 test_arithmetic.py 的既有断言。',
            '不实现可选均值（include_mean）相关逻辑。',
        ],
        'scope': ['arithmetic.py'],
        'acceptance': ['AC-total-behavior', 'AC-summarize-contract'],
        'required_checks': ['original', 'summary'],
        'context_paths': ['test_arithmetic.py', 'test_summary.py'],
        'test_decision_refs': ['spec.test_decisions/0', 'spec.test_decisions/1', 'spec.test_decisions/2'],
        'dependencies': [],
        'pre_refactor': True,
        'preservation_checks': ['original'],
        'preservation_inputs': ['test_arithmetic.py'],
    },
    {
        'local_key': 'REPORT',
        'title': '让 report.render(values, include_mean=False) 通过共享 summarize 生成 total=/count= 文本',
        'completion': 'report.render 对 [2,3]、空输入、[-2,3] 的一次性迭代器分别输出 "total=5; count=2"、"total=0; count=0"、"total=1; count=2"；'
                      '且每次渲染只调用一次共享接口、只消费一次输入。',
        'validation': '在 CORE 的独立任务验收通过之后运行 report 检查（python3 -B -m unittest test_report -v）核对文本输出；'
                      '单次遍历边界由 integration 检查（python3 -B -m unittest discover -v）在项目实际整个目录上核对。',
        'exclusions': [
            '不修改 arithmetic.py，该文件由 CORE 任务负责。',
            '不修改 test_report.py、test_integration.py 或任何其它测试文件。',
            '本轮不实现 include_mean=True 的可选均值输出。',
            '不改变 render 已有的参数签名 (values, include_mean=False)。',
        ],
        'scope': ['report.py'],
        'acceptance': ['AC-report-text', 'AC-single-pass'],
        'required_checks': ['report'],
        'context_paths': ['test_report.py', 'test_integration.py'],
        'test_decision_refs': ['spec.test_decisions/0', 'spec.test_decisions/3', 'spec.test_decisions/4'],
        'dependencies': [
            {
                'upstream_task': 'CORE',
                'condition_kind': 'verification_passed',
                'basis': 'CORE 的独立任务验收必须实际通过：共享 summarize 已存在，且 arithmetic.total 的原行为已由 original 判据证明保持，'
                         'report 才能依赖该接口生成报告文本；CORE 的实施完成本身不构成此条件。',
            },
        ],
    },
]

DOCUMENT = {
    'title': '共享 summarize 接口：保留 arithmetic.total 行为并让 report.render 复用单次遍历求和',
    'plan': '分两个任务完成 arithmetic 与 report 之间的接口迁移。CORE 在 arithmetic.py 中先以 test_arithmetic 判据证明 total 的既有行为，'
            '再提取单次迭代的 summarize(values)（返回 (总和, 数量)）并保持 total 行为不变；REPORT 在 CORE 的独立验收通过之后，'
            '让 report.render(values, include_mean=False) 通过该共享接口生成 "total=5; count=2" 形式的文本，并保持一次性迭代器只被消费一次。'
            '本轮只形成并保存该方案，不接受方案、不实施、不修改业务文件。',
    'completion': '用户可核对的结果：arithmetic.total 的现有行为由未修改的 test_arithmetic 判据在改造前后保持一致；'
                  'arithmetic.summarize(values) 对正数、空输入、负数、一次性迭代器返回 (5,2)、(0,0)、(1,2) 及对应值；'
                  'report.render(values, include_mean=False) 对同一组输入输出 "total=5; count=2"、"total=0; count=0"、"total=1; count=2"；'
                  '且 report.render 每次只调用一次共享接口、不重复消费一次性迭代器；最终由 integration 检查在项目实际整个目录上核对以上全部行为。',
    'scope': ['arithmetic.py', 'report.py'],
    'acceptance': ACCEPTANCE,
    'required_checks': ['integration'],
    'spec': SPEC,
    'tasks': TASKS,
}

DATA = dict(DOCUMENT)
DATA['complexity'] = 'complex'
DATA['presentation'] = {'source': SOURCE, 'document': DOCUMENT}

request = {
    'authorization': {
        'source': SOURCE,
        'text': SOURCE,
        'effect_kinds': ['project_records'],
        'paths': [],
    },
    'input': DATA,
}

# Local self-checks mirroring the runtime's structured-plan validation.
keys = {item['key'] for item in ACCEPTANCE}
covered = set()
for task in TASKS:
    assert set(task['scope']) <= set(DOCUMENT['scope']), task['local_key']
    assert set(task['acceptance']) <= keys, task['local_key']
    covered |= set(task['acceptance'])
    for name in task['context_paths']:
        assert (ROOT / name).is_file(), name
    refs = {'spec.test_decisions/' + str(i) for i in range(len(SPEC['test_decisions']))}
    assert set(task['test_decision_refs']) <= refs, task['local_key']
assert covered == keys
assert set().union(*[set(t['scope']) for t in TASKS]) == set(DOCUMENT['scope'])
for task in TASKS:
    if task.get('pre_refactor'):
        assert set(task['preservation_checks']) <= set(task['required_checks'])
        assert set(task['preservation_inputs']) <= set(task['context_paths'])
        assert not ({ROOT / n for n in task['preservation_inputs']} & {ROOT / n for n in task['scope']})
assert set(DOCUMENT['required_checks']) and SPEC['broad_migration']
assert DATA['presentation']['document'] == {k: DATA[k] for k in
       ('title', 'plan', 'completion', 'scope', 'acceptance', 'required_checks', 'spec', 'tasks')}

OUT.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'written': str(OUT), 'bytes': OUT.stat().st_size, 'tasks': [t['local_key'] for t in TASKS],
                  'root_required_checks': DOCUMENT['required_checks'],
                  'acceptance_keys': sorted(keys), 'test_decisions': len(SPEC['test_decisions']),
                  'open_questions': [q['id'] for q in SPEC['open_questions']]}, ensure_ascii=False))
