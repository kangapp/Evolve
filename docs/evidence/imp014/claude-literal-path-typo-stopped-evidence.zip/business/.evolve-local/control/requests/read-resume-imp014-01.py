"""Read-only extraction of the resume context's plan and task definitions."""
import json
import sys
from pathlib import Path

receipt = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})
context = data.get('context') or {}

out = {'context_keys': sorted(context.keys())}

plan = context.get('plan') or {}
document = plan.get('document') or {}
out['plan'] = {
    'title': document.get('title'),
    'scope': document.get('scope'),
    'required_checks': document.get('required_checks'),
    'acceptance_keys': [a.get('key') for a in document.get('acceptance', [])],
    'test_decisions_count': len((document.get('spec') or {}).get('test_decisions', [])),
    'open_questions': [{'id': q.get('id'), 'blocking': q.get('blocking')}
                       for q in (document.get('spec') or {}).get('open_questions', [])],
    'broad_migration': (document.get('spec') or {}).get('broad_migration'),
    'integration_boundary': (document.get('spec') or {}).get('integration_boundary'),
}
out['tasks'] = []
for task in document.get('tasks', []):
    out['tasks'].append({
        'local_key': task.get('local_key'),
        'scope': task.get('scope'),
        'required_checks': task.get('required_checks'),
        'acceptance': task.get('acceptance'),
        'context_paths': task.get('context_paths'),
        'pre_refactor': task.get('pre_refactor'),
        'preservation_checks': task.get('preservation_checks'),
        'preservation_inputs': task.get('preservation_inputs'),
        'dependencies': task.get('dependencies'),
        'test_decision_refs': task.get('test_decision_refs'),
        'exclusions': task.get('exclusions'),
    })

for task in context.get('task_contexts', []):
    out.setdefault('task_contexts', []).append({
        'local_key': task.get('local_key'),
        'state': task.get('state'),
        'definition_scope': (task.get('definition') or {}).get('scope'),
        'definition_required_checks': (task.get('definition') or {}).get('required_checks'),
        'definition_acceptance': [a.get('key') for a in (task.get('definition') or {}).get('acceptance', [])],
        'checks_basis': [c.get('id') for c in (task.get('definition') or {}).get('checks_basis', [])],
    })

print(json.dumps(out, ensure_ascii=False, indent=2)[:12000])
