"""Read-only extraction of selected fields from an Evolve CLI receipt."""
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
receipt = json.loads(path.read_text(encoding='utf-8'))
data = receipt.get('response', {}).get('data', {})

out = {
    'exit_code': receipt.get('exit_code'),
    'ok': receipt.get('response', {}).get('ok'),
    'outcome': data.get('outcome'),
    'project_state': (data.get('project') or {}).get('state'),
    'project_id': (data.get('project') or {}).get('project_id'),
}
if 'change' in data:
    out['change'] = data['change']

project = data.get('project') or {}
for change in project.get('changes', []):
    entry = {
        'id': change.get('id'),
        'code': change.get('code'),
        'title': change.get('title'),
        'complexity': change.get('complexity'),
        'state': change.get('state'),
        'current_revision': change.get('current_revision'),
        'definition_digest': change.get('definition_digest'),
        'plan_digest': change.get('plan_digest'),
        'tasks': [],
    }
    for task in change.get('tasks', []):
        entry['tasks'].append({
            'task_code': task.get('task_code'),
            'local_key': task.get('local_key'),
            'state': task.get('state'),
            'scope': task.get('scope'),
            'required_checks': task.get('required_checks'),
            'acceptance': task.get('acceptance'),
            'dependencies': task.get('dependencies'),
            'pre_refactor': task.get('pre_refactor'),
            'readiness': task.get('readiness'),
        })
    out.setdefault('changes', []).append(entry)

for key in ('plan', 'verification', 'latest_verification', 'pending_runs', 'knowledge_refs',
            'pending_knowledge', 'task_contexts', 'workspace_observation'):
    if key in data:
        out[key] = data[key]

print(json.dumps(out, ensure_ascii=False, indent=2)[:12000])
