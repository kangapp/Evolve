import unittest
from arithmetic_second import total
class SecondArithmetic(unittest.TestCase):
    def test_independent_examples(self):
        self.assertEqual(total([5,7]),12)
        self.assertEqual(total([]),0)
        self.assertEqual(total([9,-2]),7)
