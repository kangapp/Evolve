import unittest
from arithmetic import total
class Arithmetic(unittest.TestCase):
    def test_independent_examples(self):
        self.assertEqual(total([8,3]),11)
        self.assertEqual(total([]),0)
        self.assertEqual(total([-4,3]),-1)
