import unittest
from total import total
class Totals(unittest.TestCase):
    def test_literals(self):
        self.assertEqual(total([2,3]),5)
        self.assertEqual(total([]),0)
        self.assertEqual(total([-2,3]),1)
    def test_iterator_literals(self):
        self.assertEqual(total(iter([5,-2])),3)
