---
name: evolve-workflow
description: 定位 Evolve 项目工作项、只读状态、下一步与跨会话续接；或分派明确的 Evolve 动作。
---

归属 status、next、resume。先解释用户意图和唯一目标，再调用实际负责的 Skill；router 不代写业务。无动作使用 status。resume／next 从封存事实恢复方案、进度、失败与现场差异；多个目标明确选择。查询不写入或授权，不接管旧执行。读取[续接请求](../../shared/protocol.md#normal-continuation)，用户明确继续后由原 owner 核对范围并新建 run。

定位后先读取正式知识，再由 evolve-learn 检索少量相关经验；经验仍需核对版本、范围和实际效果，不充当原授权。单独 resume／next 查询不登记采用。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-workflow`，动作必须属于本 Skill。用户不需要填写内部编号。
