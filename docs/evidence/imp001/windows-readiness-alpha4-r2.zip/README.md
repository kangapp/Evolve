# 原生 Windows 整包重定位验收材料

这是本地／私有受控验收材料，版本 0.1.0-alpha.4（schema1／protocol3）。
它包含同一完整运行包与三个验收脚本，不含个人配置、凭证、项目历史或模型请求。
尚未执行原生 Windows；本机演练不能代替该证据。

Windows 需有 Python 3.11+。解压到本地新目录，在该目录打开 PowerShell：

```powershell
py -3 -X utf8 .\acceptance\verify_relocation.py --package .\package --out "$env:TEMP\Evolve Windows 验收 01" --require-windows
```

输出路径必须不存在。UTF-8 选项用于控制脚本，子进程使用本进程的 PYTHONUTF8=1；不改系统或个人配置。
脚本拒绝非原生 Windows；它仅修改新建的输出目录，并保留提供的完整包。
输出 summary.json、commands.json、workflow-evidence/、continuation-evidence/。
失败必须保留实际证据并核实原因，不能通过手改结果、移除必需检查或改协议号标为通过。

实测内容：

1. 复制完整包到含空格／中文路径，删除该次下载副本，从独立 cwd 运行 doctor。
2. 实际独立失败、记录调查、修复、原判据复验、受控双维审查及封存。
3. 移动整个安装根并移除旧路径；新位置恢复原项目身份，查询保持业务／历史字节。
4. 前次真实工作生成候选经验；第二文件对实际失败、检索核实采用、正常暂停、新 CLI 续接、真实验收封存及 unknown 反馈。

该脚本不安装 Codex／Claude，不发送模型请求，不证明原生宿主 Skill 发现或新模型会话行为。
它也不证明完整升级／降级、异常恢复、外部数据操作或档案整体恢复。
Windows 宿主安装、项目范围、实际加载根与生命周期仍须使用独立隔离配置另行实测，保存真实宿主版本和记录。
只有脚本退出零且 summary.status=passed_for_observed_runtime_platform 与 native_windows_observed=true 时，
才可认定该 Windows 运行包分支通过；整项 V-137、M1 及下一阶段仍按工程验收映射核对。

其他平台只用于准备性自检：去掉 --require-windows；结果仅适用于实际观察到的平台。
readiness-manifest.json 列出所有材料的字节摘要，不包含自身；完整运行包仍通过自己的 evolve-package.json 检查。
