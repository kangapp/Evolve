---
name: evolve-apply
description: 按已接受的 Evolve 方案及有效修改授权实施和修复，或处理具体授权的数据操作。
---

归属 apply。先核对方案版本、目标、现场、依赖和授权。完成可验证的小流程，失败在原范围修正；目标或验收含义变化交 propose。正式数据操作必须明确 external 方法，未知效果不重发。

正常暂停或换会话时读取[暂停与续接](../../shared/protocol.md#normal-continuation)，保存实际部分结果及剩余工作。结束本轮时核对有无可复用发现，交 evolve-learn 保存实际经验或已检查的无新发现；未检查明确 pending。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目，再执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-apply`，动作必须属于本 Skill。用户不需要填写内部编号。
