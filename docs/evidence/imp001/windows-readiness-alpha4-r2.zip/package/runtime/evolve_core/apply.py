"""Apply a bound short plan, preserve file facts, then perform task-level checks."""
import json
from pathlib import Path

from .checks import pending_checks, run_check
from .errors import EvolveError
from .package import canonical, digest
from .plans import business_path
from .requests import normalize, require_effect
from .store import Store, identifier
from .work import change_context, check_basis, check_event_sink, claim_resources, fingerprint, gate, record_check, versions
from .workspace import (current_digest, finish_journal, inside, install_files,
                        prepare_files, writer_lock)


def implement(root, payload):
    root = Path(root).resolve()
    request = normalize(payload)
    require_effect(request, 'project_records')
    require_effect(request, 'business_files')
    data = request['input']
    pause = data.get('pause')
    if pause is not None:
        if not isinstance(pause, dict) or not isinstance(pause.get('reason'), str) or not pause['reason'].strip():
            raise EvolveError('INPUT', 'Normal pause requires its actual reason and progress')
        for key in ('completed', 'remaining', 'next_steps'):
            value = pause.get(key)
            if not isinstance(value, list) or any(not isinstance(item, str) or not item.strip() for item in value):
                raise EvolveError('INPUT', 'Pause progress requires explicit string arrays')
        if not pause['remaining'] or not pause['next_steps']:
            raise EvolveError('INPUT', 'Partial work must retain remaining work and a next step')
    files = data.get('files')
    if not isinstance(data.get('observations', {}), dict):
        raise EvolveError('INPUT', 'External observations must map explicit paths to observed digests')
    if not isinstance(files, list) or any(not isinstance(f, dict) for f in files):
        raise EvolveError('INPUT', 'Implementation requires an explicit files array')
    for item in files:
        if not isinstance(item.get('path'), str) or not isinstance(item.get('content'), str) or 'expected_digest' not in item:
            raise EvolveError('INPUT', 'Each file requires path, expected digest, and candidate text')
        business_path(root, item['path'])
    if len({f['path'] for f in files}) != len(files):
        raise EvolveError('INPUT', 'Duplicate implementation targets')
    operation_id, run_id = identifier(), None
    store = None
    try:
        with writer_lock(root) as generation:
            store = Store(root)
            run_id, previous = store.start(request, action='apply', method='implement', owner='evolve-apply')
            if previous is not None:
                return previous
            from .continuation import bind_continuation
            with store.transaction():
                continuation = bind_continuation(store, request, run_id)
            change, revision, task, definition = change_context(store, request)
            check_basis(root, definition)
            if definition['required_checks'] and pause is None:
                require_effect(request, 'checks')
            if data.get('accepted_plan_digest') != revision['plan_digest']:
                raise EvolveError('PLAN_ACCEPTANCE', 'Acceptance must bind the actual presented plan text', exit_code=3)
            authorized = request['authorization'].get('paths')
            if not isinstance(authorized, list) or not all(isinstance(p, str) for p in authorized):
                raise EvolveError('AUTHORIZATION', 'Business modification authorization requires explicit paths')
            if not set(f['path'] for f in files).issubset(set(definition['scope']) & set(authorized)):
                raise EvolveError('SCOPE', 'Candidate exceeds accepted plan or authorized file scope')
            formal = {inside(root, row['path']).resolve() for row in store.connection.execute(
                "SELECT path FROM artifacts WHERE kind='knowledge' AND path IS NOT NULL")}
            for item in files:
                if business_path(root, item['path']).resolve() in formal:
                    raise EvolveError('KNOWLEDGE_OWNER', 'Formal mapped documents require their knowledge owner, not apply')
            old_result = json.loads(task['result_json']) if task['result_json'] else None
            baseline = old_result['fingerprint']['scope'] if old_result else definition['baseline']
            observed = data.get('observations', {})
            for name in definition['scope']:
                actual = current_digest(business_path(root, name))
                if actual != baseline[name] and observed.get(name) != actual:
                    raise EvolveError('FILE_CONFLICT', 'Unregistered workspace change requires an explicit observation: ' + name,
                                      exit_code=3)
            if task['state'] == 'done':
                failure = store.one("SELECT id FROM verifications WHERE change_id=? AND revision_id=? "
                                    "AND status IN ('failed','blocked') ORDER BY observed_at DESC LIMIT 1",
                                    (change['id'], revision['id']))
                if not failure or data.get('reopen_verification_id') != failure['id']:
                    raise EvolveError('TASK_DONE', 'Reopening the same task requires its failure evidence', exit_code=3)
            claim_resources(store, run_id, operation_id, generation, change, definition['scope'], 'business_files')
            with store.transaction() as connection:
                accepted = revision['accepted_event_id']
                if accepted is None:
                    accepted = store.event(run_id, 'plan_accepted', {'revision_id': revision['id'],
                                          'plan_digest': revision['plan_digest'], 'authorization': request['authorization']})
                    connection.execute('UPDATE plan_revisions SET accepted_event_id=? WHERE id=?', (accepted, revision['id']))
                connection.execute("UPDATE changes SET state='active',row_version=row_version+1 WHERE id=?", (change['id'],))
                connection.execute("UPDATE tasks SET state='in_progress',row_version=row_version+1 WHERE id=?", (task['id'],))
                for name, content_digest in observed.items():
                    if name not in definition['scope'] or current_digest(business_path(root, name)) != content_digest:
                        raise EvolveError('OBSERVATION', 'External observation is not current or in scope', exit_code=3)
                    store.event(run_id, 'external_observation', {'path': name, 'digest': content_digest,
                                                               'source': 'external_or_unknown'})
            expected = versions(store, change['id'], task['id'])
            gate(store, request, run_id, operation_id, expected)
            journal = prepare_files(root, operation_id, files)
            with store.transaction() as connection:
                connection.execute('UPDATE operations SET journal_path=? WHERE id=?',
                                   ('.evolve-local/control/operations/' + operation_id + '.json', operation_id))
            gate(store, request, run_id, operation_id, expected)
            install_files(root, journal, before_write=lambda: gate(store, request, run_id, operation_id, expected))
            snapshot = fingerprint(root, definition)
            with store.transaction() as connection:
                artifacts = [store.artifact(item['path'], 'source_result', business_path(root, item['path']).read_bytes(),
                                            run_id, 'evolve-apply') for item in files]
                connection.execute("UPDATE operations SET state='committed',result_json=? WHERE id=?",
                                   (canonical({'artifacts': artifacts, 'fingerprint': snapshot}).decode(), operation_id))
                store.event(run_id, 'files_applied', {'operation_id': operation_id, 'artifacts': artifacts})
            finish_journal(root, journal)
            if pause is not None:
                gate(store, request, run_id, operation_id, expected)
                current = fingerprint(root, definition)
                if current['digest'] != snapshot['digest']:
                    raise EvolveError('WORKSPACE_CHANGED', 'Workspace changed before the safe pause', exit_code=3)
                result = {'fingerprint': current, 'definition_digest': task['definition_digest'],
                          'artifacts': artifacts, 'check_evidence': [], 'progress': pause,
                          'checks': 'not_run', 'learning': 'pending'}
                with store.transaction() as connection:
                    connection.execute('UPDATE tasks SET state=?,row_version=row_version+1,result_json=? WHERE id=?',
                                       ('in_progress', canonical(result).decode(), task['id']))
                    connection.execute('DELETE FROM resource_claims WHERE operation_id=?', (operation_id,))
                    store.event(run_id, 'implementation_paused', {'task_id': task['id'], 'progress': pause,
                                                                'checks': 'not_run'})
                return store.finish(run_id, {'committed': True, 'outcome': 'partial', 'operation_id': operation_id,
                    'change_id': change['id'], 'revision_id': revision['id'], 'task_id': task['id'],
                    'definition_digest': task['definition_digest'], 'fingerprint': current, 'progress': pause,
                    'continuation': continuation, 'checks': 'not_run', 'learning': 'pending',
                    'versions': versions(store, change['id'], task['id']), 'overall_verification': 'not_run'})
        # All long commands run outside the writer lock and SQLite transaction.
        results, evidence_ids = [], []
        for check in check_basis(root, definition):
            with writer_lock(root):
                gate(store, request, run_id, operation_id, expected)
                if fingerprint(root, definition)['digest'] != snapshot['digest']:
                    raise EvolveError('WORKSPACE_CHANGED', 'Workspace changed before task check', exit_code=3)
            result = run_check(root, check, event_sink=check_event_sink(store, request, run_id, operation_id, expected))
            with writer_lock(root):
                gate(store, request, run_id, operation_id, expected)
                with store.transaction():
                    evidence_ids.append(record_check(store, run_id, result))
                    store.event(run_id, 'task_check', {'check_id': check['id'], 'status': result['status'],
                                                     'evidence_id': evidence_ids[-1]})
            results.append(result)
            if result['unfinished_processes']:
                raise EvolveError('CHECK_RUNNING', 'A check process group is still present; inspect before continuing', exit_code=4, committed=True)
        with writer_lock(root):
            gate(store, request, run_id, operation_id, expected)
            current = fingerprint(root, definition)
            if current['digest'] != snapshot['digest']:
                raise EvolveError('WORKSPACE_CHANGED', 'Workspace changed during task checks; source was preserved', exit_code=3)
            missing = [p for p in definition['required_deliverables'] if current['scope'][p] is None]
            passed = not missing and all(item['status'] == 'passed' for item in results)
            outcome = 'implemented' if passed else 'checks_not_passed'
            task_result = {'fingerprint': current, 'definition_digest': task['definition_digest'],
                           'artifacts': artifacts, 'check_evidence': evidence_ids, 'missing': missing,
                           'implementation_source': 'evolve-apply' if files else 'observed_existing_files'}
            with store.transaction() as connection:
                connection.execute('UPDATE tasks SET state=?,row_version=row_version+1,result_json=? WHERE id=?',
                                   ('done' if passed else 'in_progress', canonical(task_result).decode(), task['id']))
                connection.execute('DELETE FROM resource_claims WHERE operation_id=?', (operation_id,))
                store.event(run_id, 'task_result', {'task_id': task['id'], 'outcome': outcome,
                                                   'definition_digest': task['definition_digest']})
            return store.finish(run_id, {'committed': True, 'outcome': outcome, 'operation_id': operation_id,
                                'change_id': change['id'], 'revision_id': revision['id'], 'task_id': task['id'],
                                'definition_digest': task['definition_digest'], 'fingerprint': current,
                                'versions': versions(store, change['id'], task['id']),
                                'task_checks': [{**{key: item[key] for key in ('check_id', 'status', 'returncode')},
                                                'evidence_id': evidence_ids[i]} for i, item in enumerate(results)],
                                'overall_verification': 'not_run'})
    except (EvolveError, OSError) as error:
        if store is not None and run_id is not None:
            if not store.run_started(run_id):
                if isinstance(error, EvolveError):
                    error.committed = True
                    raise
                raise EvolveError('NEEDS_RECOVERY', 'Completed facts are saved but their receipt failed', exit_code=4, committed=True)
            with writer_lock(root):
                operation = store.one('SELECT * FROM operations WHERE id=?', (operation_id,))
                journal_path = inside(root, '.evolve-local/control/operations/' + operation_id + '.json')
                pending_files = journal_path.exists() and json.loads(journal_path.read_text()).get('state') != 'committed'
                pending_processes = pending_checks(store.connection, run_id)
                with store.transaction() as connection:
                    if pending_files:
                        connection.execute("UPDATE operations SET state='needs_recovery' WHERE id=?", (operation_id,))
                    elif not pending_processes:
                        connection.execute('DELETE FROM resource_claims WHERE operation_id=?', (operation_id,))
                        if operation and operation['state'] == 'prepared':
                            connection.execute("UPDATE operations SET state='failed' WHERE id=?", (operation_id,))
                    store.event(run_id, 'implementation_interrupted' if pending_files else 'implementation_blocked',
                                {'message': str(error), 'operation_id': operation_id, 'writer_stopped': True})
                if not pending_files and not pending_processes:
                    store.finish(run_id, {'committed': True, 'outcome': 'blocked', 'message': str(error)}, status='blocked')
                if isinstance(error, EvolveError):
                    error.committed = True
                    raise
                raise EvolveError('NEEDS_RECOVERY', 'Local write did not finish: ' + str(error), exit_code=4, committed=True)
        raise
    finally:
        if store is not None:
            store.close()
