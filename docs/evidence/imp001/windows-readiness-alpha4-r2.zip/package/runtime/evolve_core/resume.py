"""Pure project context restoration; no commands, indexing or writer takeover."""
import json
from pathlib import Path

from .continuation import sealed_result
from .errors import EvolveError
from .reading import current_state, history_snapshot
from .store import now
from .work import fingerprint



def restored_run(connection, row, change_id=None):
    body, result = json.loads(row['input_json'])['request'], None
    if row['status'] != 'started':
        _, body, result = sealed_result(connection, {'run_id': row['id'], 'result_digest': row['result_digest']})
    revoked = False
    for event in connection.execute("SELECT payload_json FROM events WHERE kind='authorization_revoked'"):
        value = json.loads(event[0])
        revoked |= value.get('request_id') == row['request_id'] or (change_id is not None and value.get('change_id') == change_id)
    from .learning import learning_status
    return {'learning': learning_status(connection, row['id']), 'run_id': row['id'], 'action': row['action'], 'status': row['status'],
            'result_digest': row['result_digest'], 'result': result,
            'authorization': body['authorization'], 'authorization_revoked': revoked,
            'input_scope': body['input'].get('scope'), 'ended_at': row['ended_at'],
            'evidence': [dict(e) for e in connection.execute(
                'SELECT id,subject_kind,observer,method,observed_at,limitations FROM evidence WHERE source_run_id=?', (row['id'],))]}


def resume_view(root, target=None):
    root = Path(root).resolve()
    navigation = current_state(root)
    candidates = [{'kind': 'change', 'id': c['id'], 'title': c['title'], 'state': c['state']}
                  for c in navigation['changes'] if c['state'] != 'archived']
    candidates += [{'kind': 'analysis', 'id': a['run_id'], 'title': a['question'], 'state': a['run_status']}
                   for a in navigation.get('analyses', []) if a['answer_status'] != 'answered' or a['current_head_status'] != 'completed']
    if target is None:
        if len(candidates) != 1:
            return {'selection': 'required' if candidates else 'none', 'candidates': candidates,
                    'project': navigation, 'suggested_action': 'choose_target' if candidates else 'inspect_or_propose',
                    'authorization_granted': False, 'observed_at': now()}
        target = candidates[0]['id']
    if navigation['state'] != 'connected':
        raise EvolveError('NOT_CONNECTED', 'No connected project contains this target')
    selected = current_state(root, target)
    if selected.get('checkpoint') != navigation.get('checkpoint'):
        raise EvolveError('PROJECT_CHANGED', 'History changed during target selection; read again', exit_code=3)
    if selected.get('analyses'):
        analysis = selected['analyses'][0]
        with history_snapshot(root) as (connection, meta):
            if meta.get('checkpoint') != selected.get('checkpoint'):
                raise EvolveError('PROJECT_CHANGED', 'History changed before analysis context read', exit_code=3)
            ids = dict.fromkeys((analysis['run_id'], analysis['current_head']))
            runs = [restored_run(connection, connection.execute('SELECT * FROM phase_runs WHERE id=?', (key,)).fetchone()) for key in ids]
        return {'selection': 'selected', 'target_kind': 'analysis', 'project': selected, 'runs': runs,
                'suggested_action': 'inspect_original_owner' if selected['pending_runs'] else 'analyze',
                'authorization_granted': False, 'observed_at': now()}
    change = selected['changes'][0]
    if len(change['tasks']) != 1:
        raise EvolveError('UNAVAILABLE', 'This package restores the simple single-task path; complex tasks are not selected implicitly')
    task = change['tasks'][0]
    runs = []
    with history_snapshot(root) as (connection, meta):
        if meta.get('checkpoint') != selected.get('checkpoint'):
            raise EvolveError('PROJECT_CHANGED', 'History changed before context read; read again', exit_code=3)
        for row in connection.execute("SELECT * FROM phase_runs WHERE action!='learn' ORDER BY started_at,id"):
            body = json.loads(row['input_json'])['request']
            if body['input'].get('change_id') != change['id'] and not (
                    row['action'] == 'propose' and row['result_json'] and json.loads(row['result_json']).get('change_id') == change['id']):
                continue
            runs.append(restored_run(connection, row, change['id']))
        saved = connection.execute('SELECT result_json FROM tasks WHERE id=?', (task['id'],)).fetchone()[0]
        task_result = json.loads(saved) if saved else None
        from .learning import work_learning
        learning_context = work_learning(connection, change['id'])
        basis = task_result['fingerprint'] if task_result else {'scope': task['definition']['baseline']}
        try:
            current = fingerprint(root, task['definition'])
            observation = {'status': 'observed', 'current': current,
                           'scope_changes': [{'path': path, 'previous_digest': old, 'current_digest': current['scope'][path],
                                              'source': 'external_or_unknown'} for path, old in basis['scope'].items()
                                             if current['scope'][path] != old],
                           'other_inputs_changed': bool(basis.get('files') is not None and basis['files'] != current['files']),
                           'external_data': 'not_observed'}
        except EvolveError as error:
            observation = {'status': 'unavailable', 'error': {'code': error.code, 'message': str(error)}, 'external_data': 'not_observed'}
    blocked_owner = selected['pending_runs'] or selected['initialization'] != 'committed'
    suggested = ('inspect_original_owner' if blocked_owner else 'inspect_archived' if change['state'] == 'archived'
                 else 'verify' if task['state'] == 'done' else 'apply')
    if not blocked_owner and (observation['status'] != 'observed' or observation.get('scope_changes')):
        suggested = 'inspect_workspace_change'
    return {'selection': 'selected', 'target_kind': 'change', 'project': selected,
            'task_result': task_result, 'runs': runs, 'workspace_observation': observation, 'learning_context': learning_context,
            'suggested_action': suggested, 'authorization_granted': False, 'observed_at': now(),
            'continuation_requires': 'Explicit continue intent, still-applicable original grant and fresh versions; saved context alone authorizes nothing'}
