---
name: evolve-maintain
description: 查询 Evolve 历史、诊断档案，或按请求导出、取消、备份及恢复时使用。
---

归属 history、maintain。默认 doctor 只读。恢复先保护现存内容并核对包／身份／版本，补确定性事实；保留包外用户文件和未知外部保护，不重放业务命令或自动合并分叉库。

完整备份、损坏／倒退恢复或 14→15 升级时，先读[完整档案维护](../../shared/recovery.md)。损坏库及旧协议不以 status 成功为前置；直接准备维护方案，呈现准确集合后按实际授权执行。先保存唯一完整请求，未知结果恢复原 journal.request，不新建 ID 或重绑新 epoch。

导出报告、有限血缘图或历史底稿时，先读[保存事实导出](../../shared/data-work.md#从保存事实导出)，从原回执绑定源分析；该分支直接 export，不先 status 或重新查询业务来源。

明确取消工作项时，先读[安全取消](../../shared/multiple-work.md#安全取消)，核对当前目标和安全结束状态；已发生效果和未知占用保持。

首次使用先读 [共享运行约定](../../shared/contract.md)，定位真实插件根和目标项目；已定位源分析的 export，以及上述损坏恢复／升级按各自分支直接调用，其余分支先执行只读 status。当前 alpha 的具体能力以 runtime 返回为准；未开放方法停止在明确限制处。调用运行时传 `--owner evolve-maintain`，动作必须属于本 Skill。用户不需要填写内部编号。

遇到真实数据 sender、外部取消或未决操作时读[数据操作](../../shared/external-work.md)；维护只保护／核对登记，不派发或补偿。
