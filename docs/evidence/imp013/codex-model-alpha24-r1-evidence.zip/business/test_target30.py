import sqlite3,unittest
class ActualTarget(unittest.TestCase):
    def test_original_literal(self):
        db=sqlite3.connect("file:business.db?mode=ro",uri=True)
        try:
            self.assertEqual(db.execute("SELECT id,value FROM ledger ORDER BY id").fetchall(),[(1,30)])
        finally:
            db.close()
