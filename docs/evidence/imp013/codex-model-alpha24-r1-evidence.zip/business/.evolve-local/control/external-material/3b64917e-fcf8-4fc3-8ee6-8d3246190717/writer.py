import json,sys
from helper import execute
print(json.dumps(execute(sys.argv[1], sys.argv[2])))
