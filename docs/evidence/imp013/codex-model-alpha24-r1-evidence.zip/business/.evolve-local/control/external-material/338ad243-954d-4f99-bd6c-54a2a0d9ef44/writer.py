import sys
from helper import execute
execute(sys.argv[1],sys.argv[2])
print("transport receipt deliberately lost after real commit")
