import json,sqlite3
from pathlib import Path

def execute(path, operation_id):
    alias=json.loads(Path('alias.json').read_text())
    sql=Path(alias['sql']).read_text()
    db=sqlite3.connect(path, isolation_level=None)
    try:
        db.execute('BEGIN IMMEDIATE')
        identity=db.execute('SELECT value FROM identity').fetchone()[0]
        if identity != alias['identity']: raise RuntimeError('wrong actual target')
        previous=db.execute('SELECT operation_id FROM operation_receipts WHERE operation_id=?',(operation_id,)).fetchone()
        if previous:
            db.rollback()
            return {'operation_id':operation_id,'target_identity':identity,'provider_operation_ref':operation_id}
        before=db.execute('SELECT value FROM ledger WHERE id=1').fetchone()[0]
        if before != alias['before']: raise RuntimeError('actual target precondition changed')
        db.execute(sql,(alias['after'],alias['before']))
        known={'ledger_id':1,'before':before,'after':alias['after'],'complete_scope':True}
        db.execute('INSERT INTO operation_receipts VALUES (?,?,?,1)',(operation_id,'succeeded',json.dumps(known)))
        db.commit()
        return {'operation_id':operation_id,'target_identity':identity,'provider_operation_ref':operation_id}
    finally:
        db.close()
