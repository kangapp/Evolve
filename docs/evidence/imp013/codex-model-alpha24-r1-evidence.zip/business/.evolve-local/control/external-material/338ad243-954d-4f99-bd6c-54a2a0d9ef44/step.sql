UPDATE ledger SET value=? WHERE id=1 AND value=?;
