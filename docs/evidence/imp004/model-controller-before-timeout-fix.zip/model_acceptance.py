#!/usr/bin/env python3
"""Prepare or run explicitly authorized, disposable host-model acceptance."""
import argparse
import ast
import json
import os
from pathlib import Path
import selectors
import shutil
import sqlite3
import subprocess
import sys
import time
import tomllib

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True

PROMPTS = {
    'inspect': '使用 Evolve 看一下总计为什么不对，说明相关代码、实际症状和修复建议，暂不改业务代码。',
    'repair': '使用 Evolve 接入此项目。检查入口为 python3 -B -m unittest discover -v。先呈现具体短方案，再在 arithmetic.py 与 test_arithmetic.py 范围内修复总计错误，保留现有独立断言，完成相关检查、规格与规范审查及封存。授权在该范围内修正验收发现；不批准正式项目知识。请忠实记录实际用户来源和本次授权，不预填审查结论。',
    'verify': '使用 Evolve 仅验收这个工作项的当前现场；不要修复或修改测试。说明历史结果和当前结论的区别，以及必要的后续方案。原工作项若已封存，不得越过终态修改历史或强行重开。',
}
LIMITS = ('本次插件验收的操作边界：只操作当前临时业务项目及其 Evolve 记录，读取本次安装缓存内插件资料。'
          '不操作本插件源码工程、其他业务项目、个人配置、凭证或外部应用，不启动嵌套代理，不提交、发布或部署。'
          '遇到真实权限、认证或能力阻碍如实报告；不绕过限制。实际修改走 Evolve 的授权和工具协议。')


def save(path, value):
    path.write_text(redact(json.dumps(value, ensure_ascii=False, indent=2)) + '\n')


def shell(argv, *, env, cwd, log):
    result = subprocess.run(argv, env=env, cwd=cwd, capture_output=True, text=True, timeout=60)
    save(log, {'argv': argv, 'cwd': str(cwd), 'exit_code': result.returncode,
               'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode:
        raise RuntimeError('Setup command failed; see ' + str(log))
    return json.loads(result.stdout) if '--json' in argv else result.stdout


class CodexSession:
    def __init__(self, project, evidence):
        self.project, self.evidence = project, evidence
        settings_path = Path.home() / '.codex/config.toml'
        settings = tomllib.loads(settings_path.read_text()) if settings_path.is_file() else {}
        overrides = []
        for key in ('mcp_servers', 'plugins'):
            value = '{' + ','.join(json.dumps(name) + '={enabled=false}' for name in settings.get(key, {})) + '}'
            overrides += ['-c', key + '=' + value]
        self.process = subprocess.Popen(['codex', 'app-server', '--stdio', *overrides,
            '-c', 'features.multi_agent=false', '-c', 'features.apps=false', '-c', 'features.memories=false'],
            cwd=project, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.process.stdout, selectors.EVENT_READ)
        self.buffer, self.messages, self.counter = b'', [], 0
        self.log = (evidence / 'model-events.jsonl').open('w')
        try:
            self.rpc('initialize', {'clientInfo': {'name': 'evolve-model-acceptance', 'version': '1'},
                                    'capabilities': {'experimentalApi': True}})
            self.send({'method': 'initialized'})
            models = self.rpc('model/list', {})['data']
            defaults = [m for m in models if m.get('isDefault') and not m.get('hidden')]
            if len(defaults) != 1:
                raise RuntimeError('Account did not identify one default model; do not guess a replacement')
            self.model = defaults[0]['model']
            save(evidence / 'account-default-model.json', {'configured_model': settings.get('model'),
                 'account_default_model': self.model, 'selection_basis': 'model/list isDefault, not an arbitrary model override',
                 'credential_copy': False, 'personal_configuration_changed': False})
        except BaseException:
            self.close()
            raise

    def send(self, value):
        self.process.stdin.write((json.dumps(value) + '\n').encode())
        self.process.stdin.flush()

    def wait(self, predicate):
        deadline = time.monotonic() + 600
        while time.monotonic() < deadline:
            for index, message in enumerate(self.messages):
                if predicate(message):
                    return self.messages.pop(index)
            if self.process.poll() is not None:
                raise RuntimeError('Codex app-server exited: ' + str(self.process.returncode))
            if not self.selector.select(1):
                continue
            self.buffer += os.read(self.process.stdout.fileno(), 65536)
            while b'\n' in self.buffer:
                line, self.buffer = self.buffer.split(b'\n', 1)
                message = json.loads(line)
                self.log.write(redact(json.dumps(message, ensure_ascii=False)) + '\n')
                self.log.flush()
                if 'id' in message and 'method' in message:
                    # Unexpected approval and user-input requests are not silently granted.
                    self.send({'id': message['id'], 'error': {'code': -32601, 'message': 'This acceptance runner cannot grant additional permissions'}})
                self.messages.append(message)
        raise TimeoutError('Codex observation deadline; inspect the existing process before any restart')

    def rpc(self, method, params):
        self.counter += 1
        identifier = self.counter
        self.send({'id': identifier, 'method': method, 'params': params})
        response = self.wait(lambda m: m.get('id') == identifier and 'method' not in m)
        if 'error' in response:
            raise RuntimeError('Codex RPC failed: ' + redact(json.dumps(response['error'])))
        return response['result']

    def run(self, prompt, cache):
        thread = self.rpc('thread/start', {'cwd': str(self.project), 'ephemeral': True,
                          'approvalPolicy': 'never', 'sandbox': 'workspace-write', 'model': self.model})
        thread_id = thread['thread']['id']
        result = self.rpc('turn/start', {'threadId': thread_id, 'input': [
            {'type': 'text', 'text': '$evolve-workflow\n本次宿主选择的 Skill 实际路径：' + str(cache / 'skills/evolve-workflow/SKILL.md') + '\n' + prompt + '\n' + LIMITS},
            {'type': 'skill', 'name': 'evolve-workflow', 'path': str(cache / 'skills/evolve-workflow/SKILL.md')}]})
        turn_id = result['turn']['id']
        completed = self.wait(lambda m: m.get('method') == 'turn/completed'
                              and m['params'].get('threadId') == thread_id and m['params']['turn']['id'] == turn_id)
        turn = completed['params']['turn']
        if turn['status'] != 'completed':
            raise RuntimeError('Codex turn did not complete: ' + redact(json.dumps(turn)))
        return {'thread_id': thread_id, 'turn_id': turn_id, 'status': turn['status'], 'model': thread.get('model'),
                'skill_loading': 'explicit documented skill input from the actual isolated installation cache'}

    def close(self):
        self.process.terminate()
        try:
            self.process.wait(5)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()
        self.selector.close()
        self.process.stdin.close()
        self.process.stdout.close()
        self.log.close()



def original_fixture():
    return {'arithmetic.py': 'def total(values):\n    return len(values)\n',
            'test_arithmetic.py': ('import unittest\nfrom arithmetic import total\nclass Arithmetic(unittest.TestCase):\n'
                '    def test_independent_examples(self):\n'
                '        self.assertEqual(total([8,3]),11)\n'
                '        self.assertEqual(total([]),0)\n'
                '        self.assertEqual(total([-4,3]),-1)\n')}


def main():
    global check_package, digest, redact, history_snapshot
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True, choices=('codex', 'claude'))
    parser.add_argument('--out', type=Path)
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--skip-inspect', action='store_true', help='Retest the affected repair and verification paths only')
    parser.add_argument('--verify-missing-tests', action='store_true', help='Controlled verification variant: remove test contents after closure; the model must only propose missing tests')
    parser.add_argument('--diagnostic', action='store_true', help='Retest the same controlled intent classes with alpha.3 investigation and original-criterion repair')
    parser.add_argument('--claude-model', help='Explicit human-selected Claude Code model for this controlled process only')
    parser.add_argument('--preflight-only', action='store_true', help='Validate the selected complete runtime without profile writes, installation or model requests')
    parser.add_argument('--prepare-only', action='store_true', help='Install and discover in isolated profiles, save prompts/scope, then stop before any model transport')
    parser.add_argument('--session-learning', action='store_true', help='Expanded IMP-004 normal-pause/fresh-session/second-task model cases')
    parser.add_argument('--authorization-text', help='Actual human authorization for the expanded scope; not needed for read-only preflight/preparation')
    parser.add_argument('--expected-scope-digest', help='Exact reviewed expanded scope digest from preflight/preparation')
    args = parser.parse_args()
    if args.prepare_only and args.preflight_only:
        parser.error('--prepare-only and --preflight-only are separate modes')
    if args.session_learning and args.skip_inspect:
        parser.error('Expanded fresh-session acceptance requires all five ordered cases')
    if args.claude_model and args.host != 'claude':
        parser.error('--claude-model applies only to the Claude host')
    supplied = args.package.resolve()
    # Controller helpers must match the actual pinned archive protocol, not this checkout.
    sys.path.insert(0, str(supplied / 'runtime'))
    from evolve_core.package import check_package, digest
    from evolve_core.privacy import redact
    from evolve_core.reading import history_snapshot
    manifest = check_package(supplied)
    scope = None
    if args.session_learning:
        from model_session_checks import scope_for
        try:
            scope = scope_for(manifest, args.host, args.claude_model, original_fixture(), Path(__file__),
                              missing_tests=args.verify_missing_tests)
        except ValueError as error:
            parser.error(str(error))
        if not args.preflight_only and not args.prepare_only:
            if not args.authorization_text or not args.authorization_text.strip():
                parser.error('Expanded IMP-004 model dispatch needs the actual human authorization for the reviewed new scope')
            if args.expected_scope_digest != scope['scope_digest']:
                parser.error('Expanded scope differs from the reviewed digest; prepare and review the actual scope first')
    if args.preflight_only:
        print(json.dumps({'package_version': manifest['package_version'], 'schema_version': manifest['schema_version'],
                          'protocol_version': manifest['protocol_version'], 'content_digest': manifest['content_digest'],
                          'controller_runtime': str(supplied / 'runtime'), 'model_requests_sent': False,
                          'host_profile_created': False, 'preflight_only': True, 'expanded_scope': scope}))
        return 0
    if args.out is None:
        parser.error('--out is required for an actual controlled host run')
    lab = args.out.resolve()
    lab.mkdir(mode=0o700, parents=True, exist_ok=False)
    project, evidence, profile = (lab / name for name in ('business', 'evidence', 'host-profile'))
    for path in (project, evidence, profile):
        path.mkdir()
    download = lab / 'download'
    shutil.copytree(supplied, download)
    package = profile / 'installed-source'
    shutil.copytree(download, package)
    shutil.rmtree(download)
    save(evidence / 'installation-layout.json', {'supplied_artifact': str(supplied), 'download_copy_removed': True,
         'persistent_local_marketplace_installation_root': str(package),
         'reason': 'Claude local-directory marketplaces load their relative-path plugin in place. The registered installation root must be retained, independently of the original download.',
         'content_digest': check_package(package)['content_digest']})
    source = project / 'arithmetic.py'
    tests = project / 'test_arithmetic.py'
    for name, content in original_fixture().items():
        (project / name).write_text(content)
    (evidence / 'empty-mcp.json').write_text('{"mcpServers":{}}')
    env = {**os.environ, ('CODEX_HOME' if args.host == 'codex' else 'CLAUDE_CONFIG_DIR'): str(profile)}
    if args.host == 'claude':
        env['CLAUDE_CODE_DISABLE_AUTO_MEMORY'] = '1'
    summary = {'host': args.host, 'content_digest': manifest['content_digest'], 'package_version': manifest['package_version'],
               'authorization': 'User explicitly authorized this controlled host-model acceptance in the current chat',
               'model_requests_sent': False, 'automated_checks_passed': False, 'review_status': 'pending', 'passed': False, 'cases': []}
    summary['diagnostic_variant'] = args.diagnostic
    summary['session_learning_variant'] = args.session_learning
    summary['prepare_only'] = args.prepare_only
    if scope:
        summary['expanded_scope_digest'] = scope['scope_digest']
        summary['authorization'] = ({'source': 'actual human authorization in this chat', 'text': args.authorization_text}
                                    if args.authorization_text else 'Expanded model dispatch not authorized by this preparation')
        save(evidence / 'expanded-scope.json', scope)
    summary['verify_missing_tests_variant'] = args.verify_missing_tests
    if args.claude_model:
        summary['explicit_user_model_choice'] = args.claude_model
    save(evidence / 'runner-version.json', {'script': 'scripts/model_acceptance.py',
         'sha256': digest(Path(__file__).read_bytes()), 'package_digest': manifest['content_digest']})
    client = None
    def ledger():
        with history_snapshot(project) as (connection, _):
            return {table: {row['id']: dict(row) for row in connection.execute('SELECT * FROM ' + table)}
                    for table in ('changes', 'tasks', 'verifications')}
    try:
        command = ['codex', 'plugin', 'marketplace', 'add', str(package), '--json'] if args.host == 'codex' else [
            'claude', 'plugin', 'marketplace', 'add', str(package), '--scope', 'project']
        shell(command, env=env, cwd=project, log=evidence / 'marketplace.json')
        installed = shell([args.host, 'plugin', 'add' if args.host == 'codex' else 'install', 'evolve@evolve-local',
                           *(('--json',) if args.host == 'codex' else ('--scope', 'project'))],
                          env=env, cwd=project, log=evidence / 'installation.json')
        if args.host == 'codex':
            cache = Path(installed['installedPath'])
            (project / '.codex').mkdir()
            (project / '.codex/config.toml').write_text('[plugins."evolve@evolve-local"]\nenabled=true\n')
            from verify_hosts import codex_skills
            other = lab / 'other-project'
            other.mkdir()
            config = profile / 'config.toml'
            config.write_text(config.read_text().replace('enabled = true', 'enabled = false') +
                              '\n[projects.' + json.dumps(str(project)) + ']\ntrust_level="trusted"\n')
            discovery = codex_skills(env, project, other)
            save(evidence / 'discovery.json', discovery)
            if len(discovery[0]['skills']) != 8 or discovery[1]['skills']:
                raise RuntimeError('Isolated Codex installation or project scope failed')
            if not args.prepare_only:
                client = CodexSession(project, evidence)
        else:
            installed = shell(['claude', 'plugin', 'list', '--json'], env=env, cwd=project, log=evidence / 'installed.json')
            cache = Path(next(p['installPath'] for p in installed if p['id'] == 'evolve@evolve-local'))
            if scope or args.prepare_only:
                from verify_hosts import claude_skills
                discovery = claude_skills(env, project)
                save(evidence / 'discovery.json', discovery)
                if not discovery['complete']:
                    raise RuntimeError('Isolated Claude Skill discovery failed')
        if check_package(cache)['content_digest'] != manifest['content_digest']:
            raise RuntimeError('Actual installation differs from the requested package')
        summary['registered_installation_root'] = str(package)
        summary['host_cache_root'] = str(cache)
        initial_lab_entries = {path.name for path in lab.iterdir()}
        if args.prepare_only:
            for case, prompt in (scope['cases'] if scope else PROMPTS).items():
                (evidence / (case + '-prompt.txt')).write_text(prompt + '\n' + LIMITS + '\n')
            summary['preparation_status'] = 'installed_and_discovered_no_model_dispatch'
            summary['scope_authorization_required'] = bool(scope)
            return 0
        checker = None
        if scope:
            from model_session_checks import SessionChecks
            checker = SessionChecks(project, scope, evidence)
        prompts = scope['cases'] if scope else PROMPTS
        for case, prompt in prompts.items():
            if not scope and args.diagnostic and case == 'inspect':
                prompt = '使用 Evolve 即时解释一下总计为什么不对，说明实际代码、症状和建议；暂不留档，不接入，不修改业务代码。'
            if not scope and args.diagnostic and case == 'repair':
                prompt = ('使用 Evolve 接入此项目，检查入口为 python3 -B -m unittest discover -v。先独立留档调查总计错误，'
                          '保存真实失败、独立预期、原症状判据、来源和限制，不为调查创建 Change。随后呈现具体短方案，'
                          '引用调查与原判据，在 arithmetic.py 与 test_arithmetic.py 范围内修复，保留原三条独立断言；'
                          '按原判据复验、完成真实检查和规格／规范审查后封存。授权在该范围内修正验收发现；'
                          '不批准正式项目知识。请忠实记录实际用户来源，不预填结论。')
            if case == 'inspect' and args.skip_inspect:
                continue
            if checker:
                checker.before(case, missing_tests=args.verify_missing_tests)
                if case == 'verify' and args.verify_missing_tests:
                    prompt += ' 如果缺少可用测试，仅提出补测方案，不要补写。'
            elif case == 'verify':
                before_ledger = ledger()
                source.write_text('def total(values):\n    return len(values)\n')
                if args.verify_missing_tests:
                    tests.write_text('')
                    prompt += ' 如果缺少可用测试，仅提出补测方案，不要补写。'
            before = {path.name: path.read_bytes() for path in (source, tests)}
            (evidence / (case + '-prompt.txt')).write_text(prompt + '\n' + LIMITS + '\n')
            print(json.dumps({'host': args.host, 'case': case, 'state': 'started'}), flush=True)
            summary['model_requests_sent'] = True
            save(evidence / 'summary.json', summary)
            if args.host == 'codex':
                result = client.run(prompt, cache)
            else:
                argv = ['claude', '--print', '--verbose', '--output-format', 'stream-json', '--no-session-persistence',
                        '--setting-sources', 'project', '--permission-mode', 'acceptEdits', '--strict-mcp-config',
                        '--mcp-config', str(evidence / 'empty-mcp.json'), '--disallowedTools', 'Agent,Task',
                        '--allowedTools', 'Read,Write,Edit,Glob,Grep,Skill,Bash(python3:*),Bash(ls:*),Bash(cat:*),Bash(rg:*)']
                if args.claude_model:
                    argv += ['--model', args.claude_model]
                process = subprocess.run(argv, input=prompt + '\n' + LIMITS, env=env, cwd=project,
                                         text=True, capture_output=True, timeout=600)
                save(evidence / (case + '-model.json'), {'argv': argv, 'exit_code': process.returncode,
                                                        'stdout': process.stdout, 'stderr': process.stderr})
                if process.returncode:
                    raise RuntimeError('Claude run failed; inspect its saved result')
                result = {'exit_code': process.returncode}
            unexpected = sorted(path.name for path in lab.iterdir()
                                if path.name not in initial_lab_entries)
            if unexpected:
                raise AssertionError('Host left request artifacts outside the business project: ' + ', '.join(unexpected))
            if checker:
                observation = checker.after(case)
                save(evidence / (case + '-parent-observation.json'), observation)
                summary['cases'].append({'case': case, 'model_result': result, 'parent_observation': observation})
                save(evidence / 'summary.json', summary)
                print(json.dumps({'host': args.host, 'case': case, 'state': 'observed'}), flush=True)
                continue
            if case != 'repair':
                if any(path.read_bytes() != before[path.name] for path in (source, tests)):
                    raise AssertionError('Read-only intent changed business or test bytes')
                if args.diagnostic and case == 'inspect' and ((project / 'evolve').exists() or (project / '.evolve-local').exists()):
                    raise AssertionError('Immediate answer created record facilities despite explicit no-record intent')
                if case == 'verify':
                    after = ledger()
                    if any(after[table] != before_ledger[table] for table in ('changes', 'tasks')):
                        raise AssertionError('Verification reopened or changed completed work')
                    if any(after['verifications'].get(key) != row for key, row in before_ledger['verifications'].items()):
                        raise AssertionError('Verification rewrote historical evidence')
                    fresh = [row for key, row in after['verifications'].items() if key not in before_ledger['verifications']]
                    if not fresh or not any(row['status'] in ('failed', 'blocked') for row in fresh):
                        raise AssertionError('Current failed scope was not recorded by the supported archived verification path')
            else:
                original_assertions = [ast.dump(node) for node in ast.walk(ast.parse(before[tests.name]))
                                       if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'assertEqual']
                current_assertions = [ast.dump(node) for node in ast.walk(ast.parse(tests.read_bytes()))
                                      if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'assertEqual']
                if any(item not in current_assertions for item in original_assertions):
                    raise AssertionError('Existing independent test assertions changed or were removed')
                # Execute the original literal assertions independently of any
                # test additions or formatting the model may have introduced.
                check = subprocess.run([sys.executable, '-B', '-c', before[tests.name].decode() + '\nunittest.main()\n'],
                                       cwd=project, capture_output=True, text=True, timeout=30)
                save(evidence / 'independent-check.json', {'exit_code': check.returncode, 'stdout': check.stdout, 'stderr': check.stderr})
                db = sqlite3.connect(project / 'evolve/history.db')
                try:
                    changes = db.execute('SELECT state FROM changes').fetchall()
                    verifications = db.execute('SELECT status FROM verifications').fetchall()
                    if check.returncode or not changes or any(r[0] != 'archived' for r in changes) or not verifications or verifications[-1][0] != 'passed':
                        raise AssertionError('Actual checks, Evolve verification and closure did not all pass')
                    if args.diagnostic:
                        analyses = db.execute("SELECT id,result_json,result_digest FROM phase_runs WHERE action='analyze' AND status='completed'").fetchall()
                        if not analyses or not any(json.loads(row[1]).get('analysis', {}).get('symptom', {}).get('status') == 'reproduced' for row in analyses):
                            raise AssertionError('Repair did not preserve an independent investigation with actual red evidence')
                        definitions = [json.loads(row[0]) for row in db.execute('SELECT definition_json FROM tasks')]
                        if any(not definition.get('analysis_basis') or not definition.get('symptom_before') for definition in definitions):
                            raise AssertionError('Diagnostic repair bypassed the original investigation/criterion binding')
                        latest = json.loads(db.execute('SELECT items_json FROM verifications ORDER BY observed_at DESC LIMIT 1').fetchone()[0])
                        if not latest.get('symptom_result'):
                            raise AssertionError('No original-criterion post-repair observation was saved')
                finally:
                    db.close()
                if (project / 'evolve/project.md').exists():
                    raise AssertionError('Formal knowledge was applied without specific approval')
            summary['cases'].append({'case': case, 'model_result': result, 'business_digest': digest(source.read_bytes())})
            save(evidence / 'summary.json', summary)
            print(json.dumps({'host': args.host, 'case': case, 'state': 'observed'}), flush=True)
        summary['automated_checks_passed'] = True
    except Exception as error:
        summary['error'] = redact(str(error))
    finally:
        if client:
            client.close()
        save(evidence / 'summary.json', summary)
        print(json.dumps(summary, ensure_ascii=False), flush=True)
    return 0 if summary['automated_checks_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
