WITH latest AS (
 SELECT amount, ROW_NUMBER() OVER (
  PARTITION BY business_date, order_id ORDER BY revision DESC
 ) AS n
 FROM orders WHERE business_date = :business_date
)
SELECT COALESCE(SUM(amount),0), COUNT(*) FROM latest
WHERE n = 1 AND amount IS NOT NULL;
