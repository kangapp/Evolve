from total import total
def render_total(values):
    return "external:" + str(total(values))
