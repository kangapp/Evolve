# 术语

总额：数值之和。

核对整数求和时使用独立字面量样例，注明观察范围。

Foreign unapproved content.
