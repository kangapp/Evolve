import unittest
from total import total
class Totals(unittest.TestCase):
    def test_values(self):
        self.assertEqual(total([2,3]),5)
        self.assertEqual(total([]),0)
        self.assertEqual(total([-2,3]),1)
