"""Shared, host-independent Evolve runtime."""
VERSION = "0.1.0-alpha.20"
PROTOCOL_VERSION = 14
SCHEMA_VERSION = 4
DESIGN_BASELINE = "0.6.2"
