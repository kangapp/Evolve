"""Consistent local protection before the first managed write of a UTC day."""
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile

from .errors import EvolveError
from .package import canonical, digest
from .store import now
from .workspace import current_digest, durable_write, inside


def protect_before_write(store, request_id):
    root = store.root
    folder = inside(root, '.evolve-local/backups/' + now()[:10])
    manifest_path = folder / 'manifest.json'
    init_journal = inside(root, '.evolve-local/control/init.json')
    if init_journal.exists() and json.loads(init_journal.read_text()).get('state') != 'committed':
        raise EvolveError('NEEDS_RECOVERY', 'Project initialization has not been finalized', exit_code=4)
    pending = store.one("SELECT id FROM operations WHERE state IN ('prepared','needs_recovery') LIMIT 1")
    if pending:
        raise EvolveError('NEEDS_RECOVERY', 'Unresolved file operation prevents a consistent protection backup', exit_code=4)
    operations = inside(root, '.evolve-local/control/operations')
    if operations.exists():
        for path in operations.glob('*.json'):
            if json.loads(path.read_text()).get('state') != 'committed':
                raise EvolveError('NEEDS_RECOVERY', 'Pending file journal prevents a consistent backup', exit_code=4)
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        if manifest['project_id'] != store.meta['project_id'] or manifest['workspace_epoch'] != store.meta['workspace_epoch']:
            raise EvolveError('BACKUP_CONFLICT', 'Existing daily backup belongs to another project or epoch', exit_code=4)
        for item in manifest['files']:
            path = inside(folder, item['path'])
            if current_digest(path) != item['digest']:
                raise EvolveError('BACKUP_INVALID', 'Existing protection backup is incomplete', exit_code=4)
        return manifest_path.relative_to(root).as_posix()
    if folder.exists():
        raise EvolveError('BACKUP_INVALID', 'Incomplete protection backup must be inspected before new writes', exit_code=4)
    config = inside(root, 'evolve/config.toml')
    if not config.is_file():
        raise EvolveError('PROJECT_INCOMPLETE', 'Cannot protect history without its configuration')
    parent = folder.parent
    parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.backup-', dir=parent))
    try:
        target_db = staging / 'evolve/history.db'
        target_db.parent.mkdir(parents=True)
        destination = sqlite3.connect(target_db)
        try:
            store.connection.backup(destination)
            checkpoint = destination.execute("SELECT value FROM project_meta WHERE key='checkpoint'").fetchone()[0]
            if checkpoint != store.meta['checkpoint']:
                raise EvolveError('PROJECT_CHANGED', 'Backup checkpoint changed during collection', exit_code=3)
        finally:
            destination.close()
        config_bytes = config.read_bytes()
        durable_write(staging / 'evolve/config.toml', config_bytes, new=True)
        registered = store.connection.execute(
            "SELECT a.path, b.content, b.digest FROM artifacts a "
            "JOIN artifact_versions v ON v.id=a.current_version JOIN blobs b ON b.digest=v.blob_digest "
            "WHERE a.kind IN ('config','knowledge','evidence','plan') AND a.path IS NOT NULL").fetchall()
        observations = []
        for artifact in registered:
            path = inside(root, artifact['path'])
            durable_write(inside(staging, artifact['path']), artifact['content'])
            actual = path.read_bytes() if path.is_file() else None
            if actual is None or digest(actual) != artifact['digest']:
                observation = {'path': artifact['path'], 'registered_digest': artifact['digest'],
                               'actual_digest': digest(actual) if actual is not None else None,
                               'source': 'external_or_unknown'}
                if actual is not None:
                    appendix = 'observed/' + digest(actual)
                    durable_write(staging / appendix, actual)
                    observation['protected_copy'] = appendix
                observations.append(observation)
        if config.read_bytes() != config_bytes:
            raise EvolveError('PROJECT_CHANGED', 'Configuration changed while collecting protection backup', exit_code=3)
        checkpoint = store.one("SELECT value FROM project_meta WHERE key='checkpoint'")[0]
        if checkpoint != store.meta['checkpoint']:
            raise EvolveError('PROJECT_CHANGED', 'History changed while collecting protection backup', exit_code=3)
        files = [{'path': p.relative_to(staging).as_posix(), 'digest': digest(p.read_bytes())}
                 for p in sorted(staging.rglob('*')) if p.is_file()]
        manifest = {'project_id': store.meta['project_id'], 'workspace_epoch': store.meta['workspace_epoch'],
                    'checkpoint': store.meta['checkpoint'], 'requested_by': request_id,
                    'observed_at': now(), 'day_basis': 'UTC', 'files': files,
                    'external_observations': observations, 'business_data_included': False}
        durable_write(staging / 'manifest.json', canonical(manifest), new=True)
        staging.rename(folder)
    except EvolveError:
        raise
    except OSError as error:
        raise EvolveError('BACKUP_FAILED', 'Protection failed before managed write: ' + str(error), exit_code=4)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return manifest_path.relative_to(root).as_posix()
