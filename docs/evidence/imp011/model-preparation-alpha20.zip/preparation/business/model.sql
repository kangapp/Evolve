SELECT COALESCE(SUM(amount),0), COUNT(*) FROM orders;
