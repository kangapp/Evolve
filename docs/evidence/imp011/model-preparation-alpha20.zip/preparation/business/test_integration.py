import unittest
from report import render_total
class TestIntegration(unittest.TestCase):
    def test_negative_report(self): self.assertEqual(render_total([-2,3]),"1")
