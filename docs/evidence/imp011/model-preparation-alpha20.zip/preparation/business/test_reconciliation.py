import json,sqlite3,unittest
from pathlib import Path
class Reconciliation(unittest.TestCase):
    def actual(self,day):
        with sqlite3.connect(':memory:') as con:
            con.execute('CREATE TABLE orders(order_id TEXT,business_date TEXT,revision INTEGER,amount INTEGER)')
            con.executemany('INSERT INTO orders VALUES (?,?,?,?)',json.loads(Path('orders.json').read_text()))
            rows=con.execute(Path('model.sql').read_text(),{'business_date':day}).fetchall()
            self.assertEqual(len(rows),1)
            return rows[0]
    def test_first_date_latest_duplicate_refund_and_null(self):
        self.assertEqual(self.actual('2026-10-30'),(10,2))
    def test_second_date_is_a_separate_grain(self):
        self.assertEqual(self.actual('2026-10-31'),(8,2))
    def test_empty_date_does_not_include_other_dates(self):
        self.assertEqual(self.actual('2026-11-01'),(0,0))
