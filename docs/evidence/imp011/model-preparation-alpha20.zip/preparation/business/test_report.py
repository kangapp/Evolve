import unittest
from report import render_total
class TestReport(unittest.TestCase):
    def test_literal(self): self.assertEqual(render_total([2,3]),"5")
