# Evolve analysis report

Source: 6e1cf456-5dd2-49b5-aaa9-289d76480f15
Result digest: bbd6e37958ba4a52225ad1f94f137c0b8b02b7f3971d074417a7a28f27ca23f6
Generated: 2026-11-01T01:42:56.885165+00:00
Business sources were not reobserved during export.

Answer status: partial

在三个业务日期的本地固定输入与当前 SQL 范围内，观察到 orders→daily_totals：按日期筛选，每日期每订单取最新 revision 一条，再排除空金额，汇总金额与有效订单数，负数退款计入，空日期输出(0,0)。生产上游与时效未调查。

## Data context

```json
{
  "business_dates": [
    "2026-10-30",
    "2026-10-31",
    "2026-11-01"
  ],
  "definitions": [
    "先取最新版本再排空金额；空最新版本不能回退历史值。",
    "重复最新版本只计一次，固定输入并列金额相同。",
    "负数退款参与求和和订单数；空日期返回(0,0)。",
    "daily_totals 指 SQL 返回的金额合计与有效订单数，不是已观察的生产物化表。"
  ],
  "grain": "每业务日期每订单取最新版本后，每日期输出金额合计与有效订单数",
  "limitations": [
    "仅只读当前 model.sql、orders.json 和原独立检查 test_reconciliation.py，未在本轮执行检查或 SQL。",
    "生产上游、生产执行、数据完整性及数据时效均未调查；本地文件观察时间不代表生产数据新鲜度。",
    "固定输入的并列最新 revision 金额相同；SQL 未定义并列版本的额外排序，金额冲突时选取规则未验证。",
    "daily_totals 是当前 SQL 汇总输出的分析名称，不表示已发现或物化生产同名表；本关系不是完整生产血缘。"
  ],
  "objects": [
    "orders",
    "daily_totals"
  ],
  "source_ids": [
    "S1",
    "S2",
    "S3"
  ]
}
```

## Coverage

- 仅 model.sql、orders.json、test_reconciliation.py。
- 业务日期为 2026-10-30、2026-10-31、2026-11-01；来源 observed_at 为本轮真实读取时点，区别于业务日期。

## Limitations

- 仅只读当前 model.sql、orders.json 和原独立检查 test_reconciliation.py，未在本轮执行检查或 SQL。
- 生产上游、生产执行、数据完整性及数据时效均未调查；本地文件观察时间不代表生产数据新鲜度。
- 固定输入的并列最新 revision 金额相同；SQL 未定义并列版本的额外排序，金额冲突时选取规则未验证。
- daily_totals 是当前 SQL 汇总输出的分析名称，不表示已发现或物化生产同名表；本关系不是完整生产血缘。

## Remaining questions

- 生产 orders 的上游来源与更新链路未知。
- 生产数据时效与完整性未知。
- 并列最新版本金额冲突时的业务选择规则未知。

## Next steps

- 本轮仅从已保存底稿导出 Markdown 和 JSON；进一步生产调查需另行明确范围。

## Observations

- F1: 当前 model.sql 使用 business_date = :business_date 筛选；ROW_NUMBER 按 business_date、order_id 分区，revision DESC 排序；取 version_rank=1 后才排除空 amount，再 COALESCE(SUM(amount),0)、COUNT(*) 汇总。 [S1]
- F2: 固定订单：10-30 A 最新两行均为12只取一条，B=-2参与金额与数量，C最新为空不回退历史9；10-31 A=5、D=3；11-01无记录；10-29 Z=100在目标日期外。 [S2]
- F3: 原独立检查以 SQLite :memory: 加载固定订单执行 model.sql，要求每日期一行，字面量预期分别为 2026-10-30 (10,2)、2026-10-31 (8,2)、2026-11-01 (0,0)。此处为读取检查定义，非本轮执行结果。 [S3]

## Hypotheses


## Observed relationship scope

```mermaid
flowchart LR
  N0["orders"]
  N1["daily_totals"]
  N0 --> N1
```

- R1 (observed): orders -> daily_totals; WHERE business_date = :business_date；ROW_NUMBER() OVER (PARTITION BY business_date, order_id ORDER BY revision DESC)；取 version_rank = 1 后排除 amount IS NULL；COALESCE(SUM(amount),0) 汇总金额、COUNT(*) 汇总有效订单数量。; sources: S1, S2, S3
  - 仅只读当前 model.sql、orders.json 和原独立检查 test_reconciliation.py，未在本轮执行检查或 SQL。
  - 生产上游、生产执行、数据完整性及数据时效均未调查；本地文件观察时间不代表生产数据新鲜度。
  - 固定输入的并列最新 revision 金额相同；SQL 未定义并列版本的额外排序，金额冲突时选取规则未验证。
  - daily_totals 是当前 SQL 汇总输出的分析名称，不表示已发现或物化生产同名表；本关系不是完整生产血缘。

## Source observations

- S1: model.sql; observer: Codex 本轮只读文件观察; observed: 2026-11-01T01:42:22.902768+00:00; version: dd0006a731e1a30112d00924d70ad701b8982052e20f5034ee9ab2f66bce0114
  - 仅只读当前 model.sql、orders.json 和原独立检查 test_reconciliation.py，未在本轮执行检查或 SQL。
  - 生产上游、生产执行、数据完整性及数据时效均未调查；本地文件观察时间不代表生产数据新鲜度。
  - 固定输入的并列最新 revision 金额相同；SQL 未定义并列版本的额外排序，金额冲突时选取规则未验证。
  - daily_totals 是当前 SQL 汇总输出的分析名称，不表示已发现或物化生产同名表；本关系不是完整生产血缘。
- S2: orders.json; observer: Codex 本轮只读文件观察; observed: 2026-11-01T01:42:22.902858+00:00; version: b3a5b3e958fa4ccdd4cb210cdf81680223504560b5110d26d10a730783a48dd5
  - 仅只读当前 model.sql、orders.json 和原独立检查 test_reconciliation.py，未在本轮执行检查或 SQL。
  - 生产上游、生产执行、数据完整性及数据时效均未调查；本地文件观察时间不代表生产数据新鲜度。
  - 固定输入的并列最新 revision 金额相同；SQL 未定义并列版本的额外排序，金额冲突时选取规则未验证。
  - daily_totals 是当前 SQL 汇总输出的分析名称，不表示已发现或物化生产同名表；本关系不是完整生产血缘。
- S3: test_reconciliation.py; observer: Codex 本轮只读文件观察; observed: 2026-11-01T01:42:22.902889+00:00; version: 94214150c83f55cbeffc14170dbea4fb4ea6d2e32286ecff38d3d9bd44c89c5e
  - 仅只读当前 model.sql、orders.json 和原独立检查 test_reconciliation.py，未在本轮执行检查或 SQL。
  - 生产上游、生产执行、数据完整性及数据时效均未调查；本地文件观察时间不代表生产数据新鲜度。
  - 固定输入的并列最新 revision 金额相同；SQL 未定义并列版本的额外排序，金额冲突时选取规则未验证。
  - daily_totals 是当前 SQL 汇总输出的分析名称，不表示已发现或物化生产同名表；本关系不是完整生产血缘。

## Recorded successor and corrections

Current recorded head: 6e1cf456-5dd2-49b5-aaa9-289d76480f15
[]
