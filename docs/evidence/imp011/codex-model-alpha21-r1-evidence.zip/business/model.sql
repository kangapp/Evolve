WITH ranked_orders AS (
    SELECT amount,
           ROW_NUMBER() OVER (
               PARTITION BY business_date, order_id
               ORDER BY revision DESC
           ) AS version_rank
    FROM orders
    WHERE business_date = :business_date
)
SELECT COALESCE(SUM(amount),0), COUNT(*)
FROM ranked_orders
WHERE version_rank = 1 AND amount IS NOT NULL;
